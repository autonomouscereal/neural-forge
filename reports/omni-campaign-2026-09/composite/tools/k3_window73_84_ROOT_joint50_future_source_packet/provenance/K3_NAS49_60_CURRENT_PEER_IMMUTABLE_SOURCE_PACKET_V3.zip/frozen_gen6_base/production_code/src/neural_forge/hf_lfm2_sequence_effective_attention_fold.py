"""Fit-only fixed-Q/K sequence-effective V/O folding for LFM2 attention.

The production CPCF attention compiler already derives one authenticated,
target-native Q/K/V producer from complete causal fit trajectories.  This
module keeps its exact Q/K state and folds the remaining value/output path by
the sequence function it implements:

``z_h = softmax(Q_h K_h^T) X_K`` and ``delta = sum_h z_h V_g O_h``.

For one fixed production policy, the compiler:

* ridge-fits the complete causal attended-input operator to the parent
  residual write;
* extracts one shared value subspace per target KV group by SVD;
* performs a bounded, monotone sequence of closed-form block V/O solves; and
* applies a fixed producer-value subspace anchor before materializing ordinary
  dense target V/O tensors.

An opt-in residual V/O seam instead starts at an authenticated dense V0/O0
split, solves at most two zero-centered delta sweeps, and deterministically
materializes the best finite target-dtype fit proposal.  The default path and
its v2 artifact remain byte-compatible.

Only ``fit_cases`` are accepted.  Selection and validation have no interface
to this primitive.  It performs no model forward, backward, optimizer,
training, pruning, or quantization operation.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Callable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from neural_forge import hf_lfm2_structural_residual_attention_fold as structural
from neural_forge.hf_lfm2_structural_residual_attention_fold import (
    Lfm2CachedAttentionFoldCase,
    Lfm2CompiledStructuralAttentionProducerFold,
)


LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_SCHEMA = (
    "neural-forge-lfm2-fixed-qk-sequence-effective-attention-fold-v2"
)
LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEEDED_SCHEMA = (
    "neural-forge-lfm2-fixed-qk-sequence-effective-residual-vo-seeded-fold-v1"
)
LFM2_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEED_SCHEMA = (
    "neural-forge-lfm2-sequence-effective-residual-vo-seed-v1"
)
LFM2_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEED_PROVENANCE_SCHEMA = (
    "neural-forge-lfm2-sequence-effective-residual-vo-seed-provenance-v1"
)
LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_INSTALL_SCHEMA = (
    "neural-forge-lfm2-fixed-qk-sequence-effective-attention-install-v1"
)
LFM2_SEQUENCE_EFFECTIVE_PCG_OBSERVATION_SCHEMA = (
    "neural-forge-lfm2-sequence-effective-pcg-observation-v1"
)
LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_CHOLESKY_SCHEMA = (
    "neural-forge-lfm2-sequence-effective-hidden-partial-trace-cholesky-v1"
)
LFM2_SEQUENCE_EFFECTIVE_ROW_BLOCK_JACOBI_SCHEMA = (
    "neural-forge-lfm2-sequence-effective-row-block-jacobi-v1"
)
LFM2_SEQUENCE_EFFECTIVE_VO_SEED_BANK_SCHEMA = (
    "neural-forge-lfm2-sequence-effective-vo-seed-bank-v1"
)
FIXED_QK_SEQUENCE_EFFECTIVE_VO_ALS_CANDIDATE_ID = (
    "fixed_qk_sequence_effective_vo_als"
)
_IMPLEMENTATION = "neural_forge.hf_lfm2_sequence_effective_attention_fold"
_MAXIMUM_DENSE_RIDGE_SYSTEM_ELEMENTS = 8_000_000
_MAXIMUM_EXPLICIT_COEFFICIENT_ELEMENTS = 16_000_000
_MAXIMUM_STREAMED_ALS_ITERATIONS = 2
_MAXIMUM_STREAMED_VO_SEED_CANDIDATES = 4
_STATISTICS_ROW_CHUNK_SIZE = 2048
_PCG_MAXIMUM_ITERATIONS = 64
_PCG_RESTART_BLOCK_ITERATIONS = 64
_PCG_HARD_MAXIMUM_ITERATIONS = 512
_PCG_HIDDEN_PARTIAL_TRACE_HARD_MAXIMUM_ITERATIONS = 4096
_PCG_ROW_BLOCK_HARD_MAXIMUM_ITERATIONS = 4096
_PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE = 1e-8
_ZERO_EXECUTION = {
    "parent_model_forward_calls": 0,
    "target_model_forward_calls": 0,
    "target_layer_forward_calls": 0,
    "generation_calls": 0,
    "training_steps": 0,
    "backward_calls": 0,
    "optimizer_steps": 0,
    "parameters_pruned": 0,
    "parameters_quantized": 0,
    "autograd_graphs": 0,
}


class Lfm2SequenceEffectiveAttentionFoldError(ValueError):
    """Sequence-effective attention input, topology, or authentication error."""

    def __init__(
        self,
        message: str,
        *,
        failure_report: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.failure_report = (
            None
            if failure_report is None
            else MappingProxyType(dict(failure_report))
        )


class Lfm2SequenceEffectiveAttentionInstallError(RuntimeError):
    """Exact dense installation or rollback failure."""


_PCG_OBSERVER: ContextVar[Callable[[Mapping[str, Any]], None] | None] = ContextVar(
    "lfm2_sequence_effective_pcg_observer",
    default=None,
)


@contextmanager
def observe_lfm2_sequence_effective_pcg(
    observer: Callable[[Mapping[str, Any]], None],
) -> Iterator[None]:
    """Observe sealed PCG reports without replacing or wrapping solver calls.

    The observer is scoped to the current context, receives a detached
    canonical copy only after a solve has produced its authenticated report,
    and cannot mutate the report returned by the solver.  Nested observers are
    rejected so a probe has one unambiguous telemetry owner.
    """

    if not callable(observer):
        raise TypeError("observer must be callable.")
    if _PCG_OBSERVER.get() is not None:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "A sequence-effective PCG observer is already active."
        )
    token = _PCG_OBSERVER.set(observer)
    try:
        yield
    finally:
        _PCG_OBSERVER.reset(token)


def _observe_pcg_report(
    solver_kind: str,
    report: Mapping[str, Any],
) -> None:
    observer = _PCG_OBSERVER.get()
    if observer is None:
        return
    detached_report = json.loads(_canonical_json(dict(report)).decode("ascii"))
    body = {
        "schema": LFM2_SEQUENCE_EFFECTIVE_PCG_OBSERVATION_SCHEMA,
        "solver_kind": solver_kind,
        "report": detached_report,
        "report_sha256": detached_report["report_sha256"],
        "solver_result_or_arguments_modified": False,
    }
    event = MappingProxyType(
        {**body, "observation_sha256": _sha256(body)}
    )
    try:
        observer(event)
    except BaseException as exc:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Sequence-effective PCG observation failed closed."
        ) from exc


def _seal_observe_pcg_report(
    solver_kind: str,
    body: Mapping[str, Any],
) -> dict[str, Any]:
    report = _seal(body)
    _observe_pcg_report(solver_kind, report)
    return report


def _torch() -> Any:
    return structural._torch()


def _canonical_json(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("ascii")
    except (TypeError, ValueError) as exc:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Sequence-effective metadata must be finite canonical JSON."
        ) from exc


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value)).hexdigest()


def _seal(body: Mapping[str, Any]) -> dict[str, Any]:
    value = dict(body)
    value["report_sha256"] = _sha256(value)
    return value


def _hidden_partial_trace_pcg_execution_profile() -> dict[str, Any]:
    """Seal continuation semantics without changing the v2 solver-plan pin.

    The existing solver plan authenticates the streamed statistics topology
    and remains byte-compatible with the immutable H776 checkpoint.  This
    separate profile binds the production PCG continuation selected after an
    unchanged scalar lane misses its exact residual gate.
    """

    return _seal(
        {
            "schema": (
                "neural-forge-lfm2-sequence-effective-hidden-partial-trace-"
                "pcg-execution-profile-v1"
            ),
            "original_lane_solver": "deterministic_jacobi_pcg_single_tensor",
            "original_lane_maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
            "continuation_lane_solver": (
                "deterministic_continuous_hidden_partial_trace_"
                "cholesky_pcg_single_tensor"
            ),
            "continuation_preconditioner_schema": (
                LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_CHOLESKY_SCHEMA
            ),
            "continuation_preconditioner_formula": (
                "P_H=ridge*I_H+sum_(h,o)(trace(C_o,h)/head_dim)*A_h,o"
            ),
            "single_restart_after_original_lane_exact_authentication_miss": (
                True
            ),
            "periodic_restart_count": 0,
            "hard_maximum_iterations": (
                _PCG_HIDDEN_PARTIAL_TRACE_HARD_MAXIMUM_ITERATIONS
            ),
            "required_relative_normal_residual": (
                _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
            ),
            "exact_residual_used_to_initialize_continuous_lane_once": True,
            "exact_diagnostic_matvecs_modify_recurrence_state_or_direction": (
                False
            ),
            "factorization_materialized_only_after_original_lane_exact_miss": (
                True
            ),
            "production_row_block_preconditioner_selected": False,
            "full_operator_materialized": False,
        }
    )


LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE = (
    MappingProxyType(_hidden_partial_trace_pcg_execution_profile())
)
LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE_SHA256 = (
    LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE[
        "report_sha256"
    ]
)


def _digest(value: Any, name: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{name} must be a lowercase SHA-256 digest."
        )
    return value


def _finite_float(
    value: Any,
    name: str,
    *,
    minimum: float | None = None,
    maximum: float | None = None,
) -> float:
    if isinstance(value, bool):
        raise Lfm2SequenceEffectiveAttentionFoldError(f"{name} must be finite.")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{name} must be finite."
        ) from exc
    if (
        not math.isfinite(result)
        or (minimum is not None and result < minimum)
        or (maximum is not None and result > maximum)
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{name} is outside its supported range."
        )
    return result


def _positive_int(value: Any, name: str, *, maximum: int) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or value <= 0
        or value > maximum
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{name} must be a supported positive integer."
        )
    return value


def _tensor(
    value: Any,
    name: str,
    *,
    dimensions: int,
) -> Any:
    torch = _torch()
    if (
        not isinstance(value, torch.Tensor)
        or value.layout != torch.strided
        or value.device.type == "meta"
        or value.ndim != dimensions
        or any(int(size) <= 0 for size in value.shape)
        or value.dtype
        not in {
            torch.float16,
            torch.bfloat16,
            torch.float32,
            torch.float64,
        }
        or not bool(torch.isfinite(value).all().item())
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{name} must be one finite dense floating rank-{dimensions} tensor."
        )
    return value.detach().to(device="cpu").contiguous()


def _tensor_sha256(value: Any) -> str:
    return structural._tensor_sha256(value)


def _state_sha256(values: Mapping[str, Any]) -> str:
    return structural._state_sha256(values)


@dataclass(frozen=True, slots=True)
class _PcgRestartRowBlockPreconditioner:
    """Caller-built exact operator row blocks, authenticated only on use."""

    row_blocks: Any
    construction_report: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class _PcgRestartHiddenPartialTracePreconditioner:
    """Caller-built hidden partial trace, authenticated/factored only on use."""

    partial_trace: Any
    construction_report: Mapping[str, Any]


def _copy_parameter(target: Any, source: Any) -> None:
    target.copy_(source)


def _relative_rmse(prediction: Any, target: Any) -> float:
    return structural._relative_rmse(prediction, target)


def _case_bundle_sha256(
    cases: Sequence[Lfm2CachedAttentionFoldCase],
) -> str:
    tensor_fields = (
        "target_query_input",
        "target_key_value_input",
        "parent_query_linear",
        "parent_key_linear",
        "parent_value",
        "parent_query",
        "parent_key",
        "parent_context",
        "parent_post_attention_residual_target_space",
        "target_pre_attention_residual",
        "query_cosine",
        "query_sine",
        "key_cosine",
        "key_sine",
        "key_mask",
        "parent_contribution",
        "query_row_sqrt_weights",
        "key_value_row_sqrt_weights",
    )
    body = []
    for case_index, case in enumerate(cases):
        values = {}
        for field in tensor_fields:
            value = getattr(case, field)
            values[field] = None if value is None else _tensor_sha256(value)
        body.append(
            {
                "case_index": case_index,
                "tensor_sha256": values,
            }
        )
    return _sha256(body)


@dataclass(frozen=True, slots=True)
class Lfm2FixedQkSequenceEffectiveVoAlsPolicy:
    """Authenticated singular production policy proven before integration."""

    ridge_scale: float = 1e-4
    absolute_ridge_floor: float = 1e-12
    value_anchor_fraction: float = 0.25
    maximum_als_iterations: int = 12
    fit_tolerance: float = 1e-12
    horizon_power: float = 0.0
    authentication_sha256: str = ""

    def __post_init__(self) -> None:
        ridge = _finite_float(
            self.ridge_scale,
            "ridge_scale",
            minimum=1e-12,
            maximum=1.0,
        )
        floor = _finite_float(
            self.absolute_ridge_floor,
            "absolute_ridge_floor",
            minimum=1e-16,
            maximum=1e-2,
        )
        anchor = _finite_float(
            self.value_anchor_fraction,
            "value_anchor_fraction",
            minimum=0.0,
            maximum=1.0,
        )
        tolerance = _finite_float(
            self.fit_tolerance,
            "fit_tolerance",
            minimum=0.0,
            maximum=1e-4,
        )
        horizon = _finite_float(
            self.horizon_power,
            "horizon_power",
            minimum=0.0,
            maximum=0.0,
        )
        iterations = _positive_int(
            self.maximum_als_iterations,
            "maximum_als_iterations",
            maximum=64,
        )
        object.__setattr__(self, "ridge_scale", ridge)
        object.__setattr__(self, "absolute_ridge_floor", floor)
        object.__setattr__(self, "value_anchor_fraction", anchor)
        object.__setattr__(self, "fit_tolerance", tolerance)
        object.__setattr__(self, "horizon_power", horizon)
        object.__setattr__(self, "maximum_als_iterations", iterations)
        if (
            ridge != 1e-4
            or floor != 1e-12
            or anchor != 0.25
            or iterations != 12
            or tolerance != 1e-12
            or horizon != 0.0
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "The sequence-effective production policy is singular and fixed."
            )
        expected = _sha256(self.authentication_body())
        supplied = str(self.authentication_sha256).strip().lower()
        if supplied and supplied != expected:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Policy authentication_sha256 is invalid."
            )
        object.__setattr__(self, "authentication_sha256", expected)

    def authentication_body(self) -> dict[str, Any]:
        return {
            "schema": LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_SCHEMA,
            "kind": "fixed_qk_sequence_effective_vo_als_policy",
            "ridge_scale": self.ridge_scale,
            "absolute_ridge_floor": self.absolute_ridge_floor,
            "value_anchor_fraction": self.value_anchor_fraction,
            "maximum_als_iterations": self.maximum_als_iterations,
            "fit_tolerance": self.fit_tolerance,
            "horizon_power": self.horizon_power,
            "fixed_query_key_required": True,
            "causal_attended_input_operator": True,
            "shared_value_subspace_svd": True,
            "monotone_closed_form_value_output_als": (
                "dense_small_topology_only"
            ),
            "monotone_pcg_normal_equation_value_output_als": True,
            "streamed_cross_head_sufficient_statistics": True,
            "maximum_dense_ridge_system_elements": (
                _MAXIMUM_DENSE_RIDGE_SYSTEM_ELEMENTS
            ),
            "maximum_explicit_coefficient_elements": (
                _MAXIMUM_EXPLICIT_COEFFICIENT_ELEMENTS
            ),
            "statistics_row_chunk_size": _STATISTICS_ROW_CHUNK_SIZE,
            "pcg_maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
            "pcg_relative_normal_residual_tolerance": (
                _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
            ),
            "accumulation_dtype": "torch.float64",
            "selection_inputs_accessible": False,
            "validation_inputs_accessible": False,
            "execution": {
                **_ZERO_EXECUTION,
                "closed_form_linear_solves": True,
                "dense_target_value_output_materialization": True,
            },
        }

    def verify_authentication(self) -> bool:
        return self.authentication_sha256 == _sha256(self.authentication_body())

    def as_dict(self) -> dict[str, Any]:
        return {
            **self.authentication_body(),
            "authentication_sha256": self.authentication_sha256,
        }


FIXED_QK_SEQUENCE_EFFECTIVE_VO_ALS_POLICY_SHA256 = (
    Lfm2FixedQkSequenceEffectiveVoAlsPolicy().authentication_sha256
)


def _residual_delta_policy_report(
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
) -> dict[str, Any]:
    body = {
        "schema": (
            "neural-forge-lfm2-sequence-effective-residual-vo-delta-policy-v1"
        ),
        "kind": "fixed_qk_residual_vo_zero_centered_delta_policy",
        "ridge_scale": policy.ridge_scale,
        "absolute_ridge_floor": policy.absolute_ridge_floor,
        "fit_tolerance": policy.fit_tolerance,
        "maximum_residual_delta_sweeps": _MAXIMUM_STREAMED_ALS_ITERATIONS,
        "zero_delta_ridge_anchor": True,
        "target_dtype_fit_selection": True,
        "selection_inputs_accessible": False,
        "validation_inputs_accessible": False,
    }
    return {**body, "authentication_sha256": _sha256(body)}


@dataclass(frozen=True, slots=True)
class Lfm2SequenceEffectiveResidualVoSeedProvenance:
    """Sealed caller-supplied provenance for one exact fit-only V/O split."""

    source_artifact_schema: str
    source_artifact_seal_sha256: str
    source_compiled_state_sha256: str
    source_value_weight_sha256: str
    source_output_weight_sha256: str
    evidence_split: str = "fit"
    authentication_sha256: str = ""

    def __post_init__(self) -> None:
        schema = str(self.source_artifact_schema).strip()
        if not schema:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "source_artifact_schema must be non-empty."
            )
        seal_sha = _digest(
            self.source_artifact_seal_sha256,
            "source_artifact_seal_sha256",
        )
        state_sha = _digest(
            self.source_compiled_state_sha256,
            "source_compiled_state_sha256",
        )
        value_sha = _digest(
            self.source_value_weight_sha256,
            "source_value_weight_sha256",
        )
        output_sha = _digest(
            self.source_output_weight_sha256,
            "source_output_weight_sha256",
        )
        if self.evidence_split != "fit":
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Residual V/O seed provenance must be exact fit-only evidence."
            )
        object.__setattr__(self, "source_artifact_schema", schema)
        object.__setattr__(self, "source_artifact_seal_sha256", seal_sha)
        object.__setattr__(self, "source_compiled_state_sha256", state_sha)
        object.__setattr__(self, "source_value_weight_sha256", value_sha)
        object.__setattr__(self, "source_output_weight_sha256", output_sha)
        expected = _sha256(self.authentication_body())
        supplied = str(self.authentication_sha256).strip().lower()
        if supplied and supplied != expected:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Residual V/O seed provenance authentication is invalid."
            )
        object.__setattr__(self, "authentication_sha256", expected)

    def authentication_body(self) -> dict[str, Any]:
        return {
            "schema": (
                LFM2_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEED_PROVENANCE_SCHEMA
            ),
            "source_artifact_schema": self.source_artifact_schema,
            "source_artifact_seal_sha256": (
                self.source_artifact_seal_sha256
            ),
            "source_compiled_state_sha256": (
                self.source_compiled_state_sha256
            ),
            "source_value_weight_sha256": self.source_value_weight_sha256,
            "source_output_weight_sha256": self.source_output_weight_sha256,
            "evidence_split": self.evidence_split,
            "caller_source_artifact_cross_authentication_required": True,
        }

    def verify_authentication(self) -> bool:
        return self.authentication_sha256 == _sha256(
            self.authentication_body()
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            **self.authentication_body(),
            "authentication_sha256": self.authentication_sha256,
        }


@dataclass(frozen=True, slots=True)
class Lfm2SequenceEffectiveResidualVoSeed:
    """Authenticated dense residual V/O split used only as a fit seed."""

    value_weight: Any
    output_weight: Any
    provenance: Lfm2SequenceEffectiveResidualVoSeedProvenance
    authentication_sha256: str = ""

    def __post_init__(self) -> None:
        value = _tensor(self.value_weight, "value_weight", dimensions=2)
        output = _tensor(self.output_weight, "output_weight", dimensions=2)
        if (
            not isinstance(
                self.provenance,
                Lfm2SequenceEffectiveResidualVoSeedProvenance,
            )
            or not self.provenance.verify_authentication()
            or self.provenance.source_value_weight_sha256
            != _tensor_sha256(value)
            or self.provenance.source_output_weight_sha256
            != _tensor_sha256(output)
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Residual V/O seed provenance does not authenticate its "
                "exact tensor bundle."
            )
        object.__setattr__(self, "value_weight", value.clone())
        object.__setattr__(self, "output_weight", output.clone())
        expected = _sha256(self.authentication_body())
        supplied = str(self.authentication_sha256).strip().lower()
        if supplied and supplied != expected:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Residual V/O seed authentication_sha256 is invalid."
            )
        object.__setattr__(self, "authentication_sha256", expected)

    def authentication_body(self) -> dict[str, Any]:
        return {
            "schema": LFM2_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEED_SCHEMA,
            "provenance": self.provenance.as_dict(),
            "provenance_sha256": self.provenance.authentication_sha256,
            "value_weight_shape": list(self.value_weight.shape),
            "value_weight_dtype": str(self.value_weight.dtype),
            "value_weight_sha256": _tensor_sha256(self.value_weight),
            "output_weight_shape": list(self.output_weight.shape),
            "output_weight_dtype": str(self.output_weight.dtype),
            "output_weight_sha256": _tensor_sha256(self.output_weight),
            "ordinary_dense_target_value_output": True,
            "fit_seed_only": True,
            "selection_inputs_accessible": False,
            "validation_inputs_accessible": False,
        }

    def verify_authentication(self) -> bool:
        return self.authentication_sha256 == _sha256(
            self.authentication_body()
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            **self.authentication_body(),
            "authentication_sha256": self.authentication_sha256,
        }


@dataclass(frozen=True, slots=True)
class Lfm2CompiledFixedQkSequenceEffectiveAttentionFold:
    """Authenticated exact-Q/K plus sequence-effective dense V/O state."""

    producer_artifact: Lfm2CompiledStructuralAttentionProducerFold
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy
    value_weight: Any
    output_weight: Any
    fit_case_count: int
    fit_case_bundle_sha256: str
    producer_state_sha256_before: str
    producer_state_sha256_after: str
    target_template_sha256: str
    compiled_state_sha256: str
    candidate_frontier_sha256: str
    report: Mapping[str, Any]
    residual_vo_seed: Lfm2SequenceEffectiveResidualVoSeed | None = None

    def __post_init__(self) -> None:
        if not isinstance(
            self.producer_artifact,
            Lfm2CompiledStructuralAttentionProducerFold,
        ):
            raise TypeError(
                "producer_artifact must be an LFM2 attention producer fold."
            )
        if not isinstance(
            self.policy,
            Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
        ) or not self.policy.verify_authentication():
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Sequence-effective policy authentication failed."
            )
        topology = self.producer_artifact.topology
        value = _tensor(self.value_weight, "value_weight", dimensions=2)
        output = _tensor(self.output_weight, "output_weight", dimensions=2)
        if tuple(value.shape) != (
            topology.target_key_value_heads * topology.head_dim,
            topology.target_hidden_size,
        ) or tuple(output.shape) != (
            topology.target_output_size,
            topology.target_query_heads * topology.head_dim,
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Compiled V/O tensors differ from the producer topology."
            )
        case_count = _positive_int(
            self.fit_case_count,
            "fit_case_count",
            maximum=1_000_000,
        )
        fit_sha = _digest(
            self.fit_case_bundle_sha256,
            "fit_case_bundle_sha256",
        )
        producer_before = _digest(
            self.producer_state_sha256_before,
            "producer_state_sha256_before",
        )
        producer_after = _digest(
            self.producer_state_sha256_after,
            "producer_state_sha256_after",
        )
        template_sha = _digest(
            self.target_template_sha256,
            "target_template_sha256",
        )
        state_sha = _digest(
            self.compiled_state_sha256,
            "compiled_state_sha256",
        )
        frontier_sha = _digest(
            self.candidate_frontier_sha256,
            "candidate_frontier_sha256",
        )
        if producer_before != producer_after:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "The fixed Q/K producer changed during V/O compilation."
            )
        producer_state_sha = _state_sha256(self.producer_artifact.state_dict())
        if (
            producer_state_sha != producer_before
            or producer_state_sha
            != self.producer_artifact.compiled_state_sha256
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Producer state authentication differs from the artifact."
            )
        object.__setattr__(self, "value_weight", value.clone())
        object.__setattr__(self, "output_weight", output.clone())
        if _state_sha256(self.state_dict()) != state_sha:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Compiled Q/K/V/O state authentication failed."
            )
        report = dict(self.report)
        supplied = report.pop("report_sha256", None)
        inventory = report.get("candidate_frontier")
        execution = report.get("execution")
        seeded = self.residual_vo_seed is not None
        if seeded and (
            not isinstance(
                self.residual_vo_seed,
                Lfm2SequenceEffectiveResidualVoSeed,
            )
            or not self.residual_vo_seed.verify_authentication()
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Residual V/O seed authentication failed."
            )
        expected_schema = (
            LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEEDED_SCHEMA
            if seeded
            else LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_SCHEMA
        )
        expected_policy = (
            _residual_delta_policy_report(self.policy)
            if seeded
            else self.policy.as_dict()
        )
        if (
            supplied != _sha256(report)
            or report.get("schema") != expected_schema
            or report.get("candidate_id")
            != FIXED_QK_SEQUENCE_EFFECTIVE_VO_ALS_CANDIDATE_ID
            or report.get("policy") != expected_policy
            or report.get("policy_sha256")
            != expected_policy["authentication_sha256"]
            or report.get("producer_artifact")
            != self.producer_artifact.as_dict()
            or report.get("producer_artifact_sha256")
            != _sha256(self.producer_artifact.as_dict())
            or report.get("fixed_query_key_sha256")
            != self.producer_artifact.score_state_sha256
            or report.get("fit_case_count") != case_count
            or report.get("fit_case_bundle_sha256") != fit_sha
            or report.get("producer_state_sha256_before") != producer_before
            or report.get("producer_state_sha256_after") != producer_after
            or report.get("target_template_sha256") != template_sha
            or report.get("compiled_state_sha256") != state_sha
            or not isinstance(inventory, list)
            or not inventory
            or _sha256(inventory) != frontier_sha
            or report.get("candidate_frontier_sha256") != frontier_sha
            or report.get("fit_only_compilation") is not True
            or report.get("compiled_from_splits") != ["fit"]
            or report.get("selection_case_count_consumed") != 0
            or report.get("validation_case_count_consumed") != 0
            or report.get("dense_target_native_qkvo") is not True
            or not isinstance(execution, Mapping)
            or any(execution.get(name) != value for name, value in _ZERO_EXECUTION.items())
            or (
                report.get("solver_strategy")
                == "streamed_cross_head_statistics_pcg"
                and (
                    not _verify_streamed_vo_seed_bank_report(
                        report.get("initial_vo_seed_bank"),
                        fit_case_count=case_count,
                        fit_case_bundle_sha256=fit_sha,
                    )
                    or report.get("initial_vo_seed_bank_sha256")
                    != report.get("initial_vo_seed_bank", {}).get(
                        "report_sha256"
                    )
                    or report.get(
                        "selected_initial_vo_seed_candidate_id"
                    )
                    != report.get("initial_vo_seed_bank", {}).get(
                        "selected_candidate_id"
                    )
                    or report.get(
                        "selected_initial_vo_seed_candidate_index"
                    )
                    != report.get("initial_vo_seed_bank", {}).get(
                        "selected_candidate_index"
                    )
                    or report.get(
                        "selected_initial_vo_seed_nonincreasing"
                    )
                    is not True
                )
            )
            or (
                seeded
                and (
                    report.get("residual_vo_seed")
                    != self.residual_vo_seed.as_dict()
                    or report.get("residual_vo_seed_sha256")
                    != self.residual_vo_seed.authentication_sha256
                    or report.get("residual_delta_parameterization")
                    is not True
                    or report.get(
                        "source_seed_fit_provenance_cross_authenticated"
                    )
                    is not False
                    or report.get(
                        "caller_source_artifact_cross_authentication_required"
                    )
                    is not True
                )
            )
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Sequence-effective artifact seal is invalid."
            )
        object.__setattr__(self, "fit_case_count", case_count)
        object.__setattr__(self, "report", MappingProxyType(dict(self.report)))

    @property
    def topology(self) -> Any:
        return self.producer_artifact.topology

    @property
    def cluster_plan(self) -> Any:
        return self.producer_artifact.cluster_plan

    def state_dict(self) -> Mapping[str, Any]:
        return MappingProxyType(
            {
                "q_proj.weight": self.producer_artifact.query_weight.detach()
                .cpu()
                .clone(),
                "k_proj.weight": self.producer_artifact.key_weight.detach()
                .cpu()
                .clone(),
                "v_proj.weight": self.value_weight.detach().cpu().clone(),
                "out_proj.weight": self.output_weight.detach().cpu().clone(),
            }
        )

    def verify_authentication(self) -> bool:
        try:
            report = dict(self.report)
            supplied = report.pop("report_sha256", None)
            return bool(
                self.policy.verify_authentication()
                and supplied == _sha256(report)
                and _state_sha256(self.state_dict()) == self.compiled_state_sha256
                and report.get("candidate_frontier_sha256")
                == _sha256(report.get("candidate_frontier"))
                and report.get("fixed_query_key_sha256")
                == self.producer_artifact.score_state_sha256
                and (
                    report.get("solver_strategy")
                    != "streamed_cross_head_statistics_pcg"
                    or (
                        _verify_streamed_vo_seed_bank_report(
                            report.get("initial_vo_seed_bank"),
                            fit_case_count=self.fit_case_count,
                            fit_case_bundle_sha256=(
                                self.fit_case_bundle_sha256
                            ),
                        )
                        and report.get("initial_vo_seed_bank_sha256")
                        == report.get("initial_vo_seed_bank", {}).get(
                            "report_sha256"
                        )
                    )
                )
                and (
                    self.residual_vo_seed is None
                    or (
                        self.residual_vo_seed.verify_authentication()
                        and report.get("residual_vo_seed")
                        == self.residual_vo_seed.as_dict()
                        and report.get("residual_vo_seed_sha256")
                        == self.residual_vo_seed.authentication_sha256
                    )
                )
            )
        except (TypeError, ValueError, RuntimeError):
            return False

    def as_dict(self) -> dict[str, Any]:
        return dict(self.report)


@dataclass(frozen=True, slots=True)
class Lfm2SequenceEffectiveAttentionInstallReport:
    """Authenticated exact in-place dense Q/K/V/O installation receipt."""

    report: Mapping[str, Any]

    def __post_init__(self) -> None:
        body = dict(self.report)
        supplied = body.pop("report_sha256", None)
        if (
            supplied != _sha256(body)
            or body.get("schema")
            != LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_INSTALL_SCHEMA
            or body.get("accepted") is not True
        ):
            raise Lfm2SequenceEffectiveAttentionInstallError(
                "Sequence-effective installation report is invalid."
            )
        object.__setattr__(
            self,
            "report",
            MappingProxyType(dict(self.report)),
        )

    @property
    def accepted(self) -> bool:
        return True

    def as_dict(self) -> dict[str, Any]:
        return dict(self.report)


def _ridge_solve(
    design: Any,
    target: Any,
    *,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    role: str,
) -> tuple[Any, dict[str, Any]]:
    torch = _torch()
    if (
        design.ndim != 2
        or target.ndim != 2
        or int(design.shape[0]) != int(target.shape[0])
        or int(design.shape[0]) == 0
        or int(design.shape[1]) == 0
        or int(target.shape[1]) == 0
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} ridge system is empty or misaligned."
        )
    rows = int(design.shape[0])
    features = int(design.shape[1])
    trace_scale = float(design.square().sum().item()) / max(features, 1)
    ridge = max(
        policy.absolute_ridge_floor,
        policy.ridge_scale * max(trace_scale, 0.0),
    )
    # The sequence operator can have Hq*hidden columns.  Solve its ridge
    # system in row space when that is smaller, avoiding a quadratic feature
    # Gram while preserving the same closed-form ridge solution.
    use_dual = features > rows
    if use_dual:
        regularized = design @ design.T + ridge * torch.eye(
            rows,
            dtype=torch.float64,
        )
        right = target
    else:
        regularized = design.T @ design + ridge * torch.eye(
            features,
            dtype=torch.float64,
        )
        right = design.T @ target
    solver = "solve"
    try:
        solved = torch.linalg.solve(regularized, right)
    except RuntimeError as solve_error:
        solver = "lstsq"
        try:
            solved = torch.linalg.lstsq(
                regularized,
                right,
                driver="gelsd",
            ).solution
        except RuntimeError as lstsq_error:
            failure = _seal(
                {
                    "status": "failed_closed",
                    "failure_stage": "ridge_factorization",
                    "failure_reason": "solve_and_lstsq_failed",
                    "role": role,
                    "solve_exception_type": type(solve_error).__name__,
                    "lstsq_exception_type": type(lstsq_error).__name__,
                }
            )
            raise Lfm2SequenceEffectiveAttentionFoldError(
                f"{role} ridge factorization failed numerically.",
                failure_report=failure,
            ) from lstsq_error
    solution = design.T @ solved if use_dual else solved
    if not bool(torch.isfinite(solution).all().item()):
        failure = _seal(
            {
                "status": "failed_closed",
                "failure_stage": "ridge_solution",
                "failure_reason": "non_finite_solution",
                "role": role,
            }
        )
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} ridge solution is non-finite.",
            failure_report=failure,
        )
    prediction = design @ solution
    report = {
        "role": role,
        "rows": int(design.shape[0]),
        "features": int(design.shape[1]),
        "outputs": int(target.shape[1]),
        "system_domain": "row_dual" if use_dual else "feature_primal",
        "linear_system_dimension": rows if use_dual else features,
        "ridge_scale": policy.ridge_scale,
        "trace_scale": trace_scale,
        "ridge": ridge,
        "solver": solver,
        "relative_rmse": _relative_rmse(prediction, target),
        "solution_sha256": _tensor_sha256(solution),
    }
    return solution.contiguous(), _seal(report)


def _sequence_effective_solver_plan(
    *,
    fit_rows: int,
    target_query_heads: int,
    target_hidden_size: int,
    target_output_size: int,
    head_dim: int,
) -> dict[str, Any]:
    rows = _positive_int(fit_rows, "fit_rows", maximum=1_000_000_000)
    query_heads = _positive_int(
        target_query_heads,
        "target_query_heads",
        maximum=1_000_000,
    )
    hidden = _positive_int(
        target_hidden_size,
        "target_hidden_size",
        maximum=1_000_000,
    )
    output = _positive_int(
        target_output_size,
        "target_output_size",
        maximum=1_000_000,
    )
    dimension = _positive_int(head_dim, "head_dim", maximum=1_000_000)
    global_features = query_heads * hidden
    global_system_dimension = min(rows, global_features)
    global_system_elements = global_system_dimension**2
    value_feature_count = hidden * dimension
    forbidden_value_coefficient_elements = (
        rows * output * value_feature_count
    )
    dense_small_path = bool(
        global_system_elements <= _MAXIMUM_DENSE_RIDGE_SYSTEM_ELEMENTS
        and value_feature_count**2 <= _MAXIMUM_DENSE_RIDGE_SYSTEM_ELEMENTS
        and forbidden_value_coefficient_elements
        <= _MAXIMUM_EXPLICIT_COEFFICIENT_ELEMENTS
    )
    if dense_small_path:
        strategy = "complete_causal_operator_exact_ridge"
        largest_system_dimension = global_system_dimension
        estimated_statistics_bytes = global_system_elements * 8
    else:
        strategy = "streamed_cross_head_statistics_pcg"
        largest_system_dimension = max(
            hidden,
            query_heads * dimension,
        )
        if largest_system_dimension**2 > _MAXIMUM_DENSE_RIDGE_SYSTEM_ELEMENTS:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Sequence-effective topology exceeds the authenticated dense "
                "headwise ridge budget."
            )
        estimated_statistics_bytes = (
            query_heads * query_heads * hidden * hidden
            + query_heads * hidden * output
        ) * 8
    body = {
        "strategy": strategy,
        "fit_rows": rows,
        "target_query_heads": query_heads,
        "target_hidden_size": hidden,
        "target_output_size": output,
        "head_dim": dimension,
        "complete_operator_feature_count": global_features,
        "complete_operator_dense_system_dimension": global_system_dimension,
        "complete_operator_dense_system_elements": global_system_elements,
        "complete_operator_dense_system_bytes": global_system_elements * 8,
        "maximum_dense_ridge_system_elements": (
            _MAXIMUM_DENSE_RIDGE_SYSTEM_ELEMENTS
        ),
        "maximum_explicit_coefficient_elements": (
            _MAXIMUM_EXPLICIT_COEFFICIENT_ELEMENTS
        ),
        "largest_executed_dense_system_dimension": largest_system_dimension,
        "largest_executed_dense_system_elements": largest_system_dimension**2,
        "estimated_streamed_statistics_bytes": estimated_statistics_bytes,
        "forbidden_value_coefficient_elements_per_kv_group": (
            forbidden_value_coefficient_elements
        ),
        "forbidden_value_coefficient_bytes_per_kv_group": (
            forbidden_value_coefficient_elements * 8
        ),
        "forbidden_value_dense_gram_elements": value_feature_count**2,
        "forbidden_value_dense_gram_bytes": value_feature_count**2 * 8,
        "forbidden_value_coefficient_materialized": False,
        "forbidden_value_dense_gram_materialized": False,
        "statistics_row_chunk_size": _STATISTICS_ROW_CHUNK_SIZE,
        "complete_operator_quadratic_gram_avoided": False,
        "monolithic_flat_feature_gram_materialized": (
            strategy == "complete_causal_operator_exact_ridge"
        ),
        "complete_operator_dense_factorization_avoided": (
            strategy == "streamed_cross_head_statistics_pcg"
        ),
        "matrix_materialization_bound_authenticated": True,
    }
    return _seal(body)


def _ridge_solve_statistics(
    gram: Any,
    right: Any,
    *,
    target_square_sum: float,
    rows: int,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    role: str,
) -> tuple[Any, dict[str, Any]]:
    torch = _torch()
    features = int(gram.shape[0])
    outputs = int(right.shape[1])
    if (
        gram.ndim != 2
        or right.ndim != 2
        or tuple(gram.shape) != (features, features)
        or int(right.shape[0]) != features
        or rows <= 0
        or not bool(torch.isfinite(gram).all().item())
        or not bool(torch.isfinite(right).all().item())
        or not math.isfinite(target_square_sum)
        or target_square_sum < 0.0
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} streamed ridge statistics are invalid."
        )
    trace_scale = float(torch.trace(gram).item()) / max(features, 1)
    ridge = max(
        policy.absolute_ridge_floor,
        policy.ridge_scale * max(trace_scale, 0.0),
    )
    regularized = gram + ridge * torch.eye(features, dtype=torch.float64)
    solver = "solve"
    try:
        solution = torch.linalg.solve(regularized, right)
    except RuntimeError as solve_error:
        solver = "lstsq"
        try:
            solution = torch.linalg.lstsq(
                regularized,
                right,
                driver="gelsd",
            ).solution
        except RuntimeError as lstsq_error:
            failure = _seal(
                {
                    "status": "failed_closed",
                    "failure_stage": "ridge_factorization",
                    "failure_reason": "solve_and_lstsq_failed",
                    "role": role,
                    "solve_exception_type": type(solve_error).__name__,
                    "lstsq_exception_type": type(lstsq_error).__name__,
                }
            )
            raise Lfm2SequenceEffectiveAttentionFoldError(
                f"{role} streamed ridge factorization failed numerically.",
                failure_report=failure,
            ) from lstsq_error
    if not bool(torch.isfinite(solution).all().item()):
        failure = _seal(
            {
                "status": "failed_closed",
                "failure_stage": "ridge_solution",
                "failure_reason": "non_finite_solution",
                "role": role,
            }
        )
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} streamed ridge solution is non-finite.",
            failure_report=failure,
        )
    prediction_square = float((solution * (gram @ solution)).sum().item())
    cross = float((solution * right).sum().item())
    squared_error = max(
        prediction_square - 2.0 * cross + target_square_sum,
        0.0,
    )
    relative_rmse = math.sqrt(
        squared_error / max(target_square_sum, torch.finfo(torch.float64).eps)
    )
    report = {
        "role": role,
        "rows": rows,
        "features": features,
        "outputs": outputs,
        "system_domain": "streamed_feature_primal",
        "linear_system_dimension": features,
        "ridge_scale": policy.ridge_scale,
        "trace_scale": trace_scale,
        "ridge": ridge,
        "solver": solver,
        "relative_rmse": relative_rmse,
        "solution_sha256": _tensor_sha256(solution),
    }
    return solution.contiguous(), _seal(report)


def _pcg_multi_rhs(
    *,
    right: Any,
    matvec: Any,
    diagonal: Any,
    role: str,
) -> tuple[Any, dict[str, Any]]:
    """Deterministic Jacobi-PCG with one independent Krylov scalar per output."""

    torch = _torch()
    solution = torch.zeros_like(right)
    residual = right.clone()
    right_norm = torch.sqrt(
        residual.square().sum(dim=tuple(range(residual.ndim - 1)))
    ).clamp_min(torch.finfo(torch.float64).eps)
    preconditioned = residual / diagonal.unsqueeze(-1)
    direction = preconditioned.clone()
    rz = (residual * preconditioned).sum(
        dim=tuple(range(residual.ndim - 1))
    )
    relative = torch.sqrt(
        residual.square().sum(dim=tuple(range(residual.ndim - 1)))
    ) / right_norm
    active = relative > _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
    if not bool(active.any().item()):
        body = {
            "role": role,
            "solver": "deterministic_jacobi_pcg_multi_rhs",
            "maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
            "iterations_executed": 0,
            "required_relative_normal_residual": (
                _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
            ),
            "initial_relative_normal_residual": float(relative.max().item()),
            "final_maximum_relative_normal_residual": float(
                relative.max().item()
            ),
            "relative_normal_residual_history": [],
            "solution_sha256": _tensor_sha256(solution),
        }
        return solution.contiguous(), _seal_observe_pcg_report(
            "multi_rhs",
            body,
        )
    history = []
    iterations = 0
    for iteration in range(1, _PCG_MAXIMUM_ITERATIONS + 1):
        if not bool(active.any().item()):
            break
        applied = matvec(direction)
        denominator = (direction * applied).sum(
            dim=tuple(range(direction.ndim - 1))
        )
        if bool(
            (
                active
                & (denominator.abs() <= torch.finfo(torch.float64).eps)
            ).any().item()
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                f"{role} PCG encountered a singular search direction."
            )
        alpha = torch.where(
            active,
            rz / torch.where(
                active,
                denominator,
                torch.ones_like(denominator),
            ),
            torch.zeros_like(rz),
        )
        view = (1,) * (solution.ndim - 1) + (-1,)
        solution = solution + direction * alpha.reshape(view)
        residual = residual - applied * alpha.reshape(view)
        relative = torch.sqrt(
            residual.square().sum(dim=tuple(range(residual.ndim - 1)))
        ) / right_norm
        maximum_relative = float(relative.max().item())
        history.append(maximum_relative)
        iterations = iteration
        next_active = relative > _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
        if not bool(next_active.any().item()):
            break
        next_preconditioned = residual / diagonal.unsqueeze(-1)
        next_rz = (residual * next_preconditioned).sum(
            dim=tuple(range(residual.ndim - 1))
        )
        beta = torch.where(
            next_active,
            next_rz
            / torch.where(next_active, rz, torch.ones_like(rz)),
            torch.zeros_like(rz),
        )
        direction = (
            next_preconditioned + direction * beta.reshape(view)
        ) * next_active.reshape(view)
        rz = next_rz
        active = next_active
    final_relative = history[-1]
    if (
        not bool(torch.isfinite(solution).all().item())
        or final_relative > _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} PCG failed its authenticated residual tolerance "
            f"({final_relative:.6e})."
        )
    body = {
        "role": role,
        "solver": "deterministic_jacobi_pcg_multi_rhs",
        "maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
        "iterations_executed": iterations,
        "required_relative_normal_residual": (
            _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
        ),
        "initial_relative_normal_residual": 1.0,
        "final_maximum_relative_normal_residual": final_relative,
        "relative_normal_residual_history": history,
        "solution_sha256": _tensor_sha256(solution),
    }
    return solution.contiguous(), _seal_observe_pcg_report(
        "multi_rhs",
        body,
    )


def _pcg_json_float(value: Any) -> float | None:
    try:
        normalized = float(value)
    except (TypeError, ValueError):
        return None
    return normalized if math.isfinite(normalized) else None


class _PcgRowBlockPreconditionerAuthenticationError(ValueError):
    def __init__(
        self,
        reason: str,
        *,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(reason)
        self.reason = reason
        self.details = {} if details is None else dict(details)


def _row_block_numerical_tolerance(value: Any) -> float:
    torch = _torch()
    scale = max(1.0, float(value.abs().max().item()))
    return 128.0 * float(torch.finfo(value.dtype).eps) * scale


def _build_structured_value_row_block_jacobi_preconditioner(
    *,
    cross: Any,
    output_blocks: Any,
    group_heads: Sequence[int],
    diagonal: Any,
    ridge: float,
    role: str,
) -> _PcgRestartRowBlockPreconditioner:
    """Materialize only the exact head-dimension block for each hidden row."""

    torch = _torch()
    heads = tuple(int(head) for head in group_heads)
    ridge_value = _pcg_json_float(ridge)
    if (
        cross.ndim != 4
        or output_blocks.ndim != 3
        or diagonal.ndim != 2
        or not heads
        or any(head < 0 or head >= int(cross.shape[0]) for head in heads)
        or int(cross.shape[0]) != int(cross.shape[1])
        or int(cross.shape[2]) != int(cross.shape[3])
        or int(cross.shape[2]) != int(diagonal.shape[0])
        or int(output_blocks.shape[0]) != int(cross.shape[0])
        or int(output_blocks.shape[1]) != int(diagonal.shape[1])
        or cross.dtype != diagonal.dtype
        or output_blocks.dtype != diagonal.dtype
        or cross.device != diagonal.device
        or output_blocks.device != diagonal.device
        or ridge_value is None
        or ridge_value <= 0.0
        or not role
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} row-block Jacobi construction inputs are invalid."
        )
    if (
        any(
            not bool(torch.isfinite(cross[head, other]).all().item())
            for head in heads
            for other in heads
        )
        or not bool(torch.isfinite(output_blocks).all().item())
        or not bool(torch.isfinite(diagonal).all().item())
        or not bool((diagonal > 0.0).all().item())
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} row-block Jacobi construction inputs must be finite "
            "with a positive scalar diagonal."
        )

    row_count, block_size = map(int, diagonal.shape)
    row_blocks = torch.zeros(
        row_count,
        block_size,
        block_size,
        dtype=diagonal.dtype,
        device=diagonal.device,
    )
    source_terms = []
    for head in heads:
        for other in heads:
            cross_diagonal = torch.diagonal(cross[head, other]).contiguous()
            coupling = (
                output_blocks[other] @ output_blocks[head].T
            ).contiguous()
            row_blocks.add_(
                cross_diagonal.reshape(row_count, 1, 1)
                * coupling.T.unsqueeze(0)
            )
            source_terms.append(
                {
                    "head": head,
                    "other_head": other,
                    "cross_diagonal_sha256": _tensor_sha256(cross_diagonal),
                    "coupling_sha256": _tensor_sha256(coupling),
                }
            )
    row_blocks.add_(
        ridge_value
        * torch.eye(
            block_size,
            dtype=row_blocks.dtype,
            device=row_blocks.device,
        ).unsqueeze(0)
    )
    row_blocks = (
        0.5 * (row_blocks + row_blocks.transpose(1, 2))
    ).contiguous()
    row_block_diagonal = torch.diagonal(
        row_blocks,
        dim1=1,
        dim2=2,
    ).contiguous()
    maximum_asymmetry = float(
        (row_blocks - row_blocks.transpose(1, 2)).abs().max().item()
    )
    symmetry_tolerance = _row_block_numerical_tolerance(row_blocks)
    scalar_diagonal_error = float(
        (row_block_diagonal - diagonal).abs().max().item()
    )
    diagonal_tolerance = _row_block_numerical_tolerance(row_block_diagonal)
    body = {
        "schema": LFM2_SEQUENCE_EFFECTIVE_ROW_BLOCK_JACOBI_SCHEMA,
        "role": role,
        "construction": "exact_structured_operator_row_blocks",
        "row_block_count": row_count,
        "row_block_size": block_size,
        "row_blocks_shape": list(row_blocks.shape),
        "row_blocks_dtype": str(row_blocks.dtype),
        "row_blocks_sha256": _tensor_sha256(row_blocks),
        "scalar_diagonal_sha256": _tensor_sha256(diagonal),
        "scalar_diagonal_maximum_absolute_error": scalar_diagonal_error,
        "scalar_diagonal_match_tolerance": diagonal_tolerance,
        "row_blocks_maximum_asymmetry": maximum_asymmetry,
        "row_blocks_symmetry_tolerance": symmetry_tolerance,
        "source_term_count": len(source_terms),
        "source_terms_sha256": _sha256(source_terms),
        "ridge": ridge_value,
        "full_operator_materialized": False,
    }
    return _PcgRestartRowBlockPreconditioner(
        row_blocks=row_blocks,
        construction_report=MappingProxyType(_seal(body)),
    )


def _authenticate_restart_row_block_preconditioner(
    *,
    supplied: Any,
    right: Any,
    diagonal: Any,
    role: str,
) -> tuple[Any, dict[str, Any]]:
    """Authenticate and factor caller-built row blocks after scalar miss."""

    torch = _torch()

    def reject(
        reason: str,
        *,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        raise _PcgRowBlockPreconditionerAuthenticationError(
            reason,
            details=details,
        )

    if not isinstance(supplied, _PcgRestartRowBlockPreconditioner):
        reject("row_block_preconditioner_has_wrong_type")
    row_blocks = supplied.row_blocks
    if (
        not isinstance(row_blocks, torch.Tensor)
        or row_blocks.layout != torch.strided
        or row_blocks.device.type == "meta"
        or row_blocks.ndim != 3
        or right.ndim != 2
        or diagonal.ndim != 2
    ):
        reject("row_block_preconditioner_tensor_is_invalid")
    expected_shape = (
        int(right.shape[0]),
        int(right.shape[1]),
        int(right.shape[1]),
    )
    if (
        tuple(row_blocks.shape) != expected_shape
        or tuple(diagonal.shape) != tuple(right.shape)
        or row_blocks.dtype != right.dtype
        or diagonal.dtype != right.dtype
        or row_blocks.device != right.device
        or diagonal.device != right.device
    ):
        reject(
            "row_block_preconditioner_topology_mismatch",
            details={
                "expected_shape": list(expected_shape),
                "observed_shape": list(row_blocks.shape),
                "right_shape": list(right.shape),
                "diagonal_shape": list(diagonal.shape),
                "dtype_matches": row_blocks.dtype == right.dtype,
                "device_matches": row_blocks.device == right.device,
            },
        )
    if not bool(torch.isfinite(row_blocks).all().item()):
        reject("row_block_preconditioner_is_non_finite")

    try:
        report = dict(supplied.construction_report)
    except (TypeError, ValueError):
        reject("row_block_preconditioner_report_is_invalid")
    expected_report_keys = {
        "schema",
        "role",
        "construction",
        "row_block_count",
        "row_block_size",
        "row_blocks_shape",
        "row_blocks_dtype",
        "row_blocks_sha256",
        "scalar_diagonal_sha256",
        "scalar_diagonal_maximum_absolute_error",
        "scalar_diagonal_match_tolerance",
        "row_blocks_maximum_asymmetry",
        "row_blocks_symmetry_tolerance",
        "source_term_count",
        "source_terms_sha256",
        "ridge",
        "full_operator_materialized",
        "report_sha256",
    }
    if set(report) != expected_report_keys:
        reject("row_block_preconditioner_report_fields_are_not_exact")
    supplied_sha256 = report.pop("report_sha256")
    try:
        report_sha256 = _sha256(report)
    except Lfm2SequenceEffectiveAttentionFoldError:
        reject("row_block_preconditioner_report_is_not_canonical")
    if supplied_sha256 != report_sha256:
        reject("row_block_preconditioner_report_seal_mismatch")
    source_term_count = report.get("source_term_count")
    source_terms_sha256 = report.get("source_terms_sha256")
    ridge_value = _pcg_json_float(report.get("ridge"))
    if (
        report.get("schema")
        != LFM2_SEQUENCE_EFFECTIVE_ROW_BLOCK_JACOBI_SCHEMA
        or report.get("role") != role
        or report.get("construction")
        != "exact_structured_operator_row_blocks"
        or report.get("row_block_count") != expected_shape[0]
        or report.get("row_block_size") != expected_shape[1]
        or report.get("row_blocks_shape") != list(expected_shape)
        or report.get("row_blocks_dtype") != str(row_blocks.dtype)
        or report.get("full_operator_materialized") is not False
        or not isinstance(source_term_count, int)
        or isinstance(source_term_count, bool)
        or source_term_count <= 0
        or ridge_value is None
        or ridge_value <= 0.0
    ):
        reject("row_block_preconditioner_report_binding_mismatch")
    try:
        _digest(source_terms_sha256, "source_terms_sha256")
    except Lfm2SequenceEffectiveAttentionFoldError:
        reject("row_block_preconditioner_source_digest_is_invalid")
    if (
        report.get("row_blocks_sha256") != _tensor_sha256(row_blocks)
        or report.get("scalar_diagonal_sha256") != _tensor_sha256(diagonal)
    ):
        reject("row_block_preconditioner_tensor_hash_mismatch")

    row_block_diagonal = torch.diagonal(
        row_blocks,
        dim1=1,
        dim2=2,
    ).contiguous()
    diagonal_error = float(
        (row_block_diagonal - diagonal).abs().max().item()
    )
    diagonal_tolerance = _row_block_numerical_tolerance(row_block_diagonal)
    maximum_asymmetry = float(
        (row_blocks - row_blocks.transpose(1, 2)).abs().max().item()
    )
    symmetry_tolerance = _row_block_numerical_tolerance(row_blocks)
    if (
        report.get("scalar_diagonal_maximum_absolute_error")
        != diagonal_error
        or report.get("scalar_diagonal_match_tolerance")
        != diagonal_tolerance
        or diagonal_error > diagonal_tolerance
    ):
        reject(
            "row_block_preconditioner_scalar_diagonal_mismatch",
            details={
                "maximum_absolute_error": diagonal_error,
                "required_tolerance": diagonal_tolerance,
            },
        )
    if (
        report.get("row_blocks_maximum_asymmetry")
        != maximum_asymmetry
        or report.get("row_blocks_symmetry_tolerance")
        != symmetry_tolerance
        or maximum_asymmetry > symmetry_tolerance
    ):
        reject(
            "row_block_preconditioner_is_not_symmetric",
            details={
                "maximum_asymmetry": maximum_asymmetry,
                "required_tolerance": symmetry_tolerance,
            },
        )

    factor, factorization_info = torch.linalg.cholesky_ex(
        row_blocks,
        upper=False,
        check_errors=False,
    )
    failing = torch.nonzero(
        factorization_info != 0,
        as_tuple=False,
    ).flatten()
    if (
        int(failing.numel()) != 0
        or not bool(torch.isfinite(factor).all().item())
        or not bool(
            (
                torch.diagonal(factor, dim1=1, dim2=2) > 0.0
            ).all().item()
        )
    ):
        reject(
            "row_block_preconditioner_cholesky_failed",
            details={
                "failing_row_count": int(failing.numel()),
                "first_failing_row": (
                    int(failing[0].item())
                    if int(failing.numel()) != 0
                    else None
                ),
                "factor_finite": bool(torch.isfinite(factor).all().item()),
            },
        )
    construction_report = dict(supplied.construction_report)
    receipt = _seal(
        {
            "kind": "deterministic_exact_row_block_jacobi_cholesky",
            "construction_report": construction_report,
            "construction_report_sha256": construction_report[
                "report_sha256"
            ],
            "row_blocks_sha256": construction_report[
                "row_blocks_sha256"
            ],
            "factorization": "batched_lower_cholesky_ex",
            "factor_sha256": _tensor_sha256(factor),
            "row_block_count": expected_shape[0],
            "row_block_size": expected_shape[1],
            "all_row_blocks_spd": True,
            "factorization_materialized_only_after_original_lane_exact_miss": (
                True
            ),
            "full_operator_materialized": False,
        }
    )
    return factor.contiguous(), receipt


class _PcgHiddenPartialTracePreconditionerAuthenticationError(ValueError):
    def __init__(
        self,
        reason: str,
        *,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(reason)
        self.reason = reason
        self.details = {} if details is None else dict(details)


def _hidden_partial_trace_numerical_tolerance(value: Any) -> float:
    torch = _torch()
    scale = max(1.0, float(value.abs().max().item()))
    return 128.0 * float(torch.finfo(value.dtype).eps) * scale


_HIDDEN_PARTIAL_TRACE_FORMULA = (
    "P_H=ridge*I_H+sum_(h,o)(trace(C_o,h)/head_dim)*A_h,o"
)


def _build_structured_value_hidden_partial_trace_preconditioner(
    *,
    cross: Any,
    output_blocks: Any,
    group_heads: Sequence[int],
    ridge: float,
    role: str,
) -> _PcgRestartHiddenPartialTracePreconditioner:
    """Build the normalized hidden-side partial trace of the SPD operator."""

    torch = _torch()
    heads = tuple(int(head) for head in group_heads)
    ridge_value = _pcg_json_float(ridge)
    if (
        cross.ndim != 4
        or output_blocks.ndim != 3
        or not heads
        or any(head < 0 or head >= int(cross.shape[0]) for head in heads)
        or len(set(heads)) != len(heads)
        or int(cross.shape[0]) != int(cross.shape[1])
        or int(cross.shape[2]) != int(cross.shape[3])
        or int(output_blocks.shape[0]) != int(cross.shape[0])
        or int(output_blocks.shape[1]) <= 0
        or cross.dtype != output_blocks.dtype
        or cross.device != output_blocks.device
        or ridge_value is None
        or ridge_value <= 0.0
        or not role
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} hidden partial-trace construction inputs are invalid."
        )
    if (
        any(
            not bool(torch.isfinite(cross[head, other]).all().item())
            for head in heads
            for other in heads
        )
        or not bool(torch.isfinite(output_blocks).all().item())
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} hidden partial-trace construction inputs must be finite."
        )

    hidden_size = int(cross.shape[2])
    head_dim = int(output_blocks.shape[1])
    partial_trace = torch.eye(
        hidden_size,
        dtype=cross.dtype,
        device=cross.device,
    ).mul_(ridge_value)
    source_terms = []
    for head in heads:
        for other in heads:
            left = cross[head, other].contiguous()
            coupling = (output_blocks[other] @ output_blocks[head].T).contiguous()
            trace_weight = float(torch.trace(coupling).item()) / head_dim
            partial_trace.add_(left, alpha=trace_weight)
            source_terms.append(
                {
                    "head": head,
                    "other_head": other,
                    "left_sha256": _tensor_sha256(left),
                    "coupling_sha256": _tensor_sha256(coupling),
                    "partial_trace_weight": trace_weight,
                }
            )
    raw_maximum_asymmetry = float(
        (partial_trace - partial_trace.T).abs().max().item()
    )
    raw_symmetry_tolerance = _hidden_partial_trace_numerical_tolerance(
        partial_trace
    )
    if raw_maximum_asymmetry > raw_symmetry_tolerance:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} hidden partial trace exceeds its numerical symmetry "
            "tolerance."
        )
    # The paired normal-equation terms are mathematically symmetric.  This
    # half-sum removes only floating-point summation skew.
    partial_trace = (
        0.5 * (partial_trace + partial_trace.T)
    ).contiguous()
    symmetry_tolerance = _hidden_partial_trace_numerical_tolerance(partial_trace)
    if not bool(torch.isfinite(partial_trace).all().item()):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} hidden partial trace is non-finite."
        )
    if raw_maximum_asymmetry > symmetry_tolerance:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} symmetrized hidden partial trace changed its numerical "
            "symmetry scale."
        )
    source_terms_sha256 = _sha256(source_terms)
    body = {
        "schema": (
            LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_CHOLESKY_SCHEMA
        ),
        "role": role,
        "construction": "normalized_hidden_side_partial_trace",
        "formula": _HIDDEN_PARTIAL_TRACE_FORMULA,
        "ridge": ridge_value,
        "hidden_size": hidden_size,
        "head_dim": head_dim,
        "partial_trace_shape": list(partial_trace.shape),
        "partial_trace_dtype": str(partial_trace.dtype),
        "partial_trace_device": str(partial_trace.device),
        "partial_trace_sha256": _tensor_sha256(partial_trace),
        "partial_trace_tensor_bytes": int(
            partial_trace.numel() * partial_trace.element_size()
        ),
        "source_term_count": len(source_terms),
        "source_terms": source_terms,
        "source_terms_sha256": source_terms_sha256,
        "raw_maximum_absolute_asymmetry": raw_maximum_asymmetry,
        "symmetry_tolerance": symmetry_tolerance,
        "symmetric_within_numerical_tolerance": True,
        "symmetrization": "half_sum_with_transpose",
        "full_operator_materialized": False,
    }
    return _PcgRestartHiddenPartialTracePreconditioner(
        partial_trace=partial_trace,
        construction_report=MappingProxyType(_seal(body)),
    )


def _authenticate_restart_hidden_partial_trace_preconditioner(
    *,
    supplied: Any,
    right: Any,
    diagonal: Any,
    role: str,
    expected_ridge: Any,
) -> tuple[Any, dict[str, Any]]:
    """Authenticate and factor the hidden partial trace after scalar miss."""

    torch = _torch()

    def reject(
        reason: str,
        *,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        raise _PcgHiddenPartialTracePreconditionerAuthenticationError(
            reason,
            details=details,
        )

    if not isinstance(
        supplied,
        _PcgRestartHiddenPartialTracePreconditioner,
    ):
        reject("hidden_partial_trace_preconditioner_has_wrong_type")
    partial_trace = supplied.partial_trace
    if (
        not isinstance(partial_trace, torch.Tensor)
        or partial_trace.layout != torch.strided
        or partial_trace.device.type == "meta"
        or partial_trace.ndim != 2
        or right.ndim != 2
        or diagonal.ndim != 2
    ):
        reject("hidden_partial_trace_preconditioner_tensor_is_invalid")
    expected_shape = (
        int(right.shape[0]),
        int(right.shape[0]),
    )
    if (
        tuple(partial_trace.shape) != expected_shape
        or tuple(diagonal.shape) != tuple(right.shape)
        or partial_trace.dtype != right.dtype
        or diagonal.dtype != right.dtype
        or partial_trace.device != right.device
        or diagonal.device != right.device
    ):
        reject(
            "hidden_partial_trace_preconditioner_topology_mismatch",
            details={
                "expected_shape": list(expected_shape),
                "observed_shape": list(partial_trace.shape),
                "right_shape": list(right.shape),
                "diagonal_shape": list(diagonal.shape),
                "dtype_matches": partial_trace.dtype == right.dtype,
                "device_matches": partial_trace.device == right.device,
            },
        )
    if not bool(torch.isfinite(partial_trace).all().item()):
        reject("hidden_partial_trace_preconditioner_is_non_finite")

    try:
        report = dict(supplied.construction_report)
    except (TypeError, ValueError):
        reject("hidden_partial_trace_preconditioner_report_is_invalid")
    expected_report_keys = {
        "schema",
        "role",
        "construction",
        "formula",
        "ridge",
        "hidden_size",
        "head_dim",
        "partial_trace_shape",
        "partial_trace_dtype",
        "partial_trace_device",
        "partial_trace_sha256",
        "partial_trace_tensor_bytes",
        "source_term_count",
        "source_terms",
        "source_terms_sha256",
        "raw_maximum_absolute_asymmetry",
        "symmetry_tolerance",
        "symmetric_within_numerical_tolerance",
        "symmetrization",
        "full_operator_materialized",
        "report_sha256",
    }
    if set(report) != expected_report_keys:
        reject(
            "hidden_partial_trace_preconditioner_report_fields_are_not_exact"
        )
    supplied_sha256 = report.pop("report_sha256")
    try:
        report_sha256 = _sha256(report)
    except Lfm2SequenceEffectiveAttentionFoldError:
        reject("hidden_partial_trace_preconditioner_report_is_not_canonical")
    if supplied_sha256 != report_sha256:
        reject("hidden_partial_trace_preconditioner_report_seal_mismatch")
    source_term_count = report.get("source_term_count")
    source_terms = report.get("source_terms")
    source_terms_sha256 = report.get("source_terms_sha256")
    ridge_value = _pcg_json_float(report.get("ridge"))
    expected_ridge_value = _pcg_json_float(expected_ridge)
    if (
        report.get("schema")
        != LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_CHOLESKY_SCHEMA
        or report.get("role") != role
        or report.get("construction")
        != "normalized_hidden_side_partial_trace"
        or report.get("formula") != _HIDDEN_PARTIAL_TRACE_FORMULA
        or report.get("hidden_size") != int(right.shape[0])
        or report.get("head_dim") != int(right.shape[1])
        or report.get("partial_trace_shape") != list(expected_shape)
        or report.get("partial_trace_dtype") != str(partial_trace.dtype)
        or report.get("partial_trace_device") != str(partial_trace.device)
        or report.get("partial_trace_tensor_bytes")
        != int(partial_trace.numel() * partial_trace.element_size())
        or report.get("full_operator_materialized") is not False
        or not isinstance(source_term_count, int)
        or isinstance(source_term_count, bool)
        or source_term_count <= 0
        or not isinstance(source_terms, list)
        or len(source_terms) != source_term_count
        or ridge_value is None
        or ridge_value <= 0.0
        or expected_ridge_value is None
        or ridge_value != expected_ridge_value
    ):
        reject("hidden_partial_trace_preconditioner_report_binding_mismatch")
    source_pairs: set[tuple[int, int]] = set()
    for term in source_terms:
        if (
            not isinstance(term, dict)
            or set(term)
            != {
                "head",
                "other_head",
                "left_sha256",
                "coupling_sha256",
                "partial_trace_weight",
            }
            or isinstance(term.get("head"), bool)
            or not isinstance(term.get("head"), int)
            or term["head"] < 0
            or isinstance(term.get("other_head"), bool)
            or not isinstance(term.get("other_head"), int)
            or term["other_head"] < 0
            or _pcg_json_float(term.get("partial_trace_weight")) is None
        ):
            reject("hidden_partial_trace_preconditioner_source_term_is_invalid")
        pair = (term["head"], term["other_head"])
        if pair in source_pairs:
            reject("hidden_partial_trace_preconditioner_source_term_is_duplicate")
        source_pairs.add(pair)
        try:
            _digest(term.get("left_sha256"), "left_sha256")
            _digest(term.get("coupling_sha256"), "coupling_sha256")
        except Lfm2SequenceEffectiveAttentionFoldError:
            reject(
                "hidden_partial_trace_preconditioner_source_digest_is_invalid"
            )
    try:
        _digest(source_terms_sha256, "source_terms_sha256")
    except Lfm2SequenceEffectiveAttentionFoldError:
        reject("hidden_partial_trace_preconditioner_source_digest_is_invalid")
    if (
        report.get("source_terms_sha256") != _sha256(source_terms)
        or report.get("partial_trace_sha256")
        != _tensor_sha256(partial_trace)
    ):
        reject("hidden_partial_trace_preconditioner_tensor_hash_mismatch")

    maximum_asymmetry = float(
        (partial_trace - partial_trace.T).abs().max().item()
    )
    symmetry_tolerance = _hidden_partial_trace_numerical_tolerance(
        partial_trace
    )
    reported_raw_asymmetry = _pcg_json_float(
        report.get("raw_maximum_absolute_asymmetry")
    )
    reported_symmetry_tolerance = _pcg_json_float(
        report.get("symmetry_tolerance")
    )
    if (
        reported_raw_asymmetry is None
        or reported_symmetry_tolerance is None
        or reported_raw_asymmetry > reported_symmetry_tolerance
        or report.get("symmetric_within_numerical_tolerance") is not True
        or report.get("symmetrization") != "half_sum_with_transpose"
        or report.get("symmetry_tolerance") != symmetry_tolerance
        or maximum_asymmetry > symmetry_tolerance
    ):
        reject(
            "hidden_partial_trace_preconditioner_is_not_symmetric",
            details={
                "maximum_asymmetry": maximum_asymmetry,
                "required_tolerance": symmetry_tolerance,
            },
        )

    factor, factorization_info = torch.linalg.cholesky_ex(
        partial_trace,
        upper=False,
        check_errors=False,
    )
    if (
        int(factorization_info.item()) != 0
        or not bool(torch.isfinite(factor).all().item())
        or not bool((torch.diagonal(factor) > 0.0).all().item())
    ):
        reject(
            "hidden_partial_trace_preconditioner_cholesky_failed",
            details={
                "factorization_info": int(factorization_info.item()),
                "factor_finite": bool(torch.isfinite(factor).all().item()),
            },
        )
    try:
        inverse_probe = torch.cholesky_solve(right, factor, upper=False)
    except RuntimeError as exc:
        reject(
            "hidden_partial_trace_preconditioner_orientation_probe_failed",
            details={"exception_type": type(exc).__name__},
        )
    inverse_probe_tolerance = 1e-10
    inverse_probe_relative_residual = float(
        (
            torch.linalg.vector_norm(
                partial_trace @ inverse_probe - right
            )
            / torch.linalg.vector_norm(right).clamp_min(
                torch.finfo(right.dtype).eps
            )
        ).item()
    )
    if (
        not math.isfinite(inverse_probe_relative_residual)
        or inverse_probe_relative_residual > inverse_probe_tolerance
    ):
        reject(
            "hidden_partial_trace_preconditioner_orientation_probe_failed",
            details={
                "relative_residual": _pcg_json_float(
                    inverse_probe_relative_residual
                ),
                "required_tolerance": inverse_probe_tolerance,
            },
        )
    construction_report = dict(supplied.construction_report)
    receipt = _seal(
        {
            "kind": "deterministic_hidden_partial_trace_cholesky",
            "construction_report": construction_report,
            "construction_report_sha256": construction_report[
                "report_sha256"
            ],
            "partial_trace_sha256": construction_report[
                "partial_trace_sha256"
            ],
            "factorization": "lower_cholesky_ex",
            "factorization_info": 0,
            "factor_sha256": _tensor_sha256(factor),
            "factor_shape": list(factor.shape),
            "factor_dtype": str(factor.dtype),
            "factor_device": str(factor.device),
            "hidden_size": int(right.shape[0]),
            "head_dim": int(right.shape[1]),
            "partial_trace_spd": True,
            "positive_finite_factor_diagonal": True,
            "inverse_orientation_probe_relative_residual": (
                inverse_probe_relative_residual
            ),
            "inverse_orientation_probe_tolerance": inverse_probe_tolerance,
            "factorization_materialized_only_after_original_lane_exact_miss": (
                True
            ),
            "full_operator_materialized": False,
        }
    )
    return factor.contiguous(), receipt


def _single_tensor_pcg_extended_body(
    *,
    role: str,
    solution: Any,
    initial_relative: float | None,
    original_lane_iterations: int,
    original_lane_final_relative: float | None,
    total_iterations: int,
    history: Sequence[float],
    exact_relative: float | None,
    exact_final_residual_authenticated: bool,
    exact_checkpoints: Sequence[Mapping[str, Any]],
    restart_schedule: Sequence[Mapping[str, Any]],
    total_matvec_calls: int,
    extension_triggered: bool,
) -> dict[str, Any]:
    torch = _torch()
    solution_finite = bool(torch.isfinite(solution).all().item())
    recurrence_history = list(history)
    checkpoints = [dict(value) for value in exact_checkpoints]
    schedule = [dict(value) for value in restart_schedule]
    final_recurrence = (
        recurrence_history[-1]
        if recurrence_history
        else _pcg_json_float(initial_relative)
    )
    return {
        "role": role,
        "solver": "deterministic_restarted_jacobi_pcg_single_tensor",
        "maximum_iterations": _PCG_HARD_MAXIMUM_ITERATIONS,
        "original_lane_maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
        "original_lane_iterations_executed": original_lane_iterations,
        "restart_block_iterations": _PCG_RESTART_BLOCK_ITERATIONS,
        "iterations_executed": total_iterations,
        "required_relative_normal_residual": (
            _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
        ),
        "initial_relative_normal_residual": _pcg_json_float(initial_relative),
        "original_lane_final_recurrence_relative_normal_residual": (
            _pcg_json_float(original_lane_final_relative)
        ),
        "final_recurrence_relative_normal_residual": _pcg_json_float(
            final_recurrence
        ),
        "final_relative_normal_residual": (
            _pcg_json_float(exact_relative)
            if exact_final_residual_authenticated
            else None
        ),
        "relative_normal_residual_history": recurrence_history,
        "recurrence_history_sha256": _sha256(recurrence_history),
        "exact_relative_normal_residual_checkpoints": checkpoints,
        "exact_residual_checkpoints_sha256": _sha256(checkpoints),
        "restart_schedule": schedule,
        "restart_schedule_sha256": _sha256(schedule),
        "total_matvec_calls": total_matvec_calls,
        "exact_final_residual_authenticated": (
            exact_final_residual_authenticated
        ),
        "extended_after_original_lane_exact_authentication_miss": (
            extension_triggered
        ),
        "solution_finite": solution_finite,
        "solution_sha256": (
            _tensor_sha256(solution) if solution_finite else None
        ),
    }


def _single_tensor_pcg_continuous_row_block_body(
    *,
    role: str,
    solution: Any,
    initial_relative: float | None,
    original_lane_iterations: int,
    original_lane_final_relative: float | None,
    total_iterations: int,
    history: Sequence[float],
    exact_relative: float | None,
    exact_final_residual_authenticated: bool,
    exact_checkpoints: Sequence[Mapping[str, Any]],
    total_matvec_calls: int,
    lane_state: Mapping[str, Any],
    preconditioner_state: Mapping[str, Any],
) -> dict[str, Any]:
    torch = _torch()
    solution_finite = bool(torch.isfinite(solution).all().item())
    recurrence_history = list(history)
    checkpoints = [dict(value) for value in exact_checkpoints]
    final_recurrence = (
        recurrence_history[-1]
        if recurrence_history
        else _pcg_json_float(initial_relative)
    )
    return {
        "role": role,
        "solver": (
            "deterministic_continuous_row_block_jacobi_pcg_single_tensor"
        ),
        "maximum_iterations": _PCG_ROW_BLOCK_HARD_MAXIMUM_ITERATIONS,
        "hard_cap_includes_original_lane_iterations": True,
        "original_lane_maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
        "original_lane_iterations_executed": original_lane_iterations,
        "single_restart_after_original_lane_exact_authentication_miss": True,
        "periodic_restart_count": 0,
        "iterations_executed": total_iterations,
        "continuous_row_block_lane_iterations_executed": (
            total_iterations - original_lane_iterations
        ),
        "required_relative_normal_residual": (
            _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
        ),
        "initial_relative_normal_residual": _pcg_json_float(initial_relative),
        "original_lane_final_recurrence_relative_normal_residual": (
            _pcg_json_float(original_lane_final_relative)
        ),
        "final_recurrence_relative_normal_residual": _pcg_json_float(
            final_recurrence
        ),
        "final_relative_normal_residual": (
            _pcg_json_float(exact_relative)
            if exact_final_residual_authenticated
            else None
        ),
        "relative_normal_residual_history": recurrence_history,
        "recurrence_history_sha256": _sha256(recurrence_history),
        "exact_relative_normal_residual_checkpoints": checkpoints,
        "exact_residual_checkpoints_sha256": _sha256(checkpoints),
        "total_matvec_calls": total_matvec_calls,
        "exact_final_residual_authenticated": (
            exact_final_residual_authenticated
        ),
        "extended_after_original_lane_exact_authentication_miss": True,
        "exact_residual_used_to_initialize_continuous_lane_once": True,
        "exact_diagnostic_matvecs_modify_recurrence_state_or_direction": False,
        "continuous_row_block_lane": dict(lane_state),
        "restart_preconditioner": dict(preconditioner_state),
        "solution_finite": solution_finite,
        "solution_sha256": (
            _tensor_sha256(solution) if solution_finite else None
        ),
    }


def _single_tensor_pcg_continuous_hidden_partial_trace_body(
    *,
    role: str,
    solution: Any,
    initial_relative: float | None,
    original_lane_iterations: int,
    original_lane_final_relative: float | None,
    total_iterations: int,
    history: Sequence[float],
    exact_relative: float | None,
    exact_final_residual_authenticated: bool,
    exact_checkpoints: Sequence[Mapping[str, Any]],
    total_matvec_calls: int,
    lane_state: Mapping[str, Any],
    preconditioner_state: Mapping[str, Any],
) -> dict[str, Any]:
    torch = _torch()
    solution_finite = bool(torch.isfinite(solution).all().item())
    recurrence_history = list(history)
    checkpoints = [dict(value) for value in exact_checkpoints]
    final_recurrence = (
        recurrence_history[-1]
        if recurrence_history
        else _pcg_json_float(initial_relative)
    )
    return {
        "role": role,
        "solver": (
            "deterministic_continuous_hidden_partial_trace_"
            "cholesky_pcg_single_tensor"
        ),
        "maximum_iterations": (
            _PCG_HIDDEN_PARTIAL_TRACE_HARD_MAXIMUM_ITERATIONS
        ),
        "hard_cap_includes_original_lane_iterations": True,
        "original_lane_maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
        "original_lane_iterations_executed": original_lane_iterations,
        "single_restart_after_original_lane_exact_authentication_miss": True,
        "periodic_restart_count": 0,
        "iterations_executed": total_iterations,
        "continuous_hidden_partial_trace_lane_iterations_executed": (
            total_iterations - original_lane_iterations
        ),
        "required_relative_normal_residual": (
            _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
        ),
        "initial_relative_normal_residual": _pcg_json_float(initial_relative),
        "original_lane_final_recurrence_relative_normal_residual": (
            _pcg_json_float(original_lane_final_relative)
        ),
        "final_recurrence_relative_normal_residual": _pcg_json_float(
            final_recurrence
        ),
        "final_relative_normal_residual": (
            _pcg_json_float(exact_relative)
            if exact_final_residual_authenticated
            else None
        ),
        "relative_normal_residual_history": recurrence_history,
        "recurrence_history_sha256": _sha256(recurrence_history),
        "exact_relative_normal_residual_checkpoints": checkpoints,
        "exact_residual_checkpoints_sha256": _sha256(checkpoints),
        "total_matvec_calls": total_matvec_calls,
        "exact_final_residual_authenticated": (
            exact_final_residual_authenticated
        ),
        "extended_after_original_lane_exact_authentication_miss": True,
        "exact_residual_used_to_initialize_continuous_lane_once": True,
        "exact_diagnostic_matvecs_modify_recurrence_state_or_direction": False,
        "execution_profile": dict(
            LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE
        ),
        "execution_profile_sha256": (
            LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE_SHA256
        ),
        "continuous_hidden_partial_trace_lane": dict(lane_state),
        "restart_preconditioner": dict(preconditioner_state),
        "solution_finite": solution_finite,
        "solution_sha256": (
            _tensor_sha256(solution) if solution_finite else None
        ),
    }


def _pcg_single_tensor(
    *,
    right: Any,
    matvec: Any,
    diagonal: Any,
    initial: Any,
    role: str,
    restart_row_block_preconditioner: Any | None = None,
    restart_hidden_partial_trace_preconditioner: Any | None = None,
    restart_hidden_partial_trace_ridge: Any | None = None,
) -> tuple[Any, dict[str, Any]]:
    torch = _torch()
    solution = initial.clone()
    history: list[float] = []
    exact_checkpoints: list[dict[str, Any]] = []
    restart_schedule: list[dict[str, Any]] = []
    total_iterations = 0
    total_matvec_calls = 0
    initial_relative: float | None = None
    original_lane_iterations = 0
    original_lane_final_relative: float | None = None
    exact_residual = None
    exact_relative: float | None = None
    exact_iteration: int | None = None
    extension_triggered = False
    row_block_lane_started = False
    row_block_lane_state: dict[str, Any] = {}
    row_block_preconditioner_state: dict[str, Any] = {
        "kind": "deterministic_exact_row_block_jacobi_cholesky",
        "supplied": restart_row_block_preconditioner is not None,
        "authentication_attempted": False,
        "authenticated": False,
        "applied": False,
        "application_attempt_count": 0,
        "application_count": 0,
        "receipt": None,
        "authentication_failure_reason": None,
    }
    hidden_partial_trace_lane_started = False
    hidden_partial_trace_lane_state: dict[str, Any] = {}
    hidden_partial_trace_preconditioner_state: dict[str, Any] = {
        "kind": "deterministic_hidden_partial_trace_cholesky",
        "supplied": restart_hidden_partial_trace_preconditioner is not None,
        "authentication_attempted": False,
        "authenticated": False,
        "applied": False,
        "application_attempt_count": 0,
        "application_count": 0,
        "receipt": None,
        "authentication_failure_reason": None,
    }

    def extended_body() -> dict[str, Any]:
        if row_block_lane_started:
            return _single_tensor_pcg_continuous_row_block_body(
                role=role,
                solution=solution,
                initial_relative=initial_relative,
                original_lane_iterations=original_lane_iterations,
                original_lane_final_relative=original_lane_final_relative,
                total_iterations=total_iterations,
                history=history,
                exact_relative=exact_relative,
                exact_final_residual_authenticated=(
                    exact_iteration == total_iterations
                    and _pcg_json_float(exact_relative) is not None
                ),
                exact_checkpoints=exact_checkpoints,
                total_matvec_calls=total_matvec_calls,
                lane_state=row_block_lane_state,
                preconditioner_state=row_block_preconditioner_state,
            )
        if hidden_partial_trace_lane_started:
            return _single_tensor_pcg_continuous_hidden_partial_trace_body(
                role=role,
                solution=solution,
                initial_relative=initial_relative,
                original_lane_iterations=original_lane_iterations,
                original_lane_final_relative=original_lane_final_relative,
                total_iterations=total_iterations,
                history=history,
                exact_relative=exact_relative,
                exact_final_residual_authenticated=(
                    exact_iteration == total_iterations
                    and _pcg_json_float(exact_relative) is not None
                ),
                exact_checkpoints=exact_checkpoints,
                total_matvec_calls=total_matvec_calls,
                lane_state=hidden_partial_trace_lane_state,
                preconditioner_state=hidden_partial_trace_preconditioner_state,
            )
        return _single_tensor_pcg_extended_body(
            role=role,
            solution=solution,
            initial_relative=initial_relative,
            original_lane_iterations=original_lane_iterations,
            original_lane_final_relative=original_lane_final_relative,
            total_iterations=total_iterations,
            history=history,
            exact_relative=exact_relative,
            exact_final_residual_authenticated=(
                exact_iteration == total_iterations
                and _pcg_json_float(exact_relative) is not None
            ),
            exact_checkpoints=exact_checkpoints,
            restart_schedule=restart_schedule,
            total_matvec_calls=total_matvec_calls,
            extension_triggered=extension_triggered,
        )

    def fail_closed(
        reason: str,
        *,
        stage: str,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        failure_report = _seal(
            {
                **extended_body(),
                "status": "failed_closed",
                "failure_reason": reason,
                "failure_stage": stage,
                "failure_details": (
                    {} if details is None else dict(details)
                ),
            }
        )
        authenticated = failure_report[
            "exact_final_residual_authenticated"
        ]
        value = failure_report["final_relative_normal_residual"]
        residual_text = (
            f"{float(value):.6e}"
            if authenticated and value is not None
            else "unavailable"
        )
        raise Lfm2SequenceEffectiveAttentionFoldError(
            f"{role} PCG failed its authenticated exact residual tolerance "
            f"or solver invariant at {stage}; exact residual {residual_text}; "
            f"failure report "
            f"{failure_report['report_sha256']}.",
            failure_report=failure_report,
        )

    right_finite = bool(torch.isfinite(right).all().item())
    initial_finite = bool(torch.isfinite(solution).all().item())
    diagonal_finite = bool(torch.isfinite(diagonal).all().item())
    diagonal_positive = bool((diagonal > 0.0).all().item())
    if (
        not right_finite
        or not initial_finite
        or not diagonal_finite
        or not diagonal_positive
    ):
        fail_closed(
            "invalid_non_finite_or_non_positive_input",
            stage="input_validation",
            details={
                "right_finite": right_finite,
                "initial_finite": initial_finite,
                "diagonal_finite": diagonal_finite,
                "diagonal_strictly_positive": diagonal_positive,
            },
        )

    right_norm = torch.linalg.vector_norm(right).clamp_min(
        torch.finfo(torch.float64).eps
    )
    if not bool(torch.isfinite(right_norm).item()):
        fail_closed(
            "non_finite_right_norm",
            stage="input_validation",
        )
    applied_initial = matvec(solution)
    total_matvec_calls += 1
    residual = right - applied_initial
    if not bool(torch.isfinite(applied_initial).all().item()) or not bool(
        torch.isfinite(residual).all().item()
    ):
        fail_closed(
            "non_finite_initial_operator_application",
            stage="initial_exact_residual",
        )
    initial_relative = float(
        (torch.linalg.vector_norm(residual) / right_norm).item()
    )
    if not math.isfinite(initial_relative):
        fail_closed(
            "non_finite_initial_relative_residual",
            stage="initial_exact_residual",
        )
    exact_residual = residual
    exact_relative = initial_relative
    exact_iteration = 0
    if initial_relative <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE:
        body = {
            "role": role,
            "solver": "deterministic_jacobi_pcg_single_tensor",
            "maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
            "iterations_executed": 0,
            "required_relative_normal_residual": (
                _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
            ),
            "initial_relative_normal_residual": initial_relative,
            "final_relative_normal_residual": initial_relative,
            "relative_normal_residual_history": [],
            "solution_sha256": _tensor_sha256(solution),
        }
        return solution.contiguous(), _seal_observe_pcg_report(
            "single_tensor",
            body,
        )

    preconditioned = residual / diagonal
    direction = preconditioned.clone()
    rz = float((residual * preconditioned).sum().item())
    if not math.isfinite(rz) or rz <= 0.0:
        if not math.isfinite(rz):
            exact_iteration = None
        fail_closed(
            "non_positive_or_non_finite_preconditioned_residual",
            stage="original_lane_initialization",
            details={"residual_preconditioner_inner_product": _pcg_json_float(rz)},
        )

    original_lane_exact_checked = False
    for iteration in range(1, _PCG_MAXIMUM_ITERATIONS + 1):
        applied = matvec(direction)
        total_matvec_calls += 1
        denominator = float((direction * applied).sum().item())
        applied_finite = bool(torch.isfinite(applied).all().item())
        curvature_finite = math.isfinite(denominator)
        if (
            not applied_finite
            or not curvature_finite
            or denominator <= 0.0
        ):
            if not applied_finite or not curvature_finite:
                exact_iteration = None
            original_lane_iterations = total_iterations
            original_lane_final_relative = (
                history[-1] if history else initial_relative
            )
            fail_closed(
                "non_positive_or_non_finite_curvature",
                stage="original_lane_curvature",
                details={
                    "attempted_iteration": iteration,
                    "curvature": _pcg_json_float(denominator),
                    "curvature_finite_strictly_positive": False,
                    "curvature_matvec_call": total_matvec_calls,
                },
            )
        alpha = rz / denominator
        solution = solution + alpha * direction
        residual = residual - alpha * applied
        total_iterations = iteration
        exact_iteration = None
        if (
            not bool(torch.isfinite(solution).all().item())
            or not bool(torch.isfinite(residual).all().item())
            or not math.isfinite(alpha)
        ):
            original_lane_iterations = total_iterations
            original_lane_final_relative = (
                history[-1] if history else initial_relative
            )
            fail_closed(
                "non_finite_original_lane_update",
                stage="original_lane_update",
                details={"attempted_iteration": iteration},
            )
        relative = float(
            (torch.linalg.vector_norm(residual) / right_norm).item()
        )
        if not math.isfinite(relative):
            original_lane_iterations = total_iterations
            original_lane_final_relative = (
                history[-1] if history else initial_relative
            )
            fail_closed(
                "non_finite_original_lane_recurrence_residual",
                stage="original_lane_update",
                details={"attempted_iteration": iteration},
            )
        history.append(relative)
        if relative <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE:
            original_lane_iterations = total_iterations
            original_lane_final_relative = relative
            applied_exact = matvec(solution)
            total_matvec_calls += 1
            exact_residual = right - applied_exact
            exact_finite = (
                bool(torch.isfinite(applied_exact).all().item())
                and bool(torch.isfinite(exact_residual).all().item())
            )
            exact_relative = (
                float(
                    (
                        torch.linalg.vector_norm(exact_residual)
                        / right_norm
                    ).item()
                )
                if exact_finite
                else None
            )
            exact_finite = (
                exact_finite
                and _pcg_json_float(exact_relative) is not None
            )
            exact_iteration = total_iterations if exact_finite else None
            exact_checkpoints.append(
                {
                    "iteration": total_iterations,
                    "relative_normal_residual": (
                        _pcg_json_float(exact_relative)
                    ),
                    "finite": exact_finite,
                }
            )
            original_lane_exact_checked = True
            if (
                exact_finite
                and exact_relative is not None
                and exact_relative
                <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
            ):
                body = {
                    "role": role,
                    "solver": "deterministic_jacobi_pcg_single_tensor",
                    "maximum_iterations": _PCG_MAXIMUM_ITERATIONS,
                    "iterations_executed": iteration,
                    "required_relative_normal_residual": (
                        _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
                    ),
                    "initial_relative_normal_residual": initial_relative,
                    "final_relative_normal_residual": relative,
                    "relative_normal_residual_history": history,
                    "solution_sha256": _tensor_sha256(solution),
                }
                return solution.contiguous(), _seal_observe_pcg_report(
                    "single_tensor",
                    body,
                )
            extension_triggered = True
            break
        next_preconditioned = residual / diagonal
        next_rz = float((residual * next_preconditioned).sum().item())
        if not math.isfinite(next_rz) or next_rz <= 0.0:
            original_lane_iterations = total_iterations
            original_lane_final_relative = relative
            fail_closed(
                "non_positive_or_non_finite_preconditioned_residual",
                stage="original_lane_direction_update",
                details={
                    "attempted_iteration": iteration,
                    "residual_preconditioner_inner_product": (
                        _pcg_json_float(next_rz)
                    ),
                },
            )
        direction = next_preconditioned + (next_rz / rz) * direction
        preconditioned = next_preconditioned
        rz = next_rz

    if not original_lane_exact_checked:
        original_lane_iterations = total_iterations
        original_lane_final_relative = history[-1]
        applied_exact = matvec(solution)
        total_matvec_calls += 1
        exact_residual = right - applied_exact
        exact_finite = (
            bool(torch.isfinite(applied_exact).all().item())
            and bool(torch.isfinite(exact_residual).all().item())
        )
        exact_relative = (
            float(
                (
                    torch.linalg.vector_norm(exact_residual)
                    / right_norm
                ).item()
            )
            if exact_finite
            else None
        )
        exact_finite = (
            exact_finite and _pcg_json_float(exact_relative) is not None
        )
        exact_iteration = total_iterations if exact_finite else None
        exact_checkpoints.append(
            {
                "iteration": total_iterations,
                "relative_normal_residual": _pcg_json_float(exact_relative),
                "finite": exact_finite,
            }
        )
        extension_triggered = True

    if exact_iteration != total_iterations or exact_relative is None:
        fail_closed(
            "non_finite_original_lane_exact_residual",
            stage="original_lane_exact_authentication",
        )
    if exact_relative <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE:
        return solution.contiguous(), _seal_observe_pcg_report(
            "single_tensor",
            extended_body(),
        )

    if (
        restart_row_block_preconditioner is not None
        and restart_hidden_partial_trace_preconditioner is not None
    ):
        fail_closed(
            "multiple_restart_preconditioners_supplied",
            stage="restart_preconditioner_selection",
        )

    if (
        restart_row_block_preconditioner is not None
        or restart_hidden_partial_trace_preconditioner is not None
    ):
        use_row_block = restart_row_block_preconditioner is not None
        if use_row_block:
            row_block_lane_started = True
            active_lane_state = row_block_lane_state
            active_preconditioner_state = row_block_preconditioner_state
            continuous_hard_cap = _PCG_ROW_BLOCK_HARD_MAXIMUM_ITERATIONS
            continuous_lane_name = "continuous_row_block_lane"
            preconditioner_name = "row_block_preconditioner"
        else:
            hidden_partial_trace_lane_started = True
            active_lane_state = hidden_partial_trace_lane_state
            active_preconditioner_state = (
                hidden_partial_trace_preconditioner_state
            )
            continuous_hard_cap = (
                _PCG_HIDDEN_PARTIAL_TRACE_HARD_MAXIMUM_ITERATIONS
            )
            continuous_lane_name = "continuous_hidden_partial_trace_lane"
            preconditioner_name = "hidden_partial_trace_preconditioner"
        lane_matvec_start = total_matvec_calls
        active_lane_state.update(
            {
                "start_iteration": total_iterations,
                "planned_stop_iteration": continuous_hard_cap,
                "iterations_executed": 0,
                "attempted_matvec_calls": 0,
                "exact_diagnostic_matvec_calls": 0,
                "termination": "preconditioner_authentication",
                "ending_iteration": total_iterations,
                "ending_recurrence_relative_normal_residual": (
                    original_lane_final_relative
                ),
                "ending_exact_relative_normal_residual": exact_relative,
                "ending_exact_residual_authenticated": True,
            }
        )
        active_preconditioner_state["authentication_attempted"] = True
        try:
            if use_row_block:
                restart_factor, restart_receipt = (
                    _authenticate_restart_row_block_preconditioner(
                        supplied=restart_row_block_preconditioner,
                        right=right,
                        diagonal=diagonal,
                        role=role,
                    )
                )
            else:
                restart_factor, restart_receipt = (
                    _authenticate_restart_hidden_partial_trace_preconditioner(
                        supplied=restart_hidden_partial_trace_preconditioner,
                        right=right,
                        diagonal=diagonal,
                        role=role,
                        expected_ridge=restart_hidden_partial_trace_ridge,
                    )
                )
        except (
            _PcgRowBlockPreconditionerAuthenticationError,
            _PcgHiddenPartialTracePreconditionerAuthenticationError,
        ) as exc:
            active_preconditioner_state[
                "authentication_failure_reason"
            ] = exc.reason
            active_lane_state["termination"] = (
                "preconditioner_authentication_failure"
            )
            fail_closed(
                exc.reason,
                stage=f"{preconditioner_name}_authentication",
                details=exc.details,
            )
        active_preconditioner_state.update(
            {
                "authenticated": True,
                "receipt": restart_receipt,
            }
        )

        def apply_restart_preconditioner(value: Any) -> Any:
            active_preconditioner_state[
                "application_attempt_count"
            ] += 1
            try:
                if use_row_block:
                    result = torch.cholesky_solve(
                        value.unsqueeze(-1),
                        restart_factor,
                        upper=False,
                    ).squeeze(-1)
                else:
                    result = torch.cholesky_solve(
                        value,
                        restart_factor,
                        upper=False,
                    )
            except RuntimeError as exc:
                active_lane_state["termination"] = (
                    "preconditioner_application_failure"
                )
                fail_closed(
                    f"{preconditioner_name}_application_failed",
                    stage=f"{preconditioner_name}_application",
                    details={"exception_type": type(exc).__name__},
                )
            if not bool(torch.isfinite(result).all().item()):
                active_lane_state["termination"] = (
                    "preconditioner_application_failure"
                )
                fail_closed(
                    f"{preconditioner_name}_application_is_non_finite",
                    stage=f"{preconditioner_name}_application",
                )
            active_preconditioner_state["applied"] = True
            active_preconditioner_state["application_count"] += 1
            return result

        # This is the sole restart.  The exact residual authenticated after
        # the historical scalar lane initializes one continuous
        # partial-trace-PCG recurrence; diagnostic matvecs never replace it.
        residual = exact_residual
        preconditioned = apply_restart_preconditioner(residual)
        direction = preconditioned.clone()
        rz = float((residual * preconditioned).sum().item())
        if not math.isfinite(rz) or rz <= 0.0:
            if not math.isfinite(rz):
                exact_iteration = None
            active_lane_state["termination"] = (
                "preconditioned_residual_failure"
            )
            fail_closed(
                "non_positive_or_non_finite_preconditioned_residual",
                stage=f"{continuous_lane_name}_initialization",
                details={
                    "residual_preconditioner_inner_product": (
                        _pcg_json_float(rz)
                    ),
                },
            )
        active_lane_state["termination"] = "running"

        for attempted_iteration in range(
            total_iterations + 1,
            continuous_hard_cap + 1,
        ):
            applied = matvec(direction)
            total_matvec_calls += 1
            active_lane_state["attempted_matvec_calls"] = (
                total_matvec_calls - lane_matvec_start
            )
            denominator = float((direction * applied).sum().item())
            applied_finite = bool(torch.isfinite(applied).all().item())
            curvature_finite = math.isfinite(denominator)
            if (
                not applied_finite
                or not curvature_finite
                or denominator <= 0.0
            ):
                if not applied_finite or not curvature_finite:
                    exact_iteration = None
                active_lane_state["termination"] = (
                    "curvature_failure"
                )
                fail_closed(
                    "non_positive_or_non_finite_curvature",
                    stage=f"{continuous_lane_name}_curvature",
                    details={
                        "attempted_iteration": attempted_iteration,
                        "curvature": _pcg_json_float(denominator),
                        "curvature_finite_strictly_positive": False,
                        "curvature_matvec_call": total_matvec_calls,
                    },
                )
            alpha = rz / denominator
            solution = solution + alpha * direction
            residual = residual - alpha * applied
            total_iterations += 1
            exact_iteration = None
            active_lane_state["iterations_executed"] = (
                total_iterations - original_lane_iterations
            )
            active_lane_state[
                "ending_iteration"
            ] = total_iterations
            active_lane_state[
                "ending_exact_residual_authenticated"
            ] = False
            active_lane_state[
                "ending_exact_relative_normal_residual"
            ] = None
            if (
                not bool(torch.isfinite(solution).all().item())
                or not bool(torch.isfinite(residual).all().item())
                or not math.isfinite(alpha)
            ):
                active_lane_state["termination"] = (
                    "non_finite_update"
                )
                fail_closed(
                    f"non_finite_{continuous_lane_name}_update",
                    stage=f"{continuous_lane_name}_update",
                    details={"attempted_iteration": attempted_iteration},
                )
            relative = float(
                (torch.linalg.vector_norm(residual) / right_norm).item()
            )
            if not math.isfinite(relative):
                active_lane_state["termination"] = (
                    "non_finite_recurrence_residual"
                )
                fail_closed(
                    f"non_finite_{continuous_lane_name}_recurrence_residual",
                    stage=f"{continuous_lane_name}_update",
                    details={"attempted_iteration": attempted_iteration},
                )
            history.append(relative)
            active_lane_state[
                "ending_recurrence_relative_normal_residual"
            ] = relative

            if relative <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE:
                applied_exact = matvec(solution)
                total_matvec_calls += 1
                active_lane_state["attempted_matvec_calls"] = (
                    total_matvec_calls - lane_matvec_start
                )
                active_lane_state[
                    "exact_diagnostic_matvec_calls"
                ] += 1
                exact_residual = right - applied_exact
                exact_finite = (
                    bool(torch.isfinite(applied_exact).all().item())
                    and bool(torch.isfinite(exact_residual).all().item())
                )
                exact_relative = (
                    float(
                        (
                            torch.linalg.vector_norm(exact_residual)
                            / right_norm
                        ).item()
                    )
                    if exact_finite
                    else None
                )
                exact_finite = (
                    exact_finite
                    and _pcg_json_float(exact_relative) is not None
                )
                exact_iteration = (
                    total_iterations if exact_finite else None
                )
                exact_checkpoints.append(
                    {
                        "iteration": total_iterations,
                        "relative_normal_residual": (
                            _pcg_json_float(exact_relative)
                        ),
                        "finite": exact_finite,
                    }
                )
                active_lane_state[
                    "ending_exact_relative_normal_residual"
                ] = _pcg_json_float(exact_relative)
                active_lane_state[
                    "ending_exact_residual_authenticated"
                ] = exact_finite
                if (
                    exact_finite
                    and exact_relative is not None
                    and exact_relative
                    <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
                ):
                    active_lane_state["termination"] = (
                        "exact_tolerance_reached"
                    )
                    return solution.contiguous(), _seal_observe_pcg_report(
                        "single_tensor",
                        extended_body(),
                    )
                if not exact_finite:
                    active_lane_state["termination"] = (
                        "non_finite_exact_diagnostic"
                    )
                    fail_closed(
                        f"non_finite_{continuous_lane_name}_exact_residual",
                        stage=f"{continuous_lane_name}_exact_diagnostic",
                    )

            if total_iterations >= continuous_hard_cap:
                break
            next_preconditioned = apply_restart_preconditioner(residual)
            next_rz = float(
                (residual * next_preconditioned).sum().item()
            )
            if not math.isfinite(next_rz) or next_rz <= 0.0:
                active_lane_state["termination"] = (
                    "preconditioned_residual_failure"
                )
                fail_closed(
                    "non_positive_or_non_finite_preconditioned_residual",
                    stage=f"{continuous_lane_name}_direction_update",
                    details={
                        "attempted_iteration": attempted_iteration,
                        "residual_preconditioner_inner_product": (
                            _pcg_json_float(next_rz)
                        ),
                    },
                )
            direction = (
                next_preconditioned + (next_rz / rz) * direction
            )
            preconditioned = next_preconditioned
            rz = next_rz

        if exact_iteration != total_iterations:
            applied_exact = matvec(solution)
            total_matvec_calls += 1
            active_lane_state["attempted_matvec_calls"] = (
                total_matvec_calls - lane_matvec_start
            )
            active_lane_state[
                "exact_diagnostic_matvec_calls"
            ] += 1
            exact_residual = right - applied_exact
            exact_finite = (
                bool(torch.isfinite(applied_exact).all().item())
                and bool(torch.isfinite(exact_residual).all().item())
            )
            exact_relative = (
                float(
                    (
                        torch.linalg.vector_norm(exact_residual)
                        / right_norm
                    ).item()
                )
                if exact_finite
                else None
            )
            exact_finite = (
                exact_finite
                and _pcg_json_float(exact_relative) is not None
            )
            exact_iteration = total_iterations if exact_finite else None
            exact_checkpoints.append(
                {
                    "iteration": total_iterations,
                    "relative_normal_residual": (
                        _pcg_json_float(exact_relative)
                    ),
                    "finite": exact_finite,
                }
            )
            active_lane_state[
                "ending_exact_relative_normal_residual"
            ] = _pcg_json_float(exact_relative)
            active_lane_state[
                "ending_exact_residual_authenticated"
            ] = exact_finite
        if exact_iteration != total_iterations or exact_relative is None:
            active_lane_state["termination"] = (
                "non_finite_final_exact_residual"
            )
            fail_closed(
                f"non_finite_{continuous_lane_name}_exact_residual",
                stage=f"{continuous_lane_name}_final_exact_authentication",
            )
        if exact_relative <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE:
            active_lane_state["termination"] = (
                "exact_tolerance_reached_at_hard_cap"
            )
            return solution.contiguous(), _seal_observe_pcg_report(
                "single_tensor",
                extended_body(),
            )
        active_lane_state["termination"] = (
            "hard_iteration_cap_reached"
        )
        fail_closed(
            "hard_iteration_cap_reached",
            stage=f"{continuous_lane_name}_hard_iteration_cap",
        )

    while total_iterations < _PCG_HARD_MAXIMUM_ITERATIONS:
        block_start = total_iterations
        block_stop = min(
            block_start + _PCG_RESTART_BLOCK_ITERATIONS,
            _PCG_HARD_MAXIMUM_ITERATIONS,
        )
        residual = exact_residual
        preconditioned = residual / diagonal
        direction = preconditioned.clone()
        rz = float((residual * preconditioned).sum().item())
        if not math.isfinite(rz) or rz <= 0.0:
            if not math.isfinite(rz):
                exact_iteration = None
            fail_closed(
                "non_positive_or_non_finite_preconditioned_residual",
                stage="restart_initialization",
                details={
                    "restart_iteration": block_start,
                    "residual_preconditioner_inner_product": (
                        _pcg_json_float(rz)
                    ),
                },
            )
        block_history_start = len(history)
        block_matvec_start = total_matvec_calls
        exact_checkpoint_taken = False

        for attempted_iteration in range(block_start + 1, block_stop + 1):
            applied = matvec(direction)
            total_matvec_calls += 1
            denominator = float((direction * applied).sum().item())
            applied_finite = bool(torch.isfinite(applied).all().item())
            curvature_finite = math.isfinite(denominator)
            if (
                not applied_finite
                or not curvature_finite
                or denominator <= 0.0
            ):
                if not applied_finite or not curvature_finite:
                    exact_iteration = None
                exact_is_current = exact_iteration == total_iterations
                restart_schedule.append(
                    {
                        "restart_iteration": block_start,
                        "planned_stop_iteration": block_stop,
                        "iterations_executed": (
                            len(history) - block_history_start
                        ),
                        "ending_iteration": total_iterations,
                        "attempted_matvec_calls": (
                            total_matvec_calls - block_matvec_start
                        ),
                        "termination": "curvature_failure",
                        "ending_recurrence_relative_normal_residual": (
                            history[-1]
                        ),
                        "ending_exact_relative_normal_residual": (
                            _pcg_json_float(exact_relative)
                            if exact_is_current
                            else None
                        ),
                        "ending_exact_residual_authenticated": exact_is_current,
                    }
                )
                fail_closed(
                    "non_positive_or_non_finite_curvature",
                    stage="restart_curvature",
                    details={
                        "attempted_iteration": attempted_iteration,
                        "curvature": _pcg_json_float(denominator),
                        "curvature_finite_strictly_positive": False,
                        "curvature_matvec_call": total_matvec_calls,
                    },
                )
            alpha = rz / denominator
            solution = solution + alpha * direction
            residual = residual - alpha * applied
            total_iterations += 1
            exact_iteration = None
            if (
                not bool(torch.isfinite(solution).all().item())
                or not bool(torch.isfinite(residual).all().item())
                or not math.isfinite(alpha)
            ):
                fail_closed(
                    "non_finite_restart_update",
                    stage="restart_update",
                    details={"attempted_iteration": attempted_iteration},
                )
            relative = float(
                (torch.linalg.vector_norm(residual) / right_norm).item()
            )
            if not math.isfinite(relative):
                fail_closed(
                    "non_finite_restart_recurrence_residual",
                    stage="restart_update",
                    details={"attempted_iteration": attempted_iteration},
                )
            history.append(relative)
            if relative <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE:
                applied_exact = matvec(solution)
                total_matvec_calls += 1
                exact_residual = right - applied_exact
                exact_finite = (
                    bool(torch.isfinite(applied_exact).all().item())
                    and bool(torch.isfinite(exact_residual).all().item())
                )
                exact_relative = (
                    float(
                        (
                            torch.linalg.vector_norm(exact_residual)
                            / right_norm
                        ).item()
                    )
                    if exact_finite
                    else None
                )
                exact_finite = (
                    exact_finite
                    and _pcg_json_float(exact_relative) is not None
                )
                exact_iteration = total_iterations if exact_finite else None
                exact_checkpoints.append(
                    {
                        "iteration": total_iterations,
                        "relative_normal_residual": (
                            _pcg_json_float(exact_relative)
                        ),
                        "finite": exact_finite,
                    }
                )
                exact_checkpoint_taken = True
                break
            next_preconditioned = residual / diagonal
            next_rz = float((residual * next_preconditioned).sum().item())
            if not math.isfinite(next_rz) or next_rz <= 0.0:
                fail_closed(
                    "non_positive_or_non_finite_preconditioned_residual",
                    stage="restart_direction_update",
                    details={
                        "attempted_iteration": attempted_iteration,
                        "residual_preconditioner_inner_product": (
                            _pcg_json_float(next_rz)
                        ),
                    },
                )
            direction = next_preconditioned + (next_rz / rz) * direction
            preconditioned = next_preconditioned
            rz = next_rz

        if not exact_checkpoint_taken:
            applied_exact = matvec(solution)
            total_matvec_calls += 1
            exact_residual = right - applied_exact
            exact_finite = (
                bool(torch.isfinite(applied_exact).all().item())
                and bool(torch.isfinite(exact_residual).all().item())
            )
            exact_relative = (
                float(
                    (
                        torch.linalg.vector_norm(exact_residual)
                        / right_norm
                    ).item()
                )
                if exact_finite
                else None
            )
            exact_finite = (
                exact_finite and _pcg_json_float(exact_relative) is not None
            )
            exact_iteration = total_iterations if exact_finite else None
            exact_checkpoints.append(
                {
                    "iteration": total_iterations,
                    "relative_normal_residual": _pcg_json_float(exact_relative),
                    "finite": exact_finite,
                }
            )

        exact_authenticated = exact_iteration == total_iterations
        restart_schedule.append(
            {
                "restart_iteration": block_start,
                "planned_stop_iteration": block_stop,
                "iterations_executed": len(history) - block_history_start,
                "ending_iteration": total_iterations,
                "attempted_matvec_calls": (
                    total_matvec_calls - block_matvec_start
                ),
                "termination": (
                    "exact_tolerance_reached"
                    if exact_authenticated
                    and exact_relative is not None
                    and exact_relative
                    <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE
                    else "block_boundary"
                ),
                "ending_recurrence_relative_normal_residual": history[-1],
                "ending_exact_relative_normal_residual": (
                    _pcg_json_float(exact_relative)
                    if exact_authenticated
                    else None
                ),
                "ending_exact_residual_authenticated": exact_authenticated,
            }
        )
        if not exact_authenticated or exact_relative is None:
            fail_closed(
                "non_finite_restart_exact_residual",
                stage="restart_exact_authentication",
            )
        if exact_relative <= _PCG_RELATIVE_NORMAL_RESIDUAL_TOLERANCE:
            return solution.contiguous(), _seal_observe_pcg_report(
                "single_tensor",
                extended_body(),
            )

    fail_closed(
        "hard_iteration_cap_reached",
        stage="hard_iteration_cap",
    )
    raise AssertionError("unreachable")


def _canonicalize_value_factor(
    value_factor: Any,
    output_blocks: Any,
) -> tuple[Any, Any]:
    factors = value_factor.clone()
    blocks = output_blocks.clone()
    groups, _hidden, head_dim = map(int, factors.shape)
    heads_per_group = int(blocks.shape[0]) // groups
    for group in range(groups):
        head_slice = slice(
            group * heads_per_group,
            (group + 1) * heads_per_group,
        )
        for coordinate in range(head_dim):
            pivot = int(factors[group, :, coordinate].abs().argmax().item())
            if float(factors[group, pivot, coordinate].item()) < 0.0:
                factors[group, :, coordinate] *= -1.0
                blocks[head_slice, coordinate, :] *= -1.0
    return factors.contiguous(), blocks.contiguous()


def _context_heads(
    attended_inputs: Any,
    value_factor: Any,
    *,
    heads_per_group: int,
) -> Any:
    torch = _torch()
    return torch.stack(
        [
            attended_inputs[:, head]
            @ value_factor[head // heads_per_group]
            for head in range(int(attended_inputs.shape[1]))
        ],
        dim=1,
    )


def _fit_output(
    attended_inputs: Any,
    target: Any,
    value_factor: Any,
    *,
    heads_per_group: int,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    role: str,
    output_seed: Any | None = None,
) -> tuple[Any, Any, dict[str, Any]]:
    contexts = _context_heads(
        attended_inputs,
        value_factor,
        heads_per_group=heads_per_group,
    )
    features = contexts.reshape(
        int(contexts.shape[0]),
        int(contexts.shape[1]) * int(contexts.shape[2]),
    )
    if output_seed is None:
        output_transpose, report = _ridge_solve(
            features,
            target,
            policy=policy,
            role=role,
        )
    else:
        seed = output_seed.reshape(
            int(contexts.shape[1]) * int(contexts.shape[2]),
            int(target.shape[1]),
        )
        residual_target = target - features @ seed
        delta, delta_report = _ridge_solve(
            features,
            residual_target,
            policy=policy,
            role=f"{role}_zero_centered_delta",
        )
        output_transpose = seed + delta
        report = _seal(
            {
                "role": role,
                "parameterization": (
                    "output_blocks=output_seed+zero_centered_delta"
                ),
                "zero_delta_ridge_anchor": True,
                "output_seed_sha256": _tensor_sha256(output_seed),
                "delta_sha256": _tensor_sha256(delta),
                "delta_solve_report_sha256": delta_report["report_sha256"],
                "relative_rmse": _relative_rmse(
                    features @ output_transpose,
                    target,
                ),
                "solution_sha256": _tensor_sha256(output_transpose),
            }
        )
    output_blocks = output_transpose.reshape(
        int(contexts.shape[1]),
        int(contexts.shape[2]),
        int(target.shape[1]),
    )
    return output_blocks.contiguous(), features, report


def _prediction(
    attended_inputs: Any,
    value_factor: Any,
    output_blocks: Any,
    *,
    heads_per_group: int,
) -> Any:
    contexts = _context_heads(
        attended_inputs,
        value_factor,
        heads_per_group=heads_per_group,
    )
    return _torch().einsum("nhd,hdo->no", contexts, output_blocks)


def _initial_shared_value_factors(
    effective: Any,
    *,
    target_key_value_heads: int,
    heads_per_group: int,
    head_dim: int,
) -> tuple[Any, Any, list[dict[str, Any]]]:
    torch = _torch()
    value_groups = []
    output_blocks = []
    reports = []
    for group in range(target_key_value_heads):
        head_slice = slice(
            group * heads_per_group,
            (group + 1) * heads_per_group,
        )
        concatenated = torch.cat(
            tuple(effective[head_slice]),
            dim=1,
        )
        left, singular, right = torch.linalg.svd(
            concatenated,
            full_matrices=False,
        )
        if int(singular.numel()) < head_dim:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "The effective operator cannot support the target head dimension."
            )
        root = singular[:head_dim].clamp_min(0.0).sqrt()
        value_group = left[:, :head_dim] * root.unsqueeze(0)
        output_group = (
            root.unsqueeze(1) * right[:head_dim]
        ).reshape(
            head_dim,
            heads_per_group,
            int(effective.shape[-1]),
        ).permute(1, 0, 2)
        value_groups.append(value_group)
        output_blocks.append(output_group)
        reports.append(
            {
                "group": group,
                "singular_values": [
                    float(value) for value in singular[:head_dim].tolist()
                ],
                "retained_rank": head_dim,
                "concatenated_effective_operator_sha256": (
                    _tensor_sha256(concatenated)
                ),
            }
        )
    factors = torch.stack(value_groups, dim=0)
    blocks = torch.cat(output_blocks, dim=0)
    factors, blocks = _canonicalize_value_factor(factors, blocks)
    return factors, blocks, reports


def _block_value_sweep(
    attended_inputs: Any,
    target: Any,
    value_factor: Any,
    output_blocks: Any,
    *,
    heads_per_group: int,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    iteration: int,
    value_seed: Any | None = None,
) -> tuple[Any, list[dict[str, Any]]]:
    torch = _torch()
    updated = value_factor.clone()
    reports = []
    group_count = int(updated.shape[0])
    for group in range(group_count):
        prediction = _prediction(
            attended_inputs,
            updated,
            output_blocks,
            heads_per_group=heads_per_group,
        )
        start = group * heads_per_group
        stop = start + heads_per_group
        group_context = torch.stack(
            [
                attended_inputs[:, head] @ updated[group]
                for head in range(start, stop)
            ],
            dim=1,
        )
        group_prediction = torch.einsum(
            "nhd,hdo->no",
            group_context,
            output_blocks[start:stop],
        )
        if value_seed is None:
            residual = target - (prediction - group_prediction)
        else:
            seed_context = torch.stack(
                [
                    attended_inputs[:, head] @ value_seed[group]
                    for head in range(start, stop)
                ],
                dim=1,
            )
            seed_prediction = torch.einsum(
                "nhd,hdo->no",
                seed_context,
                output_blocks[start:stop],
            )
            residual = target - (
                prediction - group_prediction + seed_prediction
            )
        coefficients = torch.einsum(
            "nhi,hdo->noid",
            attended_inputs[:, start:stop],
            output_blocks[start:stop],
        ).reshape(
            int(target.shape[0]) * int(target.shape[1]),
            int(attended_inputs.shape[2]) * int(updated.shape[2]),
        )
        solution, solve_report = _ridge_solve(
            coefficients,
            residual.reshape(-1, 1),
            policy=policy,
            role=f"sequence_effective_value_iteration_{iteration}_group_{group}",
        )
        solved_group = solution.reshape(
            int(attended_inputs.shape[2]),
            int(updated.shape[2]),
        )
        if value_seed is None:
            updated[group] = solved_group
            reports.append(solve_report)
        else:
            updated[group] = value_seed[group] + solved_group
            reports.append(
                _seal(
                    {
                        "role": (
                            f"sequence_effective_value_iteration_{iteration}_"
                            f"group_{group}"
                        ),
                        "parameterization": (
                            "value_group=value_seed+zero_centered_delta"
                        ),
                        "zero_delta_ridge_anchor": True,
                        "value_seed_group_sha256": _tensor_sha256(
                            value_seed[group]
                        ),
                        "delta_sha256": _tensor_sha256(solved_group),
                        "delta_solve_report_sha256": (
                            solve_report["report_sha256"]
                        ),
                        "solution_sha256": _tensor_sha256(updated[group]),
                    }
                )
            )
    return updated.contiguous(), reports


def _effective_operator_value_sweep(
    effective: Any,
    value_factor: Any,
    output_blocks: Any,
    *,
    heads_per_group: int,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    iteration: int,
) -> tuple[Any, list[dict[str, Any]]]:
    """Update shared V against headwise effective operators without row tensors."""

    updated = value_factor.clone()
    reports = []
    for group in range(int(updated.shape[0])):
        start = group * heads_per_group
        stop = start + heads_per_group
        effective_group = _torch().cat(
            tuple(effective[start:stop]),
            dim=1,
        )
        output_group = _torch().cat(
            tuple(output_blocks[start:stop]),
            dim=1,
        )
        value_transpose, solve_report = _ridge_solve(
            output_group.T,
            effective_group.T,
            policy=policy,
            role=(
                f"sequence_effective_streamed_value_iteration_{iteration}_"
                f"group_{group}"
            ),
        )
        updated[group] = value_transpose.T
        reports.append(solve_report)
    return updated.contiguous(), reports


def _producer_value_anchor(
    value_factor: Any,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    *,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
) -> tuple[Any, list[dict[str, Any]]]:
    torch = _torch()
    topology = producer.topology
    anchored = value_factor.clone()
    reports = []
    producer_value = producer.value_weight.detach().to(
        device="cpu",
        dtype=torch.float64,
    )
    for group in range(topology.target_key_value_heads):
        value_slice = slice(
            group * topology.head_dim,
            (group + 1) * topology.head_dim,
        )
        anchor = producer_value[value_slice].T.contiguous()
        gram = anchor.T @ anchor + policy.absolute_ridge_floor * torch.eye(
            topology.head_dim,
            dtype=torch.float64,
        )
        alignment = torch.linalg.solve(
            gram,
            anchor.T @ anchored[group],
        )
        aligned_anchor = anchor @ alignment
        anchored[group] = (
            (1.0 - policy.value_anchor_fraction) * anchored[group]
            + policy.value_anchor_fraction * aligned_anchor
        )
        reports.append(
            {
                "group": group,
                "anchor_fraction": policy.value_anchor_fraction,
                "producer_value_group_sha256": _tensor_sha256(anchor),
                "alignment_sha256": _tensor_sha256(alignment),
                "anchored_value_group_sha256": _tensor_sha256(anchored[group]),
            }
        )
    return anchored.contiguous(), reports


def _fit_context_preservation(
    *,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    normalized_cases: Sequence[Mapping[str, Any]],
    fit_cases: Sequence[Lfm2CachedAttentionFoldCase],
    materialized_value_factor: Any,
) -> float:
    torch = _torch()
    topology = producer.topology
    predictions = []
    targets = []
    for normalized, case in zip(normalized_cases, fit_cases, strict=True):
        child_heads = _context_heads(
            normalized["weighted_inputs"],
            materialized_value_factor,
            heads_per_group=topology.target_query_heads_per_group,
        )
        parent_context = case.parent_context.detach().to(
            device="cpu",
            dtype=torch.float64,
        )
        target_heads = []
        for members, weights in zip(
            producer.query_groups,
            producer.query_barycentric_weights,
            strict=True,
        ):
            selected = parent_context.index_select(
                1,
                torch.tensor(members, dtype=torch.long),
            )
            coefficients = torch.tensor(
                weights,
                dtype=torch.float64,
            ).reshape(1, len(members), 1, 1)
            target_heads.append((selected * coefficients).sum(dim=1))
        target = torch.stack(target_heads, dim=1)
        predictions.append(child_heads.reshape(-1, topology.head_dim))
        targets.append(target.reshape(-1, topology.head_dim))
    return _relative_rmse(
        torch.cat(predictions, dim=0),
        torch.cat(targets, dim=0),
    )


def _case_query_row_weights(
    case: Lfm2CachedAttentionFoldCase,
    *,
    case_index: int,
    batch: int,
    query_length: int,
) -> tuple[Any, bool]:
    torch = _torch()
    if case.query_row_sqrt_weights is None:
        return (
            torch.ones(batch, query_length, dtype=torch.float64),
            False,
        )
    weights = _tensor(
        case.query_row_sqrt_weights,
        f"fit_cases[{case_index}].query_row_sqrt_weights",
        dimensions=2,
    ).to(torch.float64)
    if tuple(weights.shape) != (batch, query_length) or bool(
        (weights <= 0.0).any().item()
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Fit row weights must be positive and query-aligned."
        )
    return weights, True


def _normalize_sequence_case(
    case: Lfm2CachedAttentionFoldCase,
    *,
    case_index: int,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    query_norm_weight: Any | None,
    key_norm_weight: Any | None,
    norm_epsilon: float,
) -> Mapping[str, Any]:
    try:
        return structural._normalize_attention_value_output_case(
            case,
            case_index=case_index,
            producer=producer,
            query_norm_weight=query_norm_weight,
            key_norm_weight=key_norm_weight,
            normalized_query_norm_weight=query_norm_weight,
            normalized_key_norm_weight=key_norm_weight,
            norm_epsilon=norm_epsilon,
        )
    except structural.Lfm2StructuralResidualAttentionFoldError as exc:
        raise Lfm2SequenceEffectiveAttentionFoldError(str(exc)) from exc


def _accumulate_streamed_sequence_statistics(
    *,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    cases: Sequence[Lfm2CachedAttentionFoldCase],
    query_norm_weight: Any | None,
    key_norm_weight: Any | None,
    norm_epsilon: float,
) -> tuple[Mapping[str, Any], dict[str, Any], int]:
    torch = _torch()
    topology = producer.topology
    cross = torch.zeros(
        topology.target_query_heads,
        topology.target_query_heads,
        topology.target_hidden_size,
        topology.target_hidden_size,
        dtype=torch.float64,
    )
    right = torch.zeros(
        topology.target_query_heads,
        topology.target_hidden_size,
        topology.target_output_size,
        dtype=torch.float64,
    )
    target_square_sum = 0.0
    row_count = 0
    explicit_weight_count = 0
    chunk_count = 0
    for case_index, case in enumerate(cases):
        normalized = _normalize_sequence_case(
            case,
            case_index=case_index,
            producer=producer,
            query_norm_weight=query_norm_weight,
            key_norm_weight=key_norm_weight,
            norm_epsilon=norm_epsilon,
        )
        batch = int(normalized["batch"])
        query_length = int(normalized["query_length"])
        attended = normalized["weighted_inputs"].permute(
            0,
            2,
            1,
            3,
        ).reshape(
            batch * query_length,
            topology.target_query_heads,
            topology.target_hidden_size,
        )
        row_weights, explicit = _case_query_row_weights(
            case,
            case_index=case_index,
            batch=batch,
            query_length=query_length,
        )
        explicit_weight_count += int(explicit)
        weight = row_weights.reshape(-1, 1)
        weighted_attended = attended * weight.unsqueeze(1)
        weighted_target = normalized["endpoint"] * weight
        for start in range(
            0,
            int(weighted_attended.shape[0]),
            _STATISTICS_ROW_CHUNK_SIZE,
        ):
            stop = min(
                start + _STATISTICS_ROW_CHUNK_SIZE,
                int(weighted_attended.shape[0]),
            )
            design = weighted_attended[start:stop]
            target = weighted_target[start:stop]
            for head in range(topology.target_query_heads):
                right[head].add_(design[:, head].T @ target)
                for other in range(head, topology.target_query_heads):
                    block = design[:, head].T @ design[:, other]
                    cross[head, other].add_(block)
                    if other != head:
                        cross[other, head].add_(block.T)
            target_square_sum += float(target.square().sum().item())
            row_count += int(target.shape[0])
            chunk_count += 1
    statistics = MappingProxyType(
        {
            "cross_head_gram": cross,
            "endpoint_right": right,
            "endpoint_square_sum": target_square_sum,
            "row_count": row_count,
        }
    )
    body = {
        "role": "streamed_sequence_effective_sufficient_statistics",
        "row_count": row_count,
        "chunk_count": chunk_count,
        "row_chunk_size": _STATISTICS_ROW_CHUNK_SIZE,
        "cross_head_gram_shape": list(cross.shape),
        "endpoint_right_shape": list(right.shape),
        "cross_head_gram_sha256": _tensor_sha256(cross),
        "endpoint_right_sha256": _tensor_sha256(right),
        "endpoint_square_sum": target_square_sum,
        "accumulation_dtype": "torch.float64",
        "full_cross_head_symmetry_materialized": True,
        "row_design_released_after_each_case": True,
        "forbidden_value_coefficient_tensor_materialized": False,
        "forbidden_hidden_head_dim_gram_materialized": False,
    }
    return statistics, _seal(body), explicit_weight_count


def _fit_streamed_global_effective_operator(
    *,
    statistics: Mapping[str, Any],
    topology: Any,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
) -> tuple[Any, dict[str, Any]]:
    torch = _torch()
    cross = statistics["cross_head_gram"]
    right = statistics["endpoint_right"]
    feature_count = topology.target_query_heads * topology.target_hidden_size
    trace_scale = (
        sum(
            float(torch.trace(cross[head, head]).item())
            for head in range(topology.target_query_heads)
        )
        / feature_count
    )
    ridge = max(
        policy.absolute_ridge_floor,
        policy.ridge_scale * max(trace_scale, 0.0),
    )
    diagonal = torch.stack(
        [
            torch.diagonal(cross[head, head]) + ridge
            for head in range(topology.target_query_heads)
        ],
        dim=0,
    ).clamp_min(policy.absolute_ridge_floor)

    def matvec(value: Any) -> Any:
        result = torch.zeros_like(value)
        for head in range(topology.target_query_heads):
            for other in range(topology.target_query_heads):
                result[head].add_(cross[head, other] @ value[other])
        return result + ridge * value

    solution, pcg_report = _pcg_multi_rhs(
        right=right,
        matvec=matvec,
        diagonal=diagonal,
        role="sequence_effective_complete_causal_operator_pcg",
    )
    applied = matvec(solution)
    normal_residual = float(
        (
            torch.linalg.vector_norm(applied - right)
            / torch.linalg.vector_norm(right).clamp_min(
                torch.finfo(torch.float64).eps
            )
        ).item()
    )
    body = {
        "role": "sequence_effective_complete_causal_operator",
        "rows": statistics["row_count"],
        "features": feature_count,
        "outputs": topology.target_output_size,
        "system_domain": "streamed_cross_head_statistics_pcg",
        "linear_system_dimension": feature_count,
        "ridge_scale": policy.ridge_scale,
        "trace_scale": trace_scale,
        "ridge": ridge,
        "relative_normal_residual": normal_residual,
        "pcg_report": pcg_report,
        "solution_sha256": _tensor_sha256(solution),
    }
    return solution.contiguous(), _seal(body)


def _fit_streamed_headwise_effective_operator(
    *,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    cases: Sequence[Lfm2CachedAttentionFoldCase],
    query_norm_weight: Any | None,
    key_norm_weight: Any | None,
    norm_epsilon: float,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
) -> tuple[Any, dict[str, Any], int]:
    """Fit target-head contribution operators from streamed sufficient stats."""

    torch = _torch()
    topology = producer.topology
    grams = [
        torch.zeros(
            topology.target_hidden_size,
            topology.target_hidden_size,
            dtype=torch.float64,
        )
        for _head in range(topology.target_query_heads)
    ]
    rights = [
        torch.zeros(
            topology.target_hidden_size,
            topology.target_output_size,
            dtype=torch.float64,
        )
        for _head in range(topology.target_query_heads)
    ]
    target_square_sums = [0.0] * topology.target_query_heads
    row_counts = [0] * topology.target_query_heads
    explicit_weight_count = 0
    for case_index, case in enumerate(cases):
        normalized = _normalize_sequence_case(
            case,
            case_index=case_index,
            producer=producer,
            query_norm_weight=query_norm_weight,
            key_norm_weight=key_norm_weight,
            norm_epsilon=norm_epsilon,
        )
        batch = int(normalized["batch"])
        query_length = int(normalized["query_length"])
        attended = normalized["weighted_inputs"].permute(
            0,
            2,
            1,
            3,
        ).reshape(
            batch * query_length,
            topology.target_query_heads,
            topology.target_hidden_size,
        )
        row_weights, explicit = _case_query_row_weights(
            case,
            case_index=case_index,
            batch=batch,
            query_length=query_length,
        )
        explicit_weight_count += int(explicit)
        contribution = _tensor(
            case.parent_contribution,
            f"fit_cases[{case_index}].parent_contribution",
            dimensions=4,
        ).to(torch.float64)
        if tuple(contribution.shape) != (
            batch,
            topology.source_query_heads,
            query_length,
            topology.target_output_size,
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Streamed headwise ridge requires complete target-space "
                "parent attention-head contributions."
            )
        weight = row_weights.reshape(-1, 1)
        for target_head, members in enumerate(producer.query_groups):
            index = torch.tensor(members, dtype=torch.long)
            target = contribution.index_select(1, index).sum(dim=1).reshape(
                batch * query_length,
                topology.target_output_size,
            )
            design = attended[:, target_head]
            weighted_design = design * weight
            weighted_target = target * weight
            grams[target_head].add_(weighted_design.T @ weighted_design)
            rights[target_head].add_(weighted_design.T @ weighted_target)
            target_square_sums[target_head] += float(
                weighted_target.square().sum().item()
            )
            row_counts[target_head] += int(weighted_design.shape[0])
    effective = []
    solve_reports = []
    for head in range(topology.target_query_heads):
        solution, report = _ridge_solve_statistics(
            grams[head],
            rights[head],
            target_square_sum=target_square_sums[head],
            rows=row_counts[head],
            policy=policy,
            role=f"sequence_effective_streamed_head_{head}",
        )
        effective.append(solution)
        solve_reports.append(report)
    body = {
        "role": "sequence_effective_streamed_headwise_contribution_operator",
        "head_count": topology.target_query_heads,
        "head_solve_report_sha256": [
            report["report_sha256"] for report in solve_reports
        ],
        "largest_linear_system_dimension": topology.target_hidden_size,
        "complete_parent_contribution_partition": True,
        "source_head_groups_partitioned_without_drop": (
            sorted(
                member
                for group in producer.query_groups
                for member in group
            )
            == list(range(topology.source_query_heads))
        ),
        "global_hq_times_hidden_gram_materialized": False,
        "row_design_materialized_across_cases": False,
    }
    return (
        torch.stack(effective, dim=0).contiguous(),
        _seal(body),
        explicit_weight_count,
    )


def _fit_output_streamed(
    *,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    cases: Sequence[Lfm2CachedAttentionFoldCase],
    query_norm_weight: Any | None,
    key_norm_weight: Any | None,
    norm_epsilon: float,
    value_factor: Any,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    role: str,
) -> tuple[Any, dict[str, Any]]:
    """Fit O from streamed Hq*head_dim context sufficient statistics."""

    torch = _torch()
    topology = producer.topology
    feature_count = topology.target_query_heads * topology.head_dim
    gram = torch.zeros(feature_count, feature_count, dtype=torch.float64)
    right = torch.zeros(
        feature_count,
        topology.target_output_size,
        dtype=torch.float64,
    )
    target_square_sum = 0.0
    row_count = 0
    for case_index, case in enumerate(cases):
        normalized = _normalize_sequence_case(
            case,
            case_index=case_index,
            producer=producer,
            query_norm_weight=query_norm_weight,
            key_norm_weight=key_norm_weight,
            norm_epsilon=norm_epsilon,
        )
        batch = int(normalized["batch"])
        query_length = int(normalized["query_length"])
        attended = normalized["weighted_inputs"].permute(
            0,
            2,
            1,
            3,
        ).reshape(
            batch * query_length,
            topology.target_query_heads,
            topology.target_hidden_size,
        )
        features = _context_heads(
            attended,
            value_factor,
            heads_per_group=topology.target_query_heads_per_group,
        ).reshape(batch * query_length, feature_count)
        row_weights, _explicit = _case_query_row_weights(
            case,
            case_index=case_index,
            batch=batch,
            query_length=query_length,
        )
        weight = row_weights.reshape(-1, 1)
        weighted_features = features * weight
        weighted_target = normalized["endpoint"] * weight
        gram.add_(weighted_features.T @ weighted_features)
        right.add_(weighted_features.T @ weighted_target)
        target_square_sum += float(weighted_target.square().sum().item())
        row_count += int(weighted_features.shape[0])
    output_transpose, report = _ridge_solve_statistics(
        gram,
        right,
        target_square_sum=target_square_sum,
        rows=row_count,
        policy=policy,
        role=role,
    )
    return (
        output_transpose.reshape(
            topology.target_query_heads,
            topology.head_dim,
            topology.target_output_size,
        ).contiguous(),
        report,
    )


def _output_statistics_from_sequence_statistics(
    *,
    statistics: Mapping[str, Any],
    topology: Any,
    value_factor: Any,
) -> tuple[Any, Any]:
    """Project cached hidden-space Gram/right into the target O domain."""

    torch = _torch()
    cross = statistics["cross_head_gram"]
    right = statistics["endpoint_right"]
    feature_count = topology.target_query_heads * topology.head_dim
    gram = torch.zeros(feature_count, feature_count, dtype=torch.float64)
    output_right = torch.zeros(
        feature_count,
        topology.target_output_size,
        dtype=torch.float64,
    )
    for head in range(topology.target_query_heads):
        group = head // topology.target_query_heads_per_group
        head_slice = slice(
            head * topology.head_dim,
            (head + 1) * topology.head_dim,
        )
        output_right[head_slice] = value_factor[group].T @ right[head]
        for other in range(topology.target_query_heads):
            other_group = other // topology.target_query_heads_per_group
            other_slice = slice(
                other * topology.head_dim,
                (other + 1) * topology.head_dim,
            )
            gram[head_slice, other_slice] = (
                value_factor[group].T
                @ cross[head, other]
                @ value_factor[other_group]
            )
    return gram, output_right


def _sequence_statistics_relative_rmse(
    *,
    statistics: Mapping[str, Any],
    topology: Any,
    value_factor: Any,
    output_blocks: Any,
) -> float:
    """Score one finite V/O proposal from exact fit sufficient statistics."""

    torch = _torch()
    gram, output_right = _output_statistics_from_sequence_statistics(
        statistics=statistics,
        topology=topology,
        value_factor=value_factor,
    )
    output_transpose = output_blocks.reshape(
        topology.target_query_heads * topology.head_dim,
        topology.target_output_size,
    )
    prediction_square = float(
        (
            output_transpose
            * (gram @ output_transpose)
        ).sum().item()
    )
    target_cross = float(
        (output_transpose * output_right).sum().item()
    )
    target_square = float(statistics["endpoint_square_sum"])
    squared_error = max(
        prediction_square - 2.0 * target_cross + target_square,
        0.0,
    )
    result = math.sqrt(
        squared_error / max(target_square, torch.finfo(torch.float64).eps)
    )
    if not math.isfinite(result):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Sequence-effective proposal fit is non-finite."
        )
    return result


def _fit_output_from_sequence_statistics(
    *,
    statistics: Mapping[str, Any],
    topology: Any,
    value_factor: Any,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    role: str,
    output_seed: Any | None = None,
) -> tuple[Any, dict[str, Any]]:
    feature_count = topology.target_query_heads * topology.head_dim
    gram, output_right = _output_statistics_from_sequence_statistics(
        statistics=statistics,
        topology=topology,
        value_factor=value_factor,
    )
    if output_seed is None:
        output_transpose, report = _ridge_solve_statistics(
            gram,
            output_right,
            target_square_sum=float(statistics["endpoint_square_sum"]),
            rows=int(statistics["row_count"]),
            policy=policy,
            role=role,
        )
    else:
        seed = output_seed.reshape(
            feature_count,
            topology.target_output_size,
        )
        seed_prediction_square = float((seed * (gram @ seed)).sum().item())
        seed_cross = float((seed * output_right).sum().item())
        residual_square_sum = max(
            float(statistics["endpoint_square_sum"])
            - 2.0 * seed_cross
            + seed_prediction_square,
            0.0,
        )
        delta, delta_report = _ridge_solve_statistics(
            gram,
            output_right - gram @ seed,
            target_square_sum=residual_square_sum,
            rows=int(statistics["row_count"]),
            policy=policy,
            role=f"{role}_zero_centered_delta",
        )
        output_transpose = seed + delta
        report = _seal(
            {
                "role": role,
                "parameterization": (
                    "output_blocks=output_seed+zero_centered_delta"
                ),
                "zero_delta_ridge_anchor": True,
                "output_seed_sha256": _tensor_sha256(output_seed),
                "delta_sha256": _tensor_sha256(delta),
                "delta_solve_report_sha256": delta_report["report_sha256"],
                "relative_rmse": _sequence_statistics_relative_rmse(
                    statistics=statistics,
                    topology=topology,
                    value_factor=value_factor,
                    output_blocks=output_transpose.reshape(
                        topology.target_query_heads,
                        topology.head_dim,
                        topology.target_output_size,
                    ),
                ),
                "solution_sha256": _tensor_sha256(output_transpose),
            }
        )
    return (
        output_transpose.reshape(
            topology.target_query_heads,
            topology.head_dim,
            topology.target_output_size,
        ).contiguous(),
        report,
    )


def _structured_value_pcg_sweep(
    *,
    statistics: Mapping[str, Any],
    topology: Any,
    value_factor: Any,
    output_blocks: Any,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    iteration: int,
    value_seed: Any | None = None,
) -> tuple[Any, list[dict[str, Any]]]:
    torch = _torch()
    cross = statistics["cross_head_gram"]
    endpoint_right = statistics["endpoint_right"]
    updated = value_factor.clone()
    reports = []
    for group in range(topology.target_key_value_heads):
        start = group * topology.target_query_heads_per_group
        stop = start + topology.target_query_heads_per_group
        group_heads = tuple(range(start, stop))
        other_heads = tuple(
            head
            for head in range(topology.target_query_heads)
            if head not in group_heads
        )
        right = torch.zeros(
            topology.target_hidden_size,
            topology.head_dim,
            dtype=torch.float64,
        )
        for head in group_heads:
            right.add_(endpoint_right[head] @ output_blocks[head].T)
            for other in other_heads:
                other_group = (
                    other // topology.target_query_heads_per_group
                )
                coupling = output_blocks[other] @ output_blocks[head].T
                right.sub_(
                    cross[head, other]
                    @ updated[other_group]
                    @ coupling
                )
        trace_numerator = 0.0
        diagonal = torch.zeros_like(updated[group])
        for head in group_heads:
            for other in group_heads:
                coupling = output_blocks[other] @ output_blocks[head].T
                trace_numerator += float(
                    torch.trace(cross[head, other]).item()
                ) * float((output_blocks[head] * output_blocks[other]).sum())
                diagonal.add_(
                    torch.diagonal(cross[head, other]).unsqueeze(1)
                    * torch.diagonal(coupling).unsqueeze(0)
                )
        trace_scale = trace_numerator / (
            topology.target_hidden_size * topology.head_dim
        )
        ridge = max(
            policy.absolute_ridge_floor,
            policy.ridge_scale * max(trace_scale, 0.0),
        )
        diagonal = (diagonal + ridge).clamp_min(
            policy.absolute_ridge_floor
        )

        def matvec(value: Any) -> Any:
            result = torch.zeros_like(value)
            for head in group_heads:
                for other in group_heads:
                    coupling = output_blocks[other] @ output_blocks[head].T
                    result.add_(
                        cross[head, other] @ value @ coupling
                    )
            return result + ridge * value

        role = (
            f"sequence_effective_structured_value_iteration_{iteration}_"
            f"group_{group}"
        )
        hidden_partial_trace_preconditioner = (
            _build_structured_value_hidden_partial_trace_preconditioner(
                cross=cross,
                output_blocks=output_blocks,
                group_heads=group_heads,
                ridge=ridge,
                role=role,
            )
        )
        solve_right = right
        initial = updated[group]
        if value_seed is not None:
            unregularized_seed_application = (
                matvec(value_seed[group]) - ridge * value_seed[group]
            )
            solve_right = right - unregularized_seed_application
            initial = updated[group] - value_seed[group]
        solution, pcg_report = _pcg_single_tensor(
            right=solve_right,
            matvec=matvec,
            diagonal=diagonal,
            initial=initial,
            role=role,
            restart_hidden_partial_trace_preconditioner=(
                hidden_partial_trace_preconditioner
            ),
            restart_hidden_partial_trace_ridge=ridge,
        )
        updated[group] = (
            solution
            if value_seed is None
            else value_seed[group] + solution
        )
        body = {
            "role": role,
            "group": group,
            "heads": list(group_heads),
            "features": topology.target_hidden_size * topology.head_dim,
            "ridge_scale": policy.ridge_scale,
            "trace_scale": trace_scale,
            "ridge": ridge,
            "pcg_report": pcg_report,
            "hidden_partial_trace_construction_report": dict(
                hidden_partial_trace_preconditioner.construction_report
            ),
            "hidden_partial_trace_supplied_to_restart_lane": True,
            "hidden_partial_trace_pcg_execution_profile_sha256": (
                LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE_SHA256
            ),
            "solution_sha256": _tensor_sha256(updated[group]),
            "explicit_coefficient_tensor_materialized": False,
            "hidden_head_dim_gram_materialized": False,
        }
        if value_seed is not None:
            body.update(
                {
                    "parameterization": (
                        "value_group=value_seed+zero_centered_delta"
                    ),
                    "zero_delta_ridge_anchor": True,
                    "value_seed_group_sha256": _tensor_sha256(
                        value_seed[group]
                    ),
                    "delta_sha256": _tensor_sha256(solution),
                    "delta_right_sha256": _tensor_sha256(solve_right),
                }
            )
        reports.append(_seal(body))
    return updated.contiguous(), reports


def _streaming_materialized_metrics(
    *,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    cases: Sequence[Lfm2CachedAttentionFoldCase],
    query_norm_weight: Any | None,
    key_norm_weight: Any | None,
    norm_epsilon: float,
    value_factor: Any,
    output_blocks: Any,
) -> tuple[float, float, float]:
    torch = _torch()
    topology = producer.topology
    weighted_error = weighted_target_square = 0.0
    plain_error = plain_target_square = 0.0
    context_error = context_target_square = 0.0
    for case_index, case in enumerate(cases):
        normalized = _normalize_sequence_case(
            case,
            case_index=case_index,
            producer=producer,
            query_norm_weight=query_norm_weight,
            key_norm_weight=key_norm_weight,
            norm_epsilon=norm_epsilon,
        )
        batch = int(normalized["batch"])
        query_length = int(normalized["query_length"])
        attended = normalized["weighted_inputs"].permute(
            0,
            2,
            1,
            3,
        ).reshape(
            batch * query_length,
            topology.target_query_heads,
            topology.target_hidden_size,
        )
        prediction = _prediction(
            attended,
            value_factor,
            output_blocks,
            heads_per_group=topology.target_query_heads_per_group,
        )
        target = normalized["endpoint"]
        row_weights, _explicit = _case_query_row_weights(
            case,
            case_index=case_index,
            batch=batch,
            query_length=query_length,
        )
        weight = row_weights.reshape(-1, 1)
        weighted_error += float(((prediction - target) * weight).square().sum())
        weighted_target_square += float((target * weight).square().sum())
        plain_error += float((prediction - target).square().sum())
        plain_target_square += float(target.square().sum())

        child_heads = _context_heads(
            attended,
            value_factor,
            heads_per_group=topology.target_query_heads_per_group,
        ).reshape(
            batch,
            query_length,
            topology.target_query_heads,
            topology.head_dim,
        )
        parent_context = case.parent_context.detach().to(
            device="cpu",
            dtype=torch.float64,
        )
        target_heads = []
        for members, weights in zip(
            producer.query_groups,
            producer.query_barycentric_weights,
            strict=True,
        ):
            selected = parent_context.index_select(
                1,
                torch.tensor(members, dtype=torch.long),
            )
            coefficients = torch.tensor(
                weights,
                dtype=torch.float64,
            ).reshape(1, len(members), 1, 1)
            target_heads.append((selected * coefficients).sum(dim=1))
        context_target = torch.stack(target_heads, dim=2)
        context_error += float((child_heads - context_target).square().sum())
        context_target_square += float(context_target.square().sum())
    epsilon = torch.finfo(torch.float64).eps
    return (
        math.sqrt(weighted_error / max(weighted_target_square, epsilon)),
        math.sqrt(plain_error / max(plain_target_square, epsilon)),
        math.sqrt(context_error / max(context_target_square, epsilon)),
    )


def _materialize_vo_proposal(
    *,
    value_factor: Any,
    output_blocks: Any,
    topology: Any,
    value_dtype: Any,
    output_dtype: Any,
) -> tuple[Any, Any, Any, Any]:
    torch = _torch()
    value_fp64 = value_factor.permute(0, 2, 1).reshape(
        topology.target_key_value_heads * topology.head_dim,
        topology.target_hidden_size,
    )
    output_fp64 = output_blocks.reshape(
        topology.target_query_heads * topology.head_dim,
        topology.target_output_size,
    ).T
    value_weight = value_fp64.to(dtype=value_dtype).contiguous().clone()
    output_weight = output_fp64.to(dtype=output_dtype).contiguous().clone()
    materialized_factor = value_weight.to(torch.float64).reshape(
        topology.target_key_value_heads,
        topology.head_dim,
        topology.target_hidden_size,
    ).permute(0, 2, 1)
    materialized_blocks = output_weight.to(torch.float64).T.reshape(
        topology.target_query_heads,
        topology.head_dim,
        topology.target_output_size,
    )
    return (
        value_weight,
        output_weight,
        materialized_factor,
        materialized_blocks,
    )


def _verify_streamed_vo_seed_bank_report(
    report: Any,
    *,
    fit_case_count: int,
    fit_case_bundle_sha256: str,
) -> bool:
    """Verify one bounded FIT-only exact-target-dtype seed tournament."""

    try:
        bank = dict(report)
        supplied = bank.pop("report_sha256")
        candidates = bank["candidates"]
        attempts = bank["effective_operator_attempts"]
        selected_index = bank["selected_candidate_index"]
        incumbent_index = bank["incumbent_candidate_index"]
        if (
            supplied != _sha256(bank)
            or bank.get("schema")
            != LFM2_SEQUENCE_EFFECTIVE_VO_SEED_BANK_SCHEMA
            or bank.get("fit_case_count") != fit_case_count
            or bank.get("fit_case_bundle_sha256")
            != fit_case_bundle_sha256
            or bank.get("compiled_from_splits") != ["fit"]
            or bank.get("selection_case_count_consumed") != 0
            or bank.get("validation_case_count_consumed") != 0
            or bank.get("selection_inputs_accessible") is not False
            or bank.get("validation_inputs_accessible") is not False
            or bank.get("maximum_candidate_count")
            != _MAXIMUM_STREAMED_VO_SEED_CANDIDATES
            or not isinstance(candidates, list)
            or not 1
            <= len(candidates)
            <= _MAXIMUM_STREAMED_VO_SEED_CANDIDATES
            or bank.get("candidate_count") != len(candidates)
            or bank.get("exact_target_dtype_evaluation_count")
            != len(candidates)
            or not isinstance(attempts, list)
            or [attempt.get("candidate_id") for attempt in attempts]
            != [
                "headwise_effective_operator_svd",
                "global_effective_operator_svd",
            ]
            or incumbent_index != 0
            or not isinstance(selected_index, int)
            or isinstance(selected_index, bool)
            or not 0 <= selected_index < len(candidates)
        ):
            return False
        exact_bfloat16 = bool(
            bank.get("value_target_dtype") == "torch.bfloat16"
            and bank.get("output_target_dtype") == "torch.bfloat16"
        )
        if bank.get("exact_bfloat16_evaluation") is not exact_bfloat16:
            return False
        candidate_ids = []
        for index, candidate in enumerate(candidates):
            body = dict(candidate)
            candidate_seal = body.pop("report_sha256")
            score = body.get(
                "weighted_fit_relative_rmse_exact_target_dtype"
            )
            if (
                candidate_seal != _sha256(body)
                or body.get("candidate_index") != index
                or body.get("evidence_split") != "fit"
                or body.get("fit_case_bundle_sha256")
                != fit_case_bundle_sha256
                or body.get("selection_inputs_consumed") != 0
                or body.get("validation_inputs_consumed") != 0
                or not isinstance(score, (int, float))
                or isinstance(score, bool)
                or not math.isfinite(float(score))
                or body.get("exact_target_dtype_evaluated") is not True
                or body.get("exact_bfloat16_evaluated")
                is not exact_bfloat16
            ):
                return False
            for name in (
                "source_report_sha256",
                "value_factor_fp64_sha256_before_materialization",
                "output_blocks_fp64_sha256_before_materialization",
                "value_weight_sha256",
                "output_weight_sha256",
            ):
                _digest(body.get(name), name)
            candidate_ids.append(body.get("candidate_id"))
        allowed = {
            "authenticated_residual_vo",
            "producer_shared_value",
            "headwise_effective_operator_svd",
            "global_effective_operator_svd",
        }
        if (
            len(set(candidate_ids)) != len(candidate_ids)
            or not set(candidate_ids).issubset(allowed)
            or "producer_shared_value" not in candidate_ids
            or candidate_ids[0]
            not in {
                "authenticated_residual_vo",
                "producer_shared_value",
            }
            or candidates[selected_index].get("candidate_id")
            != bank.get("selected_candidate_id")
            or candidates[incumbent_index].get("candidate_id")
            != bank.get("incumbent_candidate_id")
        ):
            return False
        accepted_attempt_ids = []
        for attempt in attempts:
            body = dict(attempt)
            attempt_seal = body.pop("report_sha256")
            candidate_id = body.get("candidate_id")
            status = body.get("status")
            if (
                attempt_seal != _sha256(body)
                or candidate_id
                not in {
                    "headwise_effective_operator_svd",
                    "global_effective_operator_svd",
                }
                or status
                not in {
                    "accepted_into_seed_bank",
                    "typed_numerical_or_evidence_rejection",
                }
                or body.get("selection_inputs_consumed") != 0
                or body.get("validation_inputs_consumed") != 0
                or (
                    status == "accepted_into_seed_bank"
                    and candidate_id not in candidate_ids
                )
                or (
                    status == "typed_numerical_or_evidence_rejection"
                    and candidate_id in candidate_ids
                )
            ):
                return False
            if status == "accepted_into_seed_bank":
                accepted_attempt_ids.append(candidate_id)
                candidate = next(
                    value
                    for value in candidates
                    if value["candidate_id"] == candidate_id
                )
                if (
                    body.get("source_report_sha256")
                    != candidate.get("source_report_sha256")
                ):
                    return False
        expected_ids = (
            (
                ["authenticated_residual_vo"]
                if candidate_ids[0] == "authenticated_residual_vo"
                else []
            )
            + ["producer_shared_value"]
            + accepted_attempt_ids
        )
        if candidate_ids != expected_ids:
            return False
        selected_score = float(
            candidates[selected_index][
                "weighted_fit_relative_rmse_exact_target_dtype"
            ]
        )
        incumbent_score = float(
            candidates[incumbent_index][
                "weighted_fit_relative_rmse_exact_target_dtype"
            ]
        )
        fit_tolerance = float(bank.get("fit_tolerance"))
        return bool(
            bank.get(
                "selected_weighted_fit_relative_rmse_exact_target_dtype"
            )
            == selected_score
            and bank.get(
                "incumbent_weighted_fit_relative_rmse_exact_target_dtype"
            )
            == incumbent_score
            and bank.get("selected_seed_nonincreasing_from_incumbent")
            is True
            and math.isfinite(fit_tolerance)
            and fit_tolerance >= 0.0
            and selected_score <= incumbent_score + fit_tolerance
        )
    except (
        KeyError,
        TypeError,
        ValueError,
        Lfm2SequenceEffectiveAttentionFoldError,
    ):
        return False


def _build_streamed_vo_seed_bank(
    *,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    cases: Sequence[Lfm2CachedAttentionFoldCase],
    statistics: Mapping[str, Any],
    query_norm_weight: Any | None,
    key_norm_weight: Any | None,
    norm_epsilon: float,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    value_dtype: Any,
    output_dtype: Any,
    fit_case_bundle_sha256: str,
    residual_vo_seed: Lfm2SequenceEffectiveResidualVoSeed | None,
) -> tuple[Any, Any, list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    """Build, target-dtype score, and select bounded FIT-only V/O starts."""

    torch = _torch()
    topology = producer.topology
    candidates: list[dict[str, Any]] = []
    candidate_states: list[tuple[Any, Any]] = []
    attempts: list[dict[str, Any]] = []

    def add_candidate(
        *,
        candidate_id: str,
        source_kind: str,
        value_factor: Any,
        output_blocks: Any,
        source_report: Mapping[str, Any],
        svd_reports: Sequence[Mapping[str, Any]],
    ) -> None:
        if len(candidates) >= _MAXIMUM_STREAMED_VO_SEED_CANDIDATES:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "The streamed V/O seed bank exceeded its authenticated bound."
            )
        (
            materialized_value,
            materialized_output,
            materialized_factor,
            materialized_blocks,
        ) = _materialize_vo_proposal(
            value_factor=value_factor,
            output_blocks=output_blocks,
            topology=topology,
            value_dtype=value_dtype,
            output_dtype=output_dtype,
        )
        if not bool(
            torch.isfinite(materialized_value).all().item()
            and torch.isfinite(materialized_output).all().item()
        ):
            raise Lfm2SequenceEffectiveAttentionFoldError(
                f"{candidate_id} produced a non-finite target-dtype seed."
            )
        score = _sequence_statistics_relative_rmse(
            statistics=statistics,
            topology=topology,
            value_factor=materialized_factor,
            output_blocks=materialized_blocks,
        )
        body = {
            "candidate_index": len(candidates),
            "candidate_id": candidate_id,
            "source_kind": source_kind,
            "evidence_split": "fit",
            "fit_case_bundle_sha256": fit_case_bundle_sha256,
            "source_report_sha256": source_report["report_sha256"],
            "shared_value_svd_report_sha256": [
                _sha256(dict(value)) for value in svd_reports
            ],
            "value_factor_fp64_sha256_before_materialization": (
                _tensor_sha256(value_factor)
            ),
            "output_blocks_fp64_sha256_before_materialization": (
                _tensor_sha256(output_blocks)
            ),
            "value_weight_shape": list(materialized_value.shape),
            "value_weight_dtype": str(materialized_value.dtype),
            "value_weight_sha256": _tensor_sha256(materialized_value),
            "output_weight_shape": list(materialized_output.shape),
            "output_weight_dtype": str(materialized_output.dtype),
            "output_weight_sha256": _tensor_sha256(materialized_output),
            "weighted_fit_relative_rmse_exact_target_dtype": score,
            "fit_score_source": (
                "projected_cached_cross_head_gram_and_endpoint_right"
            ),
            "exact_target_dtype_evaluated": True,
            "exact_bfloat16_evaluated": bool(
                value_dtype == torch.bfloat16
                and output_dtype == torch.bfloat16
            ),
            "selection_inputs_consumed": 0,
            "validation_inputs_consumed": 0,
        }
        candidates.append(_seal(body))
        candidate_states.append(
            (
                materialized_factor.contiguous(),
                materialized_blocks.contiguous(),
            )
        )

    if residual_vo_seed is not None:
        residual_factor = residual_vo_seed.value_weight.to(
            torch.float64
        ).reshape(
            topology.target_key_value_heads,
            topology.head_dim,
            topology.target_hidden_size,
        ).permute(0, 2, 1).contiguous()
        residual_blocks = residual_vo_seed.output_weight.to(
            torch.float64
        ).T.reshape(
            topology.target_query_heads,
            topology.head_dim,
            topology.target_output_size,
        ).contiguous()
        residual_report = _seal(
            {
                "role": "streamed_vo_seed_bank_residual_incumbent",
                "residual_vo_seed_sha256": (
                    residual_vo_seed.authentication_sha256
                ),
                "fit_seed_only": True,
                "selection_inputs_consumed": 0,
                "validation_inputs_consumed": 0,
            }
        )
        add_candidate(
            candidate_id="authenticated_residual_vo",
            source_kind="authenticated_dense_residual_vo_split",
            value_factor=residual_factor,
            output_blocks=residual_blocks,
            source_report=residual_report,
            svd_reports=(),
        )

    producer_factor = producer.value_weight.to(torch.float64).reshape(
        topology.target_key_value_heads,
        topology.head_dim,
        topology.target_hidden_size,
    ).permute(0, 2, 1).contiguous()
    producer_blocks, producer_report = (
        _fit_output_from_sequence_statistics(
            statistics=statistics,
            topology=topology,
            value_factor=producer_factor,
            policy=policy,
            role="streamed_vo_seed_bank_producer_output",
        )
    )
    producer_factor, producer_blocks = _canonicalize_value_factor(
        producer_factor,
        producer_blocks,
    )
    add_candidate(
        candidate_id="producer_shared_value",
        source_kind="fit_compiled_producer_shared_value_subspace",
        value_factor=producer_factor,
        output_blocks=producer_blocks,
        source_report=producer_report,
        svd_reports=(),
    )

    def add_effective_candidate(
        *,
        candidate_id: str,
        fit_operator: Callable[
            [],
            tuple[Any, Mapping[str, Any], int | None],
        ],
    ) -> None:
        try:
            effective, operator_report, explicit_weight_count = (
                fit_operator()
            )
            value_factor, _svd_output, svd_reports = (
                _initial_shared_value_factors(
                    effective,
                    target_key_value_heads=(
                        topology.target_key_value_heads
                    ),
                    heads_per_group=(
                        topology.target_query_heads_per_group
                    ),
                    head_dim=topology.head_dim,
                )
            )
            output_blocks, output_report = (
                _fit_output_from_sequence_statistics(
                    statistics=statistics,
                    topology=topology,
                    value_factor=value_factor,
                    policy=policy,
                    role=(
                        f"streamed_vo_seed_bank_{candidate_id}_output"
                    ),
                )
            )
            value_factor, output_blocks = _canonicalize_value_factor(
                value_factor,
                output_blocks,
            )
            source_report = _seal(
                {
                    "role": f"streamed_vo_seed_bank_{candidate_id}",
                    "effective_operator_report": dict(operator_report),
                    "effective_operator_report_sha256": operator_report[
                        "report_sha256"
                    ],
                    "output_solve_report": dict(output_report),
                    "output_solve_report_sha256": output_report[
                        "report_sha256"
                    ],
                    "effective_operator_sha256": _tensor_sha256(
                        effective
                    ),
                    "explicit_fit_row_weight_case_count": (
                        explicit_weight_count
                    ),
                    "selection_inputs_consumed": 0,
                    "validation_inputs_consumed": 0,
                }
            )
            add_candidate(
                candidate_id=candidate_id,
                source_kind="fit_effective_operator_shared_value_svd",
                value_factor=value_factor,
                output_blocks=output_blocks,
                source_report=source_report,
                svd_reports=svd_reports,
            )
            attempts.append(
                _seal(
                    {
                        "candidate_id": candidate_id,
                        "status": "accepted_into_seed_bank",
                        "source_report_sha256": source_report[
                            "report_sha256"
                        ],
                        "selection_inputs_consumed": 0,
                        "validation_inputs_consumed": 0,
                    }
                )
            )
        except Lfm2SequenceEffectiveAttentionFoldError as error:
            failure = (
                None
                if error.failure_report is None
                else dict(error.failure_report)
            )
            attempts.append(
                _seal(
                    {
                        "candidate_id": candidate_id,
                        "status": (
                            "typed_numerical_or_evidence_rejection"
                        ),
                        "exception_type": type(error).__name__,
                        "failure_report": failure,
                        "failure_report_sha256": (
                            None
                            if failure is None
                            else failure.get("report_sha256")
                        ),
                        "selection_inputs_consumed": 0,
                        "validation_inputs_consumed": 0,
                    }
                )
            )

    add_effective_candidate(
        candidate_id="headwise_effective_operator_svd",
        fit_operator=lambda: _fit_streamed_headwise_effective_operator(
            producer=producer,
            cases=cases,
            query_norm_weight=query_norm_weight,
            key_norm_weight=key_norm_weight,
            norm_epsilon=norm_epsilon,
            policy=policy,
        ),
    )

    def global_operator() -> tuple[Any, Mapping[str, Any], int | None]:
        effective, report = _fit_streamed_global_effective_operator(
            statistics=statistics,
            topology=topology,
            policy=policy,
        )
        return effective, report, None

    add_effective_candidate(
        candidate_id="global_effective_operator_svd",
        fit_operator=global_operator,
    )
    incumbent_index = 0
    best_score = min(
        float(
            candidate[
                "weighted_fit_relative_rmse_exact_target_dtype"
            ]
        )
        for candidate in candidates
    )
    selection_pool = tuple(
        index
        for index, candidate in enumerate(candidates)
        if float(
            candidate[
                "weighted_fit_relative_rmse_exact_target_dtype"
            ]
        )
        <= best_score + policy.fit_tolerance
    )
    selected_index = min(selection_pool)
    selected_score = float(
        candidates[selected_index][
            "weighted_fit_relative_rmse_exact_target_dtype"
        ]
    )
    incumbent_score = float(
        candidates[incumbent_index][
            "weighted_fit_relative_rmse_exact_target_dtype"
        ]
    )
    if selected_score > incumbent_score + policy.fit_tolerance:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "The streamed V/O seed tournament was not nonincreasing."
        )
    bank_report = _seal(
        {
            "schema": LFM2_SEQUENCE_EFFECTIVE_VO_SEED_BANK_SCHEMA,
            "fit_case_count": len(cases),
            "fit_case_bundle_sha256": fit_case_bundle_sha256,
            "compiled_from_splits": ["fit"],
            "selection_case_count_consumed": 0,
            "validation_case_count_consumed": 0,
            "selection_inputs_accessible": False,
            "validation_inputs_accessible": False,
            "maximum_candidate_count": (
                _MAXIMUM_STREAMED_VO_SEED_CANDIDATES
            ),
            "candidate_count": len(candidates),
            "candidates": candidates,
            "effective_operator_attempts": attempts,
            "exact_target_dtype_evaluation_count": len(candidates),
            "value_target_dtype": str(value_dtype),
            "output_target_dtype": str(output_dtype),
            "exact_bfloat16_evaluation": bool(
                value_dtype == torch.bfloat16
                and output_dtype == torch.bfloat16
            ),
            "incumbent_candidate_index": incumbent_index,
            "incumbent_candidate_id": candidates[incumbent_index][
                "candidate_id"
            ],
            (
                "incumbent_weighted_fit_relative_rmse_"
                "exact_target_dtype"
            ): incumbent_score,
            "selected_candidate_index": selected_index,
            "selected_candidate_id": candidates[selected_index][
                "candidate_id"
            ],
            (
                "selected_weighted_fit_relative_rmse_"
                "exact_target_dtype"
            ): selected_score,
            "selected_seed_nonincreasing_from_incumbent": True,
            "fit_tolerance": policy.fit_tolerance,
            "deterministic_selection_rule": (
                "lowest_candidate_index_within_fit_tolerance_of_best"
            ),
            "ordinary_dense_target_value_output": True,
            "training_steps": 0,
            "backward_calls": 0,
            "optimizer_steps": 0,
            "parameters_pruned": 0,
            "parameters_quantized": 0,
        }
    )
    if not _verify_streamed_vo_seed_bank_report(
        bank_report,
        fit_case_count=len(cases),
        fit_case_bundle_sha256=fit_case_bundle_sha256,
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "The streamed V/O seed bank authentication failed."
        )
    selected_factor, selected_blocks = candidate_states[selected_index]
    svd_reports = [
        {
            "seed": "bounded_fit_only_effective_operator_seed_bank",
            "selected_candidate_id": candidates[selected_index][
                "candidate_id"
            ],
            "selected_candidate_index": selected_index,
            "seed_bank_report_sha256": bank_report["report_sha256"],
            "exact_target_dtype_start": True,
        }
    ]
    selection_report = _seal(
        {
            "role": "sequence_effective_streamed_vo_seed_bank_selection",
            "seed_bank_report_sha256": bank_report["report_sha256"],
            "selected_candidate_id": candidates[selected_index][
                "candidate_id"
            ],
            "selected_candidate_index": selected_index,
            "relative_rmse": selected_score,
            "exact_target_dtype_start": True,
            "selection_inputs_consumed": 0,
            "validation_inputs_consumed": 0,
        }
    )
    return (
        selected_factor.clone(),
        selected_blocks.clone(),
        svd_reports,
        selection_report,
        bank_report,
    )


def _recoverable_residual_delta_solve_failure(
    error: Lfm2SequenceEffectiveAttentionFoldError,
) -> bool:
    """Accept only sealed numerical/convergence failures as seed fallbacks."""

    if error.failure_report is None:
        return False
    report = dict(error.failure_report)
    supplied = report.pop("report_sha256", None)
    if (
        supplied != _sha256(report)
        or report.get("status") != "failed_closed"
    ):
        return False
    stage = str(report.get("failure_stage", ""))
    if stage in {"ridge_factorization", "ridge_solution"}:
        return True
    if (
        not stage
        or stage == "input_validation"
        or "authentication" in stage
        or "application" in stage
        or stage == "restart_preconditioner_selection"
    ):
        return False
    return bool(
        stage == "initial_exact_residual"
        or stage == "hard_iteration_cap"
        or stage.startswith("original_lane_")
        or stage.startswith("continuous_")
        or stage.startswith("restart_")
    )


def compile_lfm2_fixed_qk_sequence_effective_attention_fold(
    *,
    producer: Lfm2CompiledStructuralAttentionProducerFold,
    target_value_weight_template: Any,
    target_output_weight_template: Any,
    fit_cases: Sequence[Lfm2CachedAttentionFoldCase],
    query_norm_weight: Any | None = None,
    key_norm_weight: Any | None = None,
    norm_epsilon: float = 1e-6,
    policy: Lfm2FixedQkSequenceEffectiveVoAlsPolicy | None = None,
    residual_vo_seed: Lfm2SequenceEffectiveResidualVoSeed | None = None,
) -> Lfm2CompiledFixedQkSequenceEffectiveAttentionFold:
    """Compile one authenticated fit-only exact-Q/K sequence-effective arm."""

    torch = _torch()
    selected_policy = (
        Lfm2FixedQkSequenceEffectiveVoAlsPolicy()
        if policy is None
        else policy
    )
    if not isinstance(
        selected_policy,
        Lfm2FixedQkSequenceEffectiveVoAlsPolicy,
    ) or not selected_policy.verify_authentication():
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "policy must be an authenticated sequence-effective policy."
        )
    if not isinstance(
        producer,
        Lfm2CompiledStructuralAttentionProducerFold,
    ) or not producer.full_source_coverage:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "producer must be one full-coverage structural attention producer."
        )
    seeded = residual_vo_seed is not None
    if seeded and (
        not isinstance(
            residual_vo_seed,
            Lfm2SequenceEffectiveResidualVoSeed,
        )
        or not residual_vo_seed.verify_authentication()
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "residual_vo_seed must be one authenticated dense residual V/O seed."
        )
    cases = tuple(fit_cases)
    if not cases or any(
        not isinstance(case, Lfm2CachedAttentionFoldCase) for case in cases
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "fit_cases must contain at least one cached attention case."
        )
    epsilon = _finite_float(
        norm_epsilon,
        "norm_epsilon",
        minimum=1e-12,
        maximum=1.0,
    )
    topology = producer.topology
    try:
        value_dtype, value_shape = structural._dense_template(
            target_value_weight_template,
            "target_value_weight_template",
        )
        output_dtype, output_shape = structural._dense_template(
            target_output_weight_template,
            "target_output_weight_template",
        )
    except structural.Lfm2StructuralResidualAttentionFoldError as exc:
        raise Lfm2SequenceEffectiveAttentionFoldError(str(exc)) from exc
    expected_value_shape = (
        topology.target_key_value_heads * topology.head_dim,
        topology.target_hidden_size,
    )
    expected_output_shape = (
        topology.target_output_size,
        topology.target_query_heads * topology.head_dim,
    )
    if value_shape != expected_value_shape or output_shape != expected_output_shape:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Target V/O templates differ from the fixed Q/K topology."
        )
    if seeded and (
        tuple(residual_vo_seed.value_weight.shape) != expected_value_shape
        or tuple(residual_vo_seed.output_weight.shape) != expected_output_shape
        or residual_vo_seed.value_weight.dtype != value_dtype
        or residual_vo_seed.output_weight.dtype != output_dtype
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Residual V/O seed differs from the target V/O shape or dtype."
        )
    q_norm = (
        None
        if query_norm_weight is None
        else _tensor(query_norm_weight, "query_norm_weight", dimensions=1).to(
            torch.float64
        )
    )
    k_norm = (
        None
        if key_norm_weight is None
        else _tensor(key_norm_weight, "key_norm_weight", dimensions=1).to(
            torch.float64
        )
    )
    if q_norm is not None and tuple(q_norm.shape) != (topology.head_dim,):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "query_norm_weight has the wrong head dimension."
        )
    if k_norm is not None and tuple(k_norm.shape) != (topology.head_dim,):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "key_norm_weight has the wrong head dimension."
        )

    producer_before = _state_sha256(producer.state_dict())
    case_bundle_before = _case_bundle_sha256(cases)
    residual_seed_before = (
        residual_vo_seed.authentication_sha256 if seeded else None
    )
    fit_rows = sum(
        int(case.target_query_input.shape[0])
        * int(case.target_query_input.shape[1])
        for case in cases
    )
    solver_plan = _sequence_effective_solver_plan(
        fit_rows=fit_rows,
        target_query_heads=topology.target_query_heads,
        target_hidden_size=topology.target_hidden_size,
        target_output_size=topology.target_output_size,
        head_dim=topology.head_dim,
    )
    streamed_headwise = (
        solver_plan["strategy"] == "streamed_cross_head_statistics_pcg"
    )
    normalized_cases: list[Mapping[str, Any]] = []
    attended_inputs = endpoint_target = None
    plain_attended_inputs = plain_endpoint_target = None
    sequence_statistics: Mapping[str, Any] | None = None
    statistics_report: Mapping[str, Any] | None = None
    initial_vo_seed_bank: Mapping[str, Any] | None = None
    if streamed_headwise:
        (
            sequence_statistics,
            statistics_report,
            explicit_weight_count,
        ) = _accumulate_streamed_sequence_statistics(
            producer=producer,
            cases=cases,
            query_norm_weight=q_norm,
            key_norm_weight=k_norm,
            norm_epsilon=epsilon,
        )
        effective = None
        if seeded:
            effective_solve = _seal(
                {
                    "role": "sequence_effective_residual_vo_seed",
                    "seed": "authenticated_dense_residual_vo_split",
                    "residual_vo_seed_sha256": residual_seed_before,
                    "complete_effective_operator_solve_skipped": True,
                    "reason": "residual_vo_seed_is_proposal_zero",
                    "selection_inputs_consumed": 0,
                    "validation_inputs_consumed": 0,
                }
            )
        else:
            effective_solve = _seal(
                {
                    "role": "sequence_effective_scalable_shared_value_seed",
                    "seed": "fit_compiled_producer_shared_value_subspace",
                    "producer_value_sha256": _tensor_sha256(
                        producer.value_weight
                    ),
                    "complete_effective_operator_solve_skipped": True,
                    "reason": (
                        "avoid_qheads_times_hidden_multi_output_factorization"
                    ),
                    "selection_inputs_consumed": 0,
                    "validation_inputs_consumed": 0,
                }
            )
    else:
        weighted_attended = []
        weighted_targets = []
        unweighted_attended = []
        unweighted_targets = []
        explicit_weight_count = 0
        for case_index, case in enumerate(cases):
            normalized = _normalize_sequence_case(
                case,
                case_index=case_index,
                producer=producer,
                query_norm_weight=q_norm,
                key_norm_weight=k_norm,
                norm_epsilon=epsilon,
            )
            normalized_cases.append(normalized)
            batch = int(normalized["batch"])
            query_length = int(normalized["query_length"])
            attended = normalized["weighted_inputs"].permute(
                0,
                2,
                1,
                3,
            ).reshape(
                batch * query_length,
                topology.target_query_heads,
                topology.target_hidden_size,
            )
            endpoint = normalized["endpoint"]
            row_weights, explicit = _case_query_row_weights(
                case,
                case_index=case_index,
                batch=batch,
                query_length=query_length,
            )
            explicit_weight_count += int(explicit)
            weight = row_weights.reshape(-1, 1)
            unweighted_attended.append(attended)
            unweighted_targets.append(endpoint)
            weighted_attended.append(attended * weight.unsqueeze(1))
            weighted_targets.append(endpoint * weight)
        attended_inputs = torch.cat(weighted_attended, dim=0).to(torch.float64)
        endpoint_target = torch.cat(weighted_targets, dim=0).to(torch.float64)
        plain_attended_inputs = torch.cat(unweighted_attended, dim=0).to(
            torch.float64
        )
        plain_endpoint_target = torch.cat(unweighted_targets, dim=0).to(
            torch.float64
        )
        if seeded:
            effective = None
            effective_solve = _seal(
                {
                    "role": "sequence_effective_residual_vo_seed",
                    "seed": "authenticated_dense_residual_vo_split",
                    "residual_vo_seed_sha256": residual_seed_before,
                    "complete_effective_operator_solve_skipped": True,
                    "reason": "residual_vo_seed_is_proposal_zero",
                    "selection_inputs_consumed": 0,
                    "validation_inputs_consumed": 0,
                }
            )
        else:
            flat_design = attended_inputs.reshape(
                int(attended_inputs.shape[0]),
                topology.target_query_heads * topology.target_hidden_size,
            )
            effective_rows, effective_solve = _ridge_solve(
                flat_design,
                endpoint_target,
                policy=selected_policy,
                role="sequence_effective_complete_causal_operator",
            )
            effective = effective_rows.reshape(
                topology.target_query_heads,
                topology.target_hidden_size,
                topology.target_output_size,
            )
    if streamed_headwise:
        (
            value_factor,
            output_blocks,
            svd_reports,
            output_solve,
            initial_vo_seed_bank,
        ) = _build_streamed_vo_seed_bank(
            producer=producer,
            cases=cases,
            statistics=sequence_statistics,
            query_norm_weight=q_norm,
            key_norm_weight=k_norm,
            norm_epsilon=epsilon,
            policy=selected_policy,
            value_dtype=value_dtype,
            output_dtype=output_dtype,
            fit_case_bundle_sha256=case_bundle_before,
            residual_vo_seed=residual_vo_seed,
        )
        effective_solve = _seal(
            {
                "role": "sequence_effective_streamed_vo_seed_bank",
                "seed_bank_report_sha256": initial_vo_seed_bank[
                    "report_sha256"
                ],
                "selected_candidate_id": initial_vo_seed_bank[
                    "selected_candidate_id"
                ],
                "selected_candidate_index": initial_vo_seed_bank[
                    "selected_candidate_index"
                ],
                "complete_effective_operator_solve_skipped": False,
                "headwise_effective_operator_attempted": True,
                "global_effective_operator_attempted": True,
                "selection_inputs_consumed": 0,
                "validation_inputs_consumed": 0,
            }
        )
    elif seeded:
        value_factor = residual_vo_seed.value_weight.to(
            torch.float64
        ).reshape(
            topology.target_key_value_heads,
            topology.head_dim,
            topology.target_hidden_size,
        ).permute(0, 2, 1).contiguous()
        output_blocks = residual_vo_seed.output_weight.to(
            torch.float64
        ).T.reshape(
            topology.target_query_heads,
            topology.head_dim,
            topology.target_output_size,
        ).contiguous()
        svd_reports = [
            {
                "seed": "authenticated_dense_residual_vo_split",
                "residual_vo_seed_sha256": residual_seed_before,
                "svd_materialization_avoided": True,
            }
        ]
    else:
        value_factor, output_blocks, svd_reports = (
            _initial_shared_value_factors(
                effective,
                target_key_value_heads=topology.target_key_value_heads,
                heads_per_group=topology.target_query_heads_per_group,
                head_dim=topology.head_dim,
            )
        )
    if streamed_headwise:
        pass
    elif seeded:
        output_solve = _seal(
            {
                "role": "sequence_effective_residual_vo_seed_identity",
                "parameterization": (
                    "value=value_seed+zero;output=output_seed+zero"
                ),
                "zero_delta_ridge_anchor": True,
                "residual_vo_seed_sha256": residual_seed_before,
                "closed_form_linear_solves": 0,
                "selection_inputs_consumed": 0,
                "validation_inputs_consumed": 0,
            }
        )
    else:
        output_blocks, _features, output_solve = _fit_output(
            attended_inputs,
            endpoint_target,
            value_factor,
            heads_per_group=topology.target_query_heads_per_group,
            policy=selected_policy,
            role="sequence_effective_svd_seed_output",
        )
    if not seeded and not streamed_headwise:
        value_factor, output_blocks = _canonicalize_value_factor(
            value_factor,
            output_blocks,
        )
    accepted_error = (
        _sequence_statistics_relative_rmse(
            statistics=sequence_statistics,
            topology=topology,
            value_factor=value_factor,
            output_blocks=output_blocks,
        )
        if streamed_headwise
        else _relative_rmse(
            _prediction(
                attended_inputs,
                value_factor,
                output_blocks,
                heads_per_group=topology.target_query_heads_per_group,
            ),
            endpoint_target,
        )
    )
    frontier = [
        {
            "proposal_index": 0,
            "stage": (
                (
                    "residual_vo_seed_zero_delta_identity_anchor"
                    if initial_vo_seed_bank["selected_candidate_id"]
                    == "authenticated_residual_vo"
                    else (
                        "scalable_producer_shared_value_sequence_output_seed"
                        if initial_vo_seed_bank["selected_candidate_id"]
                        == "producer_shared_value"
                        else (
                            initial_vo_seed_bank["selected_candidate_id"]
                            + "_exact_target_dtype_seed"
                        )
                    )
                )
                if streamed_headwise
                else "residual_vo_seed_zero_delta_identity_anchor"
                if seeded
                else "effective_operator_shared_value_svd_seed"
            ),
            "accepted": True,
            (
                "weighted_fit_relative_rmse_fp64"
                if seeded
                else "weighted_fit_relative_rmse"
            ): accepted_error,
            "value_factor_sha256": _tensor_sha256(value_factor),
            "output_blocks_sha256": _tensor_sha256(output_blocks),
            "solve_report_sha256": output_solve["report_sha256"],
            **(
                {
                    "initial_vo_seed_bank_sha256": (
                        initial_vo_seed_bank["report_sha256"]
                    ),
                    "initial_vo_seed_candidate_id": (
                        initial_vo_seed_bank["selected_candidate_id"]
                    ),
                    "initial_vo_seed_candidate_index": (
                        initial_vo_seed_bank["selected_candidate_index"]
                    ),
                    "initial_vo_seed_exact_target_dtype": True,
                }
                if streamed_headwise
                else {}
            ),
            **(
                {
                    "zero_delta_ridge_anchor": True,
                    "residual_vo_seed_sha256": residual_seed_before,
                    "value_delta_sha256": _tensor_sha256(
                        torch.zeros_like(value_factor)
                    ),
                    "output_delta_sha256": _tensor_sha256(
                        torch.zeros_like(output_blocks)
                    ),
                }
                if seeded
                else {}
            ),
        }
    ]
    proposal_states = [(value_factor.clone(), output_blocks.clone())]
    accepted_iterations = 0
    solve_reports = [effective_solve, output_solve]
    seeded_early_stop_reason = None
    delta_solve_fallback_index = None
    als_iteration_limit = (
        min(
            selected_policy.maximum_als_iterations,
            _MAXIMUM_STREAMED_ALS_ITERATIONS,
        )
        if streamed_headwise or seeded
        else selected_policy.maximum_als_iterations
    )
    if seeded and accepted_error <= selected_policy.fit_tolerance:
        als_iteration_limit = 0
        seeded_early_stop_reason = "seed_fit_within_policy_tolerance"
    for iteration in range(1, als_iteration_limit + 1):
        try:
            if streamed_headwise:
                proposed_value, value_reports = _structured_value_pcg_sweep(
                    statistics=sequence_statistics,
                    topology=topology,
                    value_factor=value_factor,
                    output_blocks=output_blocks,
                    policy=selected_policy,
                    iteration=iteration,
                    value_seed=proposal_states[0][0] if seeded else None,
                )
                proposed_output, proposed_output_report = (
                    _fit_output_from_sequence_statistics(
                        statistics=sequence_statistics,
                        topology=topology,
                        value_factor=proposed_value,
                        policy=selected_policy,
                        role=(
                            "sequence_effective_streamed_output_iteration_"
                            f"{iteration}"
                        ),
                        output_seed=(
                            proposal_states[0][1] if seeded else None
                        ),
                    )
                )
            else:
                proposed_value, value_reports = _block_value_sweep(
                    attended_inputs,
                    endpoint_target,
                    value_factor,
                    output_blocks,
                    heads_per_group=(
                        topology.target_query_heads_per_group
                    ),
                    policy=selected_policy,
                    iteration=iteration,
                    value_seed=(
                        proposal_states[0][0] if seeded else None
                    ),
                )
                (
                    proposed_output,
                    _features,
                    proposed_output_report,
                ) = _fit_output(
                    attended_inputs,
                    endpoint_target,
                    proposed_value,
                    heads_per_group=(
                        topology.target_query_heads_per_group
                    ),
                    policy=selected_policy,
                    role=f"sequence_effective_output_iteration_{iteration}",
                    output_seed=(
                        proposal_states[0][1] if seeded else None
                    ),
                )
        except Lfm2SequenceEffectiveAttentionFoldError as error:
            if (
                not seeded
                or not _recoverable_residual_delta_solve_failure(error)
            ):
                raise
            failure = dict(error.failure_report)
            frontier.append(
                _seal(
                    {
                        "proposal_index": iteration,
                        "stage": "residual_seeded_delta_solve_rejected",
                        "accepted": False,
                        "eligible_for_target_dtype_selection": False,
                        "selected_for_materialization": False,
                        "weighted_fit_relative_rmse_fp64": None,
                        "weighted_fit_relative_rmse_target_dtype": None,
                        "failure_report": failure,
                        "failure_report_sha256": failure["report_sha256"],
                        "fallback_to_last_prior_finite_proposal": True,
                        "last_prior_proposal_index": (
                            len(proposal_states) - 1
                        ),
                    }
                )
            )
            delta_solve_fallback_index = len(proposal_states) - 1
            seeded_early_stop_reason = "typed_numerical_delta_solve_failure"
            break
        if not seeded:
            proposed_value, proposed_output = _canonicalize_value_factor(
                proposed_value,
                proposed_output,
            )
        proposed_error = (
            float(proposed_output_report["relative_rmse"])
            if streamed_headwise
            else _relative_rmse(
                _prediction(
                    attended_inputs,
                    proposed_value,
                    proposed_output,
                    heads_per_group=topology.target_query_heads_per_group,
                ),
                endpoint_target,
            )
        )
        if seeded and not math.isfinite(proposed_error):
            failure = _seal(
                {
                    "status": "failed_closed",
                    "failure_stage": "residual_delta_fit_scoring",
                    "failure_reason": "non_finite_fp64_fit_score",
                    "proposal_index": iteration,
                }
            )
            frontier.append(
                _seal(
                    {
                        "proposal_index": iteration,
                        "stage": "residual_seeded_delta_solve_rejected",
                        "accepted": False,
                        "eligible_for_target_dtype_selection": False,
                        "selected_for_materialization": False,
                        "weighted_fit_relative_rmse_fp64": None,
                        "weighted_fit_relative_rmse_target_dtype": None,
                        "failure_report": failure,
                        "failure_report_sha256": failure["report_sha256"],
                        "fallback_to_last_prior_finite_proposal": True,
                        "last_prior_proposal_index": (
                            len(proposal_states) - 1
                        ),
                    }
                )
            )
            delta_solve_fallback_index = len(proposal_states) - 1
            seeded_early_stop_reason = "non_finite_delta_fit_score"
            break
        accepted = bool(
            math.isfinite(proposed_error)
            and (
                seeded
                or proposed_error
                <= accepted_error + selected_policy.fit_tolerance
            )
        )
        solve_reports.extend(value_reports)
        solve_reports.append(proposed_output_report)
        frontier.append(
            {
                "proposal_index": iteration,
                "stage": (
                    "residual_seeded_zero_centered_value_output_delta_sweep"
                    if seeded
                    else "monotone_streamed_effective_space_value_output_als"
                    if streamed_headwise
                    else "monotone_closed_form_value_output_als"
                ),
                "accepted": accepted,
                (
                    "weighted_fit_relative_rmse_fp64"
                    if seeded
                    else "weighted_fit_relative_rmse"
                ): proposed_error,
                "value_factor_sha256": _tensor_sha256(proposed_value),
                "output_blocks_sha256": _tensor_sha256(proposed_output),
                "value_solve_report_sha256": [
                    report["report_sha256"] for report in value_reports
                ],
                "output_solve_report_sha256": (
                    proposed_output_report["report_sha256"]
                ),
                **(
                    {
                        "parameterization": (
                            "value=value_seed+delta;"
                            "output=output_seed+delta"
                        ),
                        "zero_delta_ridge_anchor": True,
                        "value_delta_sha256": _tensor_sha256(
                            proposed_value - proposal_states[0][0]
                        ),
                        "output_delta_sha256": _tensor_sha256(
                            proposed_output - proposal_states[0][1]
                        ),
                    }
                    if seeded
                    else {}
                ),
            }
        )
        if not accepted:
            break
        value_factor = proposed_value
        output_blocks = proposed_output
        accepted_error = proposed_error
        accepted_iterations += 1
        proposal_states.append(
            (value_factor.clone(), output_blocks.clone())
        )

    if seeded:
        target_dtype_proposals = []
        for proposal_index, (proposal_value, proposal_output) in enumerate(
            proposal_states
        ):
            (
                candidate_value,
                candidate_output,
                candidate_factor,
                candidate_blocks,
            ) = _materialize_vo_proposal(
                value_factor=proposal_value,
                output_blocks=proposal_output,
                topology=topology,
                value_dtype=value_dtype,
                output_dtype=output_dtype,
            )
            if not bool(
                torch.isfinite(candidate_value).all().item()
                and torch.isfinite(candidate_output).all().item()
            ):
                frontier[proposal_index][
                    "weighted_fit_relative_rmse_target_dtype"
                ] = None
                frontier[proposal_index][
                    "eligible_for_target_dtype_selection"
                ] = False
                frontier[proposal_index][
                    "target_dtype_selection_rejection_reason"
                ] = "non_finite_materialized_tensor"
                continue
            if streamed_headwise:
                candidate_metrics = (
                    _sequence_statistics_relative_rmse(
                        statistics=sequence_statistics,
                        topology=topology,
                        value_factor=candidate_factor,
                        output_blocks=candidate_blocks,
                    ),
                    None,
                    None,
                )
            else:
                candidate_metrics = (
                    _relative_rmse(
                        _prediction(
                            attended_inputs,
                            candidate_factor,
                            candidate_blocks,
                            heads_per_group=(
                                topology.target_query_heads_per_group
                            ),
                        ),
                        endpoint_target,
                    ),
                    _relative_rmse(
                        _prediction(
                            plain_attended_inputs,
                            candidate_factor,
                            candidate_blocks,
                            heads_per_group=(
                                topology.target_query_heads_per_group
                            ),
                        ),
                        plain_endpoint_target,
                    ),
                    _fit_context_preservation(
                        producer=producer,
                        normalized_cases=normalized_cases,
                        fit_cases=cases,
                        materialized_value_factor=candidate_factor,
                    ),
                )
            if not math.isfinite(candidate_metrics[0]) or any(
                value is not None and not math.isfinite(value)
                for value in candidate_metrics[1:]
            ):
                frontier[proposal_index][
                    "weighted_fit_relative_rmse_target_dtype"
                ] = None
                frontier[proposal_index][
                    "eligible_for_target_dtype_selection"
                ] = False
                frontier[proposal_index][
                    "target_dtype_selection_rejection_reason"
                ] = "non_finite_fit_metric"
                continue
            frontier[proposal_index][
                "weighted_fit_relative_rmse_target_dtype"
            ] = candidate_metrics[0]
            frontier[proposal_index][
                "eligible_for_target_dtype_selection"
            ] = True
            frontier[proposal_index]["target_dtype_fit_score_source"] = (
                "projected_cached_cross_head_gram_and_endpoint_right"
                if streamed_headwise
                else "materialized_fit_row_operator"
            )
            target_dtype_proposals.append(
                (
                    candidate_metrics[0],
                    proposal_index,
                    candidate_value,
                    candidate_output,
                    candidate_factor,
                    candidate_blocks,
                    candidate_metrics,
                )
            )
        if not target_dtype_proposals:
            raise Lfm2SequenceEffectiveAttentionFoldError(
                "Residual V/O seeded frontier has no finite target-dtype "
                "fit proposal."
            )
        if delta_solve_fallback_index is not None:
            eligible_selection = tuple(
                proposal
                for proposal in target_dtype_proposals
                if proposal[1] <= delta_solve_fallback_index
            )
            selection_pool = (
                max(eligible_selection, key=lambda proposal: proposal[1]),
            )
            selection_rule = "last_prior_finite_after_typed_solve_failure"
        else:
            best_target_dtype_score = min(
                proposal[0] for proposal in target_dtype_proposals
            )
            selection_pool = tuple(
                proposal
                for proposal in target_dtype_proposals
                if proposal[0]
                <= best_target_dtype_score + selected_policy.fit_tolerance
            )
            selection_rule = (
                "lowest_proposal_index_within_fit_tolerance_of_best"
            )
        (
            _selected_score,
            selected_proposal_index,
            compiled_value,
            compiled_output,
            materialized_factor,
            materialized_blocks,
            selected_metrics,
        ) = min(selection_pool, key=lambda proposal: proposal[1])
        for proposal in frontier:
            if "report_sha256" not in proposal:
                proposal["selected_for_materialization"] = (
                    proposal["proposal_index"] == selected_proposal_index
                )
        anchored_value, anchored_output = proposal_states[
            selected_proposal_index
        ]
        anchored_error = float(
            frontier[selected_proposal_index][
                "weighted_fit_relative_rmse_fp64"
            ]
        )
        anchor_reports = [
            {
                "kind": "zero_delta_ridge_identity_anchor",
                "residual_vo_seed_sha256": residual_seed_before,
                "proposal_zero_preserved_in_frontier": True,
                "producer_value_subspace_anchor_applied": False,
                "selection_metric": (
                    "weighted_fit_relative_rmse_target_dtype"
                ),
                "selected_proposal_index": selected_proposal_index,
                "deterministic_selection_rule": selection_rule,
            }
        ]
        weighted_materialized_error = selected_metrics[0]
        plain_materialized_error = selected_metrics[1]
        fit_context_error = selected_metrics[2]
    else:
        anchored_value, anchor_reports = _producer_value_anchor(
            value_factor,
            producer,
            policy=selected_policy,
        )
        if streamed_headwise:
            anchored_output, anchor_output_report = (
                _fit_output_from_sequence_statistics(
                    statistics=sequence_statistics,
                    topology=topology,
                    value_factor=anchored_value,
                    policy=selected_policy,
                    role="sequence_effective_streamed_anchored_output",
                )
            )
        else:
            anchored_output, _features, anchor_output_report = _fit_output(
                attended_inputs,
                endpoint_target,
                anchored_value,
                heads_per_group=topology.target_query_heads_per_group,
                policy=selected_policy,
                role="sequence_effective_anchored_output",
            )
        anchored_value, anchored_output = _canonicalize_value_factor(
            anchored_value,
            anchored_output,
        )
        anchored_error = (
            float(anchor_output_report["relative_rmse"])
            if streamed_headwise
            else _relative_rmse(
                _prediction(
                    attended_inputs,
                    anchored_value,
                    anchored_output,
                    heads_per_group=topology.target_query_heads_per_group,
                ),
                endpoint_target,
            )
        )
        solve_reports.append(anchor_output_report)
        frontier.append(
            {
                "proposal_index": len(frontier),
                "stage": "fixed_producer_value_subspace_anchor",
                "accepted": True,
                "selected_for_materialization": True,
                "weighted_fit_relative_rmse": anchored_error,
                "value_factor_sha256": _tensor_sha256(anchored_value),
                "output_blocks_sha256": _tensor_sha256(anchored_output),
                "anchor_report_sha256": [
                    _sha256(report) for report in anchor_reports
                ],
                "output_solve_report_sha256": (
                    anchor_output_report["report_sha256"]
                ),
            }
        )
        (
            compiled_value,
            compiled_output,
            materialized_factor,
            materialized_blocks,
        ) = _materialize_vo_proposal(
            value_factor=anchored_value,
            output_blocks=anchored_output,
            topology=topology,
            value_dtype=value_dtype,
            output_dtype=output_dtype,
        )
    if not seeded and streamed_headwise:
        (
            weighted_materialized_error,
            plain_materialized_error,
            fit_context_error,
        ) = _streaming_materialized_metrics(
            producer=producer,
            cases=cases,
            query_norm_weight=q_norm,
            key_norm_weight=k_norm,
            norm_epsilon=epsilon,
            value_factor=materialized_factor,
            output_blocks=materialized_blocks,
        )
    elif not seeded:
        weighted_materialized_prediction = _prediction(
            attended_inputs,
            materialized_factor,
            materialized_blocks,
            heads_per_group=topology.target_query_heads_per_group,
        )
        plain_materialized_prediction = _prediction(
            plain_attended_inputs,
            materialized_factor,
            materialized_blocks,
            heads_per_group=topology.target_query_heads_per_group,
        )
        weighted_materialized_error = _relative_rmse(
            weighted_materialized_prediction,
            endpoint_target,
        )
        plain_materialized_error = _relative_rmse(
            plain_materialized_prediction,
            plain_endpoint_target,
        )
        fit_context_error = _fit_context_preservation(
            producer=producer,
            normalized_cases=normalized_cases,
            fit_cases=cases,
            materialized_value_factor=materialized_factor,
        )

    producer_after = _state_sha256(producer.state_dict())
    case_bundle_after = _case_bundle_sha256(cases)
    residual_seed_after = (
        residual_vo_seed.authentication_sha256
        if seeded and residual_vo_seed.verify_authentication()
        else None
    )
    if (
        producer_before != producer_after
        or case_bundle_before != case_bundle_after
        or residual_seed_before != residual_seed_after
    ):
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Producer, residual seed, or fit evidence changed during "
            "sequence-effective folding."
        )
    template_sha = structural._template_sha256(
        {
            "v_proj.weight": (value_shape, str(value_dtype)),
            "out_proj.weight": (output_shape, str(output_dtype)),
        }
    )
    state = {
        "q_proj.weight": producer.query_weight,
        "k_proj.weight": producer.key_weight,
        "v_proj.weight": compiled_value,
        "out_proj.weight": compiled_output,
    }
    compiled_sha = _state_sha256(state)
    source_logical = (
        producer.source_logical_parameters
        + topology.source_hidden_size
        * topology.source_query_heads
        * topology.head_dim
    )
    target_logical = sum(int(value.numel()) for value in state.values())
    if target_logical >= source_logical:
        raise Lfm2SequenceEffectiveAttentionFoldError(
            "Sequence-effective target attention is not structurally smaller."
        )
    frontier_sha = _sha256(frontier)
    artifact_policy = (
        _residual_delta_policy_report(selected_policy)
        if seeded
        else selected_policy.as_dict()
    )
    body = {
        "schema": (
            LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEEDED_SCHEMA
            if seeded
            else LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_SCHEMA
        ),
        "candidate_id": FIXED_QK_SEQUENCE_EFFECTIVE_VO_ALS_CANDIDATE_ID,
        "implementation": _IMPLEMENTATION,
        "policy": artifact_policy,
        "policy_sha256": artifact_policy["authentication_sha256"],
        "producer_artifact": producer.as_dict(),
        "producer_artifact_sha256": _sha256(producer.as_dict()),
        "fixed_query_key_sha256": producer.score_state_sha256,
        "fixed_query_key_state_reused_exactly": True,
        "topology": topology.as_dict(),
        "fit_case_count": len(cases),
        "fit_case_bundle_sha256": case_bundle_before,
        "fit_row_weighting_mode": (
            "explicit_authenticated_query_row_sqrt_weights"
            if explicit_weight_count == len(cases)
            else (
                "uniform_default"
                if explicit_weight_count == 0
                else "mixed_explicit_and_uniform"
            )
        ),
        "producer_state_sha256_before": producer_before,
        "producer_state_sha256_after": producer_after,
        "producer_state_unchanged": True,
        "target_template_sha256": template_sha,
        "compiled_state_sha256": compiled_sha,
        "solver_plan": solver_plan,
        "solver_strategy": solver_plan["strategy"],
        "streamed_pcg_execution_profile": (
            dict(
                LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE
            )
            if streamed_headwise
            else None
        ),
        "streamed_pcg_execution_profile_sha256": (
            LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE_SHA256
            if streamed_headwise
            else None
        ),
        "streamed_sufficient_statistics": (
            None if statistics_report is None else dict(statistics_report)
        ),
        **(
            {
                "initial_vo_seed_bank": dict(initial_vo_seed_bank),
                "initial_vo_seed_bank_sha256": initial_vo_seed_bank[
                    "report_sha256"
                ],
                "selected_initial_vo_seed_candidate_id": (
                    initial_vo_seed_bank["selected_candidate_id"]
                ),
                "selected_initial_vo_seed_candidate_index": (
                    initial_vo_seed_bank["selected_candidate_index"]
                ),
                "selected_initial_vo_seed_nonincreasing": (
                    initial_vo_seed_bank[
                        "selected_seed_nonincreasing_from_incumbent"
                    ]
                ),
            }
            if streamed_headwise
            else {}
        ),
        "complete_operator_quadratic_gram_avoided": solver_plan[
            "complete_operator_quadratic_gram_avoided"
        ],
        "complete_operator_dense_factorization_avoided": solver_plan[
            "complete_operator_dense_factorization_avoided"
        ],
        "forbidden_value_coefficient_tensor_materialized": False,
        "forbidden_hidden_head_dim_gram_materialized": False,
        "candidate_frontier": frontier,
        "candidate_frontier_sha256": frontier_sha,
        "bounded_proposal_count": len(frontier),
        **(
            {
                "maximum_als_iterations": (
                    selected_policy.maximum_als_iterations
                ),
                "executed_als_iteration_limit": als_iteration_limit,
                "accepted_als_iterations": accepted_iterations,
            }
            if not seeded
            else {
                "residual_delta_sweep_limit": als_iteration_limit,
                "completed_residual_delta_sweeps": accepted_iterations,
            }
        ),
        "selected_proposal_index": (
            selected_proposal_index if seeded else len(frontier) - 1
        ),
        "effective_operator_solve": effective_solve,
        "shared_value_svd": svd_reports,
        "solve_report_sha256": [
            report["report_sha256"] for report in solve_reports
        ],
        **(
            {
                "value_subspace_anchor": anchor_reports,
                "weighted_fit_relative_rmse_fp64_before_anchor": (
                    accepted_error
                ),
                "weighted_fit_relative_rmse_fp64_after_anchor": anchored_error,
                "weighted_fit_relative_rmse_target_dtype": (
                    weighted_materialized_error
                ),
                "unweighted_fit_relative_rmse_target_dtype": (
                    plain_materialized_error
                ),
                "fit_context_barycenter_relative_rmse_target_dtype": (
                    fit_context_error
                ),
            }
            if not seeded
            else {
                "residual_delta_identity_anchor": anchor_reports,
                "residual_delta_early_stop_reason": (
                    seeded_early_stop_reason
                ),
                "selected_weighted_fit_relative_rmse_fp64": (
                    anchored_error
                ),
                "selected_weighted_fit_relative_rmse_target_dtype": (
                    weighted_materialized_error
                ),
                "selected_unweighted_fit_relative_rmse_target_dtype": (
                    plain_materialized_error
                ),
                "selected_context_barycenter_relative_rmse_target_dtype": (
                    fit_context_error
                ),
            }
        ),
        "source_logical_parameters": source_logical,
        "target_logical_parameters": target_logical,
        "removed_logical_parameters": source_logical - target_logical,
        "parameter_reduction_fraction": (
            (source_logical - target_logical) / source_logical
        ),
        "fit_only_compilation": True,
        "compiled_from_splits": ["fit"],
        "selection_case_count_consumed": 0,
        "validation_case_count_consumed": 0,
        "selection_inputs_accessible": False,
        "validation_inputs_accessible": False,
        "causal_attended_input_operator": "z_h=softmax(Q_hK_h^T)X_K",
        "ordinary_dense_target_value_output": True,
        "dense_target_native_qkvo": True,
        "blank_target_values_read": False,
        "execution": dict(_ZERO_EXECUTION),
        **(
            {
                "residual_vo_seed": residual_vo_seed.as_dict(),
                "residual_vo_seed_sha256": residual_seed_before,
                "residual_delta_parameterization": True,
                "zero_delta_ridge_anchor": True,
                "producer_value_subspace_anchor_applied": False,
                "target_dtype_fit_selection": True,
                "target_dtype_fit_selection_rule": selection_rule,
                "maximum_residual_delta_als_sweeps": (
                    _MAXIMUM_STREAMED_ALS_ITERATIONS
                ),
                "source_seed_fit_provenance_cross_authenticated": False,
                "caller_source_artifact_cross_authentication_required": True,
                "streamed_target_dtype_scoring_replayed_fit_cases": (
                    False if streamed_headwise else None
                ),
            }
            if seeded
            else {}
        ),
    }
    return Lfm2CompiledFixedQkSequenceEffectiveAttentionFold(
        producer_artifact=producer,
        policy=selected_policy,
        value_weight=compiled_value,
        output_weight=compiled_output,
        fit_case_count=len(cases),
        fit_case_bundle_sha256=case_bundle_before,
        producer_state_sha256_before=producer_before,
        producer_state_sha256_after=producer_after,
        target_template_sha256=template_sha,
        compiled_state_sha256=compiled_sha,
        candidate_frontier_sha256=frontier_sha,
        report=_seal(body),
        residual_vo_seed=residual_vo_seed,
    )


def install_lfm2_fixed_qk_sequence_effective_attention_fold(
    target_attention: Any,
    compiled: Lfm2CompiledFixedQkSequenceEffectiveAttentionFold,
) -> Lfm2SequenceEffectiveAttentionInstallReport:
    """Install exact dense Q/K/V/O in place, restoring bytes on any failure."""

    torch = _torch()
    if not isinstance(
        compiled,
        Lfm2CompiledFixedQkSequenceEffectiveAttentionFold,
    ) or not compiled.verify_authentication():
        raise Lfm2SequenceEffectiveAttentionInstallError(
            "compiled must be an authenticated sequence-effective artifact."
        )
    modules = {
        "q_proj.weight": getattr(
            getattr(target_attention, "q_proj", None),
            "weight",
            None,
        ),
        "k_proj.weight": getattr(
            getattr(target_attention, "k_proj", None),
            "weight",
            None,
        ),
        "v_proj.weight": getattr(
            getattr(target_attention, "v_proj", None),
            "weight",
            None,
        ),
        "out_proj.weight": getattr(
            getattr(target_attention, "out_proj", None),
            "weight",
            None,
        ),
    }
    expected = compiled.state_dict()
    if any(not isinstance(value, torch.Tensor) for value in modules.values()):
        raise Lfm2SequenceEffectiveAttentionInstallError(
            "target_attention must expose dense Q/K/V/O weights."
        )
    for name, parameter in modules.items():
        if (
            tuple(parameter.shape) != tuple(expected[name].shape)
            or parameter.dtype != expected[name].dtype
        ):
            raise Lfm2SequenceEffectiveAttentionInstallError(
                f"Target {name} differs from the compiled shape or dtype."
            )
    identities = {name: id(value) for name, value in modules.items()}
    shapes = {name: tuple(value.shape) for name, value in modules.items()}
    dtypes = {name: str(value.dtype) for name, value in modules.items()}
    gradients = {
        name: (
            bool(value.requires_grad),
            None if value.grad is None else id(value.grad),
            None if value.grad is None else _tensor_sha256(value.grad),
        )
        for name, value in modules.items()
    }
    backup = {
        name: value.detach().to(device="cpu").clone()
        for name, value in modules.items()
    }
    try:
        with torch.no_grad():
            for name, parameter in modules.items():
                _copy_parameter(
                    parameter,
                    expected[name].to(
                        device=parameter.device,
                        dtype=parameter.dtype,
                    ),
                )
        installed_sha = _state_sha256(
            {
                name: parameter.detach().to(device="cpu").contiguous()
                for name, parameter in modules.items()
            }
        )
        body = {
            "schema": LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_INSTALL_SCHEMA,
            "candidate_id": FIXED_QK_SEQUENCE_EFFECTIVE_VO_ALS_CANDIDATE_ID,
            "compiled_artifact_report_sha256": (
                compiled.report["report_sha256"]
            ),
            "compiled_state_sha256": compiled.compiled_state_sha256,
            "installed_state_sha256": installed_sha,
            "parameter_identities_preserved": all(
                id(modules[name]) == identities[name] for name in modules
            ),
            "parameter_shapes_preserved": all(
                tuple(modules[name].shape) == shapes[name] for name in modules
            ),
            "parameter_dtypes_preserved": all(
                str(modules[name].dtype) == dtypes[name] for name in modules
            ),
            "gradient_state_preserved": all(
                (
                    bool(modules[name].requires_grad),
                    None if modules[name].grad is None else id(modules[name].grad),
                    None
                    if modules[name].grad is None
                    else _tensor_sha256(modules[name].grad),
                )
                == gradients[name]
                for name in modules
            ),
            "fixed_query_key_installed_exactly": (
                _state_sha256(
                    {
                        "q_proj.weight": modules["q_proj.weight"],
                        "k_proj.weight": modules["k_proj.weight"],
                    }
                )
                == compiled.producer_artifact.score_state_sha256
            ),
            "ordinary_dense_target_value_output": True,
            "accepted": False,
            "execution": dict(_ZERO_EXECUTION),
        }
        accepted = bool(
            body["parameter_identities_preserved"]
            and body["parameter_shapes_preserved"]
            and body["parameter_dtypes_preserved"]
            and body["gradient_state_preserved"]
            and body["fixed_query_key_installed_exactly"]
            and installed_sha == compiled.compiled_state_sha256
        )
        body["accepted"] = accepted
        if not accepted:
            raise Lfm2SequenceEffectiveAttentionInstallError(
                "Installed sequence-effective state failed exact authentication."
            )
        return Lfm2SequenceEffectiveAttentionInstallReport(_seal(body))
    except BaseException:
        try:
            with torch.no_grad():
                for name, parameter in modules.items():
                    _copy_parameter(
                        parameter,
                        backup[name].to(
                            device=parameter.device,
                            dtype=parameter.dtype,
                        ),
                    )
            if any(
                not torch.equal(
                    parameter.detach().to(device="cpu"),
                    backup[name],
                )
                for name, parameter in modules.items()
            ):
                raise Lfm2SequenceEffectiveAttentionInstallError(
                    "Sequence-effective installation rollback was not exact."
                )
        except BaseException as rollback_error:
            raise Lfm2SequenceEffectiveAttentionInstallError(
                "Sequence-effective installation and exact rollback both failed."
            ) from rollback_error
        raise


__all__ = [
    "FIXED_QK_SEQUENCE_EFFECTIVE_VO_ALS_CANDIDATE_ID",
    "FIXED_QK_SEQUENCE_EFFECTIVE_VO_ALS_POLICY_SHA256",
    "LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_INSTALL_SCHEMA",
    "LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEEDED_SCHEMA",
    "LFM2_FIXED_QK_SEQUENCE_EFFECTIVE_ATTENTION_SCHEMA",
    "LFM2_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEED_SCHEMA",
    "LFM2_SEQUENCE_EFFECTIVE_RESIDUAL_VO_SEED_PROVENANCE_SCHEMA",
    "LFM2_SEQUENCE_EFFECTIVE_PCG_OBSERVATION_SCHEMA",
    "LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_CHOLESKY_SCHEMA",
    "LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE",
    "LFM2_SEQUENCE_EFFECTIVE_HIDDEN_PARTIAL_TRACE_PCG_EXECUTION_PROFILE_SHA256",
    "LFM2_SEQUENCE_EFFECTIVE_ROW_BLOCK_JACOBI_SCHEMA",
    "Lfm2CompiledFixedQkSequenceEffectiveAttentionFold",
    "Lfm2FixedQkSequenceEffectiveVoAlsPolicy",
    "Lfm2SequenceEffectiveResidualVoSeed",
    "Lfm2SequenceEffectiveResidualVoSeedProvenance",
    "Lfm2SequenceEffectiveAttentionFoldError",
    "Lfm2SequenceEffectiveAttentionInstallError",
    "Lfm2SequenceEffectiveAttentionInstallReport",
    "compile_lfm2_fixed_qk_sequence_effective_attention_fold",
    "install_lfm2_fixed_qk_sequence_effective_attention_fold",
    "observe_lfm2_sequence_effective_pcg",
]
