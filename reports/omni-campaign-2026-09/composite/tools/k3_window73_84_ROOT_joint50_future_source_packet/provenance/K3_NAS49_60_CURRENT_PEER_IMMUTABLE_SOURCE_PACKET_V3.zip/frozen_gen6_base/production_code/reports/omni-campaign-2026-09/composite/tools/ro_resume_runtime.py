"""One actual closed36 RO prefix -> new own NAS 37-48 path-only transition."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path, PurePosixPath

from ro_resume_paths import ROResumePaths, NativeResumeReads, pinned_json, require
from k3_recovery_ancestry import RecoveryAncestry

RUN = "764524b1-96a9-4636-be74-942f9c54754c"
PREVIOUS_NATIVE = "9086d7c0a5ec2bc7cfd1b823aecdc12e2973b3c81b064776ad3670df9d6b7b69"
PREVIOUS_PACKET = "5b9559b8ac20428de7e4ac09201f71839f4d03113a985715ca81d3aedd01246c"
CLOSED36 = "dd0ab8e821307e352096cdded457934dfd6df3434cfbe40d74e24b09a215870b"
SEALED = "/run-output/ancestry/window-25-36-b873d51f-b251-4944-aa84-5d91df96e87b"


def file_sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def add_resume_source_arguments(parser):
    for name in ("manifest", "observation", "identity"):
        parser.add_argument("--resume-source-" + name)
        parser.add_argument("--resume-source-" + name + "-sha256")
    parser.add_argument("--resume-source-root")
    return parser


class Closed36Ancestry:
    def __init__(self, paths, identity, pins, tool_path):
        self.paths = paths
        self.identity = identity
        self.input_pins = pins
        self.packet_path = Path(pins["manifest"]["path"])
        self.packet_sha = pins["manifest"]["sha256"]
        self.current_sha = file_sha(tool_path)
        code = paths.proof["source_pins"]
        for basename, path in (("ro_resume_paths.py", Path(__file__).with_name("ro_resume_paths.py")),
                               ("ro_resume_runtime.py", Path(__file__))):
            require(file_sha(path) == code[basename], "actual shared RO mapping source changed: " + basename)
        require(self.current_sha == code["k3_dense_pass.py"], "actual executing native derivative SHA changed")
        prior_packet = paths.proof["previous_recovery_packet"]
        prior_native = paths.proof["previous_native_source"]
        require(prior_packet["sha256"] == PREVIOUS_PACKET and prior_native["sha256"] == PREVIOUS_NATIVE,
                "only authentic completed9086 and original saved35 packet ancestry supported")
        require(file_sha(prior_native["path"]) == PREVIOUS_NATIVE, "authentic previous native source bytes changed")
        self.original = RecoveryAncestry(prior_packet["path"], PREVIOUS_PACKET, prior_native["path"])
        require(self.original.current_sha == PREVIOUS_NATIVE, "prior packet is not genuine completed9086")
        self.legacy_context = self.original.legacy_context
        self.previous_context = self.original.current_context
        closed_path = self.paths.verify_old_recorded_reference(SEALED + "/window_continuity.json", CLOSED36)
        closed = json.loads(Path(closed_path).read_bytes())
        require(closed.get("schema") == "neural_forge.k3_actual_window_continuity.v1"
                and closed.get("full_prefix_layers") == 36 and closed.get("completed_window") == "25-36"
                and closed.get("actual_layers_processed_this_terminal_run") == [36]
                and closed.get("ffn_full_scan_complete") is True
                and closed.get("resume_context") == self.previous_context,
                "genuine sealed completed36 context/library/prefix proof required")
        self.current_context = copy.deepcopy(self.previous_context)
        self.current_context["software"]["tool_sha256"] = self.current_sha
        require(self.current_sha not in (PREVIOUS_NATIVE, self.legacy_context["software"]["tool_sha256"]),
                "new derivative must keep its genuine new source identity")
        self.packet = {"current_mounts": copy.deepcopy(paths.proof["current_mounts"])}
        self.prior = {"path": "/resume-prefix" + SEALED[len("/run-output"):] + "/window_continuity.json", "sha256": CLOSED36}

    def logical(self, path):
        value = str(path)
        source = str(self.paths.source)
        if value.startswith(source + "/"):
            return "/run-output/" + value[len(source) + 1:]
        if value.startswith("/run-output/"):
            return value
        raise ValueError("context file is outside exact RO prefix/new owned output")

    def pin(self, path, failure=False):
        if str(path).startswith("/recovery-source/"):
            return self.original.pin(path, failure=failure)
        logical = self.logical(path)
        require(logical in self.paths.old, "old context is not an exact frozen closed36 file")
        self.paths.read_path(logical)
        return self.paths.old[logical]

    def matches(self, producer_context, path):
        if producer_context == self.current_context:
            logical = self.logical(path)
            return logical in self.paths.writes and logical not in self.paths.old
        if producer_context not in (self.previous_context, self.legacy_context):
            return False
        logical = self.logical(path)
        require(logical in self.paths.old, "old producer context is unlisted in closed36 catalog")
        self.pin(path)
        return True

    def matches_stamp(self, producer_context_json, path):
        try:
            producer = json.loads(producer_context_json)
        except (TypeError, ValueError):
            return False
        return self.matches(producer, path)

    def historical_path(self, relative):
        return self.original.historical_path(relative)

    def map_read(self, logical):
        return self.paths.read_path(logical)

    def record(self):
        return {"schema": "neural_forge.k3_closed36_RO_NAS_ancestry.v1",
                "current_tool_sha256": self.current_sha, "completed_producer_tool_sha256": PREVIOUS_NATIVE,
                "legacy_tool_sha256": self.legacy_context["software"]["tool_sha256"],
                "closed36_continuity_sha256": CLOSED36, "previous_recovery_packet_sha256": PREVIOUS_PACKET,
                "input_pins": copy.deepcopy(self.input_pins), "only_context_change": "software.tool_sha256",
                "producer_contexts_rewritten": False, "failed_layer_preserved": 36,
                "saved_prefix_through_layer": 36, "new_layer_range": [37, 48],
                "path_mapping": self.paths.record(), "runtime_admission_claimed": False}


def nas_resume_from_arguments(args, tool_path):
    pins = {}
    docs = {}
    for name in ("manifest", "observation", "identity"):
        path = getattr(args, "resume_source_" + name, None)
        expected = getattr(args, "resume_source_" + name + "_sha256", None)
        require(isinstance(path, str) and bool(path) and isinstance(expected, str),
                "explicit pinned RO resume source " + name + " required")
        p = Path(path)
        require(p.is_file() and not p.is_symlink(), "regular explicit RO metadata input required")
        raw = p.read_bytes()
        docs[name] = (raw, pinned_json(raw, expected))
        pins[name] = {"path": path, "sha256": expected, "bytes": len(raw)}
    identity = docs["identity"][1]
    require(identity.get("run_uuid") == RUN and identity.get("new_layers") == [37, 48]
            and identity.get("only_this_window_scope") is True
            and identity.get("resume_source_mounted_read_only") is True
            and identity.get("closed36_continuity_sha256") == CLOSED36
            and identity.get("native_binding", {}).get("session_generation") == 6,
            "exact current own generation6 bounded37-48 identity required")
    acting = {"owner": identity["owner"], "native_context": identity["native_thread_id"],
              "run_uuid": identity["run_uuid"], "image": identity["image"],
              "control_binding": identity["native_binding"]}
    paths = ROResumePaths(docs["manifest"][0], pins["manifest"]["sha256"],
                          docs["observation"][0], pins["observation"]["sha256"], acting_identity=acting)
    require(getattr(args, "resume_source_root", None) == "/resume-prefix"
            and str(paths.source) == "/resume-prefix" and str(paths.output) == "/run-output"
            and paths.first == 37 and paths.last == 48
            and paths.proof["source_root"]["host_path"] == identity["readonly_resume_source_root"]
            and paths.proof["output_root"]["host_path"] == identity["native_working_output_root"],
            "exact actual source aliases/host roots and one-window phase required")
    actual_mounts = {row["target"]: row for row in paths.proof["current_mounts"]}
    require(actual_mounts["/resume-prefix"] == {"target": "/resume-prefix", "source": identity["readonly_resume_source_root"], "read_only": True}
            and actual_mounts["/run-output"] == {"target": "/run-output", "source": identity["native_working_output_root"], "read_only": False}
            and actual_mounts["/run-control-output"] == {"target": "/run-control-output", "source": identity["controller_output_root"], "read_only": False},
            "actual declared RO-prefix/new NAS/model and separate controller mounts required")
    return paths, Closed36Ancestry(paths, identity, pins, tool_path)
