"""Candidate only: exact sealed reads and separately declared future writes.

The installed owner must pin this module, both manifests, actual mount/cap
evidence, and its current session before adoption. This module neither allocates
nor writes files. It never changes strings in historical receipts.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
import stat
import uuid
from pathlib import Path, PurePosixPath

CATALOG_SCHEMA = "chimera.k3_RO_prefix_fresh_NAS_output_source_route_review.v2"
CONTRACT_SCHEMA = "chimera.k3_RO_prefix_separate_output_observation.v1"
LOGICAL = "/run-output"
SOURCE_ALIAS = "/resume-prefix"
PREFIX_END = 36
NATIVE = "01a11108-009c-72f3-b2ba-e0d48fca1435"
OWNER = "codex-native-" + NATIVE
IMAGE = "sha256:d4ef16f161e51df2bd51df62c1aaa4ea7d9fc65fefcbaef8382027a527ec3ba6"
STAT_FIELDS = ("dev", "ino", "size", "mtime_ns", "ctime_ns", "mode")
ROOT_FIELDS = ("dev", "ino", "mode")


def require(value, message):
    if value is not True:
        raise ValueError(message)


def _unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def pinned_json(raw, expected):
    require(isinstance(raw, bytes) and re.fullmatch(r"[0-9a-f]{64}", expected or "") is not None,
            "raw pinned JSON and complete SHA256 required")
    require(hashlib.sha256(raw).hexdigest() == expected, "source/observation manifest SHA differs")
    return json.loads(raw, object_pairs_hook=_unique)


def logical_relative(value):
    require(isinstance(value, str) and "\\" not in value and "\x00" not in value,
            "canonical POSIX logical string required")
    path = PurePosixPath(value)
    require(path.is_absolute() and str(path) == value and ".." not in path.parts
            and path.is_relative_to(LOGICAL) and str(path) != LOGICAL,
            "canonical descendant of /run-output required")
    return path.relative_to(LOGICAL)


def _old_role(relative, role):
    s = str(relative)
    if role in ("closed_prefix_ffn.safetensors", "closed_prefix_done.json"):
        m = re.fullmatch(r"fold/dense/L(\d{2})/(ffn\.safetensors|done\.json)", s)
        return (m is not None and 1 <= int(m[1]) <= PREFIX_END
                and m[2] == role.removeprefix("closed_prefix_"))
    if role == "closed_prefix_verbatim_body":
        m = re.fullmatch(r"body/L(\d{2})/body\.safetensors", s)
        return m is not None and 1 <= int(m[1]) <= PREFIX_END
    if role == "original_dense_L00_or_globals":
        return s in {"body/model_level.safetensors", "body/L00/body.safetensors",
                     "fold/dense/L00/mlp.safetensors", "fold/dense/L00/done.json"}
    if role == "native_before37_dual_boundary":
        return s in {"fold/snapshots/before_L37.safetensors",
                     "fold/snapshots/before_L37_folded.safetensors"}
    if role == "sealed25_36_ancestry":
        prefix = "ancestry/window-25-36-b873d51f-b251-4944-aa84-5d91df96e87b/"
        return s.startswith(prefix) and s != prefix
    return False


def _future_role(relative, first, last):
    s = str(relative)
    m = re.fullmatch(r"(?:fold/dense/L(\d{2})/(?:ffn\.safetensors|done\.json)|"
                     r"body/L(\d{2})/body\.safetensors|"
                     r"fold/resid/L(\d{2})/held_rows\.safetensors)", s)
    if m:
        layer = next(int(x) for x in m.groups() if x is not None)
        return first <= layer <= last
    m = re.fullmatch(r"fold/dense/L(\d{2})/L(\d{2})_K17408_formE\.safetensors", s)
    if m:
        return int(m[1]) == int(m[2]) and first <= int(m[1]) <= last
    m = re.fullmatch(r"fold/snapshots/before_L(\d{2})(?:_folded)?\.safetensors", s)
    if m:
        # Existing before37 is a read-only initial condition, never a new write.
        return first < int(m[1]) <= last + 1
    if s == "fold/snapshots/snapshots_manifest.json":
        return True
    if s in {"receipts/k3_dense_pass_receipt.json", "receipts/k3_dense_pass_receipt.partial.json",
             "receipts/k3_dense_pass_receipt.sha256"}:
        return True
    # Caller must still provide a finite, exact path allowlist. No directory
    # wildcard, inherited arbitrary ancestry path, or copied old prefix applies.
    m = re.fullmatch(r"ancestry/(window-\d+-\d+-[0-9a-f-]{36})/(.+)", s)
    if m:
        lo, hi = (int(x) for x in m[1].split("-")[1:3])
        inner = m[2]
        metadata_names = {"original_record_plan.json", "original_accepted_receipt.json",
                          "native_runtime_observation.json", "separate_copy_receipt.json",
                          "full_ffn_validation.json", "previous_window_continuity.json"}
        if inner in {"window_continuity.json", "ffn_request.json"} or inner in {"inputs/"+x for x in metadata_names}:
            return first <= lo <= hi <= last
        return first <= lo <= hi <= last and _future_role(PurePosixPath(inner), first, last)
    return False


class LocalFiles:
    """Production backend; tests inject explicitly synthetic filesystem doubles."""
    @staticmethod
    def identity(path):
        s = Path(path).lstat()
        return dict(dev=s.st_dev, ino=s.st_ino, size=s.st_size,
                    mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns, mode=s.st_mode)

    @staticmethod
    def hash(path):
        with Path(path).open("rb") as stream:
            return hashlib.file_digest(stream, "sha256").hexdigest()

    @staticmethod
    def exists(path):
        return Path(path).exists() or Path(path).is_symlink()


class ROResumePaths:
    def __init__(self, catalog_raw, catalog_sha256, observation_raw, observation_sha256,
                 *, acting_identity, backend=None):
        self.fs = backend if backend is not None else LocalFiles()
        self.catalog = pinned_json(catalog_raw, catalog_sha256)
        self.proof = pinned_json(observation_raw, observation_sha256)
        require(self.catalog.get("schema") == CATALOG_SCHEMA
                and self.proof.get("schema") == CONTRACT_SCHEMA,
                "exact catalog and observation schemas required")
        require(self.proof.get("source_catalog_sha256") == catalog_sha256,
                "physical observation bound to different source catalog")
        identity = self.proof.get("acting_identity")
        require(isinstance(identity, dict) and identity == acting_identity
                and all(identity.get(k) for k in
                        ("owner", "native_context", "run_uuid", "image", "control_binding")),
                "exact current acting owner/native/run/image/full binding required")
        require(identity["owner"] == OWNER and identity["native_context"] == NATIVE
                and identity["image"] == IMAGE
                and identity["control_binding"].get("harness_id") == NATIVE,
                "fixed genuine K3 owner/native/immutable image required")
        uuid.UUID(identity["run_uuid"])
        self.acting_identity = copy.deepcopy(identity)
        self.first, self.last = self.proof.get("first_new_layer"), self.proof.get("last_new_layer")
        require(type(self.first) is int and type(self.last) is int
                and self.first == PREFIX_END + 1 and self.last == 48,
                "fresh suffix must start37 with exact bounded end")
        self.source = Path(self.proof["source_root"]["path"])
        self.output = Path(self.proof["output_root"]["path"])
        if backend is None:
            require(str(self.source) == SOURCE_ALIAS and str(self.output) == LOGICAL,
                    "production resolver must use exact actual container mount aliases")
        host_source = PurePosixPath(self.proof["source_root"].get("host_path", ""))
        host_output = PurePosixPath(self.proof["output_root"].get("host_path", ""))
        require(host_source.is_absolute() and host_output.is_absolute()
                and str(host_source) == self.proof["source_root"]["host_path"]
                and str(host_output) == self.proof["output_root"]["host_path"]
                and ".." not in host_source.parts and ".." not in host_output.parts
                and host_output.is_relative_to("/mnt/ai_data")
                and not host_output.is_relative_to("/mnt/ai_data/neural-forge-archives")
                and host_source != host_output,
                "canonical existing source and separate own NAS host mapping required")
        require(self.source.is_absolute() and self.output.is_absolute()
                and ".." not in self.source.parts and ".." not in self.output.parts
                and self.source != self.output
                and not self.source.is_relative_to(self.output)
                and not self.output.is_relative_to(self.source),
                "distinct nonoverlapping absolute source/output roots required")
        require(self.proof["source_root"]["alias"] == SOURCE_ALIAS
                and self.proof["source_root"]["read_only"] is True
                and self.proof["output_root"]["alias"] == LOGICAL
                and self.proof["output_root"]["read_only"] is False
                and self.proof["source_root"]["stat"]["dev"] != self.proof["output_root"]["stat"]["dev"],
                "exact RO old root and distinct-filesystem RW new root mounts required")
        self._check_roots()
        self.old = {}
        for row in self.catalog["input_catalog"]:
            logical = row.get("recorded_logical_path", LOGICAL + "/" + row.get("relative_path", ""))
            rel = logical_relative(logical)
            require(logical not in self.old and _old_role(rel, row.get("role")),
                    "duplicate/unapproved source role or source future-layer alias")
            require(re.fullmatch(r"[0-9a-f]{64}", row.get("sha256", "")) is not None,
                    "complete real source SHA required")
            require(row.get("prospective_RO_input_path") == SOURCE_ALIAS + "/" + str(rel),
                    "source catalog RO alias mapping differs")
            require(row.get("unchanged_host_input_path") == str(host_source / rel),
                    "actual host source mapping differs from pinned historical source")
            self.old[logical] = copy.deepcopy(row)
        require(len(self.old) == 127, "complete frozen125 plus two exact additional source roles required")
        require(self.catalog.get("parent_catalog_sha256") == "0f16806c5337ebe998e81893d463ba12d47489ad7cb7a26199f36b1f3864b227"
                and hashlib.sha256(json.dumps(self.catalog["input_catalog"][:125], sort_keys=True, separators=(",", ":")).encode()).hexdigest() == "ce1c414c44adf88c3b32db097a95e90af2c761a728d596d8a741d784b2b896d7",
                "original125 mappings must remain byte-value identical")
        observed = self.proof.get("source_files")
        require(isinstance(observed, dict) and set(observed) == set(self.old),
                "all125 actual source observations must join exactly")
        for logical, row in self.old.items():
            fact = observed[logical]
            require(fact.get("source_sha256") == row["sha256"]
                    and fact.get("path") == str(self.source / logical_relative(logical))
                    and set(fact.get("stat", {})) == set(STAT_FIELDS)
                    and fact["stat"]["dev"] == self.proof["source_root"]["stat"]["dev"]
                    and stat.S_ISREG(fact["stat"]["mode"]),
                    "observed source path/hash/device/regular identity differs")
            if "bytes" in row:
                require(fact["stat"]["size"] == row["bytes"], "source catalog byte extent differs")
        self.writes = set()
        declared = self.proof.get("new_write_paths")
        require(isinstance(declared, list) and declared and len(set(declared)) == len(declared),
                "finite exact new write paths required")
        for logical in declared:
            rel = logical_relative(logical)
            require(logical not in self.old and _future_role(rel, self.first, self.last),
                    "old/unlisted/future-outside-phase write role refused")
            self.writes.add(logical)
        self._verified = {}
        self._issued_new = set()
        self._created_new = {}

    def _check_roots(self):
        for path, key in ((self.source, "source_root"), (self.output, "output_root")):
            got = self.fs.identity(path)
            want = self.proof[key]["stat"]
            require(stat.S_ISDIR(got["mode"]) and all(got[k] == want[k] for k in ROOT_FIELDS),
                    "actual root device/inode/type changed")
            # Detect a symlink anywhere below the absolute root. The mount/
            # parent authority is independently supplied by normal owner guards.
            for parent in path.parents:
                require(not stat.S_ISLNK(self.fs.identity(parent)["mode"]), "root ancestor symlink refused")

    def _check_descendant(self, path, root, expected_device, *, may_not_exist=False):
        relative = path.relative_to(root)
        current = root
        parts = relative.parts
        for i, part in enumerate(parts):
            current = current / part
            if not self.fs.exists(current):
                require(may_not_exist, "missing declared source/new file; no fallback")
                continue
            got = self.fs.identity(current)
            require(got["dev"] == expected_device and not stat.S_ISLNK(got["mode"]),
                    "descendant device or symlink alias differs")
            require(stat.S_ISDIR(got["mode"]) if i < len(parts)-1 else stat.S_ISREG(got["mode"]),
                    "descendant special object or wrong type")

    def read_path(self, logical):
        """Existing exact roles always use RO root, new roles always new root."""
        rel = logical_relative(logical)
        self._check_roots()
        if logical in self.old:
            path = self.source / rel
            device = self.proof["source_root"]["stat"]["dev"]
            self._check_descendant(path, self.source, device)
            observed = self.proof["source_files"][logical]
            before = self.fs.identity(path)
            require(before == observed["stat"], "source physical identity changed")
            token = tuple(before[k] for k in STAT_FIELDS)
            if self._verified.get(logical) != token:
                require(self.fs.hash(path) == self.old[logical]["sha256"], "source body SHA differs")
                require(self.fs.identity(path) == before, "source changed during body verification")
                self._verified[logical] = token
            return path
        require(logical in self.writes, "unlisted read role refused")
        path = self.output / rel
        self._check_descendant(path, self.output, self.proof["output_root"]["stat"]["dev"])
        return path

    def write_path(self, logical):
        """Returns a declared destination only; this method never opens/writes it."""
        rel = logical_relative(logical)
        self._check_roots()
        require(logical in self.writes and logical not in self.old,
                "writes to old prefix or unlisted destination refused")
        path = self.output / rel
        self._check_descendant(path, self.output, self.proof["output_root"]["stat"]["dev"], may_not_exist=True)
        if self.fs.exists(path):
            require(logical in self._created_new, "existing undeclared-ownership output must be preserved")
            current = self.fs.identity(path)
            require(all(current[k] == self._created_new[logical][k] for k in ("dev", "ino", "mode")),
                    "own new output identity changed before rewrite")
        else:
            self._issued_new.add(logical)
        return path

    def note_created_output(self, logical):
        """Records a caller-created new output; supplies no creation/admission proof."""
        require(logical in self._issued_new and logical in self.writes,
                "no own issued new output path exists")
        path = self.read_path(logical)
        self._created_new[logical] = self.fs.identity(path)

    def verify_old_recorded_reference(self, logical, recorded_sha256):
        require(logical in self.old and recorded_sha256 == self.old[logical]["sha256"],
                "old marker/receipt hash differs from frozen source role")
        return self.read_path(logical)

    def record(self):
        return {"schema": "chimera.k3.RO_resume_mapping_provenance.v1",
                "acting_identity": copy.deepcopy(self.acting_identity),
                "source_root": copy.deepcopy(self.proof["source_root"]),
                "output_root": copy.deepcopy(self.proof["output_root"]),
                "prefix_through": PREFIX_END, "new_layer_range": [self.first, self.last],
                "old_receipt_strings_rewritten": False, "runtime_admission_claimed": False,
                "verified_in_this_instance": sorted(self._verified)}


class NativeResumeReads:
    """Explicit native call-site candidates; writer methods must use write_path."""
    def __init__(self, resolver):
        self.paths = resolver

    def marker(self, layer):
        return self.paths.read_path(f"/run-output/fold/dense/L{layer:02d}/done.json")

    def ffn_reference(self, entry):
        return VerifierReads(self.paths).recorded(entry["path"], entry["sha256"])

    def sealed_metadata(self, basename):
        require(basename in {"k3_dense_pass_receipt.json", "k3_dense_pass_receipt.partial.json",
                             "snapshots_manifest.json", "k3_dense_pass_receipt.sha256"}, "explicit sealed native metadata role required")
        choices = [logical for logical, row in self.paths.old.items()
                   if row["role"] == "sealed25_36_ancestry" and PurePosixPath(logical).name == basename]
        require(len(choices) == 1, "exact unique sealed native metadata required")
        return self.paths.read_path(choices[0])

    def snapshot(self, layer, stream):
        require(stream in ("teacher", "folded"), "exact native snapshot stream required")
        suffix = "" if stream == "teacher" else "_folded"
        return self.paths.read_path(f"/run-output/fold/snapshots/before_L{layer:02d}{suffix}.safetensors")


class VerifierReads:
    def __init__(self, resolver):
        self.paths = resolver

    def recorded(self, logical, digest):
        if logical in self.paths.old:
            return self.paths.verify_old_recorded_reference(logical, digest)
        path = self.paths.read_path(logical)
        require(self.paths.fs.hash(path) == digest, "new emitted body SHA differs")
        return path


class ControllerReads:
    def __init__(self, resolver):
        self.paths = resolver

    def existing_layer(self, layer, role):
        require(type(layer) is int and 0 <= layer <= PREFIX_END, "exact closed-prefix layer required")
        require(role in ("ffn", "body"), "explicit budget-source role required")
        logical = (f"/run-output/fold/dense/L{layer:02d}/ffn.safetensors" if role == "ffn"
                   else f"/run-output/body/L{layer:02d}/body.safetensors")
        return self.paths.read_path(logical)


class AncestryReads(VerifierReads):
    """Only an adapter candidate; old RecoveryAncestry policy stays unchanged."""
