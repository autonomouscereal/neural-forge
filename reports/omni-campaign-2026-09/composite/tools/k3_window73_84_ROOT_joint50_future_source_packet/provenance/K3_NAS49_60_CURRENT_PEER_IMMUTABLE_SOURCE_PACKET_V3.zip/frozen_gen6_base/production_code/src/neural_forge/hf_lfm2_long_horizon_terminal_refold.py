"""No-parent-forward long-horizon terminal refolding for an LFM2 child.

This module closes one deliberately narrow gap between the legacy LFM2
circuit cache and the pure terminal-action residual compiler:

* authenticate a sealed legacy cache, using bounded strict-row reads or one
  complete authenticated batch at a time for semantic retokenization;
* either invert an authenticated strict one-row tokenizer bridge or build an
  exact semantic full-prefix schedule from direct-local donor/target tokenizers;
* reconstruct the parent's final RMSNorm output analytically from the cached
  final-layer residual and a separately sealed final-normalization contract;
* replay each strict trajectory once, or each maximal target-native semantic
  branch once when suffix rewrites make one final token trajectory impossible,
  without calling ``model.forward`` or ``generate``;
* construct whole-trajectory FIT, FIT-CHECK, SELECTION, and VALIDATION banks;
* invoke the existing closed-form terminal-action residual primitive; and
* install the selected final ``w2`` writer in place only after its frozen
  validation gate accepts it.

There is no parent execution, gradient, optimizer, training loop, pruning,
quantization, parameter creation, or model-level child forward in this path.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
from collections.abc import Mapping, Sequence
from contextlib import nullcontext
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Literal

from .hf_lfm2_circuit_trace_cache import (
    BATCH_RECORD_FILENAME,
    BATCH_SCHEMA,
    CACHED_VERIFIED_TRACE_MODE,
    FULL_PREFIX_CANONICAL_TRACE_MODE,
    Lfm2CircuitTraceBatch,
    Lfm2CircuitTraceCache,
    TRACE_FILENAME,
    _file_sha256 as _cache_file_sha256,
    _fresh_verified_cache_state,
    _path_file_identity as _cache_path_file_identity,
    _read_canonical_json as _read_cache_canonical_json,
    _tensor_sha256 as _cache_tensor_sha256,
    _verify_seal as _verify_cache_seal,
    fingerprint_lfm2_parent,
)
from .hf_lfm2_cpcf_macrocell_replay import replay_lfm2_cpcf_macrocell
from .hf_lfm2_cpcf_model_compiler import _rope_from_target
from .hf_lfm2_cpcf_terminal_action_residual import (
    Lfm2CpcfTerminalActionEvidence,
    Lfm2CpcfTerminalActionPolicy,
    Lfm2CpcfTerminalActionResidualResult,
    Lfm2CpcfTerminalActionSeed,
    _evaluate_split,
    _prepare_split,
    compile_lfm2_cpcf_terminal_action_residual,
)
from .hf_lfm2_direct_local import (
    Lfm2DirectLocalError,
    _local_directory,
    _local_safetensor_shards,
    _read_json,
)
from .hf_lfm2_semantic_span_phase_bridge import (
    Lfm2SemanticSpanPhaseBridge,
    Lfm2SemanticSpanPhaseBridgeError,
    build_lfm2_semantic_span_phase_bridge,
)
from .hf_lfm2_tokenizer_bridge_trace_adapter import (
    Lfm2StrictTokenizerBridgeTraceAdapter,
    Lfm2TargetTokenizedRecord,
    authenticate_lfm2_bridge_input_pair,
    build_lfm2_strict_tokenizer_bridge_trace_adapter,
)
from .hf_tied_causal_interface_fold import TiedCausalInterfaceFold
from .hf_tied_residual_congruence import (
    TIED_RESIDUAL_CONGRUENCE_SCHEMA,
    TiedResidualAnchorTransportWitness,
    authenticate_tied_residual_congruence_interface,
)
from .hf_tokenizer_bridge import StrictTokenizerBridgeArtifact
from .hf_tokenizer_bridge import StrictTokenizerBridgeError


LFM2_LONG_HORIZON_PARENT_FINAL_NORM_SCHEMA = (
    "neural-forge-lfm2-long-horizon-parent-final-norm-v1"
)
LFM2_LONG_HORIZON_SPLIT_PLAN_SCHEMA = "neural-forge-lfm2-long-horizon-split-plan-v1"
LFM2_LONG_HORIZON_TERMINAL_REFOLD_SCHEMA = (
    "neural-forge-lfm2-long-horizon-terminal-refold-v2"
)
LFM2_LONG_HORIZON_TERMINAL_CACHE_COMPATIBILITY_SCHEMA = (
    "neural-forge-lfm2-long-horizon-terminal-cache-compatibility-v1"
)
LFM2_LONG_HORIZON_TERMINAL_PAYLOAD_LOAD_AUDIT_SCHEMA = (
    "neural-forge-lfm2-long-horizon-terminal-payload-load-audit-v1"
)
LFM2_LONG_HORIZON_TERMINAL_SOURCE_LINEAGE_SCHEMA = (
    "neural-forge-lfm2-long-horizon-terminal-source-lineage-v1"
)
LFM2_LONG_HORIZON_TERMINAL_COMPOSITE_LINEAGE_SCHEMA = (
    "neural-forge-lfm2-long-horizon-terminal-composite-lineage-v1"
)
LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_SOURCE_SCHEMA = (
    "neural-forge-lfm2-direct-local-mapped-tied-table-source-v1"
)
LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_RECONSTRUCTION_SCHEMA = (
    "neural-forge-lfm2-direct-local-mapped-tied-table-reconstruction-v1"
)

TerminalSplit = Literal["fit", "fit_check", "selection", "validation"]
TokenizerReplayMode = Literal["strict_one_row", "semantic_span"]
_SPLITS: tuple[TerminalSplit, ...] = (
    "fit",
    "fit_check",
    "selection",
    "validation",
)
_HORIZON_BUCKETS: tuple[tuple[str, int, int | None], ...] = (
    ("0-7", 0, 7),
    ("8-31", 8, 31),
    ("32+", 32, None),
)
_DECODE_FINAL_RESIDUAL = re.compile(
    r"^decode\.(\d{3})\.layer\.(\d{3})\.residual\.post_layer$"
)


class Lfm2LongHorizonTerminalRefoldError(ValueError):
    """Cache, bridge, replay, evidence, or installation failed closed."""


def _torch() -> Any:
    try:
        import torch
    except ImportError as exc:  # pragma: no cover - optional native dependency
        raise RuntimeError(
            "PyTorch is required for long-horizon LFM2 terminal refolding."
        ) from exc
    return torch


def _canonical_sha256(value: Any) -> str:
    try:
        payload = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("ascii")
    except (TypeError, ValueError) as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Long-horizon metadata must be finite canonical JSON."
        ) from exc
    return hashlib.sha256(payload).hexdigest()


def _digest(value: Any, name: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be a lowercase SHA-256 digest."
        )
    return value


def _dtype_name(value: Any) -> str:
    return str(value.dtype).removeprefix("torch.")


def _tensor_sha256(value: Any, name: str = "tensor") -> str:
    torch = _torch()
    if (
        not isinstance(value, torch.Tensor)
        or value.layout != torch.strided
        or value.device.type == "meta"
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be a materialized dense tensor."
        )
    tensor = value.detach().to(device="cpu").contiguous()
    descriptor = {
        "dtype": _dtype_name(tensor),
        "shape": [int(size) for size in tensor.shape],
        "stride": [int(size) for size in tensor.stride()],
    }
    digest = hashlib.sha256(
        json.dumps(
            descriptor,
            allow_nan=False,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("ascii")
    )
    digest.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes(order="C"))
    return digest.hexdigest()


def _interface_tensor_sha256(value: Any) -> str:
    """Match the authenticated hash contract of the tied-interface module."""

    torch = _torch()
    tensor = value.detach().to(device="cpu").contiguous()
    digest = hashlib.sha256()
    digest.update(str(tensor.dtype).encode("ascii"))
    digest.update(b"\0")
    digest.update(
        json.dumps(
            [int(size) for size in tensor.shape],
            separators=(",", ":"),
        ).encode("ascii")
    )
    digest.update(b"\0")
    digest.update(tensor.reshape(-1).view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def _owned_floating_vector(value: Any, name: str) -> Any:
    torch = _torch()
    if (
        not isinstance(value, torch.Tensor)
        or value.layout != torch.strided
        or value.device.type == "meta"
        or value.ndim != 1
        or value.numel() == 0
        or not torch.is_floating_point(value)
        or value.is_complex()
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be a nonempty dense real floating vector."
        )
    result = value.detach().to(device="cpu").contiguous().clone()
    if not bool(torch.isfinite(result).all().item()):
        raise Lfm2LongHorizonTerminalRefoldError(f"{name} contains NaN or infinity.")
    return result


def _positive_finite(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be a positive finite number."
        )
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be a positive finite number."
        )
    return result


@dataclass(frozen=True, slots=True)
class Lfm2SealedParentFinalRmsNorm:
    """Parent final RMSNorm bytes bound to one immutable circuit cache."""

    cache_key: str
    parent_fingerprint: str
    layer_topology_fingerprint: str
    weight: Any
    epsilon: float
    authentication_sha256: str = ""

    def __post_init__(self) -> None:
        cache_key = _digest(self.cache_key, "cache_key")
        parent = _digest(self.parent_fingerprint, "parent_fingerprint")
        topology = _digest(
            self.layer_topology_fingerprint,
            "layer_topology_fingerprint",
        )
        weight = _owned_floating_vector(self.weight, "weight")
        epsilon = _positive_finite(self.epsilon, "epsilon")
        body = {
            "schema": LFM2_LONG_HORIZON_PARENT_FINAL_NORM_SCHEMA,
            "cache_key": cache_key,
            "parent_fingerprint": parent,
            "layer_topology_fingerprint": topology,
            "weight_sha256": _tensor_sha256(weight, "parent_final_norm.weight"),
            "source_hidden_size": int(weight.numel()),
            "epsilon": epsilon,
            "parent_model_forward_calls": 0,
        }
        expected = _canonical_sha256(body)
        supplied = str(self.authentication_sha256).strip().lower()
        if supplied and supplied != expected:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Parent final RMSNorm authentication is invalid."
            )
        object.__setattr__(self, "cache_key", cache_key)
        object.__setattr__(self, "parent_fingerprint", parent)
        object.__setattr__(self, "layer_topology_fingerprint", topology)
        object.__setattr__(self, "weight", weight)
        object.__setattr__(self, "epsilon", epsilon)
        object.__setattr__(self, "authentication_sha256", expected)

    @property
    def source_hidden_size(self) -> int:
        return int(self.weight.numel())

    def authentication_body(self) -> dict[str, Any]:
        return {
            "schema": LFM2_LONG_HORIZON_PARENT_FINAL_NORM_SCHEMA,
            "cache_key": self.cache_key,
            "parent_fingerprint": self.parent_fingerprint,
            "layer_topology_fingerprint": self.layer_topology_fingerprint,
            "weight_sha256": _tensor_sha256(
                self.weight,
                "parent_final_norm.weight",
            ),
            "source_hidden_size": self.source_hidden_size,
            "epsilon": self.epsilon,
            "parent_model_forward_calls": 0,
        }

    def verify_authentication(self) -> bool:
        return self.authentication_sha256 == _canonical_sha256(
            self.authentication_body()
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            **self.authentication_body(),
            "authentication_sha256": self.authentication_sha256,
        }


@dataclass(frozen=True, slots=True)
class Lfm2LocalParentFinalRmsNormLoad:
    """Direct-local safetensors load bound to the cache's full parent identity."""

    final_norm: Lfm2SealedParentFinalRmsNorm
    report: Mapping[str, Any]
    result_sha256: str

    def __post_init__(self) -> None:
        if (
            not isinstance(self.final_norm, Lfm2SealedParentFinalRmsNorm)
            or not self.final_norm.verify_authentication()
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Direct-local parent final norm is not authenticated."
            )
        body = dict(self.report)
        supplied = body.pop("result_sha256", None)
        audit = body.get("operation_audit")
        if (
            supplied != self.result_sha256
            or _canonical_sha256(body) != supplied
            or body.get("cache_key") != self.final_norm.cache_key
            or body.get("cache_parent_fingerprint")
            != self.final_norm.parent_fingerprint
            or body.get("final_norm_authentication_sha256")
            != self.final_norm.authentication_sha256
            or not isinstance(audit, Mapping)
            or audit.get("parent_model_objects_constructed") != 0
            or audit.get("parent_model_forward_calls") != 0
            or audit.get("parent_model_generate_calls") != 0
            or audit.get("network_access_performed") is not False
            or audit.get("direct_local_json_and_safetensors_only") is not True
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Direct-local parent final-norm load receipt is invalid."
            )
        object.__setattr__(
            self,
            "report",
            MappingProxyType({**body, "result_sha256": supplied}),
        )

    def as_dict(self) -> dict[str, Any]:
        return dict(self.report)


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            while block := handle.read(8 * 1024**2):
                digest.update(block)
    except OSError as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Could not authenticate local checkpoint file {path.name!r}."
        ) from exc
    return digest.hexdigest()


def _direct_local_parent_runtime_dtype(
    normalized_config: Mapping[str, Any],
    checkpoint_floating_dtypes: set[Any],
) -> Any:
    torch = _torch()
    if not checkpoint_floating_dtypes or any(
        not isinstance(value, torch.dtype)
        or not value.is_floating_point
        or value.is_complex
        for value in checkpoint_floating_dtypes
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local parent checkpoint does not expose a valid real "
            "floating runtime dtype."
        )
    checkpoint_names = {
        str(value).removeprefix("torch.") for value in checkpoint_floating_dtypes
    }
    config_value = normalized_config.get("dtype")
    if config_value is None:
        if len(checkpoint_names) != 1:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Direct-local parent checkpoint has multiple floating dtypes "
                "but its normalized config does not select one runtime dtype."
            )
        dtype_name = next(iter(checkpoint_names))
    else:
        if not isinstance(config_value, str):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Normalized direct-local parent config dtype must be text."
            )
        dtype_name = config_value.removeprefix("torch.")
        if checkpoint_names != {dtype_name}:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Normalized parent config dtype and direct-local checkpoint "
                "floating dtypes disagree."
            )
    dtype = getattr(torch, dtype_name, None)
    if (
        not isinstance(dtype, torch.dtype)
        or not dtype.is_floating_point
        or dtype.is_complex
        or str(dtype).removeprefix("torch.") != dtype_name
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Unsupported direct-local parent runtime dtype {dtype_name!r}."
        )
    return dtype


def _direct_local_parent_runtime_buffers(
    config: Any,
    count: int,
    *,
    dtype: Any,
) -> dict[str, Any]:
    torch = _torch()
    if count == 0:
        return {}
    if (
        not isinstance(dtype, torch.dtype)
        or not dtype.is_floating_point
        or dtype.is_complex
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local parent runtime buffer dtype must be real floating."
        )
    rope = getattr(config, "rope_parameters", None)
    if (
        count != 2
        or not isinstance(rope, Mapping)
        or rope.get("rope_type") != "default"
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local parent identity reconstruction supports either no "
            "runtime buffers or the authenticated default LFM2 RoPE buffer pair."
        )
    base = _positive_finite(rope.get("rope_theta"), "parent rope_theta")
    hidden = int(getattr(config, "hidden_size", 0))
    heads = int(getattr(config, "num_attention_heads", 0))
    head_dim = int(getattr(config, "head_dim", 0) or (hidden // heads if heads else 0))
    if head_dim <= 0 or head_dim % 2 != 0:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Parent config cannot reconstruct the LFM2 RoPE buffers."
        )
    inv_freq = 1.0 / (
        base
        ** (
            torch.arange(0, head_dim, 2, dtype=torch.int64).to(torch.float32) / head_dim
        )
    )
    inv_freq = inv_freq.to(dtype=dtype)
    return {
        "model.rotary_emb.inv_freq": inv_freq,
        "model.rotary_emb.original_inv_freq": inv_freq.clone(),
    }


def load_lfm2_parent_final_rmsnorm_from_local_safetensors(
    cache: Lfm2CircuitTraceCache,
    model_directory: str | os.PathLike[str],
    *,
    tensor_key: str,
    epsilon_config_key: str,
) -> Lfm2LocalParentFinalRmsNormLoad:
    """Load one final norm without constructing or executing a parent model.

    The function scans the direct-local safetensors once to reconstruct the same
    state/config/runtime-buffer fingerprint sealed by the circuit cache.  The
    requested tensor and epsilon field are explicit caller inputs; no norm key or
    epsilon is guessed in core code.
    """

    if not isinstance(cache, Lfm2CircuitTraceCache):
        raise TypeError("cache must be Lfm2CircuitTraceCache.")
    if not isinstance(tensor_key, str) or not tensor_key.strip():
        raise Lfm2LongHorizonTerminalRefoldError("tensor_key must be nonempty text.")
    if not isinstance(epsilon_config_key, str) or not epsilon_config_key.strip():
        raise Lfm2LongHorizonTerminalRefoldError(
            "epsilon_config_key must be nonempty text."
        )
    try:
        from safetensors import safe_open
        from transformers import Lfm2Config
    except ImportError as exc:  # pragma: no cover - optional native dependency
        raise RuntimeError(
            "Direct-local final-norm authentication requires safetensors and "
            "the concrete LFM2 config class."
        ) from exc
    try:
        directory = _local_directory(model_directory, "model_directory")
        config_payload = _read_json(directory / "config.json", "LFM2 config")
        shards = _local_safetensor_shards(directory)
    except Lfm2DirectLocalError as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local parent checkpoint layout is invalid."
        ) from exc
    if config_payload.get("model_type") != "lfm2":
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local parent config is not LFM2."
        )
    config = Lfm2Config(**config_payload)
    normalized_config = dict(config.to_dict())
    normalized_config.pop("_name_or_path", None)
    config_sha256 = _canonical_sha256(normalized_config)
    manifest = cache.manifest
    parent = manifest.get("parent")
    if not isinstance(parent, Mapping) or parent.get("config_sha256") != config_sha256:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local parent config differs from the cache's model identity."
        )

    tensor_locations: dict[str, Path] = {}
    for shard in shards:
        with safe_open(str(shard), framework="pt", device="cpu") as handle:
            for name in handle.keys():
                if name in tensor_locations:
                    raise Lfm2LongHorizonTerminalRefoldError(
                        f"Duplicate direct-local parent tensor {name!r}."
                    )
                tensor_locations[name] = shard
    if tensor_key not in tensor_locations:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Direct-local parent lacks requested final norm tensor {tensor_key!r}."
        )

    tensor_hashes: dict[str, str] = {}
    checkpoint_floating_dtypes: set[Any] = set()
    selected_weight = None
    for shard in shards:
        with safe_open(str(shard), framework="pt", device="cpu") as handle:
            for name in sorted(handle.keys()):
                value = handle.get_tensor(name)
                tensor_hashes[name] = _cache_tensor_sha256(_torch(), value)
                if _torch().is_floating_point(value) and not value.is_complex():
                    checkpoint_floating_dtypes.add(value.dtype)
                if name == tensor_key:
                    selected_weight = (
                        value.detach().to(device="cpu").contiguous().clone()
                    )
    expected_state_count = int(parent.get("state_tensor_count", -1))
    if (
        bool(getattr(config, "tie_word_embeddings", False))
        and len(tensor_hashes) + 1 == expected_state_count
    ):
        embedding_key = "model.embed_tokens.weight"
        output_key = "lm_head.weight"
        if embedding_key in tensor_hashes and output_key not in tensor_hashes:
            tensor_hashes[output_key] = tensor_hashes[embedding_key]
        elif output_key in tensor_hashes and embedding_key not in tensor_hashes:
            tensor_hashes[embedding_key] = tensor_hashes[output_key]
    if len(tensor_hashes) != expected_state_count:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local safetensors cannot reconstruct every state-dict entry "
            "sealed by the parent cache."
        )
    state_digest = hashlib.sha256(b"neural-forge-lfm2-parent-state-v1\0")
    for name in sorted(tensor_hashes):
        state_digest.update(name.encode("utf-8"))
        state_digest.update(b"\0")
        state_digest.update(tensor_hashes[name].encode("ascii"))
        state_digest.update(b"\0")
    state_sha256 = state_digest.hexdigest()

    expected_buffer_count = int(parent.get("runtime_buffer_count", -1))
    runtime_buffer_dtype = (
        None
        if expected_buffer_count == 0
        else _direct_local_parent_runtime_dtype(
            normalized_config,
            checkpoint_floating_dtypes,
        )
    )
    buffers = _direct_local_parent_runtime_buffers(
        config,
        expected_buffer_count,
        dtype=runtime_buffer_dtype,
    )
    buffer_digest = hashlib.sha256(b"neural-forge-lfm2-parent-runtime-buffers-v1\0")
    for name in sorted(buffers):
        buffer_digest.update(name.encode("utf-8"))
        buffer_digest.update(b"\0")
        buffer_digest.update(
            _cache_tensor_sha256(_torch(), buffers[name]).encode("ascii")
        )
        buffer_digest.update(b"\0")
    buffer_sha256 = buffer_digest.hexdigest()
    identity_body = {
        "schema": "neural-forge-lfm2-parent-fingerprint-v2",
        "model_class": parent.get("model_class"),
        "config_sha256": config_sha256,
        "state_dict_sha256": state_sha256,
        "state_tensor_count": len(tensor_hashes),
        "runtime_buffer_sha256": buffer_sha256,
        "runtime_buffer_count": len(buffers),
    }
    if (
        state_sha256 != parent.get("state_dict_sha256")
        or buffer_sha256 != parent.get("runtime_buffer_sha256")
        or _canonical_sha256(identity_body) != cache.parent_fingerprint
        or selected_weight is None
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local safetensors do not reproduce the cache's full parent "
            "model identity."
        )
    epsilon = _positive_finite(
        normalized_config.get(epsilon_config_key),
        f"parent config {epsilon_config_key}",
    )
    hidden = int(getattr(config, "hidden_size", 0))
    if selected_weight.ndim != 1 or int(selected_weight.numel()) != hidden:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Requested direct-local final norm does not match parent hidden size."
        )
    final_norm = Lfm2SealedParentFinalRmsNorm(
        cache_key=cache.cache_key,
        parent_fingerprint=cache.parent_fingerprint,
        layer_topology_fingerprint=cache.layer_topology_fingerprint,
        weight=selected_weight,
        epsilon=epsilon,
    )
    body = {
        "schema": "neural-forge-lfm2-local-parent-final-rmsnorm-load-v1",
        "cache_key": cache.cache_key,
        "cache_parent_fingerprint": cache.parent_fingerprint,
        "source_directory": str(directory),
        "config_file_sha256": _file_sha256(directory / "config.json"),
        "checkpoint_files": [
            {
                "name": shard.name,
                "bytes": shard.stat().st_size,
                "sha256": _file_sha256(shard),
            }
            for shard in shards
        ],
        "tensor_key": tensor_key,
        "tensor_sha256": _cache_tensor_sha256(_torch(), selected_weight),
        "epsilon_config_key": epsilon_config_key,
        "epsilon": epsilon,
        "checkpoint_floating_dtypes": sorted(
            str(value).removeprefix("torch.") for value in checkpoint_floating_dtypes
        ),
        "runtime_buffer_dtype": (
            None
            if runtime_buffer_dtype is None
            else str(runtime_buffer_dtype).removeprefix("torch.")
        ),
        "reconstructed_parent_identity": identity_body,
        "final_norm_authentication_sha256": final_norm.authentication_sha256,
        "operation_audit": {
            "parent_model_objects_constructed": 0,
            "parent_model_forward_calls": 0,
            "parent_model_generate_calls": 0,
            "network_access_performed": False,
            "direct_local_json_and_safetensors_only": True,
            "training_steps": 0,
        },
    }
    seal = _canonical_sha256(body)
    return Lfm2LocalParentFinalRmsNormLoad(
        final_norm=final_norm,
        report={**body, "result_sha256": seal},
        result_sha256=seal,
    )


@dataclass(frozen=True, slots=True)
class Lfm2LongHorizonTrajectorySplitPlan:
    """One sealed whole-trajectory split assignment for a cache."""

    cache_key: str
    assignments: tuple[TerminalSplit, ...]
    assignment_method: str = "canonical-batch-index-modulo-four-v1"
    authentication_sha256: str = ""

    def __post_init__(self) -> None:
        cache_key = _digest(self.cache_key, "cache_key")
        assignments = tuple(self.assignments)
        if not assignments or any(value not in _SPLITS for value in assignments):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Split assignments must contain only the four terminal splits."
            )
        if set(assignments) != set(_SPLITS):
            raise Lfm2LongHorizonTerminalRefoldError(
                "FIT, FIT-CHECK, SELECTION, and VALIDATION each need at "
                "least one complete trajectory."
            )
        if (
            not isinstance(self.assignment_method, str)
            or not self.assignment_method.strip()
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "assignment_method must be nonempty text."
            )
        method = self.assignment_method.strip()
        body = {
            "schema": LFM2_LONG_HORIZON_SPLIT_PLAN_SCHEMA,
            "cache_key": cache_key,
            "batch_count": len(assignments),
            "assignments": list(assignments),
            "assignment_method": method,
            "whole_trajectory_isolation": True,
            "split_counts": {split: assignments.count(split) for split in _SPLITS},
        }
        expected = _canonical_sha256(body)
        supplied = str(self.authentication_sha256).strip().lower()
        if supplied and supplied != expected:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Long-horizon split-plan authentication is invalid."
            )
        object.__setattr__(self, "cache_key", cache_key)
        object.__setattr__(self, "assignments", assignments)
        object.__setattr__(self, "assignment_method", method)
        object.__setattr__(self, "authentication_sha256", expected)

    @classmethod
    def deterministic_round_robin(
        cls,
        cache: Lfm2CircuitTraceCache,
    ) -> "Lfm2LongHorizonTrajectorySplitPlan":
        if not isinstance(cache, Lfm2CircuitTraceCache):
            raise TypeError("cache must be Lfm2CircuitTraceCache.")
        if cache.batch_count < len(_SPLITS):
            raise Lfm2LongHorizonTerminalRefoldError(
                "At least four cache trajectories are required for isolated "
                "FIT, FIT-CHECK, SELECTION, and VALIDATION evidence."
            )
        return cls(
            cache_key=cache.cache_key,
            assignments=tuple(
                _SPLITS[index % len(_SPLITS)] for index in range(cache.batch_count)
            ),
        )

    def verify_for(self, cache: Lfm2CircuitTraceCache) -> None:
        if (
            self.cache_key != cache.cache_key
            or len(self.assignments) != cache.batch_count
            or self.authentication_sha256
            != _canonical_sha256(self.authentication_body())
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "The split plan is not authenticated for this cache."
            )

    def authentication_body(self) -> dict[str, Any]:
        return {
            "schema": LFM2_LONG_HORIZON_SPLIT_PLAN_SCHEMA,
            "cache_key": self.cache_key,
            "batch_count": len(self.assignments),
            "assignments": list(self.assignments),
            "assignment_method": self.assignment_method,
            "whole_trajectory_isolation": True,
            "split_counts": {split: self.assignments.count(split) for split in _SPLITS},
        }

    def as_dict(self) -> dict[str, Any]:
        return {
            **self.authentication_body(),
            "authentication_sha256": self.authentication_sha256,
        }


@dataclass(frozen=True, slots=True)
class _CachedTrajectory:
    batch_index: int
    input_sha256: str
    split: TerminalSplit
    target_record: Lfm2TargetTokenizedRecord | None
    semantic_bridge: Lfm2SemanticSpanPhaseBridge | None
    parent_final_norm_rows: Any
    horizon_indices: tuple[int, ...]
    selected_payload_sha256: str
    cached_full_prefix_payload: Mapping[str, Any]
    parent_final_norm_endpoint: Mapping[str, Any]
    parent_action_projection: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class _ChildTrajectoryRows:
    mlp_input: Any
    pre_mlp_residual: Any
    macrocell_replay_sha256: tuple[str, ...]
    attention_rope_materializations: int
    embedding_seed_lookup_calls: int = 1
    full_prefix_replay_calls: int = 1
    replay_strategy: str = "single-causal-trajectory-v1"
    replay_branch_phase_sha256: tuple[tuple[str, ...], ...] = ()


@dataclass(frozen=True, slots=True)
class Lfm2LongHorizonTerminalRefoldResult:
    """Authenticated evidence, pure compiler result, and install receipt."""

    split_evidence: tuple[Lfm2CpcfTerminalActionEvidence, ...]
    terminal_result: Lfm2CpcfTerminalActionResidualResult
    accepted: bool
    report: Mapping[str, Any]
    result_sha256: str

    def __post_init__(self) -> None:
        evidence = tuple(self.split_evidence)
        if (
            len(evidence) != len(_SPLITS)
            or tuple(value.split for value in evidence) != _SPLITS
            or not all(value.verify_authentication() for value in evidence)
            or not isinstance(
                self.terminal_result,
                Lfm2CpcfTerminalActionResidualResult,
            )
            or not self.terminal_result.verify_authentication()
            or not isinstance(self.accepted, bool)
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Long-horizon result contains invalid typed evidence."
            )
        body = dict(self.report)
        supplied = body.pop("result_sha256", None)
        if (
            supplied != self.result_sha256
            or _canonical_sha256(body) != self.result_sha256
            or body.get("accepted") is not self.accepted
            or body.get("terminal_result_sha256") != self.terminal_result.result_sha256
            or body.get("split_evidence_sha256")
            != {value.split: value.authentication_sha256 for value in evidence}
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Long-horizon terminal-refold result seal is invalid."
            )
        object.__setattr__(self, "split_evidence", evidence)
        object.__setattr__(
            self,
            "report",
            MappingProxyType({**body, "result_sha256": supplied}),
        )

    def as_dict(self) -> dict[str, Any]:
        return dict(self.report)


def _verify_parent_norm_binding(
    cache: Lfm2CircuitTraceCache,
    seal: Lfm2SealedParentFinalRmsNorm,
) -> None:
    if not isinstance(seal, Lfm2SealedParentFinalRmsNorm):
        raise TypeError("parent_final_norm must be Lfm2SealedParentFinalRmsNorm.")
    if (
        not seal.verify_authentication()
        or seal.cache_key != cache.cache_key
        or seal.parent_fingerprint != cache.parent_fingerprint
        or seal.layer_topology_fingerprint != cache.layer_topology_fingerprint
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Parent final RMSNorm bytes are not bound to this sealed cache."
        )


def _verify_interface_report(
    interface: TiedCausalInterfaceFold,
    source_selected_tied_table: Any,
    *,
    anchor_transport_witness: TiedResidualAnchorTransportWitness | None = None,
) -> dict[str, Any]:
    torch = _torch()
    if not isinstance(interface, TiedCausalInterfaceFold):
        raise TypeError("interface must be TiedCausalInterfaceFold.")
    report = dict(interface.report)
    supplied = report.pop("report_sha256", None)
    if not isinstance(supplied, str) or supplied != _canonical_sha256(report):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Tied causal interface report authentication is invalid."
        )
    expected_target = report.get("target_weight_sha256")
    expected_encoder = report.get("producer_encoder_sha256")
    report_schema = report.get("schema")
    expected_source = (
        report.get("mapped_parent_tied_table_sha256")
        if report_schema == TIED_RESIDUAL_CONGRUENCE_SCHEMA
        else report.get(
            "source_table_sha256",
            report.get("source_tied_table_sha256"),
        )
    )
    source = source_selected_tied_table
    if (
        not isinstance(source, torch.Tensor)
        or source.layout != torch.strided
        or source.device.type == "meta"
        or source.ndim != 2
        or source.numel() == 0
        or source.dtype != torch.bfloat16
        or not bool(torch.isfinite(source).all().item())
        or expected_target != _interface_tensor_sha256(interface.target_weight)
        or expected_encoder != _interface_tensor_sha256(interface.producer_encoder)
        or expected_source
        != _interface_tensor_sha256(
            source.detach().to(device="cpu", dtype=torch.float64)
        )
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Tied interface/source selected-table tensors differ from their "
            "authenticated lineage."
        )
    if report_schema == TIED_RESIDUAL_CONGRUENCE_SCHEMA:
        try:
            authentication = authenticate_tied_residual_congruence_interface(
                interface,
                mapped_parent_tied_table=source,
                anchor_transport_witness=anchor_transport_witness,
            )
        except (TypeError, ValueError) as exc:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Tied residual-congruence interface authentication failed."
            ) from exc
        if authentication.get("interface_report_sha256") != supplied:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Tied residual-congruence report identity changed during "
                "authentication."
            )
    return {**report, "report_sha256": supplied}


def _owned_canonical_document(
    value: Mapping[str, Any],
    *,
    name: str,
) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise Lfm2LongHorizonTerminalRefoldError(f"{name} must be a mapping.")
    try:
        return json.loads(
            json.dumps(
                dict(value),
                allow_nan=False,
                ensure_ascii=True,
                separators=(",", ":"),
                sort_keys=True,
            )
        )
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be finite canonical JSON."
        ) from exc


def _verified_file_record(value: Any, *, name: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be an authenticated file record."
        )
    record = dict(value)
    filename = record.get("name")
    size = record.get("bytes")
    if (
        not isinstance(filename, str)
        or not filename
        or Path(filename).name != filename
        or isinstance(size, bool)
        or not isinstance(size, int)
        or size <= 0
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} has an invalid filename or byte count."
        )
    _digest(record.get("sha256"), f"{name} SHA-256")
    return record


def _authenticate_direct_local_mapped_source_report(
    value: Mapping[str, Any],
    *,
    cache: Lfm2CircuitTraceCache,
    bridge: StrictTokenizerBridgeArtifact,
    parent_final_norm: Lfm2LocalParentFinalRmsNormLoad,
    source_selected_tied_table: Any,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Authenticate the exact checkpoint-to-BF16 mapped-table derivation."""

    report = _owned_canonical_document(
        value,
        name="direct-local mapped tied-table source report",
    )
    supplied = report.pop("result_sha256", None)
    if supplied != _canonical_sha256(report):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped tied-table source report self-seal is invalid."
        )
    config_file = _verified_file_record(
        report.get("config_file"),
        name="parent config file",
    )
    index_value = report.get("safetensors_index_file")
    index_file = (
        None
        if index_value is None
        else _verified_file_record(index_value, name="parent safetensors index")
    )
    raw_files = report.get("checkpoint_files")
    if not isinstance(raw_files, list) or not raw_files:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped source report has no checkpoint shards."
        )
    checkpoint_files = [
        _verified_file_record(value, name=f"parent checkpoint shard {index}")
        for index, value in enumerate(raw_files)
    ]
    if len({value["name"] for value in checkpoint_files}) != len(checkpoint_files):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped source checkpoint shard names are duplicated."
        )
    source_shard = _verified_file_record(
        report.get("source_tensor_shard"),
        name="mapped tied-table source shard",
    )
    if source_shard not in checkpoint_files:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Mapped tied-table source shard is absent from the checkpoint inventory."
        )
    source = source_selected_tied_table
    torch = _torch()
    mapping = tuple(bridge.transport_profile.target_to_donor_row_indices)
    source_shape = [int(size) for size in source.shape]
    expected_parent_norm_load = parent_final_norm.result_sha256
    parent_report = _owned_canonical_document(
        parent_final_norm.as_dict(),
        name="independently authenticated parent checkpoint report",
    )
    parent_report_body = dict(parent_report)
    parent_report_sha256 = parent_report_body.pop("result_sha256", None)
    parent_raw_files = parent_report.get("checkpoint_files")
    parent_identity = parent_report.get("reconstructed_parent_identity")
    if (
        parent_report_sha256 != _canonical_sha256(parent_report_body)
        or parent_report_sha256 != expected_parent_norm_load
        or not isinstance(parent_raw_files, list)
        or not parent_raw_files
        or not isinstance(parent_identity, Mapping)
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Independent parent checkpoint identity receipt is invalid."
        )
    parent_checkpoint_files = [
        _verified_file_record(
            value,
            name=f"independently authenticated parent checkpoint shard {index}",
        )
        for index, value in enumerate(parent_raw_files)
    ]
    parent_config_sha256 = _digest(
        parent_report.get("config_file_sha256"),
        "independently authenticated parent config SHA-256",
    )
    parent_checkpoint_files_sha256 = _canonical_sha256(parent_checkpoint_files)
    parent_identity_sha256 = _canonical_sha256(parent_identity)
    if (
        report.get("schema") != LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_SOURCE_SCHEMA
        or report.get("cache_key") != cache.cache_key
        or report.get("cache_manifest_sha256") != cache.manifest.get("manifest_sha256")
        or report.get("cache_parent_fingerprint") != cache.parent_fingerprint
        or report.get("cache_layer_topology_fingerprint")
        != cache.layer_topology_fingerprint
        or report.get("parent_final_norm_load_sha256") != expected_parent_norm_load
        or report.get("parent_final_norm_authentication_sha256")
        != parent_final_norm.final_norm.authentication_sha256
        or config_file["sha256"] != parent_config_sha256
        or checkpoint_files != parent_checkpoint_files
        or report.get("independently_authenticated_parent_checkpoint_files_sha256")
        != parent_checkpoint_files_sha256
        or report.get("independently_authenticated_parent_identity_sha256")
        != parent_identity_sha256
        or report.get("source_checkpoint_exactly_matches_authenticated_parent")
        is not True
        or parent_report.get("cache_key") != cache.cache_key
        or parent_report.get("cache_parent_fingerprint")
        != cache.parent_fingerprint
        or parent_identity_sha256 != cache.parent_fingerprint
        or report.get("bridge_artifact_sha256") != bridge.artifact_sha256
        or report.get("bridge_transport_profile_fingerprint")
        != bridge.profile_fingerprint
        or report.get("target_to_donor_row_indices_sha256")
        != _canonical_sha256(list(mapping))
        or report.get("source_tensor_key") is None
        or not isinstance(report.get("source_tensor_key"), str)
        or not report.get("source_tensor_key")
        or report.get("source_tensor_dtype")
        not in {"bfloat16", "float16", "float32", "float64"}
        or not isinstance(report.get("source_tensor_shape"), list)
        or len(report.get("source_tensor_shape")) != 2
        or any(
            type(size) is not int or size <= 0 for size in report["source_tensor_shape"]
        )
        or report["source_tensor_shape"][0]
        != bridge.transport_profile.donor_row_capacity
        or report.get("mapped_table_shape") != source_shape
        or report.get("mapped_table_dtype") != "bfloat16"
        or report.get("mapped_table_bfloat16_sha256")
        != _tensor_sha256(source, "mapped_parent_tied_table")
        or report.get("mapped_table_interface_source_sha256")
        != _interface_tensor_sha256(source.to(device="cpu", dtype=torch.float64))
        or report.get("mapping_operation")
        != "exact_target_to_donor_index_select_then_cpu_bfloat16_contiguous_clone"
        or report.get("deterministic_cast_to_bfloat16") is not True
        or report.get("network_access_performed") is not False
        or report.get("parent_model_objects_constructed") != 0
        or report.get("parent_model_forward_calls") != 0
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped tied-table source report differs from the exact "
            "cache, bridge, checkpoint, cast, or mapped BF16 table."
        )
    source_tensor_sha256 = _digest(
        report.get("source_tensor_sha256"),
        "parent tied source tensor SHA-256",
    )
    _digest(config_file["sha256"], "parent config SHA-256")
    if index_file is not None:
        _digest(index_file["sha256"], "parent safetensors index SHA-256")

    # A caller can recompute an ordinary receipt self-hash, so claimed file
    # inventory and mapped-table digests alone cannot prove that the supplied
    # table was actually read from the authenticated parent checkpoint.  Mint
    # terminal lineage only after independently reopening those exact bytes,
    # loading the declared tensor, and replaying the bridge selection/cast.
    try:
        from safetensors import safe_open
    except ImportError as exc:  # pragma: no cover - optional native dependency
        raise RuntimeError(
            "Direct-local mapped-source authentication requires safetensors."
        ) from exc
    try:
        source_directory = _local_directory(
            report.get("source_directory"),
            "mapped tied-table source directory",
        )
        parent_directory = _local_directory(
            parent_report.get("source_directory"),
            "independently authenticated parent source directory",
        )
        live_shards = _local_safetensor_shards(source_directory)
    except (TypeError, Lfm2DirectLocalError) as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped source directory cannot be authenticated."
        ) from exc
    if source_directory != parent_directory:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Mapped tied-table source directory differs from the independently "
            "authenticated parent checkpoint directory."
        )

    config_path = source_directory / config_file["name"]
    index_path = source_directory / "model.safetensors.index.json"
    try:
        live_config_file = {
            "name": config_path.name,
            "bytes": config_path.stat().st_size,
            "sha256": _file_sha256(config_path),
        }
        live_checkpoint_files = [
            {
                "name": shard.name,
                "bytes": shard.stat().st_size,
                "sha256": _file_sha256(shard),
            }
            for shard in live_shards
        ]
        live_index_file = (
            {
                "name": index_path.name,
                "bytes": index_path.stat().st_size,
                "sha256": _file_sha256(index_path),
            }
            if index_path.is_file() and not index_path.is_symlink()
            else None
        )
    except OSError as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped source files cannot be authenticated."
        ) from exc
    if (
        config_path.is_symlink()
        or any(shard.is_symlink() for shard in live_shards)
        or live_config_file != config_file
        or live_checkpoint_files != checkpoint_files
        or live_index_file != index_file
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped source files differ from the authenticated "
            "parent checkpoint inventory."
        )

    source_tensor_key = str(report["source_tensor_key"])
    reconstructed_source = None
    reconstructed_source_shard = None
    for shard in live_shards:
        with safe_open(str(shard), framework="pt", device="cpu") as handle:
            if source_tensor_key in handle.keys():
                if reconstructed_source is not None:
                    raise Lfm2LongHorizonTerminalRefoldError(
                        "Mapped tied-table source tensor appears in multiple "
                        "authenticated checkpoint shards."
                    )
                reconstructed_source = (
                    handle.get_tensor(source_tensor_key)
                    .detach()
                    .to(device="cpu")
                    .contiguous()
                    .clone()
                )
                reconstructed_source_shard = shard
    if reconstructed_source is None or reconstructed_source_shard is None:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Authenticated parent checkpoint lacks the mapped tied-table source "
            "tensor."
        )
    reconstructed_source_shape = [
        int(size) for size in reconstructed_source.shape
    ]
    reconstructed_source_dtype = str(reconstructed_source.dtype).removeprefix(
        "torch."
    )
    reconstructed_source_sha256 = _tensor_sha256(
        reconstructed_source,
        "parent_tied_source_tensor",
    )
    reconstructed_source_shard_record = next(
        value
        for value in live_checkpoint_files
        if value["name"] == reconstructed_source_shard.name
    )
    mapped_from_checkpoint = (
        reconstructed_source.index_select(
            0,
            torch.tensor(mapping, dtype=torch.long),
        )
        .detach()
        .to(device="cpu", dtype=torch.bfloat16)
        .contiguous()
        .clone()
    )
    mapped_descriptor = {
        "dtype": str(mapped_from_checkpoint.dtype).removeprefix("torch."),
        "shape": [int(size) for size in mapped_from_checkpoint.shape],
        "numel": int(mapped_from_checkpoint.numel()),
        "size_bytes": int(
            mapped_from_checkpoint.numel() * mapped_from_checkpoint.element_size()
        ),
        "bfloat16_sha256": _tensor_sha256(
            mapped_from_checkpoint,
            "mapped_parent_tied_table",
        ),
        "interface_source_sha256": _interface_tensor_sha256(
            mapped_from_checkpoint.to(device="cpu", dtype=torch.float64)
        ),
    }
    supplied_descriptor = {
        "dtype": str(source.dtype).removeprefix("torch."),
        "shape": source_shape,
        "numel": int(source.numel()),
        "size_bytes": int(source.numel() * source.element_size()),
        "bfloat16_sha256": _tensor_sha256(source, "mapped_parent_tied_table"),
        "interface_source_sha256": _interface_tensor_sha256(
            source.to(device="cpu", dtype=torch.float64)
        ),
    }
    if (
        reconstructed_source_shape != report["source_tensor_shape"]
        or reconstructed_source_dtype != report["source_tensor_dtype"]
        or reconstructed_source_sha256 != source_tensor_sha256
        or reconstructed_source_shard_record != source_shard
        or mapped_descriptor != supplied_descriptor
        or not torch.equal(
            mapped_from_checkpoint,
            source.detach().to(device="cpu").contiguous(),
        )
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Supplied mapped tied table is not the exact bridge projection of "
            "the independently authenticated parent checkpoint tensor."
        )

    # Reauthenticate file bytes after tensor materialization so a changed local
    # source cannot be accepted under the pre-read inventory.
    if live_checkpoint_files != [
        {
            "name": shard.name,
            "bytes": shard.stat().st_size,
            "sha256": _file_sha256(shard),
        }
        for shard in live_shards
    ]:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local mapped source checkpoint changed during exact "
            "reconstruction."
        )

    reconstruction_body = {
        "schema": LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_RECONSTRUCTION_SCHEMA,
        "cache_key": cache.cache_key,
        "cache_parent_fingerprint": cache.parent_fingerprint,
        "parent_final_norm_load_sha256": expected_parent_norm_load,
        "mapped_source_report_sha256": supplied,
        "source_directory": str(source_directory),
        "config_file": live_config_file,
        "checkpoint_files": live_checkpoint_files,
        "checkpoint_files_sha256": parent_checkpoint_files_sha256,
        "bridge_artifact_sha256": bridge.artifact_sha256,
        "bridge_transport_profile_fingerprint": bridge.profile_fingerprint,
        "target_to_donor_row_indices_sha256": _canonical_sha256(list(mapping)),
        "source_tensor_key": source_tensor_key,
        "source_tensor_shard": reconstructed_source_shard_record,
        "source_tensor_descriptor": {
            "dtype": reconstructed_source_dtype,
            "shape": reconstructed_source_shape,
            "numel": int(reconstructed_source.numel()),
            "size_bytes": int(
                reconstructed_source.numel() * reconstructed_source.element_size()
            ),
            "sha256": reconstructed_source_sha256,
        },
        "reconstructed_mapped_table_descriptor": mapped_descriptor,
        "supplied_mapped_table_descriptor": supplied_descriptor,
        "exact_tensor_equality_verified": True,
        "mapping_operation": (
            "exact_target_to_donor_index_select_then_cpu_bfloat16_contiguous_clone"
        ),
        "operation_audit": {
            "checkpoint_tensor_loads": 1,
            "parent_model_objects_constructed": 0,
            "parent_model_forward_calls": 0,
            "parent_model_generate_calls": 0,
            "network_access_performed": False,
            "training_steps": 0,
        },
    }
    reconstruction = {
        **reconstruction_body,
        "result_sha256": _canonical_sha256(reconstruction_body),
    }
    return {**report, "result_sha256": supplied}, reconstruction


@dataclass(frozen=True, slots=True)
class Lfm2LongHorizonTerminalSourceLineage:
    """Exact cache/bridge/checkpoint/interface ancestry for terminal evidence."""

    document: Mapping[str, Any]

    def __post_init__(self) -> None:
        document = _owned_canonical_document(
            self.document,
            name="terminal source lineage",
        )
        body = dict(document)
        supplied = body.pop("authentication_sha256", None)
        direct_local = body.get("direct_local_checkpoint_source_authenticated")
        if (
            supplied != _canonical_sha256(body)
            or body.get("schema") != LFM2_LONG_HORIZON_TERMINAL_SOURCE_LINEAGE_SCHEMA
            or type(direct_local) is not bool
            or body.get("behavioral_tolerance_used_for_source_admission") is not False
            or body.get("exact_lineage_is_source_admission_authority") is not True
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal source lineage authentication is invalid."
            )
        for name in (
            "cache_key",
            "cache_manifest_sha256",
            "cache_parent_fingerprint",
            "cache_layer_topology_fingerprint",
            "bridge_artifact_sha256",
            "bridge_transport_profile_fingerprint",
            "target_to_donor_row_indices_sha256",
            "parent_final_norm_authentication_sha256",
            "mapped_table_bfloat16_sha256",
            "mapped_table_interface_source_sha256",
            "interface_report_sha256",
            "compiler_source_binding_sha256",
        ):
            _digest(body.get(name), f"terminal source lineage {name}")
        if direct_local:
            parent_source = body.get("parent_final_norm_direct_local_source")
            mapped_source = body.get("direct_local_mapped_source_report")
            reconstruction_source = body.get("direct_local_mapped_reconstruction")
            if not isinstance(parent_source, Mapping) or not isinstance(
                mapped_source,
                Mapping,
            ) or not isinstance(reconstruction_source, Mapping):
                raise Lfm2LongHorizonTerminalRefoldError(
                    "Direct-local terminal source lineage omitted its independent "
                    "parent checkpoint receipts."
                )
            parent_document = _owned_canonical_document(
                parent_source,
                name="terminal source parent checkpoint receipt",
            )
            parent_body = dict(parent_document)
            parent_sha256 = parent_body.pop("result_sha256", None)
            mapped_document = _owned_canonical_document(
                mapped_source,
                name="terminal source mapped-table checkpoint receipt",
            )
            mapped_body = dict(mapped_document)
            mapped_sha256 = mapped_body.pop("result_sha256", None)
            reconstruction_document = _owned_canonical_document(
                reconstruction_source,
                name="terminal source exact mapped-table reconstruction receipt",
            )
            reconstruction_body = dict(reconstruction_document)
            reconstruction_sha256 = reconstruction_body.pop("result_sha256", None)
            parent_files = parent_document.get("checkpoint_files")
            mapped_files = mapped_document.get("checkpoint_files")
            parent_identity = parent_document.get("reconstructed_parent_identity")
            mapped_config = mapped_document.get("config_file")
            source_descriptor = reconstruction_document.get(
                "source_tensor_descriptor"
            )
            mapped_descriptor = reconstruction_document.get(
                "reconstructed_mapped_table_descriptor"
            )
            supplied_descriptor = reconstruction_document.get(
                "supplied_mapped_table_descriptor"
            )
            reconstruction_audit = reconstruction_document.get("operation_audit")
            if (
                parent_sha256 != _canonical_sha256(parent_body)
                or mapped_sha256 != _canonical_sha256(mapped_body)
                or reconstruction_sha256 != _canonical_sha256(reconstruction_body)
                or parent_document.get("schema")
                != "neural-forge-lfm2-local-parent-final-rmsnorm-load-v1"
                or mapped_document.get("schema")
                != LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_SOURCE_SCHEMA
                or reconstruction_document.get("schema")
                != LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_RECONSTRUCTION_SCHEMA
                or not isinstance(parent_files, list)
                or not parent_files
                or mapped_files != parent_files
                or not isinstance(parent_identity, Mapping)
                or not isinstance(mapped_config, Mapping)
                or mapped_config.get("sha256")
                != parent_document.get("config_file_sha256")
                or mapped_document.get("parent_final_norm_load_sha256")
                != parent_sha256
                or body.get("parent_final_norm_direct_local_source_sha256")
                != parent_sha256
                or body.get("direct_local_mapped_source_report_sha256")
                != mapped_sha256
                or body.get("direct_local_mapped_reconstruction_sha256")
                != reconstruction_sha256
                or parent_document.get("cache_parent_fingerprint")
                != body.get("cache_parent_fingerprint")
                or mapped_document.get(
                    "independently_authenticated_parent_checkpoint_files_sha256"
                )
                != _canonical_sha256(parent_files)
                or mapped_document.get(
                    "independently_authenticated_parent_identity_sha256"
                )
                != _canonical_sha256(parent_identity)
                or mapped_document.get(
                    "source_checkpoint_exactly_matches_authenticated_parent"
                )
                is not True
                or reconstruction_document.get("cache_key")
                != body.get("cache_key")
                or reconstruction_document.get("cache_parent_fingerprint")
                != body.get("cache_parent_fingerprint")
                or reconstruction_document.get("parent_final_norm_load_sha256")
                != parent_sha256
                or reconstruction_document.get("mapped_source_report_sha256")
                != mapped_sha256
                or reconstruction_document.get("checkpoint_files") != parent_files
                or reconstruction_document.get("checkpoint_files_sha256")
                != _canonical_sha256(parent_files)
                or reconstruction_document.get("bridge_artifact_sha256")
                != body.get("bridge_artifact_sha256")
                or reconstruction_document.get(
                    "bridge_transport_profile_fingerprint"
                )
                != body.get("bridge_transport_profile_fingerprint")
                or reconstruction_document.get(
                    "target_to_donor_row_indices_sha256"
                )
                != body.get("target_to_donor_row_indices_sha256")
                or not isinstance(source_descriptor, Mapping)
                or source_descriptor.get("sha256")
                != mapped_document.get("source_tensor_sha256")
                or not isinstance(mapped_descriptor, Mapping)
                or not isinstance(supplied_descriptor, Mapping)
                or mapped_descriptor != supplied_descriptor
                or mapped_descriptor.get("bfloat16_sha256")
                != body.get("mapped_table_bfloat16_sha256")
                or mapped_descriptor.get("interface_source_sha256")
                != body.get("mapped_table_interface_source_sha256")
                or reconstruction_document.get("exact_tensor_equality_verified")
                is not True
                or not isinstance(reconstruction_audit, Mapping)
                or reconstruction_audit.get("checkpoint_tensor_loads") != 1
                or reconstruction_audit.get("parent_model_objects_constructed") != 0
                or reconstruction_audit.get("parent_model_forward_calls") != 0
                or reconstruction_audit.get("parent_model_generate_calls") != 0
                or reconstruction_audit.get("network_access_performed") is not False
                or reconstruction_audit.get("training_steps") != 0
            ):
                raise Lfm2LongHorizonTerminalRefoldError(
                    "Direct-local terminal source lineage is not cross-bound to "
                    "one independently authenticated parent checkpoint."
                )
        object.__setattr__(
            self,
            "document",
            MappingProxyType({**body, "authentication_sha256": supplied}),
        )

    @property
    def authentication_sha256(self) -> str:
        return str(self.document["authentication_sha256"])

    @property
    def direct_local_checkpoint_source_authenticated(self) -> bool:
        return bool(self.document["direct_local_checkpoint_source_authenticated"])

    def verify_authentication(self) -> bool:
        body = dict(self.document)
        supplied = body.pop("authentication_sha256", None)
        return supplied == _canonical_sha256(body)

    def as_dict(self) -> dict[str, Any]:
        return _owned_canonical_document(
            self.document,
            name="terminal source lineage",
        )

    def verify_for(
        self,
        *,
        cache: Lfm2CircuitTraceCache,
        bridge: StrictTokenizerBridgeArtifact,
        parent_final_norm: (
            Lfm2SealedParentFinalRmsNorm | Lfm2LocalParentFinalRmsNormLoad
        ),
        interface: TiedCausalInterfaceFold,
        source_selected_tied_table: Any,
        anchor_transport_witness: TiedResidualAnchorTransportWitness | None = None,
    ) -> None:
        source_report = self.document.get("direct_local_mapped_source_report")
        normalized_parent = parent_final_norm
        if self.document.get(
            "parent_final_norm_direct_local_source"
        ) is None and isinstance(parent_final_norm, Lfm2LocalParentFinalRmsNormLoad):
            normalized_parent = parent_final_norm.final_norm
        expected = build_lfm2_long_horizon_terminal_source_lineage(
            cache=cache,
            bridge=bridge,
            parent_final_norm=normalized_parent,
            interface=interface,
            source_selected_tied_table=source_selected_tied_table,
            direct_local_mapped_source_report=(
                source_report if isinstance(source_report, Mapping) else None
            ),
            anchor_transport_witness=anchor_transport_witness,
        )
        if expected.as_dict() != self.as_dict():
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal source lineage differs from the exact live source inputs."
            )


def build_lfm2_long_horizon_terminal_source_lineage(
    *,
    cache: Lfm2CircuitTraceCache,
    bridge: StrictTokenizerBridgeArtifact,
    parent_final_norm: (Lfm2SealedParentFinalRmsNorm | Lfm2LocalParentFinalRmsNormLoad),
    interface: TiedCausalInterfaceFold,
    source_selected_tied_table: Any,
    direct_local_mapped_source_report: Mapping[str, Any] | None = None,
    anchor_transport_witness: TiedResidualAnchorTransportWitness | None = None,
) -> Lfm2LongHorizonTerminalSourceLineage:
    """Bind exact source bytes and row order without a behavioral tolerance."""

    if not isinstance(cache, Lfm2CircuitTraceCache):
        raise TypeError("cache must be Lfm2CircuitTraceCache.")
    try:
        bridge.verify_files()
    except Exception as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal source lineage tokenizer bridge authentication failed."
        ) from exc
    if isinstance(parent_final_norm, Lfm2LocalParentFinalRmsNormLoad):
        selected_parent_norm = parent_final_norm.final_norm
        parent_norm_source = parent_final_norm.as_dict()
    elif isinstance(parent_final_norm, Lfm2SealedParentFinalRmsNorm):
        selected_parent_norm = parent_final_norm
        parent_norm_source = None
    else:
        raise TypeError(
            "parent_final_norm must be a sealed norm or authenticated direct-local load."
        )
    _verify_parent_norm_binding(cache, selected_parent_norm)
    interface_report = _verify_interface_report(
        interface,
        source_selected_tied_table,
        anchor_transport_witness=anchor_transport_witness,
    )
    source = source_selected_tied_table
    torch = _torch()
    mapping = tuple(bridge.transport_profile.target_to_donor_row_indices)
    if (
        not isinstance(source, torch.Tensor)
        or source.layout != torch.strided
        or source.device.type == "meta"
        or source.ndim != 2
        or source.dtype != torch.bfloat16
        or not bool(torch.isfinite(source).all().item())
        or tuple(source.shape)
        != (
            bridge.transport_profile.target_row_capacity,
            selected_parent_norm.source_hidden_size,
        )
        or len(mapping) != int(source.shape[0])
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal source lineage requires one finite bridge-indexed BF16 table."
        )
    authenticated_source_report = None
    authenticated_source_reconstruction = None
    if direct_local_mapped_source_report is not None:
        if not isinstance(parent_final_norm, Lfm2LocalParentFinalRmsNormLoad):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Direct-local mapped source lineage requires its authenticated "
                "direct-local final-norm load."
            )
        (
            authenticated_source_report,
            authenticated_source_reconstruction,
        ) = _authenticate_direct_local_mapped_source_report(
            direct_local_mapped_source_report,
            cache=cache,
            bridge=bridge,
            parent_final_norm=parent_final_norm,
            source_selected_tied_table=source,
        )
    source64 = source.detach().to(device="cpu", dtype=torch.float64).contiguous()
    compiler_source = {
        "cache_key": cache.cache_key,
        "cache_manifest_sha256": cache.manifest["manifest_sha256"],
        "cache_parent_fingerprint": cache.parent_fingerprint,
        "cache_layer_topology_fingerprint": cache.layer_topology_fingerprint,
        "bridge_artifact_sha256": bridge.artifact_sha256,
        "bridge_transport_profile_fingerprint": bridge.profile_fingerprint,
        "target_to_donor_row_indices_sha256": _canonical_sha256(list(mapping)),
        "parent_final_norm_authentication_sha256": (
            selected_parent_norm.authentication_sha256
        ),
        "parent_final_norm_direct_local_source_sha256": (
            None if parent_norm_source is None else parent_norm_source["result_sha256"]
        ),
        "direct_local_mapped_source_report_sha256": (
            None
            if authenticated_source_report is None
            else authenticated_source_report["result_sha256"]
        ),
        "direct_local_mapped_reconstruction_sha256": (
            None
            if authenticated_source_reconstruction is None
            else authenticated_source_reconstruction["result_sha256"]
        ),
        "mapped_table_bfloat16_sha256": _tensor_sha256(
            source,
            "mapped_parent_tied_table",
        ),
        "mapped_table_interface_source_sha256": _interface_tensor_sha256(source64),
        "interface_report_sha256": interface_report["report_sha256"],
    }
    body = {
        "schema": LFM2_LONG_HORIZON_TERMINAL_SOURCE_LINEAGE_SCHEMA,
        **compiler_source,
        "parent_final_norm": selected_parent_norm.as_dict(),
        "parent_final_norm_direct_local_source": parent_norm_source,
        "direct_local_mapped_source_report": authenticated_source_report,
        "direct_local_mapped_reconstruction": (
            authenticated_source_reconstruction
        ),
        "interface_report": interface_report,
        "mapped_table_shape": [int(size) for size in source.shape],
        "mapped_table_dtype": "bfloat16",
        "direct_local_checkpoint_source_authenticated": (
            authenticated_source_report is not None
        ),
        "compiler_source_binding_sha256": _canonical_sha256(compiler_source),
        "behavioral_tolerance_used_for_source_admission": False,
        "exact_lineage_is_source_admission_authority": True,
        "operation_audit": {
            "parent_model_forward_calls": 0,
            "parent_model_generate_calls": 0,
            "network_access_performed": False,
            "training_steps": 0,
        },
    }
    return Lfm2LongHorizonTerminalSourceLineage(
        {**body, "authentication_sha256": _canonical_sha256(body)}
    )


def _target_runtime_seed(
    target_model: Any,
    interface: TiedCausalInterfaceFold,
    source_selected_tied_table: Any,
) -> tuple[Lfm2CpcfTerminalActionSeed, Any, tuple[Any, ...], float]:
    torch = _torch()
    core = getattr(target_model, "model", None)
    config = getattr(target_model, "config", None)
    layers = tuple(getattr(core, "layers", ()))
    if core is None or getattr(config, "model_type", None) != "lfm2" or not layers:
        raise Lfm2LongHorizonTerminalRefoldError(
            "target_model must be a materialized LFM2 causal language model."
        )
    final_layer = layers[-1]
    feed_forward = getattr(final_layer, "feed_forward", None)
    final_norm_module = getattr(core, "embedding_norm", None)
    final_norm = getattr(final_norm_module, "weight", None)
    target_input = getattr(target_model.get_input_embeddings(), "weight", None)
    target_output = getattr(target_model.get_output_embeddings(), "weight", None)
    gate = getattr(getattr(feed_forward, "w1", None), "weight", None)
    up = getattr(getattr(feed_forward, "w3", None), "weight", None)
    down = getattr(getattr(feed_forward, "w2", None), "weight", None)
    parameters = (gate, up, down, final_norm, target_input)
    if not all(isinstance(value, torch.nn.Parameter) for value in parameters):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Target final SwiGLU, final RMSNorm, or tied table is not materialized."
        )
    if (
        target_output is not target_input
        or any(value.dtype != torch.bfloat16 for value in parameters)
        or not torch.equal(
            target_input.detach().to(device="cpu"),
            interface.target_weight.to(torch.bfloat16),
        )
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Target must expose the exact installed native tied BF16 interface."
        )
    epsilon = _positive_finite(
        getattr(final_norm_module, "variance_epsilon", None),
        "target final RMSNorm variance_epsilon",
    )
    seed = Lfm2CpcfTerminalActionSeed(
        gate_weight=gate,
        up_weight=up,
        down_weight=down,
        final_norm_weight=final_norm,
        producer_encoder=interface.producer_encoder,
        target_tied_weight=target_input,
        source_tied_table=source_selected_tied_table,
        norm_epsilon=epsilon,
    )
    return seed, down, layers, epsilon


def _strict_inverse_mapping(
    bridge: StrictTokenizerBridgeArtifact,
    target_rows: int,
) -> tuple[int, ...]:
    if not isinstance(bridge, StrictTokenizerBridgeArtifact):
        raise TypeError("bridge must be StrictTokenizerBridgeArtifact.")
    try:
        bridge.verify_files()
    except Exception as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Strict tokenizer bridge file authentication failed."
        ) from exc
    profile = bridge.transport_profile
    mapping = tuple(profile.target_to_donor_row_indices)
    if profile.target_row_capacity != target_rows or len(mapping) != target_rows:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Tokenizer bridge target row capacity differs from the installed "
            "tied child table."
        )
    inverse = [-1] * int(profile.donor_row_capacity)
    for target_id, donor_id in enumerate(mapping):
        if donor_id < 0 or donor_id >= len(inverse):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Tokenizer bridge donor row lies outside its capacity."
            )
        inverse[donor_id] = target_id if inverse[donor_id] == -1 else -2
    return tuple(inverse)


def _map_donor_ids_to_unique_target(
    value: Any,
    inverse: tuple[int, ...],
    *,
    name: str,
) -> Any:
    torch = _torch()
    if (
        not isinstance(value, torch.Tensor)
        or value.ndim != 2
        or value.numel() == 0
        or value.device.type != "cpu"
        or value.dtype
        not in {
            torch.uint8,
            torch.int8,
            torch.int16,
            torch.int32,
            torch.int64,
        }
        or bool((value < 0).any().item())
        or bool((value >= len(inverse)).any().item())
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} is not a valid donor token-ID matrix."
        )
    lookup = torch.tensor(inverse, dtype=torch.long)
    mapped = lookup[value.to(torch.long)]
    if bool((mapped == -1).any().item()):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"The strict bridge does not cover every cached {name} row."
        )
    if bool((mapped == -2).any().item()):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"The strict bridge maps a cached {name} donor row to more than "
            "one target row; inverse replay would be ambiguous."
        )
    return mapped.contiguous().clone()


def _runtime_parent_rmsnorm(
    residual_rows: Any,
    seal: Lfm2SealedParentFinalRmsNorm,
) -> Any:
    """Replay the concrete LFM2 RMSNorm arithmetic without a model object."""

    torch = _torch()
    if (
        not isinstance(residual_rows, torch.Tensor)
        or residual_rows.ndim != 2
        or int(residual_rows.shape[1]) != seal.source_hidden_size
        or not torch.is_floating_point(residual_rows)
        or not bool(torch.isfinite(residual_rows).all().item())
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cached final residual rows differ from the sealed parent norm."
        )
    rows = residual_rows.detach().to(device="cpu").contiguous()
    input_dtype = rows.dtype
    hidden = rows.to(torch.float32)
    variance = hidden.square().mean(dim=1, keepdim=True)
    normalized = hidden * torch.rsqrt(variance + seal.epsilon)
    result = seal.weight * normalized.to(input_dtype)
    if not bool(torch.isfinite(result).all().item()):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Runtime-equivalent parent final RMSNorm replay is nonfinite."
        )
    return result.contiguous().clone()


def _verify_parent_final_norm_endpoint(
    tensors: Mapping[str, Any],
    residual_rows: Any,
    seal: Lfm2SealedParentFinalRmsNorm,
    *,
    decode_steps: int,
) -> tuple[Any, dict[str, Any]]:
    """Bind direct-local norm bytes to every authenticated cache endpoint."""

    torch = _torch()
    phases = ("prefill",) + tuple(f"decode.{step:03d}" for step in range(decode_steps))
    norm_inputs = []
    norm_outputs = []
    head_inputs = []
    endpoint_names = tuple(
        f"{phase}.output.{field}"
        for phase in phases
        for field in (
            "final_norm_input",
            "final_norm_output",
            "lm_head_input",
        )
    )
    present_endpoint_names = tuple(name for name in endpoint_names if name in tensors)
    if not present_endpoint_names:
        replayed = _runtime_parent_rmsnorm(residual_rows, seal)
        body = {
            "method": "exact-parent-identity-bound-runtime-rmsnorm-replay-v1",
            "phase_order": list(phases),
            "phase_count": len(phases),
            "parent_final_norm_authentication_sha256": seal.authentication_sha256,
            "cached_final_residual_sha256": _tensor_sha256(residual_rows),
            "cached_output_endpoint_available": False,
            "runtime_replay_to_cached_output_verified": False,
            "runtime_replay_used_as_compiler_target": True,
            "parent_model_objects_constructed": 0,
            "parent_model_forward_calls": 0,
        }
        return replayed.to(torch.bfloat16).contiguous().clone(), {
            **body,
            "authentication_sha256": _canonical_sha256(body),
        }
    if len(present_endpoint_names) != len(endpoint_names):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache final RMSNorm endpoint inventory is partial or phase-incomplete."
        )
    for phase in phases:
        values = tuple(
            tensors.get(f"{phase}.output.{field}")
            for field in (
                "final_norm_input",
                "final_norm_output",
                "lm_head_input",
            )
        )
        if (
            any(not isinstance(value, torch.Tensor) for value in values)
            or any(value.ndim != 3 for value in values)
            or len({tuple(value.shape) for value in values}) != 1
            or int(values[0].shape[0]) != 1
            or int(values[0].shape[1]) < 1
            or int(values[0].shape[2]) != seal.source_hidden_size
            or any(not torch.is_floating_point(value) for value in values)
            or any(not bool(torch.isfinite(value).all().item()) for value in values)
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache phase {phase!r} has no aligned final RMSNorm endpoint."
            )
        norm_inputs.append(values[0][:, -1, :].reshape(1, -1))
        norm_outputs.append(values[1][:, -1, :].reshape(1, -1))
        head_inputs.append(values[2][:, -1, :].reshape(1, -1))

    cached_input = torch.cat(norm_inputs, dim=0).to(device="cpu").contiguous()
    cached_output = torch.cat(norm_outputs, dim=0).to(device="cpu").contiguous()
    cached_head = torch.cat(head_inputs, dim=0).to(device="cpu").contiguous()
    residual = residual_rows.detach().to(device="cpu").contiguous()
    if not torch.equal(cached_input, residual):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cached final-layer residual does not exactly equal the final "
            "RMSNorm input."
        )
    if not torch.equal(cached_output, cached_head):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cached final RMSNorm output does not exactly equal LM-head input."
        )

    replayed = _runtime_parent_rmsnorm(cached_input, seal)
    if tuple(replayed.shape) != tuple(cached_output.shape):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Runtime-equivalent final RMSNorm replay changed endpoint shape."
        )
    replay64 = replayed.to(torch.float64)
    cached64 = cached_output.to(torch.float64)
    difference = (replay64 - cached64).abs()
    dtype = cached_output.dtype
    epsilon = float(torch.finfo(dtype).eps)
    # Preserve the former device/storage envelope as a diagnostic only.  The
    # authenticated cached endpoint is the compiler target; exact checkpoint,
    # cache, final-norm, and payload lineage provides source admission.
    multiplier = 2.0 if dtype in {torch.bfloat16, torch.float16} else 64.0
    scale = torch.maximum(replay64.abs(), cached64.abs())
    tolerance = scale * (multiplier * epsilon)
    exact_zero = scale == 0
    equivalent = (difference <= tolerance) | (exact_zero & (difference == 0))
    reference_rms = float(cached64.square().mean().sqrt().item())
    relative_rmse = float(difference.square().mean().sqrt().item()) / max(
        reference_rms,
        torch.finfo(torch.float64).tiny,
    )
    body = {
        "method": "direct-local-rmsnorm-runtime-replay-to-authenticated-cache-v1",
        "phase_order": list(phases),
        "phase_count": len(phases),
        "parent_final_norm_authentication_sha256": seal.authentication_sha256,
        "cached_final_residual_sha256": _tensor_sha256(residual),
        "cached_final_norm_input_sha256": _tensor_sha256(cached_input),
        "cached_final_norm_output_sha256": _tensor_sha256(cached_output),
        "cached_lm_head_input_sha256": _tensor_sha256(cached_head),
        "runtime_replayed_final_norm_output_sha256": _tensor_sha256(replayed),
        "final_residual_to_norm_input_exact": True,
        "final_norm_output_to_lm_head_input_exact": True,
        "runtime_replay_exact": bool(torch.equal(replayed, cached_output)),
        "runtime_replay_all_elements_finite": True,
        "runtime_replay_within_legacy_numeric_envelope": bool(equivalent.all().item()),
        "runtime_replay_relative_rmse": relative_rmse,
        "runtime_replay_maximum_absolute_error": float(difference.max().item()),
        "scale_relative_tolerance_multiplier": multiplier,
        "storage_dtype_epsilon": epsilon,
        "runtime_replay_metrics_diagnostic_only": True,
        "runtime_replay_numeric_admission_threshold_applied": False,
        "runtime_replay_numeric_error_can_reject_or_rollback": False,
        "exact_source_lineage_is_admission_authority": True,
        "absolute_denominator_floor_used": False,
        "cached_output_endpoint_available": True,
        "runtime_replay_to_cached_output_verified": True,
        "runtime_replay_used_as_compiler_target": False,
        "authenticated_cached_output_used_as_compiler_target": True,
        "parent_model_objects_constructed": 0,
        "parent_model_forward_calls": 0,
    }
    # Use the authenticated cache output itself as the folding target.  BF16 is
    # the established terminal compiler evidence dtype; this removes the old
    # FP64 analytical approximation from the target path.
    target_rows = cached_output.to(torch.bfloat16).contiguous().clone()
    return target_rows, {**body, "authentication_sha256": _canonical_sha256(body)}


def _cache_tensor_names(
    reference: Any,
    *,
    final_layer_index: int,
    decode_steps: int,
    decode_trace_mode: str,
) -> tuple[str, ...]:
    inventory = set(reference.ordered_tensor_names)
    suffixes = (
        "mlp.input",
        "residual.post_operator",
        "residual.post_layer",
    )
    names = {
        "input.input_ids",
        "input.attention_mask",
        "input.forced_decode_ids",
    }
    if "input.position_ids" in inventory:
        names.add("input.position_ids")
    phases = ("prefill",) + tuple(f"decode.{step:03d}" for step in range(decode_steps))
    for phase in phases:
        names.add(f"{phase}.logits")
        prefix = f"{phase}.layer.{final_layer_index:03d}."
        names.update(prefix + suffix for suffix in suffixes)
        if phase != "prefill":
            names.add(f"{phase}.forced_token_ids")
    if decode_trace_mode == CACHED_VERIFIED_TRACE_MODE:
        names.add("cached_prefill.logits")
        names.update(
            f"decode.{step:03d}.full_prefix_logits" for step in range(decode_steps)
        )
    endpoint_names = {
        f"{phase}.output.{field}"
        for phase in phases
        for field in (
            "final_norm_input",
            "final_norm_output",
            "lm_head_input",
        )
    }
    present_endpoint_names = endpoint_names.intersection(inventory)
    if present_endpoint_names and present_endpoint_names != endpoint_names:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Legacy cache has partial or phase-incomplete final RMSNorm evidence."
        )
    names.update(present_endpoint_names)
    missing = sorted(names.difference(inventory))
    if missing:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Legacy cache is missing required final-layer/basic endpoint "
            f"evidence: {missing[:3]}."
        )
    return tuple(sorted(names))


def _nonnegative_finite_metadata_number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be a nonnegative finite metadata number."
        )
    result = float(value)
    if not math.isfinite(result) or result < 0.0:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"{name} must be a nonnegative finite metadata number."
        )
    return result


def _cached_verification_compatibility(
    value: Mapping[str, Any],
    *,
    batch_index: int,
    expected_phase: str,
    expected_prefix_length: int,
) -> dict[str, Any]:
    """Authenticate one sealed cached/full-prefix comparison record.

    The cache collector already compared the complete cached logit row against
    a use-cache=False full-prefix execution.  The terminal fold consumes
    caller-forced tokens, so neither numerical closeness nor a greedy winner is
    a trajectory gate.  Preserve complete finite diagnostics and fail only when
    their sealed structure is malformed or internally inconsistent.
    """

    if not isinstance(value, Mapping):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} has malformed full-prefix verification."
        )
    phase = value.get("phase")
    prefix_length = value.get("prefix_length")
    if phase != expected_phase or prefix_length != expected_prefix_length:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} full-prefix verification coverage is "
            "missing, duplicated, or reordered."
        )
    numerically_close = value.get("numerically_close")
    if type(numerically_close) is not bool:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} phase {expected_phase!r} has malformed "
            "cached/full-prefix numeric diagnostics."
        )
    maximum_absolute_error = _nonnegative_finite_metadata_number(
        value.get("max_abs_error"),
        f"cache batch {batch_index} phase {expected_phase} max_abs_error",
    )
    top1_agreement = value.get("top1_agreement")
    if not isinstance(top1_agreement, bool):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} phase {expected_phase!r} has malformed "
            "top-1 verification metadata."
        )
    if expected_phase.startswith("decode."):
        _digest(
            value.get("forced_token_sha256"),
            (f"cache batch {batch_index} phase {expected_phase} forced_token_sha256"),
        )

    raw_count = value.get("top1_disagreement_count", 0 if top1_agreement else None)
    if (
        isinstance(raw_count, bool)
        or not isinstance(raw_count, int)
        or raw_count < 0
        or (top1_agreement and raw_count != 0)
        or (not top1_agreement and raw_count <= 0)
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} phase {expected_phase!r} has an invalid "
            "top-1 disagreement count."
        )
    disagreement_count = int(raw_count)
    first = value.get("first_top1_disagreement")
    envelope_verified = value.get("top1_disagreement_within_numeric_error_envelope")
    if top1_agreement:
        if first is not None or envelope_verified not in {None, True}:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {expected_phase!r} has "
                "contradictory exact top-1 metadata."
            )
    else:
        # Keep the complete disagreement diagnostics, including a material
        # disagreement outside the old envelope.  Exact cache receipts admit
        # the evidence; these values only help rank and interpret it.
        if type(envelope_verified) is not bool or not isinstance(first, Mapping):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {expected_phase!r} top-1 "
                "disagreement diagnostics are incomplete."
            )
        first_within_envelope = first.get("within_numeric_error_envelope")
        if type(first_within_envelope) is not bool:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {expected_phase!r} first "
                "top-1 disagreement has malformed envelope diagnostics."
            )
        for name in ("row_index", "cached_token_id", "full_prefix_token_id"):
            item = first.get(name)
            if isinstance(item, bool) or not isinstance(item, int) or item < 0:
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {batch_index} phase {expected_phase!r} has "
                    f"malformed near-tie field {name!r}."
                )
        if first["cached_token_id"] == first["full_prefix_token_id"]:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {expected_phase!r} claims a "
                "top-1 disagreement with identical token IDs."
            )
        numeric = {
            name: _nonnegative_finite_metadata_number(
                first.get(name),
                f"cache batch {batch_index} phase {expected_phase} {name}",
            )
            for name in (
                "cached_winner_margin",
                "full_prefix_winner_margin",
                "cached_preference_gap",
                "full_prefix_preference_gap",
                "row_max_abs_error",
                "winner_pair_error_envelope",
            )
        }
        envelope = numeric["winner_pair_error_envelope"] + 1e-12
        recomputed_first_within_envelope = not (
            numeric["cached_preference_gap"] > envelope
            or numeric["full_prefix_preference_gap"] > envelope
        )
        if first_within_envelope is not recomputed_first_within_envelope:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {expected_phase!r} near-tie "
                "metadata differs from its sealed numeric diagnostics."
            )
        for name in (
            "maximum_cached_preference_gap_on_disagreement",
            "maximum_full_prefix_preference_gap_on_disagreement",
        ):
            _nonnegative_finite_metadata_number(
                value.get(name),
                f"cache batch {batch_index} phase {expected_phase} {name}",
            )
        _digest(
            value.get("cached_top1_sha256"),
            f"cache batch {batch_index} phase {expected_phase} cached_top1_sha256",
        )
        _digest(
            value.get("full_prefix_top1_sha256"),
            (
                f"cache batch {batch_index} phase {expected_phase} "
                "full_prefix_top1_sha256"
            ),
        )

    decision_verified = value.get("top1_decision_verified")
    if decision_verified is not None and not isinstance(decision_verified, bool):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} phase {expected_phase!r} has malformed "
            "top-1 decision metadata."
        )
    body = {
        "phase": expected_phase,
        "prefix_length": expected_prefix_length,
        "numerically_close": numerically_close,
        "maximum_absolute_error": maximum_absolute_error,
        "top1_exact_agreement": top1_agreement,
        "top1_exactness_is_diagnostic_only": True,
        "top1_disagreement_count": disagreement_count,
        "top1_disagreement_numeric_envelope_verified": (
            top1_agreement or envelope_verified is True
        ),
        "collector_top1_decision_verified": decision_verified,
        "numeric_diagnostics_are_admission_authority": False,
        "exact_cache_lineage_is_admission_authority": True,
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _terminal_cache_capture_compatibility(
    capture: Mapping[str, Any],
    *,
    batch_index: int,
    expected_decode_steps: int | None = None,
) -> dict[str, Any]:
    """Validate exact phase coverage from one authenticated batch record."""

    if not isinstance(capture, Mapping):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} has no authenticated capture record."
        )
    decode_steps = capture.get("decode_steps")
    if (
        isinstance(decode_steps, bool)
        or not isinstance(decode_steps, int)
        or decode_steps <= 0
        or (expected_decode_steps is not None and decode_steps != expected_decode_steps)
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} has incompatible forced-horizon metadata."
        )
    mode = capture.get("decode_trace_mode")
    verifications = capture.get("cached_full_prefix_verifications")
    if not isinstance(verifications, list):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} has malformed verification coverage."
        )

    if mode == FULL_PREFIX_CANONICAL_TRACE_MODE:
        if (
            verifications
            or capture.get("all_cached_logits_verified") is not None
            or capture.get("all_cached_top1_verified") is not None
            or capture.get("all_cached_top1_decisions_verified") is not None
            or capture.get("cached_logits_accepted") is not False
            or capture.get("cached_forward_count") != 0
            or capture.get("canonical_trace_source")
            not in {
                "use_cache_false_full_prefix",
                "use_cache_false_full_trajectory_slices",
            }
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} has contradictory canonical "
                "full-prefix metadata."
            )
        body = {
            "batch_index": batch_index,
            "decode_trace_mode": mode,
            "decode_steps": decode_steps,
            "verification_phase_count": 0,
            "cached_logits_numerically_verified": None,
            "cached_top1_exact_for_all_phases": None,
            "top1_exactness_is_diagnostic_only": True,
            "top1_disagreement_count": 0,
            "all_top1_disagreements_numeric_envelope_verified": True,
            "forced_decode_trajectory_compatible": True,
            "numeric_diagnostics_are_admission_authority": False,
            "exact_cache_lineage_is_admission_authority": True,
        }
        return {**body, "authentication_sha256": _canonical_sha256(body)}

    if mode != CACHED_VERIFIED_TRACE_MODE:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} decode trace mode is unsupported."
        )
    expected_phases = ("cached_prefill",) + tuple(
        f"decode.{step:03d}" for step in range(decode_steps)
    )
    if len(verifications) != len(expected_phases):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} cached/full-prefix verification "
            "coverage is incomplete."
        )
    first_prefix = verifications[0].get("prefix_length") if verifications else None
    if (
        isinstance(first_prefix, bool)
        or not isinstance(first_prefix, int)
        or first_prefix <= 0
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} cached prefill prefix is malformed."
        )
    phase_receipts = tuple(
        _cached_verification_compatibility(
            value,
            batch_index=batch_index,
            expected_phase=phase,
            expected_prefix_length=(
                first_prefix if index == 0 else first_prefix + index
            ),
        )
        for index, (phase, value) in enumerate(
            zip(expected_phases, verifications, strict=True)
        )
    )
    all_exact = all(value["top1_exact_agreement"] for value in phase_receipts)
    all_numerically_close = all(
        value["numerically_close"] is True for value in phase_receipts
    )
    cached_logits_verified = capture.get("all_cached_logits_verified")
    cached_logits_accepted = capture.get("cached_logits_accepted")
    if (
        type(cached_logits_verified) is not bool
        or cached_logits_verified is not all_numerically_close
        or capture.get("all_cached_top1_verified") is not all_exact
        or type(cached_logits_accepted) is not bool
        or capture.get("canonical_trace_source") != "verified_one_token_cache"
        or capture.get("cached_forward_count") != len(expected_phases)
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} cached/full-prefix aggregate metadata "
            "contradicts its complete phase records."
        )
    top1_decisions = capture.get("all_cached_top1_decisions_verified")
    if top1_decisions is not None and not isinstance(top1_decisions, bool):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} has malformed aggregate top-1 metadata."
        )
    disagreement_count = sum(
        int(value["top1_disagreement_count"]) for value in phase_receipts
    )
    body = {
        "batch_index": batch_index,
        "decode_trace_mode": mode,
        "decode_steps": decode_steps,
        "verification_phase_count": len(phase_receipts),
        "verification_phase_order": list(expected_phases),
        "verification_authentication_sha256": [
            value["authentication_sha256"] for value in phase_receipts
        ],
        "cached_logits_numerically_verified": all_numerically_close,
        "collector_cached_logits_accepted": cached_logits_accepted,
        "cached_top1_exact_for_all_phases": all_exact,
        "collector_all_top1_decisions_verified": top1_decisions,
        "top1_exactness_is_diagnostic_only": True,
        "top1_disagreement_count": disagreement_count,
        "all_top1_disagreements_numeric_envelope_verified": all(
            value["top1_disagreement_numeric_envelope_verified"]
            for value in phase_receipts
        ),
        "forced_decode_trajectory_compatible": True,
        "numeric_diagnostics_are_admission_authority": False,
        "exact_cache_lineage_is_admission_authority": True,
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _terminal_cache_record_inventory_compatibility(
    inventory: Mapping[str, Any],
    compatibility: Mapping[str, Any],
    *,
    batch_index: int,
    final_layer_index: int,
) -> dict[str, Any]:
    """Prove from descriptors that every later terminal payload is present."""

    decode_steps = int(compatibility["decode_steps"])
    mode = compatibility["decode_trace_mode"]
    phases = ("prefill",) + tuple(f"decode.{step:03d}" for step in range(decode_steps))
    required = {
        "input.input_ids",
        "input.attention_mask",
        "input.forced_decode_ids",
    }
    for phase in phases:
        required.add(f"{phase}.logits")
        prefix = f"{phase}.layer.{final_layer_index:03d}."
        required.update(
            prefix + suffix
            for suffix in (
                "mlp.input",
                "residual.post_operator",
                "residual.post_layer",
            )
        )
        if phase != "prefill":
            required.add(f"{phase}.forced_token_ids")
    if mode == CACHED_VERIFIED_TRACE_MODE:
        required.add("cached_prefill.logits")
        required.update(
            f"decode.{step:03d}.full_prefix_logits" for step in range(decode_steps)
        )
    missing = sorted(required.difference(inventory))
    if missing:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} record inventory omits required terminal "
            f"evidence: {missing[:3]}."
        )

    def descriptor(name: str) -> tuple[str, tuple[int, ...]]:
        value = inventory.get(name)
        shape = value.get("shape") if isinstance(value, Mapping) else None
        dtype = value.get("dtype") if isinstance(value, Mapping) else None
        if (
            not isinstance(value, Mapping)
            or not isinstance(dtype, str)
            or not dtype
            or not isinstance(shape, list)
            or not shape
            or any(type(size) is not int or size <= 0 for size in shape)
            or type(value.get("numel")) is not int
            or value.get("numel") != math.prod(shape)
            or type(value.get("size_bytes")) is not int
            or value.get("size_bytes") <= 0
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} tensor descriptor {name!r} is malformed."
            )
        _digest(
            value.get("sha256"),
            f"cache batch {batch_index} tensor {name} sha256",
        )
        return dtype, tuple(shape)

    integer_dtypes = {"int8", "int16", "int32", "int64", "uint8"}
    prompt_dtype, prompt_shape = descriptor("input.input_ids")
    mask_dtype, mask_shape = descriptor("input.attention_mask")
    forced_dtype, forced_shape = descriptor("input.forced_decode_ids")
    if (
        prompt_dtype not in integer_dtypes
        or mask_dtype not in integer_dtypes
        or forced_dtype not in integer_dtypes
        or len(prompt_shape) != 2
        or prompt_shape[0] != 1
        or mask_shape != prompt_shape
        or forced_shape != (1, decode_steps)
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} input descriptor geometry is incompatible."
        )
    position = inventory.get("input.position_ids")
    if position is not None:
        position_dtype, position_shape = descriptor("input.position_ids")
        if position_dtype not in integer_dtypes or position_shape != prompt_shape:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} position descriptor is incompatible."
            )

    for phase in phases:
        logit_dtype, logit_shape = descriptor(f"{phase}.logits")
        if (
            logit_dtype not in {"float16", "bfloat16", "float32", "float64"}
            or len(logit_shape) != 3
            or logit_shape[0] != 1
            or logit_shape[-1] < 2
            or (phase != "prefill" and logit_shape[1] != 1)
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {phase!r} logit descriptor "
                "is incompatible."
            )
        if mode == CACHED_VERIFIED_TRACE_MODE:
            counterpart = (
                "cached_prefill.logits"
                if phase == "prefill"
                else f"{phase}.full_prefix_logits"
            )
            counterpart_dtype, counterpart_shape = descriptor(counterpart)
            if counterpart_dtype != logit_dtype or counterpart_shape != logit_shape:
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {batch_index} phase {phase!r} cached/full-prefix "
                    "logit descriptors differ."
                )
        prefix = f"{phase}.layer.{final_layer_index:03d}."
        endpoint_shapes = tuple(
            descriptor(prefix + suffix)[1]
            for suffix in (
                "mlp.input",
                "residual.post_operator",
                "residual.post_layer",
            )
        )
        if (
            len(set(endpoint_shapes)) != 1
            or len(endpoint_shapes[0]) != 3
            or endpoint_shapes[0][0] != 1
            or (phase != "prefill" and endpoint_shapes[0][1] != 1)
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {phase!r} final-layer "
                "descriptors are incompatible."
            )
        if phase != "prefill":
            forced_phase_dtype, forced_phase_shape = descriptor(
                f"{phase}.forced_token_ids"
            )
            if forced_phase_dtype not in integer_dtypes or forced_phase_shape != (1, 1):
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {batch_index} phase {phase!r} forced-token "
                    "descriptor is incompatible."
                )

    endpoint_names = {
        f"{phase}.output.{field}"
        for phase in phases
        for field in ("final_norm_input", "final_norm_output", "lm_head_input")
    }
    present_endpoints = endpoint_names.intersection(inventory)
    if present_endpoints and present_endpoints != endpoint_names:
        raise Lfm2LongHorizonTerminalRefoldError(
            f"Cache batch {batch_index} has partial final-normalization endpoint "
            "descriptors."
        )
    for name in sorted(present_endpoints):
        descriptor(name)
    required_names = tuple(sorted(required.union(present_endpoints)))
    body = {
        "batch_index": batch_index,
        "decode_trace_mode": mode,
        "prompt_token_count": prompt_shape[1],
        "required_tensor_count": len(required_names),
        "required_tensor_names_sha256": _canonical_sha256(list(required_names)),
        "raw_cached_full_prefix_pairs_present": (mode == CACHED_VERIFIED_TRACE_MODE),
        "final_layer_terminal_endpoints_present": bool(present_endpoints),
        "final_norm_endpoint_set_complete_if_present": True,
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _authenticate_terminal_cache_compatibility(
    cache: Lfm2CircuitTraceCache,
    manifest: Mapping[str, Any],
    completion: Mapping[str, Any],
    entries: Sequence[Mapping[str, Any]],
    records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Seal compatibility from small authenticated batch-record files."""

    if (
        len(entries) != cache.batch_count
        or len(records) != cache.batch_count
        or any(type(value.get("batch_index")) is not int for value in entries)
        or tuple(int(value["batch_index"]) for value in entries)
        != tuple(range(cache.batch_count))
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Authenticated cache batch-record coverage is incomplete or reordered."
        )
    # The v1 manifest omitted this field for its original/default cached mode;
    # each sealed batch record still states the mode explicitly.  Only the
    # later opt-in canonical mode writes it at manifest level.
    expected_mode = manifest.get("capture", {}).get(
        "decode_trace_mode",
        CACHED_VERIFIED_TRACE_MODE,
    )
    if expected_mode not in {
        CACHED_VERIFIED_TRACE_MODE,
        FULL_PREFIX_CANONICAL_TRACE_MODE,
    }:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache manifest has an unsupported terminal decode trace mode."
        )
    topology = manifest.get("layer_topology", {}).get("layers")
    if not isinstance(topology, list) or not topology:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache manifest has no terminal-compatible layer topology."
        )
    final_layer_index = len(topology) - 1
    batches = []
    for entry, record in zip(entries, records, strict=True):
        index = int(entry["batch_index"])
        inventory = record.get("tensors")
        if (
            record.get("schema") != BATCH_SCHEMA
            or record.get("cache_key") != cache.cache_key
            or type(record.get("batch_index")) is not int
            or record.get("batch_index") != index
            or record.get("input_sha256") != entry["input_sha256"]
            or record.get("record_sha256") != entry["record_sha256"]
            or not isinstance(inventory, Mapping)
            or not inventory
            or type(record.get("tensor_count")) is not int
            or record.get("tensor_count") != len(inventory)
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {index} tensor-free record binding is "
                "incompatible with its authenticated completion entry."
            )
        compatibility = _terminal_cache_capture_compatibility(
            record.get("capture"),
            batch_index=index,
        )
        inventory_compatibility = _terminal_cache_record_inventory_compatibility(
            inventory,
            compatibility,
            batch_index=index,
            final_layer_index=final_layer_index,
        )
        capture = record.get("capture")
        verifications = (
            capture.get("cached_full_prefix_verifications")
            if isinstance(capture, Mapping)
            else None
        )
        if compatibility["decode_trace_mode"] == CACHED_VERIFIED_TRACE_MODE and (
            not isinstance(verifications, list)
            or not verifications
            or verifications[0].get("prefix_length")
            != inventory_compatibility["prompt_token_count"]
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {index} cached prefill verification prefix is not "
                "bound to the sealed prompt descriptor."
            )
        if compatibility["decode_trace_mode"] != expected_mode:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {index} decode mode differs from the "
                "authenticated cache manifest."
            )
        batches.append(
            {
                **compatibility,
                "input_sha256": entry["input_sha256"],
                "record_file_sha256": entry["record_file_sha256"],
                "record_sha256": entry["record_sha256"],
                "tensor_inventory_compatibility": inventory_compatibility,
            }
        )
    disagreement_count = sum(int(value["top1_disagreement_count"]) for value in batches)
    cached_batches = tuple(
        value
        for value in batches
        if value["decode_trace_mode"] == CACHED_VERIFIED_TRACE_MODE
    )
    all_cached_logits_numerically_verified = (
        all(
            value["cached_logits_numerically_verified"] is True
            for value in cached_batches
        )
        if cached_batches
        else None
    )
    all_numeric_envelopes_verified = all(
        value["all_top1_disagreements_numeric_envelope_verified"] is True
        for value in batches
    )
    body = {
        "schema": LFM2_LONG_HORIZON_TERMINAL_CACHE_COMPATIBILITY_SCHEMA,
        "cache_key": cache.cache_key,
        "cache_parent_fingerprint": cache.parent_fingerprint,
        "cache_layer_topology_fingerprint": cache.layer_topology_fingerprint,
        "manifest_sha256": manifest["manifest_sha256"],
        "completion_sha256": completion["completion_sha256"],
        "batch_count": cache.batch_count,
        "decode_trace_mode": expected_mode,
        "ordered_batch_record_sha256": [value["record_sha256"] for value in batches],
        "ordered_batch_record_file_sha256": [
            value["record_file_sha256"] for value in batches
        ],
        "batch_compatibility": batches,
        "all_cached_logits_numerically_verified": (
            all_cached_logits_numerically_verified
        ),
        "all_cached_top1_exact": (
            all(
                value["cached_top1_exact_for_all_phases"] is True
                for value in cached_batches
            )
            if cached_batches
            else None
        ),
        "cached_top1_disagreement_count": disagreement_count,
        "all_top1_disagreements_numeric_envelope_verified": (
            all_numeric_envelopes_verified
        ),
        "forced_decode_tokens_are_caller_supplied": True,
        "top1_exactness_is_diagnostic_only": True,
        "top1_exactness_is_publication_gate": False,
        "terminal_trajectory_compatibility_verified": True,
        "full_prefix_recache_required": False,
        "full_prefix_recache_recommended_diagnostic": bool(
            all_cached_logits_numerically_verified is False
            or not all_numeric_envelopes_verified
        ),
        "full_prefix_recache_assessment": (
            "diagnostic_only_exact_cache_lineage_remains_admissible_regardless_"
            "of_cached_full_prefix_numeric_difference"
        ),
        "numeric_diagnostics_are_admission_authority": False,
        "exact_cache_lineage_is_admission_authority": True,
        "preflight_io_contract": {
            "authenticated_sealed_batch_record_metadata_used": True,
            "manifest_file_reads": 1,
            "completion_file_reads": 1,
            "record_file_sha256_passes_per_batch": 1,
            "record_file_sha256_passes_total": cache.batch_count,
            "record_file_canonical_parse_reads_per_batch": 1,
            "record_file_canonical_parse_reads_total": cache.batch_count,
            "record_file_content_read_passes_total": 2 * cache.batch_count,
            "trace_file_sha256_passes": 0,
            "trace_file_regular_identity_stat_passes_per_batch": 1,
            "trace_file_regular_identity_stat_passes_total": cache.batch_count,
            "trace_payload_bytes_read": 0,
            "trace_tensor_payloads_materialized": 0,
            "large_trace_authentication_deferred_to_consuming_session": True,
        },
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _preflight_terminal_cache_compatibility(
    cache: Lfm2CircuitTraceCache,
) -> dict[str, Any]:
    """Authenticate metadata/record files without reading trace payloads."""

    fresh_manifest, entries = _fresh_verified_cache_state(cache)
    completion = cache._completion
    if (
        fresh_manifest["manifest_sha256"] != cache.manifest["manifest_sha256"]
        or completion.get("completion_sha256") != cache._completion["completion_sha256"]
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache metadata changed during terminal compatibility preflight."
        )
    records = []
    for entry in entries:
        index = int(entry["batch_index"])
        batch_dir = cache.path / "batches" / f"batch-{index:06d}"
        if (
            not batch_dir.is_dir()
            or batch_dir.is_symlink()
            or {path.name for path in batch_dir.iterdir()}
            != {TRACE_FILENAME, BATCH_RECORD_FILENAME}
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {index} layout is unsafe or incomplete."
            )
        record_path = batch_dir / BATCH_RECORD_FILENAME
        _cache_path_file_identity(batch_dir / TRACE_FILENAME)
        record_identity = _cache_path_file_identity(record_path)
        if (
            not record_path.is_file()
            or record_path.is_symlink()
            or _cache_file_sha256(record_path) != entry["record_file_sha256"]
            or _cache_path_file_identity(record_path) != record_identity
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {index} record-file authentication failed."
            )
        record = _read_cache_canonical_json(record_path)
        if _cache_path_file_identity(record_path) != record_identity:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {index} record changed during compatibility preflight."
            )
        _verify_cache_seal(
            record,
            "record_sha256",
            f"cache batch {index} terminal compatibility record",
        )
        records.append(record)
    return _authenticate_terminal_cache_compatibility(
        cache,
        fresh_manifest,
        completion,
        entries,
        records,
    )


def preflight_lfm2_long_horizon_terminal_cache(
    cache: Lfm2CircuitTraceCache,
) -> dict[str, Any]:
    """Public metadata-only terminal compatibility preflight.

    Callers that perform upstream folding should invoke this before any target
    surgery and pass the sealed result into the terminal compiler for a fresh
    cheap revalidation/binding.  No safetensors trace payload is opened or
    hashed here.
    """

    if not isinstance(cache, Lfm2CircuitTraceCache):
        raise TypeError("cache must be Lfm2CircuitTraceCache.")
    return _preflight_terminal_cache_compatibility(cache)


def _bind_terminal_cache_compatibility_to_payload_session(
    compatibility: Mapping[str, Any],
    cache_receipt: Mapping[str, Any],
) -> dict[str, Any]:
    """Bind the cheap snapshot to the later single file-SHA authentication pass."""

    compatibility_body = dict(compatibility)
    compatibility_seal = compatibility_body.pop("authentication_sha256", None)
    if compatibility_seal != _canonical_sha256(compatibility_body):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal-cache compatibility receipt authentication failed."
        )
    session = cache_receipt.get("session")
    if not isinstance(session, Mapping):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Consuming cache session receipt is missing."
        )
    batches = session.get(
        "ordered_authenticated_batches",
        session.get("ordered_verified_batches"),
    )
    if not isinstance(batches, list):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Consuming cache session has no ordered batch authentication."
        )
    if (
        session.get("cache_key") != compatibility.get("cache_key")
        or session.get("manifest_sha256") != compatibility.get("manifest_sha256")
        or session.get("completion_sha256") != compatibility.get("completion_sha256")
        or [value.get("record_sha256") for value in batches]
        != compatibility.get("ordered_batch_record_sha256")
        or [value.get("record_file_sha256") for value in batches]
        != compatibility.get("ordered_batch_record_file_sha256")
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Consumed trace payloads do not bind to the terminal-cache "
            "compatibility preflight."
        )
    body = {
        "compatibility_authentication_sha256": compatibility_seal,
        "payload_session_sha256": session["session_sha256"],
        "manifest_completion_and_ordered_records_exact": True,
        "large_trace_file_sha256_authenticated_once_by_consuming_session": True,
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _summarize_terminal_cache_payload_loads(
    cache_receipt: Mapping[str, Any],
) -> dict[str, Any]:
    """Seal selected tensor I/O separately from the session's whole-file hashes."""

    session = cache_receipt.get("session")
    payloads = cache_receipt.get("selected_payloads")
    batches = (
        session.get(
            "ordered_authenticated_batches",
            session.get("ordered_verified_batches"),
        )
        if isinstance(session, Mapping)
        else None
    )
    if not isinstance(batches, list) or not isinstance(payloads, list):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal cache receipt has no ordered tensor-payload inventory."
        )
    if len(payloads) != len(batches):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal tensor-payload loads do not cover every authenticated batch."
        )
    expected_by_index: dict[int, Mapping[str, Any]] = {}
    for expected_index, batch in enumerate(batches):
        if not isinstance(batch, Mapping):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal cache session batch inventory is malformed."
            )
        batch_index = batch.get("batch_index")
        tensor_count = batch.get("tensor_count")
        logical_bytes = batch.get("logical_bytes")
        if (
            type(batch_index) is not int
            or batch_index != expected_index
            or type(tensor_count) is not int
            or tensor_count <= 0
            or type(logical_bytes) is not int
            or logical_bytes <= 0
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal cache session tensor inventory is invalid or reordered."
            )
        expected_by_index[batch_index] = batch

    per_batch = []
    for expected_index, payload_receipt in enumerate(payloads):
        if not isinstance(payload_receipt, Mapping):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal selected tensor-payload receipt is malformed."
            )
        batch_index = payload_receipt.get("batch_index")
        selected = payload_receipt.get("selective_payload", payload_receipt)
        if (
            type(batch_index) is not int
            or batch_index != expected_index
            or not isinstance(
                selected,
                Mapping,
            )
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal selected tensor-payload receipt is invalid or reordered."
            )
        selected_count = selected.get("selected_tensor_count")
        selected_bytes = selected.get("selected_logical_bytes")
        expected = expected_by_index[batch_index]
        expected_count = int(expected["tensor_count"])
        expected_bytes = int(expected["logical_bytes"])
        if (
            type(selected_count) is not int
            or selected_count <= 0
            or selected_count > expected_count
            or type(selected_bytes) is not int
            or selected_bytes <= 0
            or selected_bytes > expected_bytes
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal selected tensor-payload counts exceed the sealed inventory."
            )
        full_inventory = bool(
            selected_count == expected_count and selected_bytes == expected_bytes
        )
        per_batch.append(
            {
                "batch_index": batch_index,
                "selected_tensor_count": selected_count,
                "selected_logical_bytes": selected_bytes,
                "sealed_inventory_tensor_count": expected_count,
                "sealed_inventory_logical_bytes": expected_bytes,
                "full_tensor_inventory_payload_loaded": full_inventory,
            }
        )

    full_inventory = [
        value for value in per_batch if value["full_tensor_inventory_payload_loaded"]
    ]
    body = {
        "schema": LFM2_LONG_HORIZON_TERMINAL_PAYLOAD_LOAD_AUDIT_SCHEMA,
        "trace_file_sha256_passes_accounted_here": 0,
        "selected_tensor_payload_load_count": len(per_batch),
        "selected_tensor_count_total": sum(
            int(value["selected_tensor_count"]) for value in per_batch
        ),
        "selected_tensor_payload_logical_bytes_total": sum(
            int(value["selected_logical_bytes"]) for value in per_batch
        ),
        "full_tensor_inventory_payload_load_count": len(full_inventory),
        "full_tensor_inventory_payload_logical_bytes_total": sum(
            int(value["selected_logical_bytes"]) for value in full_inventory
        ),
        "every_batch_loaded_full_tensor_inventory_once": len(full_inventory)
        == len(per_batch),
        "per_batch": per_batch,
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _verify_cached_full_prefix_payload_equivalence(
    tensors: Mapping[str, Any],
    capture: Mapping[str, Any],
    *,
    batch_index: int,
    logit_rtol: float,
    logit_atol: float,
) -> dict[str, Any]:
    """Recompute every cached/full-prefix near-tie from selected raw logits."""

    torch = _torch()
    compatibility = _terminal_cache_capture_compatibility(
        capture,
        batch_index=batch_index,
    )
    mode = compatibility["decode_trace_mode"]
    if mode == FULL_PREFIX_CANONICAL_TRACE_MODE:
        body = {
            "batch_index": batch_index,
            "decode_trace_mode": mode,
            "raw_cached_full_prefix_pair_count": 0,
            "raw_logit_rows_verified": 0,
            "top1_disagreement_count": 0,
            "all_logits_numerically_close": True,
            "all_top1_disagreements_within_numeric_error_envelope": True,
            "top1_exactness_is_diagnostic_only": True,
            "numeric_diagnostics_are_admission_authority": False,
            "exact_payload_lineage_is_admission_authority": True,
        }
        return {**body, "authentication_sha256": _canonical_sha256(body)}

    decode_steps = int(compatibility["decode_steps"])
    verifications = capture["cached_full_prefix_verifications"]
    pairs = (("cached_prefill", "cached_prefill.logits", "prefill.logits"),) + tuple(
        (
            f"decode.{step:03d}",
            f"decode.{step:03d}.logits",
            f"decode.{step:03d}.full_prefix_logits",
        )
        for step in range(decode_steps)
    )
    phase_receipts = []
    total_rows = 0
    total_disagreements = 0
    for (phase, cached_name, full_name), sealed in zip(
        pairs,
        verifications,
        strict=True,
    ):
        cached = tensors.get(cached_name)
        full = tensors.get(full_name)
        if (
            not isinstance(cached, torch.Tensor)
            or not isinstance(full, torch.Tensor)
            or tuple(cached.shape) != tuple(full.shape)
            or cached.ndim < 2
            or int(cached.shape[-1]) < 2
            or not torch.is_floating_point(cached)
            or not torch.is_floating_point(full)
            or not bool(torch.isfinite(cached).all().item())
            or not bool(torch.isfinite(full).all().item())
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {phase!r} raw cached/full-prefix "
                "logit pair is missing or malformed."
            )
        forced_token_sha256 = None
        if phase.startswith("decode."):
            forced_token = tensors.get(f"{phase}.forced_token_ids")
            if not isinstance(forced_token, torch.Tensor):
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {batch_index} phase {phase!r} has no raw "
                    "forced-token binding."
                )
            forced_token_sha256 = _cache_tensor_sha256(torch, forced_token)
            if sealed.get("forced_token_sha256") != forced_token_sha256:
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {batch_index} phase {phase!r} sealed forced "
                    "token digest differs from the raw trajectory."
                )
        cached64 = cached.to(device="cpu", dtype=torch.float64).reshape(
            -1, int(cached.shape[-1])
        )
        full64 = full.to(device="cpu", dtype=torch.float64).reshape_as(cached64)
        difference = cached64 - full64
        maximum_error = float(difference.abs().max().item())
        numerically_close = bool(
            torch.allclose(
                cached64,
                full64,
                rtol=logit_rtol,
                atol=logit_atol,
            )
        )
        if (
            sealed.get("numerically_close") is not numerically_close
            or not math.isclose(
                maximum_error,
                float(sealed.get("max_abs_error")),
                rel_tol=0.0,
                abs_tol=1e-12,
            )
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {phase!r} raw logits do not "
                "reproduce the sealed numeric verification."
            )
        cached_top1 = cached64.argmax(dim=1)
        full_top1 = full64.argmax(dim=1)
        agreements = cached_top1 == full_top1
        disagreement_indices = torch.nonzero(
            ~agreements,
            as_tuple=False,
        ).reshape(-1)
        disagreement_count = int(disagreement_indices.numel())
        if bool(agreements.all().item()) is not sealed.get(
            "top1_agreement"
        ) or disagreement_count != int(
            sealed.get("top1_disagreement_count", disagreement_count)
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {phase!r} raw top-1 decisions "
                "do not reproduce the sealed verification."
            )
        for name, observed in (
            ("cached_top1_sha256", cached_top1),
            ("full_prefix_top1_sha256", full_top1),
        ):
            supplied = sealed.get(name)
            if supplied is not None and supplied != _cache_tensor_sha256(
                torch,
                observed,
            ):
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {batch_index} phase {phase!r} raw {name} "
                    "differs from the sealed verification."
                )

        every_disagreement_within_envelope = True
        first_disagreement = None
        for raw_index in disagreement_indices.tolist():
            row_index = int(raw_index)
            cached_id = int(cached_top1[row_index].item())
            full_id = int(full_top1[row_index].item())
            row_difference = difference[row_index]
            pair_envelope = float(
                (row_difference[cached_id].abs() + row_difference[full_id].abs()).item()
            )
            cached_gap = float(
                (cached64[row_index, cached_id] - cached64[row_index, full_id]).item()
            )
            full_gap = float(
                (full64[row_index, full_id] - full64[row_index, cached_id]).item()
            )
            within = bool(
                cached_gap <= pair_envelope + 1e-12
                and full_gap <= pair_envelope + 1e-12
            )
            every_disagreement_within_envelope &= within
            if first_disagreement is None:
                cached_top2 = torch.topk(cached64[row_index], k=2).values
                full_top2 = torch.topk(full64[row_index], k=2).values
                first_disagreement = {
                    "row_index": row_index,
                    "cached_token_id": cached_id,
                    "full_prefix_token_id": full_id,
                    "cached_winner_margin": float(
                        (cached_top2[0] - cached_top2[1]).item()
                    ),
                    "full_prefix_winner_margin": float(
                        (full_top2[0] - full_top2[1]).item()
                    ),
                    "cached_preference_gap": cached_gap,
                    "full_prefix_preference_gap": full_gap,
                    "row_max_abs_error": float(row_difference.abs().max().item()),
                    "winner_pair_error_envelope": pair_envelope,
                    "within_numeric_error_envelope": within,
                }
        if (
            sealed.get(
                "top1_disagreement_within_numeric_error_envelope",
                every_disagreement_within_envelope,
            )
            is not every_disagreement_within_envelope
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {phase!r} raw top-1 envelope "
                "diagnostics differ from the sealed record."
            )
        sealed_first = sealed.get("first_top1_disagreement")
        if first_disagreement is None:
            if sealed_first is not None:
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {batch_index} phase {phase!r} has a spurious "
                    "sealed first disagreement."
                )
        elif not isinstance(sealed_first, Mapping):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch_index} phase {phase!r} lacks sealed raw "
                "near-tie detail."
            )
        else:
            for name, observed in first_disagreement.items():
                supplied = sealed_first.get(name)
                if isinstance(observed, float):
                    if (
                        isinstance(supplied, bool)
                        or not isinstance(supplied, (int, float))
                        or not math.isclose(
                            float(supplied),
                            observed,
                            rel_tol=0.0,
                            abs_tol=1e-12,
                        )
                    ):
                        raise Lfm2LongHorizonTerminalRefoldError(
                            f"Cache batch {batch_index} phase {phase!r} sealed "
                            f"near-tie field {name!r} differs from raw logits."
                        )
                elif supplied != observed:
                    raise Lfm2LongHorizonTerminalRefoldError(
                        f"Cache batch {batch_index} phase {phase!r} sealed "
                        f"near-tie field {name!r} differs from raw logits."
                    )
        total_rows += int(cached64.shape[0])
        total_disagreements += disagreement_count
        phase_body = {
            "phase": phase,
            "cached_logits_sha256": _tensor_sha256(cached),
            "full_prefix_logits_sha256": _tensor_sha256(full),
            "row_count": int(cached64.shape[0]),
            "maximum_absolute_error": maximum_error,
            "numerically_close": numerically_close,
            "top1_exact_agreement": disagreement_count == 0,
            "top1_disagreement_count": disagreement_count,
            "all_top1_disagreements_within_numeric_error_envelope": (
                every_disagreement_within_envelope
            ),
            "forced_token_sha256": forced_token_sha256,
            "numeric_diagnostics_are_admission_authority": False,
            "exact_payload_lineage_is_admission_authority": True,
        }
        phase_receipts.append(
            {**phase_body, "authentication_sha256": _canonical_sha256(phase_body)}
        )
    body = {
        "batch_index": batch_index,
        "decode_trace_mode": mode,
        "raw_cached_full_prefix_pair_count": len(phase_receipts),
        "raw_logit_rows_verified": total_rows,
        "phase_verification": phase_receipts,
        "phase_authentication_sha256": [
            value["authentication_sha256"] for value in phase_receipts
        ],
        "top1_disagreement_count": total_disagreements,
        "all_logits_numerically_close": all(
            value["numerically_close"] is True for value in phase_receipts
        ),
        "all_top1_disagreements_within_numeric_error_envelope": all(
            value["all_top1_disagreements_within_numeric_error_envelope"] is True
            for value in phase_receipts
        ),
        "top1_exactness_is_diagnostic_only": True,
        "numeric_diagnostics_are_admission_authority": False,
        "exact_payload_lineage_is_admission_authority": True,
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _validate_cache_trajectory_geometry(
    tensors: Mapping[str, Any],
    record: Mapping[str, Any],
    *,
    final_layer_index: int,
    source_hidden_size: int,
    logit_rtol: float,
    logit_atol: float,
) -> tuple[Any, dict[str, Any]]:
    torch = _torch()
    prompt = tensors["input.input_ids"]
    mask = tensors["input.attention_mask"]
    forced = tensors["input.forced_decode_ids"]
    if (
        tuple(prompt.shape) != tuple(mask.shape)
        or prompt.ndim != 2
        or int(prompt.shape[0]) != 1
        or forced.ndim != 2
        or int(forced.shape[0]) != 1
        or int(forced.shape[1]) <= 0
        or not torch.equal(mask, torch.ones_like(mask))
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache trajectory is not one complete unpadded causal sequence."
        )
    capture = record.get("capture")
    if not isinstance(capture, Mapping) or capture.get("decode_steps") != int(
        forced.shape[1]
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache record and forced-decode trajectory geometry differ."
        )
    batch_index = record.get("batch_index")
    if isinstance(batch_index, bool) or not isinstance(batch_index, int):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache record has an invalid batch index."
        )
    _terminal_cache_capture_compatibility(
        capture,
        batch_index=batch_index,
        expected_decode_steps=int(forced.shape[1]),
    )
    verifications = capture.get("cached_full_prefix_verifications")
    if capture.get("decode_trace_mode") == CACHED_VERIFIED_TRACE_MODE and (
        not isinstance(verifications, list)
        or not verifications
        or verifications[0].get("prefix_length") != int(prompt.shape[1])
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cached prefill verification prefix is not bound to the raw prompt."
        )
    cached_full_prefix = _verify_cached_full_prefix_payload_equivalence(
        tensors,
        capture,
        batch_index=batch_index,
        logit_rtol=logit_rtol,
        logit_atol=logit_atol,
    )

    observed_decode = sorted(
        int(match.group(1))
        for name in record.get("tensors", {})
        for match in (_DECODE_FINAL_RESIDUAL.fullmatch(str(name)),)
        if match is not None and int(match.group(2)) == final_layer_index
    )
    expected_decode = list(range(int(forced.shape[1])))
    if observed_decode != expected_decode:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Final-layer decode endpoints are missing, duplicated, or reordered."
        )

    residual_rows = []
    phases = ("prefill",) + tuple(f"decode.{step:03d}" for step in expected_decode)
    for phase_index, phase in enumerate(phases):
        prefix = f"{phase}.layer.{final_layer_index:03d}."
        values = tuple(
            tensors[prefix + suffix]
            for suffix in (
                "mlp.input",
                "residual.post_operator",
                "residual.post_layer",
            )
        )
        if (
            any(value.ndim != 3 for value in values)
            or len({tuple(value.shape) for value in values}) != 1
            or int(values[0].shape[0]) != 1
            or int(values[0].shape[2]) != source_hidden_size
            or (phase_index > 0 and int(values[0].shape[1]) != 1)
            or (phase_index == 0 and int(values[0].shape[1]) < 1)
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache phase {phase!r} does not expose one aligned final "
                "basic endpoint row."
            )
        if phase_index > 0:
            step = phase_index - 1
            if not torch.equal(
                tensors[f"{phase}.forced_token_ids"],
                forced[:, step : step + 1],
            ):
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache phase {phase!r} forced token binding changed."
                )
        residual_rows.append(values[-1][:, -1, :].reshape(1, -1))
    return torch.cat(residual_rows, dim=0).contiguous(), cached_full_prefix


def _verify_parent_action_projection(
    tensors: Mapping[str, Any],
    parent_final_norm_rows: Any,
    bridge: StrictTokenizerBridgeArtifact,
    source_selected_tied_table: Any,
    *,
    decode_steps: int,
    source_lineage: Lfm2LongHorizonTerminalSourceLineage,
    batch_index: int,
    input_sha256: str,
    record_sha256: str,
    payload_binding_sha256: str,
) -> dict[str, Any]:
    """Bind cached actions to exact source lineage; score only diagnostically."""

    torch = _torch()
    profile = bridge.transport_profile
    mapping = tuple(profile.target_to_donor_row_indices)
    source = source_selected_tied_table
    if (
        not isinstance(source_lineage, Lfm2LongHorizonTerminalSourceLineage)
        or not source_lineage.verify_authentication()
        or source_lineage.document.get("bridge_artifact_sha256")
        != bridge.artifact_sha256
        or source_lineage.document.get("bridge_transport_profile_fingerprint")
        != bridge.profile_fingerprint
        or source_lineage.document.get("target_to_donor_row_indices_sha256")
        != _canonical_sha256(list(mapping))
        or source_lineage.document.get("mapped_table_bfloat16_sha256")
        != _tensor_sha256(source, "mapped_parent_tied_table")
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Parent action projection lacks exact authenticated source lineage."
        )
    if (
        isinstance(batch_index, bool)
        or not isinstance(batch_index, int)
        or batch_index < 0
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Parent action projection batch index is invalid."
        )
    input_sha256 = _digest(input_sha256, "parent action input SHA-256")
    record_sha256 = _digest(record_sha256, "parent action record SHA-256")
    payload_binding_sha256 = _digest(
        payload_binding_sha256,
        "parent action payload binding SHA-256",
    )
    if (
        not isinstance(source, torch.Tensor)
        or source.ndim != 2
        or source.dtype != torch.bfloat16
        or tuple(source.shape)
        != (profile.target_row_capacity, int(parent_final_norm_rows.shape[1]))
        or len(mapping) != profile.target_row_capacity
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "The authenticated source tied table does not implement the "
            "bridge's target-row action interface."
        )
    donor_rows = torch.tensor(mapping, dtype=torch.long)
    selected_rows = []
    phases = ("prefill",) + tuple(f"decode.{step:03d}" for step in range(decode_steps))
    for phase in phases:
        logits = tensors.get(f"{phase}.logits")
        if (
            not isinstance(logits, torch.Tensor)
            or logits.ndim != 3
            or int(logits.shape[0]) != 1
            or int(logits.shape[1]) < 1
            or int(logits.shape[2]) != profile.donor_row_capacity
            or not torch.is_floating_point(logits)
            or not bool(torch.isfinite(logits).all().item())
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cached parent phase {phase!r} has no authenticated full-vocabulary "
                "action row."
            )
        selected_rows.append(
            logits.detach()
            .to(device="cpu")[:, -1, :]
            .index_select(1, donor_rows)
            .reshape(1, -1)
        )
    cached = torch.cat(selected_rows, dim=0).contiguous()
    reconstructed = (
        parent_final_norm_rows.to(device="cpu", dtype=torch.float64)
        @ source.to(device="cpu", dtype=torch.float64).T
    ).contiguous()
    if tuple(cached.shape) != tuple(reconstructed.shape):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cached parent logits and reconstructed selected-row actions are not "
            "phase aligned."
        )
    cached64 = cached.to(torch.float64)
    difference = reconstructed - cached64
    if not bool(torch.isfinite(reconstructed).all().item()) or not bool(
        torch.isfinite(difference).all().item()
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Parent action projection produced non-finite diagnostic values."
        )
    reference_rms = float(cached64.square().mean().sqrt().item())
    relative_rmse = float(difference.square().mean().sqrt().item()) / max(
        reference_rms,
        torch.finfo(torch.float64).tiny,
    )
    top1 = cached64.argmax(dim=1)
    reconstructed_top1 = reconstructed.argmax(dim=1)
    agreements = top1 == reconstructed_top1
    row_error = difference.abs().amax(dim=1)
    row_index = torch.arange(int(cached64.shape[0]), dtype=torch.long)
    cached_gap = cached64[row_index, top1] - cached64[row_index, reconstructed_top1]
    reconstructed_gap = (
        reconstructed[row_index, reconstructed_top1] - reconstructed[row_index, top1]
    )
    tie_envelope = 2.0 * row_error + torch.finfo(torch.float64).eps
    tie_verified = agreements | (
        (cached_gap <= tie_envelope) & (reconstructed_gap <= tie_envelope)
    )
    if not math.isfinite(relative_rmse):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Parent action projection produced a non-finite relative-RMSE diagnostic."
        )
    body = {
        "method": "exact-source-lineage-bound-action-projection-v2",
        "source_lineage_sha256": source_lineage.authentication_sha256,
        "batch_index": batch_index,
        "input_sha256": input_sha256,
        "record_sha256": record_sha256,
        "payload_binding_sha256": payload_binding_sha256,
        "bridge_artifact_sha256": bridge.artifact_sha256,
        "bridge_transport_profile_fingerprint": bridge.profile_fingerprint,
        "phase_order": list(phases),
        "phase_count": len(phases),
        "target_to_donor_row_indices_sha256": _canonical_sha256(list(mapping)),
        "parent_final_norm_rows_sha256": _tensor_sha256(parent_final_norm_rows),
        "mapped_source_table_bfloat16_sha256": _tensor_sha256(source),
        "cached_selected_logits_sha256": _tensor_sha256(cached),
        "reconstructed_selected_logits_sha256": _tensor_sha256(reconstructed),
        "cached_selected_top1_sha256": _tensor_sha256(top1),
        "reconstructed_selected_top1_sha256": _tensor_sha256(reconstructed_top1),
        "exact_selected_top1_agreement": bool(agreements.all().item()),
        "exact_selected_top1_agreement_count": int(agreements.sum().item()),
        "numeric_tie_verified_disagreement_count": int(
            ((~agreements) & tie_verified).sum().item()
        ),
        "all_numeric_ties_within_reconstruction_envelope": bool(
            tie_verified.all().item()
        ),
        "relative_rmse": relative_rmse,
        "relative_rmse_diagnostic_only": True,
        "top1_and_tie_diagnostics_only": True,
        "numeric_admission_threshold_applied": False,
        "numeric_projection_error_can_reject_or_rollback": False,
        "exact_composite_lineage_required_for_compiler_use": True,
        "numeric_token_id_equality_required": False,
    }
    return {**body, "authentication_sha256": _canonical_sha256(body)}


def _collect_cached_trajectories(
    cache: Lfm2CircuitTraceCache,
    bridge: StrictTokenizerBridgeArtifact,
    inverse: tuple[int, ...],
    parent_final_norm: Lfm2SealedParentFinalRmsNorm,
    source_selected_tied_table: Any,
    source_lineage: Lfm2LongHorizonTerminalSourceLineage,
    split_plan: Lfm2LongHorizonTrajectorySplitPlan,
    authenticated_session: Any | None = None,
) -> tuple[
    tuple[_CachedTrajectory, ...],
    Lfm2StrictTokenizerBridgeTraceAdapter,
    tuple[dict[str, Any], ...],
    dict[str, Any],
]:
    manifest = cache.manifest
    topology = manifest.get("layer_topology", {}).get("layers")
    if not isinstance(topology, list) or not topology:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache has no authenticated LFM2 layer topology."
        )
    final_layer_index = len(topology) - 1
    records: list[Lfm2TargetTokenizedRecord] = []
    cached: list[_CachedTrajectory] = []
    parent_batches: list[dict[str, Any]] = []
    payload_receipts: list[dict[str, Any]] = []

    session_context = (
        cache.selective_authenticated_session()
        if authenticated_session is None
        else nullcontext(authenticated_session)
    )
    with session_context as session:
        references = session.batch_references
        if len(references) != cache.batch_count:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Authenticated cache batch references are incomplete."
            )
        for reference in references:
            record = reference.record
            capture = record.get("capture")
            if not isinstance(capture, Mapping):
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {reference.index} has no capture record."
                )
            decode_steps = capture.get("decode_steps")
            if (
                isinstance(decode_steps, bool)
                or not isinstance(decode_steps, int)
                or decode_steps <= 0
            ):
                raise Lfm2LongHorizonTerminalRefoldError(
                    f"Cache batch {reference.index} has no forced horizon."
                )
            names = _cache_tensor_names(
                reference,
                final_layer_index=final_layer_index,
                decode_steps=decode_steps,
                decode_trace_mode=str(capture.get("decode_trace_mode")),
            )
            payload = session.load_selected_tensors(reference.index, names)
            try:
                tensors = payload.tensors
                residual, cached_full_prefix = _validate_cache_trajectory_geometry(
                    tensors,
                    record,
                    final_layer_index=final_layer_index,
                    source_hidden_size=parent_final_norm.source_hidden_size,
                    logit_rtol=float(manifest["capture"]["logit_rtol"]),
                    logit_atol=float(manifest["capture"]["logit_atol"]),
                )
                parent_rows, norm_endpoint = _verify_parent_final_norm_endpoint(
                    tensors,
                    residual,
                    parent_final_norm,
                    decode_steps=decode_steps,
                )
                parent_action = _verify_parent_action_projection(
                    tensors,
                    parent_rows,
                    bridge,
                    source_selected_tied_table,
                    decode_steps=decode_steps,
                    source_lineage=source_lineage,
                    batch_index=reference.index,
                    input_sha256=reference.input_sha256,
                    record_sha256=reference.record_sha256,
                    payload_binding_sha256=payload.selection_sha256,
                )
                target_prompt = _map_donor_ids_to_unique_target(
                    tensors["input.input_ids"],
                    inverse,
                    name="prompt",
                )
                target_forced = _map_donor_ids_to_unique_target(
                    tensors["input.forced_decode_ids"],
                    inverse,
                    name="forced-decode",
                )
                position_ids = tensors.get("input.position_ids")
                target_record = Lfm2TargetTokenizedRecord(
                    record_id=f"cache-batch-{reference.index:06d}",
                    split=split_plan.assignments[reference.index],
                    input_ids=target_prompt,
                    attention_mask=tensors["input.attention_mask"],
                    forced_decode_ids=target_forced,
                    position_ids=position_ids,
                )
                records.append(target_record)
                cached.append(
                    _CachedTrajectory(
                        batch_index=reference.index,
                        input_sha256=reference.input_sha256,
                        split=split_plan.assignments[reference.index],
                        target_record=target_record,
                        semantic_bridge=None,
                        parent_final_norm_rows=parent_rows,
                        horizon_indices=tuple(range(decode_steps + 1)),
                        selected_payload_sha256=payload.selection_sha256,
                        cached_full_prefix_payload=MappingProxyType(cached_full_prefix),
                        parent_final_norm_endpoint=MappingProxyType(norm_endpoint),
                        parent_action_projection=MappingProxyType(parent_action),
                    )
                )
                parent_batch = {
                    "input_ids": tensors["input.input_ids"].clone(),
                    "attention_mask": tensors["input.attention_mask"].clone(),
                    "forced_decode_ids": tensors["input.forced_decode_ids"].clone(),
                }
                if position_ids is not None:
                    parent_batch["position_ids"] = position_ids.clone()
                parent_batches.append(parent_batch)
                payload_receipts.append(
                    {
                        "batch_index": reference.index,
                        "input_sha256": reference.input_sha256,
                        "selection_sha256": payload.selection_sha256,
                        "selected_tensor_count": len(names),
                        "selected_logical_bytes": payload.logical_bytes,
                    }
                )
            finally:
                session.release_selected_tensors(payload)
        session.verify()
        cache_receipt = session.as_dict()

    adapter = build_lfm2_strict_tokenizer_bridge_trace_adapter(
        bridge,
        tuple(records),
        expected_artifact_sha256=bridge.artifact_sha256,
    )
    pair_receipts = []
    for trajectory, parent_batch, aligned in zip(
        cached,
        parent_batches,
        adapter.records,
        strict=True,
    ):
        if (
            aligned.ordinal != trajectory.batch_index
            or aligned.donor_cache_input_sha256 != trajectory.input_sha256
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Tokenizer adapter does not bind to the authenticated cache input."
            )
        paired = authenticate_lfm2_bridge_input_pair(
            adapter,
            record_id=aligned.record_id,
            parent_cache_batch=parent_batch,
            child_replay_batch=aligned.as_child_replay_batch(),
        )
        pair_receipts.append(paired.to_dict())
    adapter.verify()
    return (
        tuple(cached),
        adapter,
        tuple(pair_receipts),
        {
            "session": cache_receipt,
            "selected_payloads": payload_receipts,
        },
    )


def _collect_cached_semantic_trajectories(
    cache: Lfm2CircuitTraceCache,
    bridge: StrictTokenizerBridgeArtifact,
    donor_tokenizer: Any,
    target_tokenizer: Any,
    parent_final_norm: Lfm2SealedParentFinalRmsNorm,
    source_selected_tied_table: Any,
    source_lineage: Lfm2LongHorizonTerminalSourceLineage,
    split_plan: Lfm2LongHorizonTrajectorySplitPlan,
    authenticated_session: Any | None = None,
) -> tuple[
    tuple[_CachedTrajectory, ...],
    tuple[Lfm2SemanticSpanPhaseBridge, ...],
    dict[str, Any],
]:
    """Authenticate complete cache batches and retokenize every parent phase."""

    try:
        bridge.verify_live_tokenizers(donor_tokenizer, target_tokenizer)
    except StrictTokenizerBridgeError as exc:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Live semantic tokenizers differ from the sealed child bridge."
        ) from exc
    manifest = cache.manifest
    topology = manifest.get("layer_topology", {}).get("layers")
    if not isinstance(topology, list) or not topology:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Cache has no authenticated LFM2 layer topology."
        )
    final_layer_index = len(topology) - 1
    semantic_bridges: list[Lfm2SemanticSpanPhaseBridge] = []
    cached: list[_CachedTrajectory] = []
    payload_receipts: list[dict[str, Any]] = []
    session = (
        cache.authenticated_session()
        if authenticated_session is None
        else authenticated_session
    )

    def selected_batches() -> Any:
        if authenticated_session is None:
            for batch in session.iter_batches():
                yield batch, None
            return
        references = session.batch_references
        if len(references) != cache.batch_count or tuple(
            value.index for value in references
        ) != tuple(range(cache.batch_count)):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Selective semantic cache references are incomplete or reordered."
            )
        for reference in references:
            payload = session.load_selected_tensors(
                reference.index,
                reference.ordered_tensor_names,
            )
            try:
                tensors = MappingProxyType(dict(payload.tensors))
                batch = Lfm2CircuitTraceBatch(
                    index=reference.index,
                    input_sha256=reference.input_sha256,
                    _tensors=tensors,
                    _record=MappingProxyType(reference.record),
                )
                receipt = {
                    "selection_sha256": payload.selection_sha256,
                    "selected_tensor_count": len(reference.ordered_tensor_names),
                    "selected_logical_bytes": payload.logical_bytes,
                }
            finally:
                session.release_selected_tensors(payload)
            yield batch, receipt

    for batch, selected_receipt in selected_batches():
        record = batch.record
        capture = record.get("capture")
        decode_steps = (
            None if not isinstance(capture, Mapping) else capture.get("decode_steps")
        )
        if (
            isinstance(decode_steps, bool)
            or not isinstance(decode_steps, int)
            or decode_steps <= 0
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch.index} has no forced horizon."
            )
        tensors = batch.tensors
        residual, cached_full_prefix = _validate_cache_trajectory_geometry(
            tensors,
            record,
            final_layer_index=final_layer_index,
            source_hidden_size=parent_final_norm.source_hidden_size,
            logit_rtol=float(manifest["capture"]["logit_rtol"]),
            logit_atol=float(manifest["capture"]["logit_atol"]),
        )
        parent_rows, norm_endpoint = _verify_parent_final_norm_endpoint(
            tensors,
            residual,
            parent_final_norm,
            decode_steps=decode_steps,
        )
        parent_action = _verify_parent_action_projection(
            tensors,
            parent_rows,
            bridge,
            source_selected_tied_table,
            decode_steps=decode_steps,
            source_lineage=source_lineage,
            batch_index=batch.index,
            input_sha256=batch.input_sha256,
            record_sha256=record["record_sha256"],
            payload_binding_sha256=(
                record["record_sha256"]
                if selected_receipt is None
                else selected_receipt["selection_sha256"]
            ),
        )
        try:
            semantic = build_lfm2_semantic_span_phase_bridge(
                batch,
                manifest,
                donor_tokenizer,
                target_tokenizer,
                expected_source_cache_key=cache.cache_key,
                expected_source_manifest_sha256=manifest["manifest_sha256"],
                expected_source_input_sha256=batch.input_sha256,
                expected_donor_tokenizer_fingerprint=(
                    bridge.donor_tokenizer_semantics_sha256
                ),
                expected_target_tokenizer_fingerprint=(
                    bridge.target_tokenizer_semantics_sha256
                ),
            )
        except Lfm2SemanticSpanPhaseBridgeError as exc:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Cache batch {batch.index} failed semantic-span authentication."
            ) from exc
        if (
            semantic.source_batch_index != batch.index
            or semantic.source_input_sha256 != batch.input_sha256
            or len(semantic.phases) != decode_steps + 1
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Semantic phase endpoints differ from the authenticated parent "
                "trajectory."
            )
        semantic_bridges.append(semantic)
        cached.append(
            _CachedTrajectory(
                batch_index=batch.index,
                input_sha256=batch.input_sha256,
                split=split_plan.assignments[batch.index],
                target_record=None,
                semantic_bridge=semantic,
                parent_final_norm_rows=parent_rows,
                horizon_indices=tuple(range(decode_steps + 1)),
                selected_payload_sha256=semantic.source_record_sha256,
                cached_full_prefix_payload=MappingProxyType(cached_full_prefix),
                parent_final_norm_endpoint=MappingProxyType(norm_endpoint),
                parent_action_projection=MappingProxyType(parent_action),
            )
        )
        payload_receipts.append(
            {
                "batch_index": batch.index,
                "input_sha256": batch.input_sha256,
                "record_sha256": semantic.source_record_sha256,
                "semantic_bridge_sha256": semantic.bridge_sha256,
                "authenticated_tensor_count": int(record["tensor_count"]),
                "authenticated_logical_bytes": int(capture["capture_bytes"]),
                "selective_payload": selected_receipt,
            }
        )
    session.verify()
    return (
        tuple(cached),
        tuple(semantic_bridges),
        {
            "session": session.as_dict(),
            "selected_payloads": payload_receipts,
        },
    )


@dataclass(frozen=True, slots=True)
class Lfm2LongHorizonTerminalCompositeLineage:
    """Compiler binding over source, cache session, and exact batch payloads."""

    document: Mapping[str, Any]

    def __post_init__(self) -> None:
        document = _owned_canonical_document(
            self.document,
            name="terminal composite lineage",
        )
        body = dict(document)
        supplied = body.pop("authentication_sha256", None)
        compiler_inputs = body.get("compiler_inputs")
        if (
            supplied != _canonical_sha256(body)
            or body.get("schema") != LFM2_LONG_HORIZON_TERMINAL_COMPOSITE_LINEAGE_SCHEMA
            or not isinstance(compiler_inputs, Mapping)
            or body.get("compiler_binding_sha256") != _canonical_sha256(compiler_inputs)
            or body.get("numeric_projection_diagnostics_are_admission_authority")
            is not False
            or body.get("exact_lineage_is_compiler_admission_authority") is not True
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal composite lineage authentication is invalid."
            )
        _digest(
            compiler_inputs.get("source_lineage_sha256"),
            "terminal composite source lineage SHA-256",
        )
        _digest(
            compiler_inputs.get("cache_session_sha256"),
            "terminal composite cache session SHA-256",
        )
        _digest(
            body.get("compiler_binding_sha256"),
            "terminal composite compiler binding SHA-256",
        )
        object.__setattr__(
            self,
            "document",
            MappingProxyType({**body, "authentication_sha256": supplied}),
        )

    @property
    def authentication_sha256(self) -> str:
        return str(self.document["authentication_sha256"])

    @property
    def compiler_binding_sha256(self) -> str:
        return str(self.document["compiler_binding_sha256"])

    def verify_authentication(self) -> bool:
        body = dict(self.document)
        supplied = body.pop("authentication_sha256", None)
        compiler_inputs = body.get("compiler_inputs")
        return bool(
            supplied == _canonical_sha256(body)
            and isinstance(compiler_inputs, Mapping)
            and body.get("compiler_binding_sha256")
            == _canonical_sha256(compiler_inputs)
        )

    def as_dict(self) -> dict[str, Any]:
        return _owned_canonical_document(
            self.document,
            name="terminal composite lineage",
        )


def authenticate_lfm2_long_horizon_terminal_composite_lineage(
    value: Mapping[str, Any],
    *,
    expected_source_lineage_sha256: str | None = None,
) -> Lfm2LongHorizonTerminalCompositeLineage:
    lineage = Lfm2LongHorizonTerminalCompositeLineage(value)
    compiler_inputs = lineage.document["compiler_inputs"]
    source_document = compiler_inputs.get("source_lineage")
    if not isinstance(source_document, Mapping):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal composite lineage omitted its typed source lineage."
        )
    source = Lfm2LongHorizonTerminalSourceLineage(source_document)
    if compiler_inputs.get("source_lineage_sha256") != source.authentication_sha256 or (
        expected_source_lineage_sha256 is not None
        and source.authentication_sha256
        != _digest(
            expected_source_lineage_sha256,
            "expected terminal source lineage SHA-256",
        )
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal composite and source lineage bindings differ."
        )
    return lineage


def _build_terminal_composite_lineage(
    *,
    cache: Lfm2CircuitTraceCache,
    source_lineage: Lfm2LongHorizonTerminalSourceLineage,
    compatibility: Mapping[str, Any],
    payload_binding: Mapping[str, Any],
    cache_receipt: Mapping[str, Any],
    cached: Sequence[_CachedTrajectory],
) -> Lfm2LongHorizonTerminalCompositeLineage:
    if (
        not isinstance(source_lineage, Lfm2LongHorizonTerminalSourceLineage)
        or not source_lineage.verify_authentication()
        or source_lineage.document.get("cache_key") != cache.cache_key
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal composite compiler received invalid source lineage."
        )
    compatibility_document = _owned_canonical_document(
        compatibility,
        name="terminal cache compatibility",
    )
    compatibility_body = dict(compatibility_document)
    compatibility_sha256 = compatibility_body.pop("authentication_sha256", None)
    binding_document = _owned_canonical_document(
        payload_binding,
        name="terminal cache payload binding",
    )
    binding_body = dict(binding_document)
    binding_sha256 = binding_body.pop("authentication_sha256", None)
    receipt = _owned_canonical_document(
        cache_receipt,
        name="terminal cache receipt",
    )
    session = receipt.get("session")
    payloads = receipt.get("selected_payloads")
    if not isinstance(session, Mapping) or not isinstance(payloads, list):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal composite lineage lacks cache session or payload receipts."
        )
    session_body = dict(session)
    session_sha256 = session_body.pop("session_sha256", None)
    ordered_batches = session.get(
        "ordered_authenticated_batches",
        session.get("ordered_verified_batches"),
    )
    if (
        compatibility_sha256 != _canonical_sha256(compatibility_body)
        or binding_sha256 != _canonical_sha256(binding_body)
        or session_sha256 != _canonical_sha256(session_body)
        or not isinstance(ordered_batches, list)
        or len(ordered_batches) != len(cached)
        or len(payloads) != len(cached)
        or session.get("cache_key") != cache.cache_key
        or session.get("manifest_sha256") != cache.manifest.get("manifest_sha256")
        or binding_document.get("compatibility_authentication_sha256")
        != compatibility_sha256
        or binding_document.get("payload_session_sha256") != session_sha256
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal composite cache/session binding is invalid."
        )
    projections: list[dict[str, Any]] = []
    projection_sha256: list[str] = []
    for expected_index, (trajectory, batch, payload) in enumerate(
        zip(cached, ordered_batches, payloads, strict=True)
    ):
        if not isinstance(batch, Mapping) or not isinstance(payload, Mapping):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal composite batch or payload receipt is malformed."
            )
        projection = _owned_canonical_document(
            trajectory.parent_action_projection,
            name=f"parent action projection {expected_index}",
        )
        projection_body = dict(projection)
        projection_authentication = projection_body.pop(
            "authentication_sha256",
            None,
        )
        selective = payload.get("selective_payload")
        expected_payload_binding = payload.get("selection_sha256")
        if expected_payload_binding is None and isinstance(selective, Mapping):
            expected_payload_binding = selective.get("selection_sha256")
        if expected_payload_binding is None:
            expected_payload_binding = payload.get("record_sha256")
        if (
            projection_authentication != _canonical_sha256(projection_body)
            or projection.get("source_lineage_sha256")
            != source_lineage.authentication_sha256
            or projection.get("batch_index") != expected_index
            or trajectory.batch_index != expected_index
            or batch.get("batch_index") != expected_index
            or projection.get("input_sha256") != batch.get("input_sha256")
            or projection.get("record_sha256") != batch.get("record_sha256")
            or projection.get("payload_binding_sha256") != expected_payload_binding
            or projection.get("numeric_admission_threshold_applied") is not False
            or projection.get("numeric_projection_error_can_reject_or_rollback")
            is not False
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Terminal parent-action projection differs from its exact batch "
                "or source lineage."
            )
        projections.append(projection)
        projection_sha256.append(projection_authentication)
    compiler_inputs = {
        "source_lineage": source_lineage.as_dict(),
        "source_lineage_sha256": source_lineage.authentication_sha256,
        "cache_key": cache.cache_key,
        "cache_manifest_sha256": cache.manifest["manifest_sha256"],
        "cache_parent_fingerprint": cache.parent_fingerprint,
        "cache_layer_topology_fingerprint": cache.layer_topology_fingerprint,
        "cache_compatibility_sha256": compatibility_sha256,
        "cache_payload_binding_sha256": binding_sha256,
        "cache_session_sha256": session_sha256,
        "ordered_authenticated_batches": ordered_batches,
        "selected_or_full_payload_receipts": payloads,
        "parent_action_projection_sha256": projection_sha256,
        "parent_action_projections": projections,
    }
    body = {
        "schema": LFM2_LONG_HORIZON_TERMINAL_COMPOSITE_LINEAGE_SCHEMA,
        "compiler_inputs": compiler_inputs,
        "compiler_binding_sha256": _canonical_sha256(compiler_inputs),
        "exact_cache_bridge_parent_source_interface_binding": True,
        "numeric_projection_diagnostics_are_admission_authority": False,
        "exact_lineage_is_compiler_admission_authority": True,
        "operation_audit": {
            "parent_model_forward_calls": 0,
            "parent_cache_generation_calls": 0,
            "training_steps": 0,
        },
    }
    return Lfm2LongHorizonTerminalCompositeLineage(
        {**body, "authentication_sha256": _canonical_sha256(body)}
    )


def _layer_runtime(layer: Any) -> tuple[Any, Any]:
    torch = _torch()
    parameters = tuple(layer.parameters())
    if (
        not parameters
        or any(
            parameter.device.type == "meta"
            or parameter.dtype != torch.bfloat16
            or not torch.is_floating_point(parameter)
            for parameter in parameters
        )
        or len({parameter.device for parameter in parameters}) != 1
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Every target macrocell must use one materialized BF16 device."
        )
    return parameters[0].device, parameters[0].dtype


def _additive_causal_mask(attention_mask: Any, residual: Any) -> Any:
    torch = _torch()
    sequence = int(attention_mask.shape[1])
    allowed = torch.tril(
        torch.ones(
            (sequence, sequence),
            device=residual.device,
            dtype=torch.bool,
        )
    )
    active_keys = attention_mask.to(
        device=residual.device,
        dtype=torch.bool,
    )[:, None, None, :]
    allowed = allowed[None, None, :, :] & active_keys
    minimum = torch.finfo(residual.dtype).min
    return torch.where(
        allowed,
        torch.zeros((), device=residual.device, dtype=residual.dtype),
        torch.full((), minimum, device=residual.device, dtype=residual.dtype),
    )


def _full_target_trajectory(record: Any) -> tuple[Any, Any, Any, int]:
    torch = _torch()
    prompt = record.target_input_ids
    forced = record.target_forced_decode_ids
    prompt_mask = record.attention_mask
    if not torch.equal(prompt_mask, torch.ones_like(prompt_mask)):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Long-horizon child replay currently requires the cache's unpadded "
            "one-sequence geometry."
        )
    full_ids = torch.cat((prompt, forced), dim=1).to(torch.long).contiguous()
    full_mask = torch.ones_like(full_ids, dtype=torch.long)
    positions = record.position_ids
    if positions is None:
        prompt_positions = (
            torch.arange(int(prompt.shape[1]), dtype=torch.long)
            .unsqueeze(0)
            .expand(int(prompt.shape[0]), -1)
        )
    else:
        prompt_positions = positions.to(torch.long)
    start = prompt_positions[:, -1:] + 1
    offsets = torch.arange(int(forced.shape[1]), dtype=torch.long).unsqueeze(0)
    full_positions = torch.cat(
        (prompt_positions, start + offsets),
        dim=1,
    ).contiguous()
    return full_ids, full_mask, full_positions, int(prompt.shape[1])


def _replay_child_sequence_once(
    target_model: Any,
    layers: tuple[Any, ...],
    full_ids: Any,
    full_mask: Any,
    positions: Any,
    row_indices: Sequence[int],
    *,
    replay_strategy: str,
) -> _ChildTrajectoryRows:
    torch = _torch()
    if (
        not isinstance(full_ids, torch.Tensor)
        or not isinstance(full_mask, torch.Tensor)
        or not isinstance(positions, torch.Tensor)
        or full_ids.ndim != 2
        or tuple(full_mask.shape) != tuple(full_ids.shape)
        or tuple(positions.shape) != tuple(full_ids.shape)
        or int(full_ids.shape[0]) != 1
        or int(full_ids.shape[1]) <= 0
        or not torch.equal(full_mask, torch.ones_like(full_mask))
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Target-native replay requires one complete unpadded token sequence."
        )
    selected_rows = tuple(int(value) for value in row_indices)
    if not selected_rows or any(
        value < 0 or value >= int(full_ids.shape[1]) for value in selected_rows
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Target-native replay endpoint rows lie outside the token sequence."
        )
    embedding = getattr(target_model.get_input_embeddings(), "weight", None)
    if not isinstance(embedding, torch.nn.Parameter):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Target input embedding is not materialized."
        )
    if bool((full_ids >= int(embedding.shape[0])).any().item()):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Mapped target trajectory exceeds the installed tied table."
        )
    with torch.no_grad():
        ids = full_ids.to(device=embedding.device)
        residual = (
            embedding.index_select(0, ids.reshape(-1))
            .reshape(
                int(full_ids.shape[0]),
                int(full_ids.shape[1]),
                int(embedding.shape[1]),
            )
            .detach()
        )
    replay_sha = []
    final_mlp = None
    final_pre_mlp = None
    rope_calls = 0
    for layer_index, layer in enumerate(layers):
        device, dtype = _layer_runtime(layer)
        residual = residual.to(device=device, dtype=dtype, non_blocking=False)
        if bool(getattr(layer, "is_attention_layer", False)):
            position_embeddings = _rope_from_target(
                target_model,
                residual,
                positions,
            )
            causal_mask = _additive_causal_mask(full_mask, residual)
            replay = replay_lfm2_cpcf_macrocell(
                layer,
                residual,
                position_embeddings=position_embeddings,
                additive_causal_mask=causal_mask,
            )
            rope_calls += 1
        else:
            replay = replay_lfm2_cpcf_macrocell(
                layer,
                residual,
                padding_mask=full_mask.to(device=device, dtype=dtype),
            )
        replay_sha.append(replay.replay_sha256)
        if layer_index == len(layers) - 1:
            index = torch.tensor(
                selected_rows,
                dtype=torch.long,
            )
            final_mlp = replay.mlp_input.index_select(1, index)[0]
            final_pre_mlp = replay.post_operator_residual.index_select(
                1,
                index,
            )[0]
        residual = replay.post_layer_residual
    if final_mlp is None or final_pre_mlp is None:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Complete child macrocell replay produced no final-layer endpoints."
        )
    if (
        final_mlp.dtype != torch.bfloat16
        or final_pre_mlp.dtype != torch.bfloat16
        or tuple(final_mlp.shape) != tuple(final_pre_mlp.shape)
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Child final-layer endpoint rows are not aligned exact BF16 tensors."
        )
    return _ChildTrajectoryRows(
        mlp_input=final_mlp.contiguous().clone(),
        pre_mlp_residual=final_pre_mlp.contiguous().clone(),
        macrocell_replay_sha256=tuple(replay_sha),
        attention_rope_materializations=rope_calls,
        replay_strategy=replay_strategy,
    )


def _replay_child_trajectory_once(
    target_model: Any,
    layers: tuple[Any, ...],
    aligned_record: Any,
) -> _ChildTrajectoryRows:
    full_ids, full_mask, positions, prompt_width = _full_target_trajectory(
        aligned_record
    )
    return _replay_child_sequence_once(
        target_model,
        layers,
        full_ids,
        full_mask,
        positions,
        (prompt_width - 1, *range(prompt_width, int(full_ids.shape[1]))),
        replay_strategy="strict-one-row-single-causal-trajectory-v1",
    )


def _is_token_prefix(prefix: tuple[int, ...], value: tuple[int, ...]) -> bool:
    return len(prefix) <= len(value) and value[: len(prefix)] == prefix


def _replay_child_semantic_span_once(
    target_model: Any,
    layers: tuple[Any, ...],
    semantic: Lfm2SemanticSpanPhaseBridge,
) -> _ChildTrajectoryRows:
    """Replay each maximal target-native branch once and collect phase endpoints."""

    torch = _torch()
    phase_sequences = tuple(
        phase.target_full_prefix_token_ids for phase in semantic.phases
    )
    unique_sequences = tuple(dict.fromkeys(phase_sequences))
    maxima = tuple(
        sequence
        for sequence in unique_sequences
        if not any(
            len(other) > len(sequence) and _is_token_prefix(sequence, other)
            for other in unique_sequences
        )
    )
    if not maxima:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Semantic phase schedule has no complete target-native trajectory."
        )
    assignments: list[int] = []
    for sequence in phase_sequences:
        matches = tuple(
            index
            for index, maximum in enumerate(maxima)
            if _is_token_prefix(sequence, maximum)
        )
        if not matches:
            raise Lfm2LongHorizonTerminalRefoldError(
                "Semantic phase endpoint is not represented by a complete "
                "target-native trajectory."
            )
        assignments.append(matches[0])

    mlp_rows: list[Any | None] = [None] * len(semantic.phases)
    residual_rows: list[Any | None] = [None] * len(semantic.phases)
    replay_sha: list[str] = []
    rope_calls = 0
    branch_phase_sha: list[tuple[str, ...]] = []
    for branch_index, sequence in enumerate(maxima):
        phase_indices = tuple(
            index
            for index, assignment in enumerate(assignments)
            if assignment == branch_index
        )
        ids = torch.tensor([sequence], dtype=torch.long)
        mask = torch.ones_like(ids, dtype=torch.long)
        positions = torch.arange(
            semantic.target_position_origin,
            semantic.target_position_origin + len(sequence),
            dtype=torch.long,
        ).unsqueeze(0)
        replay = _replay_child_sequence_once(
            target_model,
            layers,
            ids,
            mask,
            positions,
            tuple(len(phase_sequences[index]) - 1 for index in phase_indices),
            replay_strategy="semantic-maximal-target-prefix-branch-v1",
        )
        replay_sha.extend(replay.macrocell_replay_sha256)
        rope_calls += replay.attention_rope_materializations
        branch_phase_sha.append(
            tuple(semantic.phases[index].phase_sha256 for index in phase_indices)
        )
        for row, phase_index in enumerate(phase_indices):
            mlp_rows[phase_index] = replay.mlp_input[row : row + 1]
            residual_rows[phase_index] = replay.pre_mlp_residual[row : row + 1]
    if any(value is None for value in (*mlp_rows, *residual_rows)):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Semantic target-native replay omitted a parent phase endpoint."
        )
    return _ChildTrajectoryRows(
        mlp_input=torch.cat(tuple(mlp_rows), dim=0),
        pre_mlp_residual=torch.cat(tuple(residual_rows), dim=0),
        macrocell_replay_sha256=tuple(replay_sha),
        attention_rope_materializations=rope_calls,
        embedding_seed_lookup_calls=len(maxima),
        full_prefix_replay_calls=len(maxima),
        replay_strategy="semantic-maximal-target-prefix-branch-cover-v1",
        replay_branch_phase_sha256=tuple(branch_phase_sha),
    )


def _build_split_evidence(
    cached: tuple[_CachedTrajectory, ...],
    adapter: Lfm2StrictTokenizerBridgeTraceAdapter | None,
    target_model: Any,
    layers: tuple[Any, ...],
) -> tuple[
    tuple[Lfm2CpcfTerminalActionEvidence, ...],
    dict[str, tuple[int, ...]],
    tuple[dict[str, Any], ...],
    int,
]:
    torch = _torch()
    rows: dict[str, list[dict[str, Any]]] = {split: [] for split in _SPLITS}
    replay_receipts = []
    rope_calls = 0
    for trajectory in cached:
        if trajectory.target_record is not None:
            if adapter is None or trajectory.semantic_bridge is not None:
                raise Lfm2LongHorizonTerminalRefoldError(
                    "Strict target trajectory lost its authenticated adapter."
                )
            aligned = adapter.records[trajectory.batch_index]
            child = _replay_child_trajectory_once(target_model, layers, aligned)
            record_id = aligned.record_id
            semantic_sha256 = None
        else:
            semantic = trajectory.semantic_bridge
            if semantic is None or adapter is not None:
                raise Lfm2LongHorizonTerminalRefoldError(
                    "Semantic target trajectory has an ambiguous replay adapter."
                )
            child = _replay_child_semantic_span_once(
                target_model,
                layers,
                semantic,
            )
            record_id = f"semantic-cache-batch-{trajectory.batch_index:06d}"
            semantic_sha256 = semantic.bridge_sha256
        rope_calls += child.attention_rope_materializations
        expected_rows = len(trajectory.horizon_indices)
        if (
            int(child.mlp_input.shape[0]) != expected_rows
            or int(trajectory.parent_final_norm_rows.shape[0]) != expected_rows
        ):
            raise Lfm2LongHorizonTerminalRefoldError(
                "Parent and child complete-trajectory terminal row counts differ."
            )
        row_ids = tuple(
            f"{trajectory.input_sha256}:batch-{trajectory.batch_index:06d}:"
            f"horizon-{horizon:05d}"
            for horizon in trajectory.horizon_indices
        )
        rows[trajectory.split].append(
            {
                "row_ids": row_ids,
                "horizons": trajectory.horizon_indices,
                "mlp_input": child.mlp_input,
                "pre_mlp_residual": child.pre_mlp_residual,
                "parent_final_norm_output": (trajectory.parent_final_norm_rows),
            }
        )
        replay_receipts.append(
            {
                "batch_index": trajectory.batch_index,
                "record_id": record_id,
                "split": trajectory.split,
                "trajectory_rows": expected_rows,
                "horizon_minimum": min(trajectory.horizon_indices),
                "horizon_maximum": max(trajectory.horizon_indices),
                "embedding_seed_lookup_calls": child.embedding_seed_lookup_calls,
                "full_prefix_replay_calls": child.full_prefix_replay_calls,
                "macrocell_replay_calls": len(child.macrocell_replay_sha256),
                "attention_rope_materializations": (
                    child.attention_rope_materializations
                ),
                "replay_strategy": child.replay_strategy,
                "semantic_bridge_sha256": semantic_sha256,
                "replay_branch_phase_sha256": [
                    list(value) for value in child.replay_branch_phase_sha256
                ],
                "parent_action_projection_sha256": (
                    trajectory.parent_action_projection["authentication_sha256"]
                ),
                "parent_final_norm_endpoint_sha256": (
                    trajectory.parent_final_norm_endpoint["authentication_sha256"]
                ),
                "macrocell_replay_sha256": list(child.macrocell_replay_sha256),
            }
        )

    evidence = []
    horizons_by_split: dict[str, tuple[int, ...]] = {}
    for split in _SPLITS:
        trajectories = rows[split]
        if not trajectories:
            raise Lfm2LongHorizonTerminalRefoldError(
                f"Held-out split {split!r} has no complete trajectory."
            )
        row_ids = tuple(
            row_id for trajectory in trajectories for row_id in trajectory["row_ids"]
        )
        horizons = tuple(
            horizon for trajectory in trajectories for horizon in trajectory["horizons"]
        )
        weights = torch.cat(
            tuple(
                torch.full(
                    (len(trajectory["row_ids"]),),
                    1.0 / (len(trajectories) * len(trajectory["row_ids"])),
                    dtype=torch.float64,
                )
                for trajectory in trajectories
            )
        )
        bank = Lfm2CpcfTerminalActionEvidence(
            split=split,
            row_ids=row_ids,
            mlp_input=torch.cat(
                tuple(value["mlp_input"] for value in trajectories),
                dim=0,
            ),
            pre_mlp_residual=torch.cat(
                tuple(value["pre_mlp_residual"] for value in trajectories),
                dim=0,
            ),
            parent_final_norm_output=torch.cat(
                tuple(value["parent_final_norm_output"] for value in trajectories),
                dim=0,
            ),
            sample_weights=weights,
        )
        evidence.append(bank)
        horizons_by_split[split] = horizons
    return tuple(evidence), horizons_by_split, tuple(replay_receipts), rope_calls


def _evidence_subset(
    evidence: Lfm2CpcfTerminalActionEvidence,
    indices: Sequence[int],
) -> Lfm2CpcfTerminalActionEvidence:
    torch = _torch()
    index = torch.tensor(tuple(indices), dtype=torch.long)
    return Lfm2CpcfTerminalActionEvidence(
        split=evidence.split,
        row_ids=tuple(evidence.row_ids[value] for value in indices),
        mlp_input=evidence.mlp_input.index_select(0, index),
        pre_mlp_residual=evidence.pre_mlp_residual.index_select(0, index),
        parent_final_norm_output=evidence.parent_final_norm_output.index_select(
            0,
            index,
        ),
        sample_weights=evidence.sample_weights.index_select(0, index),
    )


def _combined_held_out_evidence(
    evidence: Mapping[str, Lfm2CpcfTerminalActionEvidence],
    horizons: Mapping[str, tuple[int, ...]],
) -> tuple[Lfm2CpcfTerminalActionEvidence, tuple[int, ...]]:
    torch = _torch()
    selected = (evidence["selection"], evidence["validation"])
    return (
        Lfm2CpcfTerminalActionEvidence(
            split="validation",
            row_ids=tuple(row for bank in selected for row in bank.row_ids),
            mlp_input=torch.cat(tuple(bank.mlp_input for bank in selected), dim=0),
            pre_mlp_residual=torch.cat(
                tuple(bank.pre_mlp_residual for bank in selected),
                dim=0,
            ),
            parent_final_norm_output=torch.cat(
                tuple(bank.parent_final_norm_output for bank in selected),
                dim=0,
            ),
            sample_weights=torch.cat(
                tuple(bank.sample_weights * 0.5 for bank in selected),
                dim=0,
            ),
        ),
        horizons["selection"] + horizons["validation"],
    )


def _horizon_metrics(
    evidence: Mapping[str, Lfm2CpcfTerminalActionEvidence],
    horizons: Mapping[str, tuple[int, ...]],
    seed: Lfm2CpcfTerminalActionSeed,
    terminal: Lfm2CpcfTerminalActionResidualResult,
    policy: Lfm2CpcfTerminalActionPolicy,
) -> dict[str, Any]:
    held_out, held_out_horizons = _combined_held_out_evidence(
        evidence,
        horizons,
    )
    result = {}
    for label, lower, upper in _HORIZON_BUCKETS:
        indices = tuple(
            index
            for index, horizon in enumerate(held_out_horizons)
            if horizon >= lower and (upper is None or horizon <= upper)
        )
        if not indices:
            result[label] = {
                "available": False,
                "rows": 0,
                "incumbent": None,
                "selected": None,
            }
            continue
        subset = _evidence_subset(held_out, indices)
        prepared = _prepare_split(subset, seed)
        incumbent = _evaluate_split(
            prepared,
            seed,
            terminal.incumbent_down_weight,
            metric_chunk_rows=policy.metric_chunk_rows,
        )
        selected = _evaluate_split(
            prepared,
            seed,
            terminal.selected_down_weight,
            metric_chunk_rows=policy.metric_chunk_rows,
        )
        result[label] = {
            "available": True,
            "rows": subset.rows,
            "row_ids_sha256": _canonical_sha256(list(subset.row_ids)),
            "incumbent": incumbent.as_dict(),
            "selected": selected.as_dict(),
        }
    return {
        "scope": "held_out_selection_plus_validation",
        "horizon_zero_is_prompt_endpoint": True,
        "forced_decode_horizon_starts_at_one": True,
        "selected_is_frozen_prepublication_candidate": True,
        "published_state": (
            "selected" if terminal.accepted and terminal.changed else "incumbent"
        ),
        "buckets": result,
    }


def _parameter_identity(parameter: Any) -> dict[str, Any]:
    return {
        "python_id": id(parameter),
        "data_ptr": int(parameter.data_ptr()),
        "shape": [int(size) for size in parameter.shape],
        "dtype": _dtype_name(parameter),
        "device": str(parameter.device),
        "requires_grad": bool(parameter.requires_grad),
    }


def _unique_parameter_count(model: Any) -> tuple[int, int]:
    seen: set[int] = set()
    tensors = 0
    elements = 0
    for parameter in model.parameters():
        if id(parameter) in seen:
            continue
        seen.add(id(parameter))
        tensors += 1
        elements += int(parameter.numel())
    return tensors, elements


def _install_if_accepted(
    parameter: Any,
    terminal: Lfm2CpcfTerminalActionResidualResult,
) -> dict[str, Any]:
    torch = _torch()
    identity = _parameter_identity(parameter)
    incumbent = parameter.detach().to(device="cpu").contiguous().clone()
    if not torch.equal(incumbent, terminal.incumbent_down_weight):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Live final writer changed after the authenticated terminal seed."
        )
    install = bool(terminal.accepted and terminal.changed)
    rollback_performed = False
    if install:
        try:
            with torch.no_grad():
                parameter.copy_(
                    terminal.published_down_weight.to(
                        device=parameter.device,
                        dtype=parameter.dtype,
                    )
                )
            if _parameter_identity(parameter) != identity or not torch.equal(
                parameter.detach().to(device="cpu"),
                terminal.published_down_weight,
            ):
                raise Lfm2LongHorizonTerminalRefoldError(
                    "Installed terminal writer changed Parameter identity or bytes."
                )
        except BaseException as exc:
            rollback_performed = True
            with torch.no_grad():
                parameter.copy_(incumbent.to(device=parameter.device))
            rollback_exact = bool(
                _parameter_identity(parameter) == identity
                and torch.equal(parameter.detach().to(device="cpu"), incumbent)
            )
            if not rollback_exact:
                raise Lfm2LongHorizonTerminalRefoldError(
                    "Failed terminal installation could not restore the exact "
                    "incumbent writer."
                ) from exc
            raise Lfm2LongHorizonTerminalRefoldError(
                "Transactional terminal writer installation failed and was "
                "rolled back exactly."
            ) from exc
    elif _parameter_identity(parameter) != identity or not torch.equal(
        parameter.detach().to(device="cpu"), incumbent
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Rejected terminal selection mutated the live child writer."
        )
    return {
        "primitive_accepted": terminal.accepted,
        "primitive_changed": terminal.changed,
        "installed": install,
        "parameter_identity_before": identity,
        "parameter_identity_preserved": _parameter_identity(parameter) == identity,
        "incumbent_sha256": _tensor_sha256(incumbent),
        "published_sha256": _tensor_sha256(parameter.detach().to(device="cpu")),
        "rollback_performed": rollback_performed,
        "new_parameter_created": False,
    }


def compile_install_lfm2_long_horizon_terminal_refold(
    *,
    cache: Lfm2CircuitTraceCache,
    bridge: StrictTokenizerBridgeArtifact,
    target_model: Any,
    interface: TiedCausalInterfaceFold,
    source_selected_tied_table: Any,
    source_lineage: Lfm2LongHorizonTerminalSourceLineage,
    parent_final_norm: (Lfm2SealedParentFinalRmsNorm | Lfm2LocalParentFinalRmsNormLoad),
    split_plan: Lfm2LongHorizonTrajectorySplitPlan | None = None,
    policy: Lfm2CpcfTerminalActionPolicy | None = None,
    tokenizer_replay_mode: TokenizerReplayMode = "strict_one_row",
    donor_tokenizer: Any | None = None,
    target_tokenizer: Any | None = None,
    terminal_cache_compatibility: Mapping[str, Any] | None = None,
    anchor_transport_witness: TiedResidualAnchorTransportWitness | None = None,
) -> Lfm2LongHorizonTerminalRefoldResult:
    """Compile and conditionally install one long-horizon terminal refold."""

    if not isinstance(cache, Lfm2CircuitTraceCache):
        raise TypeError("cache must be Lfm2CircuitTraceCache.")
    current_terminal_cache_compatibility = preflight_lfm2_long_horizon_terminal_cache(
        cache
    )
    if terminal_cache_compatibility is not None and (
        not isinstance(terminal_cache_compatibility, Mapping)
        or dict(terminal_cache_compatibility) != current_terminal_cache_compatibility
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Supplied early terminal-cache compatibility receipt does not "
            "match the current sealed cache metadata."
        )
    if isinstance(parent_final_norm, Lfm2LocalParentFinalRmsNormLoad):
        selected_parent_final_norm = parent_final_norm.final_norm
        parent_final_norm_source = parent_final_norm.as_dict()
    elif isinstance(parent_final_norm, Lfm2SealedParentFinalRmsNorm):
        selected_parent_final_norm = parent_final_norm
        parent_final_norm_source = None
    else:
        raise TypeError(
            "parent_final_norm must be a sealed norm or authenticated direct-local "
            "load."
        )
    _verify_parent_norm_binding(cache, selected_parent_final_norm)
    interface_report = _verify_interface_report(
        interface,
        source_selected_tied_table,
        anchor_transport_witness=anchor_transport_witness,
    )
    if not isinstance(source_lineage, Lfm2LongHorizonTerminalSourceLineage):
        raise TypeError("source_lineage must be Lfm2LongHorizonTerminalSourceLineage.")
    source_lineage.verify_for(
        cache=cache,
        bridge=bridge,
        parent_final_norm=parent_final_norm,
        interface=interface,
        source_selected_tied_table=source_selected_tied_table,
        anchor_transport_witness=anchor_transport_witness,
    )
    selected_policy = policy or Lfm2CpcfTerminalActionPolicy()
    if (
        not isinstance(selected_policy, Lfm2CpcfTerminalActionPolicy)
        or not selected_policy.verify_authentication()
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "policy must be an authenticated terminal-action policy."
        )
    plan = split_plan or (
        Lfm2LongHorizonTrajectorySplitPlan.deterministic_round_robin(cache)
    )
    if not isinstance(plan, Lfm2LongHorizonTrajectorySplitPlan):
        raise TypeError("split_plan must be Lfm2LongHorizonTrajectorySplitPlan.")
    plan.verify_for(cache)

    if tokenizer_replay_mode not in {"strict_one_row", "semantic_span"}:
        raise Lfm2LongHorizonTerminalRefoldError(
            "tokenizer_replay_mode must be strict_one_row or semantic_span."
        )
    if tokenizer_replay_mode == "semantic_span":
        if donor_tokenizer is None or target_tokenizer is None:
            raise Lfm2LongHorizonTerminalRefoldError(
                "semantic_span replay requires direct-local donor and target "
                "tokenizers."
            )
    elif donor_tokenizer is not None or target_tokenizer is not None:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Direct-local tokenizers are accepted only by explicit semantic_span "
            "replay."
        )

    # Authenticate every trace file with one whole-file SHA pass, after the cheap
    # record-only preflight and before target seed/replay/solve.  Tensor payloads
    # are then read through this same session; semantic replay deliberately loads
    # each complete tensor inventory once and strict replay selects a subset.
    with cache.selective_authenticated_session() as terminal_cache_session:
        seed, down_parameter, layers, target_norm_epsilon = _target_runtime_seed(
            target_model,
            interface,
            source_selected_tied_table,
        )
        child_before = fingerprint_lfm2_parent(target_model)
        parameter_count_before = _unique_parameter_count(target_model)
        semantic_bridges: tuple[Lfm2SemanticSpanPhaseBridge, ...] = ()
        if tokenizer_replay_mode == "strict_one_row":
            inverse = _strict_inverse_mapping(bridge, seed.vocabulary_size)
            cached, adapter, pair_receipts, cache_receipt = (
                _collect_cached_trajectories(
                    cache,
                    bridge,
                    inverse,
                    selected_parent_final_norm,
                    source_selected_tied_table,
                    source_lineage,
                    plan,
                    authenticated_session=terminal_cache_session,
                )
            )
        else:
            if bridge.target_vocabulary_size != seed.vocabulary_size:
                raise Lfm2LongHorizonTerminalRefoldError(
                    "Semantic target tokenizer capacity differs from the installed "
                    "tied child interface."
                )
            cached, semantic_bridges, cache_receipt = (
                _collect_cached_semantic_trajectories(
                    cache,
                    bridge,
                    donor_tokenizer,
                    target_tokenizer,
                    selected_parent_final_norm,
                    source_selected_tied_table,
                    source_lineage,
                    plan,
                    authenticated_session=terminal_cache_session,
                )
            )
            adapter = None
            pair_receipts = ()
        terminal_cache_session.verify()
    terminal_cache_payload_binding = (
        _bind_terminal_cache_compatibility_to_payload_session(
            current_terminal_cache_compatibility,
            cache_receipt,
        )
    )
    terminal_composite_lineage = _build_terminal_composite_lineage(
        cache=cache,
        source_lineage=source_lineage,
        compatibility=current_terminal_cache_compatibility,
        payload_binding=terminal_cache_payload_binding,
        cache_receipt=cache_receipt,
        cached=cached,
    )
    terminal_cache_tensor_payload_load_audit = _summarize_terminal_cache_payload_loads(
        cache_receipt
    )
    authenticated_norm_endpoints = all(
        value.parent_final_norm_endpoint.get("runtime_replay_to_cached_output_verified")
        is True
        for value in cached
    )
    evidence_tuple, horizons, replay_receipts, rope_calls = _build_split_evidence(
        cached,
        adapter,
        target_model,
        layers,
    )
    evidence = {value.split: value for value in evidence_tuple}
    child_after_replay = fingerprint_lfm2_parent(target_model)
    if child_after_replay.identity_sha256 != child_before.identity_sha256:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Child state changed during no-forward macrocell replay."
        )

    terminal = compile_lfm2_cpcf_terminal_action_residual(
        seed=seed,
        fit_evidence=evidence["fit"],
        fit_check_evidence=evidence["fit_check"],
        selection_evidence=evidence["selection"],
        validation_evidence=evidence["validation"],
        policy=selected_policy,
    )
    if not terminal.verify_authentication():
        raise Lfm2LongHorizonTerminalRefoldError(
            "Closed-form terminal-action result failed authentication."
        )
    horizon_report = _horizon_metrics(
        evidence,
        horizons,
        seed,
        terminal,
        selected_policy,
    )
    installation = _install_if_accepted(down_parameter, terminal)
    child_after_install = fingerprint_lfm2_parent(target_model)
    parameter_count_after = _unique_parameter_count(target_model)
    accepted = bool(installation["installed"])
    if (
        parameter_count_after != parameter_count_before
        or (
            accepted
            and child_after_install.identity_sha256 == child_before.identity_sha256
        )
        or (
            not accepted
            and child_after_install.identity_sha256 != child_before.identity_sha256
        )
    ):
        raise Lfm2LongHorizonTerminalRefoldError(
            "Terminal publication changed child topology or contradicted its "
            "installation receipt."
        )

    macrocell_calls = sum(
        int(value["full_prefix_replay_calls"]) * len(layers)
        for value in replay_receipts
    )
    observed_macrocell_calls = sum(
        int(value["macrocell_replay_calls"]) for value in replay_receipts
    )
    if observed_macrocell_calls != macrocell_calls:
        raise Lfm2LongHorizonTerminalRefoldError(
            "Macrocell replay audit count is inconsistent."
        )
    body = {
        "schema": LFM2_LONG_HORIZON_TERMINAL_REFOLD_SCHEMA,
        "method": (
            "sealed_cache_runtime_verified_parent_final_norm_endpoint_plus_"
            + (
                "one_pass_complete_child_macrocell_trajectory"
                if tokenizer_replay_mode == "strict_one_row"
                else "semantic_maximal_target_prefix_branch_cover"
            )
            + "_plus_closed_form_terminal_writer_residual"
        ),
        "tokenizer_replay_mode": tokenizer_replay_mode,
        "cache_key": cache.cache_key,
        "cache_parent_fingerprint": cache.parent_fingerprint,
        "cache_layer_topology_fingerprint": cache.layer_topology_fingerprint,
        "cache_authentication_sha256": cache_receipt["session"]["session_sha256"],
        "cache_authentication": cache_receipt,
        "terminal_cache_compatibility": current_terminal_cache_compatibility,
        "terminal_cache_compatibility_sha256": (
            current_terminal_cache_compatibility["authentication_sha256"]
        ),
        "terminal_cache_payload_binding": terminal_cache_payload_binding,
        "terminal_source_lineage": source_lineage.as_dict(),
        "terminal_source_lineage_sha256": source_lineage.authentication_sha256,
        "terminal_composite_lineage": terminal_composite_lineage.as_dict(),
        "terminal_composite_lineage_sha256": (
            terminal_composite_lineage.authentication_sha256
        ),
        "terminal_compiler_binding_sha256": (
            terminal_composite_lineage.compiler_binding_sha256
        ),
        "terminal_cache_tensor_payload_load_audit": (
            terminal_cache_tensor_payload_load_audit
        ),
        "cached_full_prefix_payload_verification": [
            dict(value.cached_full_prefix_payload) for value in cached
        ],
        "cached_full_prefix_payload_verification_sha256": [
            value.cached_full_prefix_payload["authentication_sha256"]
            for value in cached
        ],
        "parent_final_norm": selected_parent_final_norm.as_dict(),
        "parent_final_norm_direct_local_source": parent_final_norm_source,
        "parent_final_norm_reconstruction": {
            "method": (
                "direct_local_runtime_equivalent_rmsnorm_replay_then_"
                "authenticated_cached_output"
            ),
            "final_norm_module_or_parent_model_called": False,
            "reconstructed_output_dtype": "bfloat16",
            "prompt_endpoint_and_every_forced_position": True,
            "cached_final_residual_to_norm_input_exact": (authenticated_norm_endpoints),
            "cached_final_norm_output_to_lm_head_input_exact": (
                authenticated_norm_endpoints
            ),
            "authenticated_cached_output_used_as_compiler_target": (
                authenticated_norm_endpoints
            ),
            "legacy_cache_exact_parent_identity_fallback_used": (
                not authenticated_norm_endpoints
            ),
        },
        "bridge_artifact_sha256": bridge.artifact_sha256,
        "bridge_transport_profile_fingerprint": bridge.profile_fingerprint,
        "bridge_trace_adapter_sha256": (
            None if adapter is None else adapter.evidence_sha256
        ),
        "semantic_span_bridge_sha256": [
            value.bridge_sha256 for value in semantic_bridges
        ],
        "semantic_span_bridges": [
            value.to_evidence_dict() for value in semantic_bridges
        ],
        "bridge_pair_authentication_sha256": [
            value["evidence_sha256"] for value in pair_receipts
        ],
        "bridge_inverse_contract": {
            "every_cached_donor_prompt_and_forced_id_covered": (
                tokenizer_replay_mode == "strict_one_row"
            ),
            "every_used_donor_row_has_exactly_one_target_row": (
                tokenizer_replay_mode == "strict_one_row"
            ),
            "exact_full_prefix_text_roundtrip_used": (
                tokenizer_replay_mode == "semantic_span"
            ),
            "suffix_rewrite_supported": tokenizer_replay_mode == "semantic_span",
            "numeric_token_id_equality_required": False,
        },
        "parent_action_projection_sha256": [
            value.parent_action_projection["authentication_sha256"] for value in cached
        ],
        "parent_action_projection_diagnostics": [
            dict(value.parent_action_projection) for value in cached
        ],
        "parent_action_projection_numeric_threshold_applied": False,
        "parent_action_projection_metrics_diagnostic_only": True,
        "parent_final_norm_endpoint_sha256": [
            value.parent_final_norm_endpoint["authentication_sha256"]
            for value in cached
        ],
        "split_plan": plan.as_dict(),
        "split_evidence_sha256": {
            value.split: value.authentication_sha256 for value in evidence_tuple
        },
        "split_rows": {value.split: value.rows for value in evidence_tuple},
        "split_horizon_maximum": {
            split: max(values) for split, values in horizons.items()
        },
        "whole_trajectory_split_isolation": True,
        "interface_report_sha256": interface_report["report_sha256"],
        "terminal_seed_sha256": seed.authentication_sha256,
        "target_final_norm_epsilon": target_norm_epsilon,
        "terminal_result_sha256": terminal.result_sha256,
        "terminal_result": terminal.as_dict(),
        "horizon_metrics": horizon_report,
        "trajectory_replay_receipts": list(replay_receipts),
        "child_state": {
            "before_sha256": child_before.identity_sha256,
            "after_replay_sha256": child_after_replay.identity_sha256,
            "after_install_sha256": child_after_install.identity_sha256,
            "replay_state_unchanged": True,
            "parameter_tensor_count_before": parameter_count_before[0],
            "parameter_tensor_count_after": parameter_count_after[0],
            "parameter_element_count_before": parameter_count_before[1],
            "parameter_element_count_after": parameter_count_after[1],
            "parameter_count_changed": False,
        },
        "installation": installation,
        "accepted": accepted,
        "operation_audit": {
            "parent_model_forward_calls": 0,
            "parent_model_generate_calls": 0,
            "parent_final_norm_module_calls": 0,
            "parent_cache_generation_calls": 0,
            "parent_trace_recaptures": 0,
            "metadata_preflight_trace_file_sha256_passes": 0,
            "metadata_preflight_trace_payload_bytes_read": 0,
            "consuming_selective_session_constructions": 1,
            "consuming_trace_file_sha256_passes_per_batch": 1,
            "consuming_trace_file_sha256_passes_total": cache.batch_count,
            "same_consuming_session_reused_by_collector": True,
            "additional_full_trace_file_sha256_passes_performed_by_this_terminal_compiler": 0,
            "selected_tensor_payload_loads_total": (
                terminal_cache_tensor_payload_load_audit[
                    "selected_tensor_payload_load_count"
                ]
            ),
            "selected_tensor_payload_logical_bytes_total": (
                terminal_cache_tensor_payload_load_audit[
                    "selected_tensor_payload_logical_bytes_total"
                ]
            ),
            "full_tensor_inventory_payload_loads_total": (
                terminal_cache_tensor_payload_load_audit[
                    "full_tensor_inventory_payload_load_count"
                ]
            ),
            "full_tensor_inventory_payload_logical_bytes_total": (
                terminal_cache_tensor_payload_load_audit[
                    "full_tensor_inventory_payload_logical_bytes_total"
                ]
            ),
            "parent_cached_action_rows_authenticated": sum(
                len(value.horizon_indices) for value in cached
            ),
            "child_model_forward_calls": 0,
            "child_model_generate_calls": 0,
            "child_embedding_seed_lookups": sum(
                int(value["embedding_seed_lookup_calls"]) for value in replay_receipts
            ),
            "child_target_native_full_prefix_replay_calls": sum(
                int(value["full_prefix_replay_calls"]) for value in replay_receipts
            ),
            "child_macrocell_replay_calls": observed_macrocell_calls,
            "expected_child_macrocell_replay_calls": macrocell_calls,
            "child_attention_rope_materializations": rope_calls,
            "child_layer_forward_calls": 0,
            "closed_form_terminal_compiler_calls": 1,
            "autograd_grad_calls": 0,
            "backward_calls": 0,
            "optimizer_constructions": 0,
            "optimizer_steps": 0,
            "training_steps": 0,
            "new_parameters": 0,
            "parameters_pruned": 0,
            "parameters_quantized": 0,
        },
        "scope_limits": {
            "changes_only_existing_final_layer_w2_if_accepted": True,
            "does_not_refold_upstream_layers": True,
            "does_not_create_tokenizer_rows": True,
            "semantic_evidence_is_parent_phase_terminal_only": (
                tokenizer_replay_mode == "semantic_span"
            ),
            "fabricated_intermediate_parent_rows": False,
            "reconstructs_full_attention_histories": False,
            "claims_inserted_target_subtoken_parent_actions": False,
            "does_not_claim_multimodal_coverage": True,
        },
    }
    seal = _canonical_sha256(body)
    return Lfm2LongHorizonTerminalRefoldResult(
        split_evidence=evidence_tuple,
        terminal_result=terminal,
        accepted=accepted,
        report={**body, "result_sha256": seal},
        result_sha256=seal,
    )


__all__ = [
    "LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_RECONSTRUCTION_SCHEMA",
    "LFM2_DIRECT_LOCAL_MAPPED_TIED_TABLE_SOURCE_SCHEMA",
    "LFM2_LONG_HORIZON_TERMINAL_COMPOSITE_LINEAGE_SCHEMA",
    "LFM2_LONG_HORIZON_PARENT_FINAL_NORM_SCHEMA",
    "LFM2_LONG_HORIZON_TERMINAL_SOURCE_LINEAGE_SCHEMA",
    "LFM2_LONG_HORIZON_SPLIT_PLAN_SCHEMA",
    "LFM2_LONG_HORIZON_TERMINAL_CACHE_COMPATIBILITY_SCHEMA",
    "LFM2_LONG_HORIZON_TERMINAL_PAYLOAD_LOAD_AUDIT_SCHEMA",
    "LFM2_LONG_HORIZON_TERMINAL_REFOLD_SCHEMA",
    "Lfm2LongHorizonTerminalCompositeLineage",
    "Lfm2LongHorizonTerminalRefoldError",
    "Lfm2LongHorizonTerminalRefoldResult",
    "Lfm2LongHorizonTerminalSourceLineage",
    "Lfm2LongHorizonTrajectorySplitPlan",
    "Lfm2LocalParentFinalRmsNormLoad",
    "Lfm2SealedParentFinalRmsNorm",
    "TokenizerReplayMode",
    "authenticate_lfm2_long_horizon_terminal_composite_lineage",
    "build_lfm2_long_horizon_terminal_source_lineage",
    "compile_install_lfm2_long_horizon_terminal_refold",
    "load_lfm2_parent_final_rmsnorm_from_local_safetensors",
    "preflight_lfm2_long_horizon_terminal_cache",
]
