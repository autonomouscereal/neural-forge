"""Exact own immutable boundary packets for the existing K3 host capacity caller."""
from __future__ import annotations

from datetime import datetime, timezone
import ctypes
import os
import hashlib
import json
from pathlib import Path
import re
import time


class CapacityDenied(ValueError):
    """No native subprocess is running when this boundary refusal is raised."""


class MemoryCapacityUnavailable(CapacityDenied):
    """Authenticated memory-only scarcity; all other packet guards passed."""
    def __init__(self, reason, proof):
        super().__init__(reason)
        self.proof = proof


BOUNDARY_KEYS = ("run_uuid", "allocation_id", "container_id", "driver_sha256", "config_sha256",
                 "next_window", "resume_layer", "own_remaining_write_bytes", "native_tool_sha256",
                 "projection_sha256", "admission_sha256", "identity_sha256", "source_pins_sha256",
                 "allocation_receipt_sha256", "recovery_packet_sha256", "request_boundary_id")


def require(ok, reason):
    if not ok:
        raise CapacityDenied(reason)


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def object_sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def file_sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def digest(value):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value), "capacity packet explicit SHA256 required")
    return value


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "capacity packet duplicate JSON key")
        result[key] = value
    return result


def pinned_json(path, expected, maximum=16 << 20):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= maximum,
            "capacity packet regular bounded file required")
    before = path.stat()
    raw = path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == digest(expected), "capacity packet actual full SHA256 differs")
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "capacity packet changed during full read")
    value = json.loads(raw, object_pairs_hook=unique, parse_constant=lambda value: require(False, "capacity packet nonfinite JSON"))
    require(isinstance(value, dict), "capacity packet JSON object required")
    return value


def fresh(at, now=None):
    try:
        stamp = datetime.fromisoformat(at.replace("Z", "+00:00"))
    except (AttributeError, TypeError, ValueError):
        raise CapacityDenied("capacity packet valid timezone timestamp required")
    require(stamp.tzinfo is not None, "capacity packet timezone required")
    age = ((now or datetime.now(timezone.utc)) - stamp).total_seconds()
    require(0 <= age <= 150, "capacity packet/facts stale or future; native launch refused")


def boundary(request, request_sha):
    require(request.get("schema") == "neural_forge.k3_driver_capacity_request.v1", "exact own capacity request schema required")
    require(type(request.get("own_remaining_write_bytes")) is int and request["own_remaining_write_bytes"] >= 0
            and request.get("remaining_copy_bytes") == 0
            and request.get("request_boundary_id") == request.get("attempt_uuid"),
            "exact actual own writes/completed copy/new boundary required")
    projection = request.get("projection")
    require(isinstance(projection, dict) and projection.get("required_new_bytes") == request["own_remaining_write_bytes"]
            and request["projection_sha256"] == object_sha(projection), "source-backed Driver.admit projection/hash differs")
    result = {key: request[key] for key in BOUNDARY_KEYS}
    result["driver_request_sha256"] = digest(request_sha)
    return result


def verify_packets(request, request_sha, response, capacity, caller, identity, now=None):
    expected = boundary(request, request_sha)
    require(response.get("schema") == "neural_forge.k3_driver_capacity_response.v1"
            and response.get("attempt_uuid") == request["attempt_uuid"] and response.get("run_uuid") == request["run_uuid"]
            and response.get("driver_request_sha256") == request_sha and response.get("request_boundary") == expected,
            "actual owner response differs from exact immutable own request boundary")
    fresh(response.get("at"), now)
    require(response.get("host_caller_config_sha256") == caller["host_caller_config_sha256"]
            and response.get("source_scripts") == caller["source_scripts"]
            and response.get("provider_or_allocator_mutations") is False,
            "actual owner response caller config/source pins differ")
    if response.get("capacity_pin") is None:
        raise CapacityDenied("actual owner capacity caller refused before capacity output: " + str(response.get("error_tail", "no concrete output")))
    require(capacity.get("schema") == "neural_forge.k3_owned_launch_capacity.v2"
            and capacity.get("mode") == "allocated" and capacity.get("attempt_uuid") == request["attempt_uuid"]
            and capacity.get("identity") == identity and capacity.get("request_boundary") == expected
            and capacity.get("source_pins") == caller["source_pins"]
            and capacity.get("request_pin", {}).get("sha256") == response.get("preflight_request_sha256")
            and capacity.get("provider_or_allocator_mutations") is False and capacity.get("model_payload_reads") == 0,
            "actual source capacity identity/config/allocation/native/projection boundary differs")
    fresh(capacity.get("at"), now)
    fresh(capacity.get("facts_at"), now)
    components = capacity.get("disk_components", {})
    require(components.get("remaining_copy_bytes") == 0
            and components.get("K3_selected_window_remaining_bytes") == request["own_remaining_write_bytes"],
            "actual owner capacity charged a different remaining-write projection")
    predicates = {key: capacity.get(key) for key in ("memory_admitted", "cpu_admitted", "disk_admitted")}
    require(all(type(value) is bool for value in predicates.values()), "actual capacity admission Boolean shape required")
    admitted = all(predicates.values())
    require(type(response.get("exit_code")) is int and response["exit_code"] == (0 if admitted else 2)
            and response.get("admitted") is admitted and capacity.get("admitted") is admitted,
            "actual capacity exit/admission predicates inconsistent")
    if not admitted:
        denial = {"request_boundary": expected, "admission_predicates": predicates,
                  "required_RAM_bytes": capacity.get("RAM_required_bytes"),
                  "required_CPU_threads": capacity.get("CPU_required_threads"),
                  "required_disk_bytes": capacity.get("remaining_disk_required_bytes"),
                  "actual_host": capacity.get("host"), "admitted": False, "overall92_admitted": False}
        reason = "actual owner source-backed capacity denied native boundary: " + json.dumps(denial, sort_keys=True)
        if predicates == {"memory_admitted": False, "cpu_admitted": True, "disk_admitted": True}:
            ram = capacity.get("RAM_required_bytes")
            available = capacity.get("host", {}).get("MemAvailable_bytes")
            require(type(ram) is int and type(available) is int and 0 <= available < ram,
                    "actual memory-only denial must prove concrete RAM shortfall")
            raise MemoryCapacityUnavailable(reason, denial)
        raise CapacityDenied(reason)
    return {"request_boundary": expected, "response_observed_at": response["at"],
            "capacity_observed_at": capacity["at"], "facts_observed_at": capacity["facts_at"],
            "own_remaining_write_bytes": request["own_remaining_write_bytes"],
            "admitted": True, "overall92_admitted": False}


def publish_sha(path, expected):
    # One fixed65-byte sidecar is durable before atomic publication. Linux
    # RENAME_NOREPLACE preserves any existing immutable boundary evidence.
    path = Path(path)
    require(isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected),
            "explicit full publication SHA256 required")
    require(not path.exists() and not path.is_symlink(), "immutable SHA sidecar already exists")
    pending = path.with_name(path.name + ".pending")
    raw = (expected + "\n").encode("ascii")
    with pending.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    require(pending.read_bytes() == raw, "complete pending SHA sidecar readback differs")
    if os.name == "nt":
        os.rename(pending, path)  # Windows rename refuses an existing destination.
    else:
        rename = ctypes.CDLL(None, use_errno=True).renameat2
        rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        rename.restype = ctypes.c_int
        if rename(-100, os.fsencode(pending), -100, os.fsencode(path), 1) != 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), str(path))
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    require(path.read_bytes() == raw, "complete published SHA sidecar readback differs")


def sidecar_sha(path):
    # Retain bounded waiting compatibility with an in-progress previous writer;
    # complete malformed metadata refuses rather than weakening a full SHA pin.
    path = Path(path)
    require(not path.is_symlink(), "SHA publication sidecar may not be a symlink")
    if not path.exists():
        return None
    require(path.is_file() and path.stat().st_size <= 80, "regular bounded SHA publication sidecar required")
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
            or len(raw) < 64):
        return None
    require(re.fullmatch(rb"[0-9a-f]{64}\n?", raw) is not None, "complete SHA publication metadata malformed")
    return raw[:64].decode("ascii")


def read_decision(request_path, request_sha, responses, caller, identity):
    request = pinned_json(request_path, request_sha, maximum=16384)
    attempt = request["attempt_uuid"]
    response_path = Path(responses) / ("response-" + attempt + ".json")
    response_sidecar = response_path.with_suffix(".sha256")
    expected = sidecar_sha(response_sidecar)
    require(expected is not None, "actual owner response SHA publication incomplete")
    response = pinned_json(response_path, expected)
    capacity = None
    if response.get("capacity_pin") is not None:
        pin = response["capacity_pin"]
        require(pin.get("name") == "capacity-" + attempt + ".json", "actual owner capacity leaf differs from own attempt")
        capacity = pinned_json(Path(responses) / pin["name"], pin["sha256"])
    pins = dict(request_path=str(request_path), request_sha256=request_sha, response_path=str(response_path),
                response_sha256=expected, capacity_sha256=(response.get("capacity_pin") or {}).get("sha256"))
    try:
        proof = verify_packets(request, request_sha, response, capacity, caller, identity)
    except MemoryCapacityUnavailable as error:
        error.proof.update(pins)
        raise
    proof.update(pins)
    return proof


def await_decision(request_path, request_sha, responses, caller, identity, timeout_seconds=180):
    request = pinned_json(request_path, request_sha, maximum=16384)
    sidecar = Path(responses) / ("response-" + request["attempt_uuid"] + ".sha256")
    started = time.monotonic()
    while sidecar_sha(sidecar) is None:
        require(time.monotonic() - started <= timeout_seconds, "actual owner capacity response timed out at natural native boundary")
        time.sleep(1)
    return read_decision(request_path, request_sha, responses, caller, identity)
