"""Executable dense blank-first LFM2 width folding.

The dense parameter frontier materializes a real smaller LFM2 architecture
whose learned tensors are compiler-zeroed.  This module fills that blank in
one transactional, zero-gradient model action:

* one complete-weight or circuit-balanced residual coordinate basis is shared
  by the embedding, every residual-facing circuit, and the output interface;
* GQA attention channels are folded with the existing RoPE-pair-constrained
  maps selected independently from each materialized layer's physical shape;
* every source SwiGLU neuron is assigned to the smaller coupled gate/up/down
  circuit through the existing feature-fold primitive;
* every ShortConv uses one coupled internal-channel fold distinct from the
  shared residual map, with optional cached-action-aware factor writers; and
* an optional cached child-closed-loop pass refines attention consumers,
  SwiGLU, final normalization, and the tied output interface without executing
  the parent or training.

Depth composition is deliberately outside this transaction.  A target must
retain the source layer count and operator order; callers get an explicit
failure instead of a misleading partial fold.
"""

from __future__ import annotations

import ctypes
import gc
import hashlib
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from pathlib import Path
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Protocol

from .dynamic_circuit_ir import JsonScalar, ModelCircuitGraph, canonical_sha256
from .dynamic_child_replay_phase_cache import (
    DynamicChildReplayPhaseCacheContext,
)
from .dynamic_balanced_circuit_basis import (
    PrecomputedDownstreamObservability,
)
from .dynamic_closed_loop_fold import (
    RUN_SCHEMA as CLOSED_LOOP_RUN_SCHEMA,
    ChildClosedLoopCompiler,
    ClosedLoopCompilerConfig,
)
from .dynamic_fold_executor import (
    FoldDecision,
    FoldEvaluationContext,
    FoldEvidence,
    FoldExecutionContext,
    FoldTransaction,
    fingerprint_model_state,
)
from .dynamic_fold_diagnostics import (
    TRANSACTION_REPORT_BINDING_KEY,
    WHOLE_CHILD_DIAGNOSTIC_OPERATOR_CAPABILITY,
    AuthenticatedWholeChildComponentDispatch,
    WholeChildComponentDiagnosticError,
    authenticate_whole_child_component_dispatch,
)
from .dynamic_fold_planner import (
    EXTERNAL_RESOURCE_BINDINGS_CONFIGURATION_KEY,
    DynamicFoldPlan,
    FoldAction,
    external_resource_bindings_sha256,
)
from .dynamic_lfm2_adapter import (
    Lfm2DenseBudgetedSelectedTarget,
    encode_lfm2_layer_types,
    encode_lfm2_source_spans,
    validate_lfm2_dense_budgeted_child,
)
from .hf_attention_fold import build_gqa_attention_fold_maps
from .hf_feature_fold import FeatureFoldError, SparseFeatureFoldMap, build_feature_fold_map
from .hf_lfm2_circuit_trace_cache import (
    CHILD_REPLAY_PREFIX_BY_PREFIX_MODE,
    CHILD_REPLAY_SINGLE_PASS_CAUSAL_MODE,
    FULL_PREFIX_CANONICAL_TRACE_MODE,
    Lfm2CircuitTraceCache,
    Lfm2CircuitTraceCaptureConfig,
    Lfm2CircuitTraceSelectiveAuthenticatedSession,
    capture_lfm2_child_replay,
)
from .hf_lfm2_closed_loop_restart_capsule import (
    DEFAULT_RESTART_CAPSULE_ROTATION_KEEP,
    Lfm2ClosedLoopRestartCapsuleError,
    Lfm2ClosedLoopRestartCapsuleWriter,
    latest_lfm2_closed_loop_restart_capsule,
    lfm2_restart_capsule_split_sha256,
    load_lfm2_closed_loop_restart_capsule,
)
from .hf_lfm2_dynamic_closed_loop_adapter import (
    LFM2_BODY_RECLOSURE_DISABLED,
    LFM2_BODY_RECLOSURE_MODES,
    LFM2_BODY_RECLOSURE_MOVING_GAUGE_V3,
    Lfm2DynamicClosedLoopAdapter,
    Lfm2DynamicClosedLoopAdapterConfig,
)
from .lfm2_body_global_coordinate_completion import (
    LFM2_BODY_GLOBAL_COORDINATE_COMPLETION_RECIPES,
)
from .hf_lfm2_macro_cell_attractor_gate import (
    Lfm2MacroCellAttractorGate,
    Lfm2MacroCellAttractorGateConfig,
)
from .hf_lfm2_balanced_basis_phase_cache import (
    Lfm2BalancedBasisPhaseBuildRequest,
    Lfm2BalancedBasisPhaseCacheContext,
    load_or_build_lfm2_circuit_balanced_basis,
)
from .hf_lfm2_autoregressive_hankel_observability import (
    Lfm2AutoregressiveHankelObservabilityResult,
)
from .hf_lfm2_sealed_evidence_set import (
    SEALED_EVIDENCE_CACHE_TYPES,
    SEALED_EVIDENCE_SESSION_TYPES,
    Lfm2SealedEvidenceSet,
)
from .hf_lfm2_tokenizer_bridge_trace_adapter import (
    Lfm2StrictTokenizerBridgeTraceAdapter,
    Lfm2StrictTokenizerBridgeTraceError,
)
from .hf_lfm2_streaming_vocabulary_margin_adapter import (
    Lfm2TargetTokenizerVocabularyMarginBinding,
)
from .hf_lfm2_weight_complete_basis import build_lfm2_weight_complete_basis
from .hf_tokenizer_bridge import (
    StrictTokenizerBridgeArtifact,
    compile_strict_vocabulary_operators,
)
from .lfm2_native_exact4x_target import (
    lfm2_identity_tokenizer_evidence_sha256,
)

if TYPE_CHECKING:
    from .hf_lfm2_sparse_feature_fold_bundle import Lfm2SparseFeatureFoldBundle


DENSE_BUDGET_MODEL_METHOD = "lfm2_dense_budget_residual_attention_model"
DENSE_BUDGET_FOLD_SCHEMA = "neural-forge-lfm2-dense-budget-model-fold-v1"
LFM2_SPARSE_FEATURE_FOLD_BUNDLE_RESOURCE_NAME = "lfm2_sparse_feature_fold_bundle"
_SPARSE_AXIS_MLP_POST_SWIGLU = "mlp_post_swiglu"
_SPARSE_AXIS_SHORT_CONV_CONTEXT = "short_conv_context"
VOCABULARY_MARGIN_CANDIDATE_GATE_SCHEMA = (
    "neural-forge-lfm2-dense-budget-vocabulary-margin-candidate-gate-v1"
)
LFM2_COMPONENT_FOLD_STAGE_CONFIGURATION_KEY = "lfm2_component_fold_stage"
LFM2_COMPONENT_STRUCTURAL_STAGE = "structural_transport"
LFM2_COMPONENT_CLOSED_LOOP_STAGE = "closed_loop_refinement"
LFM2_COMPONENT_DISPATCH_EXECUTION_SCHEMA = (
    "neural-forge-lfm2-component-dispatch-execution-v1"
)
SHORT_CONV_FACTOR_WRITER_SCHEMA = (
    "neural-forge-lfm2-structural-short-conv-factor-writer-v1"
)
SHORT_CONV_OUTPUT_ACTION_EVIDENCE_SCHEMA = (
    "neural-forge-lfm2-cached-short-conv-output-action-evidence-v1"
)
DENSE_FOLD_PROGRESS_SCHEMA = (
    "neural-forge-lfm2-dense-fold-progress-chain-v1"
)
DENSE_FOLD_PROGRESS_GENESIS_SHA256 = "0" * 64
DENSE_RESTART_CAPSULE_BINDING_SCHEMA = (
    "neural-forge-lfm2-dense-fold-restart-capsule-binding-v1"
)
# Emitted once per closed-loop body fold, after the adapter exists and before
# any capture, so a run journal records whether an opted-in capture merge was
# actually admitted by this adapter configuration.
DENSE_CLOSED_LOOP_MERGE_CAPTURE_POLICY_STAGE = (
    "dense_closed_loop_merge_capture_policy"
)


class Lfm2DenseBudgetFoldError(RuntimeError):
    """The dense target cannot be filled under the authenticated contract."""


def _process_memory_telemetry() -> dict[str, int]:
    """Read tensor-free process memory gauges without importing an optional agent."""

    result: dict[str, int] = {}
    try:
        status = Path("/proc/self/status").read_text(encoding="ascii")
    except (OSError, UnicodeError):
        return result
    names = {
        "VmRSS": "process_rss_bytes",
        "VmHWM": "process_peak_rss_bytes",
        "VmSwap": "process_swap_bytes",
    }
    for line in status.splitlines():
        name, separator, raw_value = line.partition(":")
        if not separator or name not in names:
            continue
        fields = raw_value.split()
        if len(fields) == 2 and fields[1] == "kB" and fields[0].isdigit():
            result[names[name]] = int(fields[0]) * 1024
    return result


def _release_cpu_allocator_retention(
    *,
    caller_declared_release_plan_units: int,
) -> dict[str, JsonScalar]:
    """Collect unreachable CPU temporaries and return free glibc arenas.

    The caller must first drop every local reference to its completed FP64
    intermediates. ``gc.collect`` and ``malloc_trim`` only affect unreachable
    objects/free allocator pages; neither touches live tensors or model math.
    """

    if (
        isinstance(caller_declared_release_plan_units, bool)
        or not isinstance(caller_declared_release_plan_units, int)
        or caller_declared_release_plan_units < 0
    ):
        raise Lfm2DenseBudgetFoldError(
            "caller_declared_release_plan_units must be a nonnegative integer."
        )
    gc_attempted = True
    gc_succeeded = False
    collected: int | None = None
    gc_error_type: str | None = None
    try:
        collected = int(gc.collect())
        gc_succeeded = True
    except Exception as error:  # pragma: no cover - interpreter/runtime specific
        gc_error_type = type(error).__name__
    trim_supported = False
    trim_attempted = False
    trim_released = False
    trim_error_type: str | None = None
    try:
        process_library = ctypes.CDLL(None)
        malloc_trim = getattr(process_library, "malloc_trim")
        malloc_trim.argtypes = [ctypes.c_size_t]
        malloc_trim.restype = ctypes.c_int
        trim_supported = True
        trim_attempted = True
        trim_released = bool(malloc_trim(0))
    except Exception as error:  # best-effort allocator observability only
        trim_error_type = type(error).__name__
    return {
        # This is an explicit caller bookkeeping hint, not a measured Python
        # reference count.  The GC and allocator fields below are measurements.
        "caller_declared_release_plan_units": (
            caller_declared_release_plan_units
        ),
        "python_gc_attempted": gc_attempted,
        "python_gc_succeeded": gc_succeeded,
        "python_gc_collected_objects": collected,
        "python_gc_error_type": gc_error_type,
        "cpu_allocator_trim_supported": trim_supported,
        "cpu_allocator_trim_attempted": trim_attempted,
        "cpu_allocator_trim_released_pages": trim_released,
        "cpu_allocator_trim_error_type": trim_error_type,
    }


class _Lfm2DenseFoldProgress:
    """Hash-chain dense fold events before forwarding them to the run journal."""

    def __init__(
        self,
        sink: Callable[[str, Mapping[str, JsonScalar]], None] | None,
        *,
        action_sha256: str,
        catalog_id: str,
        parent_cache_key: str,
        target_hidden_size: int,
    ) -> None:
        if sink is not None and not callable(sink):
            raise Lfm2DenseBudgetFoldError(
                "Dense fold progress sink must be callable or None."
            )
        self._sink = sink
        self._sequence = 0
        self._previous_sha256 = DENSE_FOLD_PROGRESS_GENESIS_SHA256
        binding = {
            "schema": DENSE_FOLD_PROGRESS_SCHEMA,
            "method_id": DENSE_BUDGET_MODEL_METHOD,
            "action_sha256": _digest(action_sha256, "action_sha256"),
            "catalog_id": _text(catalog_id, "catalog_id"),
            "parent_cache_key": _digest(
                parent_cache_key,
                "parent_cache_key",
            ),
            "target_hidden_size": _positive_int(
                target_hidden_size,
                "target_hidden_size",
            ),
        }
        self.binding_sha256 = canonical_sha256(binding)

    @property
    def sequence(self) -> int:
        """Number of events already chained by this sink."""

        return self._sequence

    @property
    def head_sha256(self) -> str:
        """Digest of the most recent chained event, or the genesis digest."""

        return self._previous_sha256

    def emit(self, stage: str, /, **metadata: JsonScalar) -> None:
        if self._sink is None:
            return
        event_stage = _text(stage, "dense fold progress stage")
        forbidden = {
            "schema",
            "binding_sha256",
            "sequence",
            "previous_event_sha256",
            "stage",
            "process_rss_bytes",
            "process_peak_rss_bytes",
            "process_swap_bytes",
            "fold_progress_schema",
            "fold_progress_binding_sha256",
            "fold_progress_sequence",
            "fold_progress_previous_event_sha256",
            "fold_progress_event_sha256",
        }
        if forbidden.intersection(metadata):
            raise Lfm2DenseBudgetFoldError(
                "Dense fold progress metadata shadows authenticated fields."
            )
        memory = _process_memory_telemetry()
        event_body: dict[str, JsonScalar] = {
            "schema": DENSE_FOLD_PROGRESS_SCHEMA,
            "binding_sha256": self.binding_sha256,
            "sequence": self._sequence,
            "previous_event_sha256": self._previous_sha256,
            "stage": event_stage,
            **memory,
            **metadata,
        }
        event_sha256 = canonical_sha256(event_body)
        self._sink(
            event_stage,
            {
                "fold_progress_schema": DENSE_FOLD_PROGRESS_SCHEMA,
                "fold_progress_binding_sha256": self.binding_sha256,
                "fold_progress_sequence": self._sequence,
                "fold_progress_previous_event_sha256": self._previous_sha256,
                "fold_progress_event_sha256": event_sha256,
                **memory,
                **metadata,
            },
        )
        self._previous_sha256 = event_sha256
        self._sequence += 1

    def __call__(
        self,
        stage: str,
        metadata: Mapping[str, JsonScalar],
    ) -> None:
        self.emit(stage, **dict(metadata))


class Lfm2DenseCacheIdentitySession(Protocol):
    """Cheap identity recheck exposed by an already-authenticated session."""

    @property
    def cache_key(self) -> str: ...

    def verify(self) -> Any: ...


class Lfm2DenseCacheVerificationLease:
    """Bind one fully authenticated cache to cheap subsequent identity checks.

    Constructing a lease does not authenticate cache payload bytes.  The caller
    must create it only after completing that full authentication, and must
    supply either a cheap identity callback or the authenticated session that
    performed it.  Every use still pins the exact cache handle and cache digest;
    callers that do not supply a lease retain the conservative full ``verify``
    path.
    """

    __slots__ = (
        "_trace_cache",
        "_cache_key",
        "_identity_check",
        "_authenticated_session",
    )

    def __init__(
        self,
        trace_cache: Lfm2CircuitTraceCache,
        expected_cache_key: str,
        *,
        identity_check: Callable[[], str] | None = None,
        authenticated_session: Lfm2DenseCacheIdentitySession | None = None,
    ) -> None:
        if not isinstance(trace_cache, SEALED_EVIDENCE_CACHE_TYPES):
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification lease requires a sealed trace cache "
                "or one merged sealed evidence-set view."
            )
        if (identity_check is None) == (authenticated_session is None):
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification lease requires exactly one identity "
                "callback or authenticated session."
            )
        if identity_check is not None and not callable(identity_check):
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification identity_check must be callable."
            )
        if authenticated_session is not None and not callable(
            getattr(authenticated_session, "verify", None)
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification session must expose verify()."
            )
        self._trace_cache = trace_cache
        self._cache_key = _digest(
            expected_cache_key,
            "dense cache verification lease cache key",
        )
        self._identity_check = identity_check
        self._authenticated_session = authenticated_session
        self.verify(trace_cache)

    @property
    def trace_cache(self) -> Lfm2CircuitTraceCache:
        return self._trace_cache

    @property
    def cache_key(self) -> str:
        return self._cache_key

    def verify(
        self,
        trace_cache: Lfm2CircuitTraceCache,
    ) -> Lfm2CircuitTraceCache:
        if trace_cache is not self._trace_cache:
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification lease received a different cache handle."
            )
        if trace_cache.cache_key != self._cache_key:
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification lease cache key changed."
            )
        try:
            if self._authenticated_session is not None:
                verified = self._authenticated_session.verify()
                if verified is not None and verified is not self._authenticated_session:
                    raise Lfm2DenseBudgetFoldError(
                        "Dense cache authenticated session returned a different "
                        "session handle."
                    )
                observed = getattr(
                    self._authenticated_session,
                    "cache_key",
                    None,
                )
            else:
                assert self._identity_check is not None
                observed = self._identity_check()
        except Lfm2DenseBudgetFoldError:
            raise
        except Exception as exc:
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification lease identity recheck failed."
            ) from exc
        if _digest(observed, "dense cache verification identity result") != (
            self._cache_key
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense cache verification lease identity differs from its "
                "bound cache key."
            )
        return trace_cache


def _verify_dense_trace_cache(
    trace_cache: Lfm2CircuitTraceCache,
    verification_lease: Lfm2DenseCacheVerificationLease | None,
) -> Lfm2CircuitTraceCache:
    if verification_lease is None:
        return trace_cache.verify()
    if not isinstance(verification_lease, Lfm2DenseCacheVerificationLease):
        raise Lfm2DenseBudgetFoldError(
            "verification_lease must be Lfm2DenseCacheVerificationLease or None."
        )
    return verification_lease.verify(trace_cache)


def _resolve_dense_evidence_cache(
    trace_cache: Any,
    evidence_set: Lfm2SealedEvidenceSet | None,
) -> Any:
    """Resolve the one sealed cache handle a dense writer binds.

    ``evidence_set`` is the additive base+extension entry point every dense
    writer takes.  With no extension member the caller's own handle is returned
    untouched, so a single-handle configuration stays byte-identical; with
    extension members the memoized merged read-only view replaces it and every
    identity the writer binds becomes the merged evidence identity.
    """

    if evidence_set is None:
        return trace_cache
    if not isinstance(evidence_set, Lfm2SealedEvidenceSet):
        raise Lfm2DenseBudgetFoldError(
            "evidence_set must be Lfm2SealedEvidenceSet or None."
        )
    if not evidence_set.has_extension_evidence:
        if trace_cache is not evidence_set.base_cache:
            raise Lfm2DenseBudgetFoldError(
                "A base-only sealed evidence set must carry the same base "
                "cache handle the dense writer was given."
            )
        return trace_cache
    if trace_cache not in (evidence_set.base_cache, evidence_set.merged_cache()):
        raise Lfm2DenseBudgetFoldError(
            "The dense trace cache is not the base or merged handle of the "
            "supplied sealed evidence set."
        )
    return evidence_set.merged_cache()


def _resolve_dense_evidence_handles(
    trace_cache: Any,
    selective_session: Any,
    evidence_set: Lfm2SealedEvidenceSet | None,
) -> tuple[Any, Any]:
    """Resolve the sealed cache/session pair a dense fold pass consumes."""

    resolved = _resolve_dense_evidence_cache(trace_cache, evidence_set)
    if evidence_set is None or not evidence_set.has_extension_evidence:
        return resolved, selective_session
    if selective_session is None:
        raise Lfm2DenseBudgetFoldError(
            "Consuming on-policy extension evidence requires the authenticated "
            "selective sessions the evidence set holds open."
        )
    return resolved, evidence_set.merged_session()


def _assert_bridge_replay_covers_evidence_set(
    trace_adapter: Any,
    evidence_set: Lfm2SealedEvidenceSet,
) -> None:
    """Require one target-token replay record per merged sealed batch.

    A bridged child speaks the target vocabulary, so a sealed parent batch is
    only usable when a target-token record exists for it: that record is the
    child replay.  On-policy rounds now seal that preimage, but a round
    captured parent-canonically has none, so this states the requirement as a
    property of the evidence actually supplied rather than as a lane taboo.
    """

    if trace_adapter is None:
        raise Lfm2DenseBudgetFoldError(
            "A bridged dense target cannot consume on-policy extension "
            "evidence without its target-token trace adapter: every sealed "
            "parent batch needs one target-token record to replay."
        )
    batches = tuple(evidence_set.iter_batches())
    if int(getattr(trace_adapter, "record_count", -1)) != len(batches):
        raise Lfm2DenseBudgetFoldError(
            "A bridged dense target cannot consume on-policy extension "
            "evidence: the supplied tokenizer-bridge trace adapter carries "
            f"{getattr(trace_adapter, 'record_count', None)} target-token "
            f"records for {len(batches)} sealed evidence batches, so an "
            "on-policy round with no target-token preimage would leave its "
            "batches without a child replay."
        )
    for record, batch in zip(trace_adapter.records, batches, strict=True):
        if record.donor_cache_input_sha256 != batch.input_sha256:
            raise Lfm2DenseBudgetFoldError(
                "A bridged dense target cannot consume on-policy extension "
                "evidence: the target-token record at merged batch "
                f"{batch.merged_index} is not the preimage of the sealed "
                f"parent batch from {batch.member_cache_key}."
            )


class Lfm2SealedDenseBudgetEvidence:
    """Executor-safe non-dataclass seal around the typed trace cache."""

    __slots__ = ("_trace_cache", "_cache_key", "_verification_lease")

    def __init__(
        self,
        trace_cache: Lfm2CircuitTraceCache,
        *,
        verification_lease: Lfm2DenseCacheVerificationLease | None = None,
    ) -> None:
        if not isinstance(trace_cache, SEALED_EVIDENCE_CACHE_TYPES):
            raise Lfm2DenseBudgetFoldError(
                "trace_cache must be a sealed trace cache or one merged sealed "
                "evidence-set view."
            )
        self._verification_lease = verification_lease
        self._trace_cache = _verify_dense_trace_cache(
            trace_cache,
            verification_lease,
        )
        self._cache_key = _digest(
            self._trace_cache.cache_key,
            "trace_cache.cache_key",
        )

    @property
    def trace_cache(self) -> Lfm2CircuitTraceCache:
        return self._trace_cache

    @property
    def cache_key(self) -> str:
        return self._cache_key

    def verify(self) -> "Lfm2SealedDenseBudgetEvidence":
        _verify_dense_trace_cache(
            self._trace_cache,
            self._verification_lease,
        )
        if self._trace_cache.cache_key != self._cache_key:
            raise Lfm2DenseBudgetFoldError(
                "Dense trace-cache seal changed after binding."
            )
        return self


def _torch() -> Any:
    try:
        import torch
    except ImportError as exc:  # pragma: no cover - optional dependency boundary
        raise Lfm2DenseBudgetFoldError(
            "PyTorch is required for dense LFM2 folding."
        ) from exc
    return torch


def _digest(value: Any, name: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        raise Lfm2DenseBudgetFoldError(f"{name} must be a lowercase SHA-256 digest.")
    return value


def _positive_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise Lfm2DenseBudgetFoldError(f"{name} must be a positive integer.")
    return value


def _unit_fraction(value: Any, name: str) -> float:
    if isinstance(value, bool):
        raise Lfm2DenseBudgetFoldError(
            f"{name} must be a finite fraction within [0, 1]."
        )
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise Lfm2DenseBudgetFoldError(
            f"{name} must be a finite fraction within [0, 1]."
        ) from exc
    if not 0.0 <= result <= 1.0:
        raise Lfm2DenseBudgetFoldError(
            f"{name} must be a finite fraction within [0, 1]."
        )
    return result


def _text(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise Lfm2DenseBudgetFoldError(f"{name} must be nonempty.")
    return value.strip()


def _layers(model: Any) -> tuple[Any, ...]:
    body = getattr(model, "model", None)
    layers = getattr(body, "layers", None)
    if layers is None:
        raise Lfm2DenseBudgetFoldError("LFM2 model does not expose model.layers.")
    result = tuple(layers)
    if not result:
        raise Lfm2DenseBudgetFoldError("LFM2 decoder has no layers.")
    return result


def _fold_layer_kind(layer: Any, *, label: str) -> str:
    """Read the executed operator kind without assuming uniform dimensions.

    A physically materialized heterogeneous child retains native decoder and
    operator semantics while owning descriptor-local attention and ShortConv
    dimensions.  The fold installer therefore authenticates its kind at the
    live module boundary rather than assuming one uniform configuration.
    """

    is_attention = getattr(layer, "is_attention_layer", None)
    if type(is_attention) is not bool:
        raise Lfm2DenseBudgetFoldError(f"{label}.is_attention_layer must be boolean.")
    operator_name = "self_attn" if is_attention else "conv"
    if getattr(layer, operator_name, None) is None:
        raise Lfm2DenseBudgetFoldError(
            f"{label} lacks its declared {operator_name} operator."
        )
    return "full_attention" if is_attention else "conv"


def _linear_weight_shape(operator: Any, name: str, *, label: str) -> tuple[int, int]:
    torch = _torch()
    projection = getattr(operator, name, None)
    weight = getattr(projection, "weight", None)
    if (
        not isinstance(weight, torch.Tensor)
        or weight.ndim != 2
        or any(int(size) <= 0 for size in weight.shape)
    ):
        raise Lfm2DenseBudgetFoldError(
            f"{label}.{name}.weight must be a nonempty matrix."
        )
    return int(weight.shape[0]), int(weight.shape[1])


def _attention_physical_geometry(
    attention: Any,
    *,
    label: str,
) -> tuple[int, int, int, int]:
    """Infer Q/KV/head geometry from one executed attention module."""

    head_dim = _positive_int(
        getattr(attention, "head_dim", None),
        f"{label}.head_dim",
    )
    if head_dim % 2:
        raise Lfm2DenseBudgetFoldError(
            f"{label}.head_dim must preserve complete RoPE pairs."
        )
    query_width, query_input = _linear_weight_shape(
        attention,
        "q_proj",
        label=label,
    )
    key_width, key_input = _linear_weight_shape(
        attention,
        "k_proj",
        label=label,
    )
    value_width, value_input = _linear_weight_shape(
        attention,
        "v_proj",
        label=label,
    )
    output_width, context_width = _linear_weight_shape(
        attention,
        "out_proj",
        label=label,
    )
    if (
        query_width % head_dim
        or key_width % head_dim
        or value_width != key_width
        or query_input != key_input
        or query_input != value_input
        or output_width != query_input
        or context_width != query_width
    ):
        raise Lfm2DenseBudgetFoldError(
            f"{label} projection matrices disagree with one coupled GQA geometry."
        )
    query_heads = query_width // head_dim
    key_value_heads = key_width // head_dim
    if query_heads % key_value_heads:
        raise Lfm2DenseBudgetFoldError(
            f"{label} query heads must divide into complete KV groups."
        )
    declared_query_heads = getattr(attention, "query_heads", None)
    if declared_query_heads is not None and declared_query_heads != query_heads:
        raise Lfm2DenseBudgetFoldError(
            f"{label}.query_heads disagrees with q_proj.weight."
        )
    declared_key_value_heads = getattr(attention, "key_value_heads", None)
    if (
        declared_key_value_heads is not None
        and declared_key_value_heads != key_value_heads
    ):
        raise Lfm2DenseBudgetFoldError(
            f"{label}.key_value_heads disagrees with k_proj.weight."
        )
    return query_heads, key_value_heads, head_dim, query_input


@dataclass(frozen=True, slots=True)
class _ShortConvPhysicalGeometry:
    internal_channels: int
    residual_width: int
    fir_length: int
    writer_rank: int | None

    @property
    def writer_topology(self) -> str:
        return "factorized" if self.writer_rank is not None else "dense"


def _short_conv_physical_geometry(
    short_conv: Any,
    *,
    label: str,
) -> _ShortConvPhysicalGeometry:
    """Authenticate dense or two-factor ShortConv physical geometry."""

    torch = _torch()
    writer = getattr(short_conv, "out_proj", None)
    input_rows, residual_width = _linear_weight_shape(
        short_conv,
        "in_proj",
        label=label,
    )
    if input_rows % 3:
        raise Lfm2DenseBudgetFoldError(
            f"{label}.in_proj must contain three complete B/C/x blocks."
        )
    internal_channels = input_rows // 3
    declared_rank = getattr(short_conv, "writer_rank", None)
    writer_rank: int | None
    if isinstance(writer, torch.nn.Sequential):
        if len(writer) != 2 or any(
            type(module) is not torch.nn.Linear for module in writer
        ):
            raise Lfm2DenseBudgetFoldError(
                f"{label}.out_proj must contain exactly two Linear factors."
            )
        first_rows, first_columns = _linear_weight_shape(
            writer,
            "0",
            label=f"{label}.out_proj",
        )
        second_rows, second_columns = _linear_weight_shape(
            writer,
            "1",
            label=f"{label}.out_proj",
        )
        writer_rank = _positive_int(declared_rank, f"{label}.writer_rank")
        if (
            first_rows != writer_rank
            or first_columns != internal_channels
            or second_rows != residual_width
            or second_columns != writer_rank
            or any(module.bias is not None for module in writer)
        ):
            raise Lfm2DenseBudgetFoldError(
                f"{label} factor writer disagrees with its [R,C] -> [H,R] ABI."
            )
    else:
        output_width, output_channels = _linear_weight_shape(
            short_conv,
            "out_proj",
            label=label,
        )
        writer_rank = None
        if declared_rank is not None:
            raise Lfm2DenseBudgetFoldError(
                f"{label} declares a writer rank without two physical factors."
            )
        if output_width != residual_width or output_channels != internal_channels:
            raise Lfm2DenseBudgetFoldError(
                f"{label} dense writer must have shape [H,C]."
            )
    convolution = getattr(short_conv, "conv", None)
    kernel = getattr(convolution, "weight", None)
    if (
        not isinstance(kernel, torch.Tensor)
        or kernel.ndim != 3
        or tuple(int(size) for size in kernel.shape[:2]) != (internal_channels, 1)
        or int(kernel.shape[2]) <= 0
    ):
        raise Lfm2DenseBudgetFoldError(
            f"{label} does not expose one C-channel ShortConv circuit."
        )
    return _ShortConvPhysicalGeometry(
        internal_channels=internal_channels,
        residual_width=residual_width,
        fir_length=int(kernel.shape[2]),
        writer_rank=writer_rank,
    )


def _short_conv_dense_writer_action(
    short_conv: Any,
    geometry: _ShortConvPhysicalGeometry,
    *,
    label: str,
) -> Any:
    """Compose either writer topology into its logical dense ``[H,C]`` action."""

    torch = _torch()
    writer = short_conv.out_proj
    if geometry.writer_rank is None:
        value = writer.weight.detach()
    else:
        if type(writer) is not torch.nn.Sequential or len(writer) != 2:
            raise Lfm2DenseBudgetFoldError(
                f"{label} factor writer changed after geometry authentication."
            )
        value = writer[1].weight.detach().to(device="cpu", dtype=torch.float64) @ (
            writer[0].weight.detach().to(device="cpu", dtype=torch.float64)
        )
    expected = (geometry.residual_width, geometry.internal_channels)
    if tuple(value.shape) != expected or not bool(torch.isfinite(value).all()):
        raise Lfm2DenseBudgetFoldError(
            f"{label} composed dense writer action is invalid."
        )
    return value


def _short_conv_writer_bias(
    short_conv: Any,
    geometry: _ShortConvPhysicalGeometry,
    *,
    label: str,
) -> Any:
    writer = short_conv.out_proj
    if geometry.writer_rank is None:
        return writer.bias
    if any(module.bias is not None for module in writer):
        raise Lfm2DenseBudgetFoldError(
            f"{label} factor writer cannot hide affine bias state."
        )
    return None


def _topology_fingerprint(model: Any) -> str:
    parameters = tuple(model.named_parameters(recurse=True, remove_duplicate=False))
    aliases: dict[int, list[str]] = {}
    for name, parameter in parameters:
        aliases.setdefault(id(parameter), []).append(name)
    alias_group = {
        parameter_id: index
        for index, parameter_id in enumerate(
            sorted(
                aliases,
                key=lambda value: tuple(sorted(aliases[value])),
            )
        )
    }
    return canonical_sha256(
        {
            "schema": "neural-forge-lfm2-live-parameter-topology-v1",
            "parameters": [
                {
                    "name": name,
                    "shape": [int(size) for size in parameter.shape],
                    "dtype": str(parameter.dtype),
                    "layout": str(parameter.layout),
                    "requires_grad": bool(parameter.requires_grad),
                    "alias_group": alias_group[id(parameter)],
                }
                for name, parameter in parameters
            ],
        }
    )


def _state_snapshot(model: Any) -> tuple[tuple[str, Any], ...]:
    return tuple(
        (
            name,
            value.detach().to(device="cpu").contiguous().clone(),
        )
        for name, value in sorted(model.state_dict().items())
    )


def _restore_state(model: Any, snapshot: Sequence[tuple[str, Any]]) -> None:
    torch = _torch()
    current = model.state_dict()
    saved = dict(snapshot)
    if set(current) != set(saved):
        raise Lfm2DenseBudgetFoldError(
            "Dense child state keys changed before rollback."
        )
    with torch.no_grad():
        for name, value in current.items():
            source = saved[name]
            if tuple(value.shape) != tuple(source.shape) or value.dtype != source.dtype:
                raise Lfm2DenseBudgetFoldError(
                    "Dense child state shape/dtype changed before rollback."
                )
            value.copy_(source.to(device=value.device, dtype=value.dtype))


def _parameter_snapshot(model: Any) -> tuple[tuple[str, Any], ...]:
    return tuple(
        (
            name,
            parameter.detach().to(device="cpu").contiguous().clone(),
        )
        for name, parameter in sorted(
            model.named_parameters(recurse=True, remove_duplicate=False)
        )
    )


def _buffer_snapshot(model: Any) -> tuple[tuple[str, Any], ...]:
    return tuple(
        (
            name,
            buffer.detach().to(device="cpu").contiguous().clone(),
        )
        for name, buffer in sorted(
            model.named_buffers(recurse=True, remove_duplicate=False)
        )
    )


def _assert_buffer_snapshot_equal(
    before: Sequence[tuple[str, Any]],
    after: Sequence[tuple[str, Any]],
) -> None:
    torch = _torch()
    left = dict(before)
    right = dict(after)
    if set(left) != set(right) or any(
        not torch.equal(left[name], right[name]) for name in left
    ):
        raise Lfm2DenseBudgetFoldError(
            "Component diagnostic refinement changed unowned model buffers."
        )


def _tensor_sha256(value: Any) -> str:
    tensor = value.detach().to(device="cpu").contiguous()
    digest = hashlib.sha256()
    digest.update(str(tuple(int(size) for size in tensor.shape)).encode("ascii"))
    digest.update(str(tensor.dtype).encode("ascii"))
    digest.update(memoryview(tensor.reshape(-1).view(_torch().uint8).numpy()))
    return digest.hexdigest()


def _component_stage_assignments(
    dispatch: AuthenticatedWholeChildComponentDispatch,
) -> tuple[tuple[str, str], ...]:
    strategy_stages: dict[str, str] = {}
    for fingerprint, strategy in dispatch.strategies:
        configuration = dict(strategy.configuration)
        if set(configuration) != {LFM2_COMPONENT_FOLD_STAGE_CONFIGURATION_KEY}:
            raise Lfm2DenseBudgetFoldError(
                "LFM2 production diagnostics accept only the explicit component "
                "fold-stage strategy configuration."
            )
        stage = configuration[LFM2_COMPONENT_FOLD_STAGE_CONFIGURATION_KEY]
        if stage not in {
            LFM2_COMPONENT_STRUCTURAL_STAGE,
            LFM2_COMPONENT_CLOSED_LOOP_STAGE,
        }:
            raise Lfm2DenseBudgetFoldError(
                "LFM2 component fold stage must select structural transport or "
                "cached closed-loop refinement."
            )
        strategy_stages[fingerprint] = str(stage)
    if len(set(strategy_stages.values())) != 2:
        raise Lfm2DenseBudgetFoldError(
            "LFM2 diagnostic strategies must execute distinct production stages."
        )
    return tuple(
        (path, strategy_stages[fingerprint])
        for path, fingerprint in dispatch.parameter_strategy_fingerprints
    )


def _compose_component_stage_parameters(
    model: Any,
    *,
    path_stages: Mapping[str, str],
    structural_snapshot: Sequence[tuple[str, Any]],
    closed_loop_snapshot: Sequence[tuple[str, Any]],
) -> None:
    torch = _torch()
    structural = dict(structural_snapshot)
    closed_loop = dict(closed_loop_snapshot)
    parameters = tuple(model.named_parameters(recurse=True, remove_duplicate=False))
    names = {name for name, _parameter in parameters}
    if (
        names != set(path_stages)
        or names != set(structural)
        or names != set(closed_loop)
    ):
        raise Lfm2DenseBudgetFoldError(
            "Component dispatch snapshots differ from live whole-child ownership."
        )
    aliases: dict[int, list[tuple[str, Any]]] = {}
    for name, parameter in parameters:
        aliases.setdefault(id(parameter), []).append((name, parameter))
    with torch.no_grad():
        for values in aliases.values():
            stages = {path_stages[name] for name, _parameter in values}
            if len(stages) != 1:
                raise Lfm2DenseBudgetFoldError(
                    "Aliased target parameter paths received different fold stages."
                )
            stage = stages.pop()
            source_snapshot = (
                structural if stage == LFM2_COMPONENT_STRUCTURAL_STAGE else closed_loop
            )
            first_name, parameter = values[0]
            source = source_snapshot[first_name]
            if tuple(source.shape) != tuple(parameter.shape):
                raise Lfm2DenseBudgetFoldError(
                    "Component dispatch changed target parameter geometry."
                )
            parameter.copy_(source.to(device=parameter.device, dtype=parameter.dtype))
            parameter.grad = None
            for alias_name, _alias in values[1:]:
                if not torch.equal(source_snapshot[alias_name], source):
                    raise Lfm2DenseBudgetFoldError(
                        "Aliased component snapshots contain different values."
                    )


def _component_operator_names(semantics: Sequence[str]) -> tuple[str, ...]:
    operators = set()
    for semantic in semantics:
        if semantic.startswith("attention_"):
            operators.add("gqa_rope_residual_attention_fold")
        elif semantic.startswith("mlp_"):
            operators.add("coupled_swiglu_feature_fold")
        elif semantic == "state_mixer":
            operators.add("coupled_short_conv_channel_fold")
        elif semantic in {"token_embedding", "output_head"}:
            operators.add("token_vocabulary_interface_fold")
        elif semantic == "normalization":
            operators.add("residual_diagonal_norm_fold")
        else:
            operators.add("topology_preservation")
    return tuple(sorted(operators))


def _component_dispatch_execution_report(
    dispatch: AuthenticatedWholeChildComponentDispatch,
    model: Any,
    *,
    path_stages: Mapping[str, str],
    structural_snapshot: Sequence[tuple[str, Any]],
    closed_loop_snapshot: Sequence[tuple[str, Any]] | None,
    exact_target_unique_parameters: int,
) -> dict[str, Any]:
    torch = _torch()
    structural = dict(structural_snapshot)
    closed_loop = (
        structural if closed_loop_snapshot is None else dict(closed_loop_snapshot)
    )
    final = dict(_parameter_snapshot(model))
    if set(final) != set(path_stages) or set(final) != set(structural):
        raise Lfm2DenseBudgetFoldError(
            "Component execution report lost whole-child path ownership."
        )
    changed_between_stages = {
        path for path in final if not torch.equal(structural[path], closed_loop[path])
    }
    for path, stage in path_stages.items():
        expected = (
            structural[path]
            if stage == LFM2_COMPONENT_STRUCTURAL_STAGE
            else closed_loop[path]
        )
        if not torch.equal(final[path], expected):
            raise Lfm2DenseBudgetFoldError(
                "Final diagnostic parameter differs from its assigned fold stage."
            )
    focus_paths = set(dispatch.focused_parameter_paths)
    focus_changed = focus_paths.intersection(changed_between_stages)
    if dispatch.binding.focus_scope_id is not None and not focus_changed:
        raise Lfm2DenseBudgetFoldError(
            "Focused LFM2 production strategy installed no distinct learned-state "
            "delta; this component diagnostic is not executable."
        )

    strategy_by_path = dispatch.parameter_strategy_by_path
    component_actions = []
    parameterized_component_ids = set()
    for component in dispatch.components:
        if not component.parameter_paths:
            continue
        parameterized_component_ids.add(component.component_id)
        fingerprints = {strategy_by_path[path] for path in component.parameter_paths}
        stages = {path_stages[path] for path in component.parameter_paths}
        if len(fingerprints) != 1 or len(stages) != 1:
            raise Lfm2DenseBudgetFoldError(
                "One discovered component was split across production strategies."
            )
        fingerprint = fingerprints.pop()
        stage = stages.pop()
        parameter_state = {
            path: _tensor_sha256(final[path]) for path in component.parameter_paths
        }
        component_actions.append(
            {
                "component_id": component.component_id,
                "semantics": list(component.semantics),
                "strategy_fingerprint": fingerprint,
                "fold_stage": stage,
                "production_fold_operators": list(
                    _component_operator_names(component.semantics)
                ),
                "target_parameter_paths": list(component.parameter_paths),
                "target_storage_groups": list(component.storage_groups),
                "final_parameter_state_sha256": canonical_sha256(parameter_state),
                "stage_delta_parameter_path_count": len(
                    set(component.parameter_paths).intersection(changed_between_stages)
                ),
                "executor_action_performed": True,
            }
        )
    if parameterized_component_ids != {
        value.component_id for value in dispatch.components if value.parameter_paths
    }:
        raise Lfm2DenseBudgetFoldError(
            "Component dispatch did not execute every learned child component."
        )
    unique_parameters = {
        id(parameter)
        for _name, parameter in model.named_parameters(
            recurse=True, remove_duplicate=False
        )
    }
    if sum(parameter.numel() for parameter in model.parameters()) != (
        exact_target_unique_parameters
    ) or len(unique_parameters) != len(tuple(model.parameters())):
        raise Lfm2DenseBudgetFoldError(
            "Component execution changed exact dense parameter accounting."
        )
    path_receipt = {
        path: {
            "strategy_fingerprint": strategy_by_path[path],
            "fold_stage": path_stages[path],
            "final_state_sha256": _tensor_sha256(final[path]),
        }
        for path in sorted(final)
    }
    structural_nodes = tuple(
        sorted(
            node
            for component in dispatch.components
            if not component.parameter_paths
            for node in component.node_ids
        )
    )
    body = {
        "schema": LFM2_COMPONENT_DISPATCH_EXECUTION_SCHEMA,
        "binding": dispatch.binding.as_dict(),
        "dispatch_sha256": dispatch.dispatch_sha256,
        "exact_target_unique_parameters": exact_target_unique_parameters,
        "complete_parameter_path_coverage": True,
        "parameter_path_count": len(path_receipt),
        "parameter_path_execution_receipt_sha256": canonical_sha256(path_receipt),
        "actual_executor_action_count": len(component_actions),
        "actual_executor_actions": component_actions,
        "structural_nodes_preserved": list(structural_nodes),
        "structural_topology_preserved": True,
        "closed_loop_stage_materialized": closed_loop_snapshot is not None,
        "stage_delta_parameter_path_count": len(changed_between_stages),
        "stage_delta_parameter_paths_sha256": canonical_sha256(
            sorted(changed_between_stages)
        ),
        "focus_parameter_path_count": len(focus_paths),
        "focus_parameter_paths_sha256": canonical_sha256(sorted(focus_paths)),
        "focus_changed_parameter_path_count": len(focus_changed),
        "focus_changed_parameter_paths_sha256": canonical_sha256(sorted(focus_changed)),
        "all_parameters_match_assigned_production_stage": True,
        "parent_forward_calls": 0,
        "training_steps": 0,
        "optimizer_steps": 0,
        "backward_calls": 0,
    }
    return {**body, "execution_sha256": canonical_sha256(body)}


def _dense_basis(mapping: Any, *, dtype: Any) -> Any:
    source_width = _positive_int(
        getattr(mapping, "source_width", None),
        "coordinate_map.source_width",
    )
    target_width = _positive_int(
        getattr(mapping, "target_width", None),
        "coordinate_map.target_width",
    )
    materialize = getattr(mapping, "materialize_dense", None)
    if not callable(materialize):
        raise Lfm2DenseBudgetFoldError(
            "Residual coordinate map cannot materialize its dense basis."
        )
    result = materialize(
        max_elements=source_width * target_width,
        dtype=dtype,
        device="cpu",
    )
    if tuple(result.shape) != (source_width, target_width):
        raise Lfm2DenseBudgetFoldError("Residual coordinate basis has the wrong shape.")
    return result


def _transport_diagonal(mapping: Any, source: Any) -> Any:
    torch = _torch()
    basis = _dense_basis(mapping, dtype=torch.float64)
    value = source.detach().to(device="cpu", dtype=torch.float64).reshape(-1)
    if int(value.numel()) != int(mapping.source_width):
        raise Lfm2DenseBudgetFoldError(
            "Diagonal source width differs from the residual coordinate map."
        )
    return (basis.square().T @ value).contiguous()


def _transport_feature_diagonal(feature_map: Any, source: Any) -> Any:
    torch = _torch()
    basis = feature_map.materialize_dense(
        max_elements=feature_map.source_width * feature_map.target_width,
        dtype=torch.float64,
        device="cpu",
    )
    value = source.detach().to(device="cpu", dtype=torch.float64).reshape(-1)
    if int(value.numel()) != feature_map.source_width:
        raise Lfm2DenseBudgetFoldError(
            "Feature-diagonal source width differs from its fold map."
        )
    return (basis.square().T @ value).contiguous()


def _transport_depthwise_kernel(mapping: Any, source: Any) -> Any:
    torch = _torch()
    value = source.detach().to(device="cpu", dtype=torch.float64)
    if value.ndim != 2 or int(value.shape[0]) != int(mapping.source_width):
        raise Lfm2DenseBudgetFoldError(
            "Depthwise FIR kernel must be [source_channels, taps]."
        )
    basis = _dense_basis(mapping, dtype=torch.float64)
    return (basis.square().T @ value).contiguous()


def _copy_parameter(
    target: Any,
    value: Any,
    *,
    name: str,
    written: set[int],
) -> None:
    torch = _torch()
    if tuple(target.shape) != tuple(value.shape):
        raise Lfm2DenseBudgetFoldError(
            f"Folded shape mismatch for {name}: "
            f"{tuple(value.shape)} != {tuple(target.shape)}."
        )
    if not bool(torch.isfinite(value.detach()).all()):
        raise Lfm2DenseBudgetFoldError(f"Folded value for {name} is non-finite.")
    target.copy_(value.to(device=target.device, dtype=target.dtype))
    target.grad = None
    written.add(id(target))


def _copy_optional_bias(
    source: Any,
    target: Any,
    value: Any,
    *,
    name: str,
    written: set[int],
) -> None:
    if (source is None) != (target is None):
        raise Lfm2DenseBudgetFoldError(
            f"Source/target bias presence differs for {name}."
        )
    if source is not None:
        _copy_parameter(target, value, name=name, written=written)


@dataclass(frozen=True, slots=True)
class _ShortConvOutputActionEvidence:
    """Authenticated cached output-action covariance in target coordinates."""

    layer_index: int
    target_hidden_size: int
    sampled_output_row_count: int
    parent_cache_key: str
    selective_session_sha256: str
    selected_payload_sha256s: tuple[str, ...]
    covariance_sha256: str
    evidence_sha256: str
    covariance: Any = field(repr=False, compare=False)

    def verify(self) -> "_ShortConvOutputActionEvidence":
        torch = _torch()
        if (
            isinstance(self.layer_index, bool)
            or not isinstance(self.layer_index, int)
            or self.layer_index < 0
        ):
            raise Lfm2DenseBudgetFoldError(
                "ShortConv output-action layer index must be nonnegative."
            )
        width = _positive_int(
            self.target_hidden_size,
            "ShortConv output-action target hidden size",
        )
        rows = _positive_int(
            self.sampled_output_row_count,
            "ShortConv sampled output-action row count",
        )
        cache_key = _digest(self.parent_cache_key, "parent_cache_key")
        session_sha256 = _digest(
            self.selective_session_sha256,
            "selective_session_sha256",
        )
        payloads = tuple(self.selected_payload_sha256s)
        if not payloads or any(
            _digest(value, "selected_payload_sha256") != value
            for value in payloads
        ):
            raise Lfm2DenseBudgetFoldError(
                "ShortConv output-action evidence needs authenticated payloads."
            )
        covariance = self.covariance
        if (
            not isinstance(covariance, torch.Tensor)
            or covariance.device.type != "cpu"
            or covariance.dtype != torch.float64
            or covariance.layout != torch.strided
            or tuple(covariance.shape) != (width, width)
            or not covariance.is_contiguous()
            or covariance.requires_grad
            or covariance.grad_fn is not None
            or not bool(torch.isfinite(covariance).all())
            or not torch.equal(covariance, covariance.T)
        ):
            raise Lfm2DenseBudgetFoldError(
                "ShortConv output-action covariance is not sealed dense CPU FP64."
            )
        covariance_sha256 = _digest(
            self.covariance_sha256,
            "covariance_sha256",
        )
        if _tensor_sha256(covariance) != covariance_sha256:
            raise Lfm2DenseBudgetFoldError(
                "ShortConv output-action covariance changed after sealing."
            )
        body = {
            "schema": SHORT_CONV_OUTPUT_ACTION_EVIDENCE_SCHEMA,
            "layer_index": self.layer_index,
            "target_hidden_size": width,
            "sampled_output_row_count": rows,
            "parent_cache_key": cache_key,
            "selective_session_sha256": session_sha256,
            "selected_payload_sha256s": list(payloads),
            "covariance_sha256": covariance_sha256,
            "parent_forward_calls": 0,
            "training_steps": 0,
        }
        if canonical_sha256(body) != _digest(
            self.evidence_sha256,
            "output-action evidence SHA-256",
        ):
            raise Lfm2DenseBudgetFoldError(
                "ShortConv output-action evidence seal is invalid."
            )
        return self

    def as_dict(self) -> dict[str, Any]:
        self.verify()
        return {
            "schema": SHORT_CONV_OUTPUT_ACTION_EVIDENCE_SCHEMA,
            "layer_index": self.layer_index,
            "target_hidden_size": self.target_hidden_size,
            "sampled_output_row_count": self.sampled_output_row_count,
            "parent_cache_key": self.parent_cache_key,
            "selective_session_sha256": self.selective_session_sha256,
            "selected_payload_sha256s": list(self.selected_payload_sha256s),
            "covariance_sha256": self.covariance_sha256,
            "evidence_sha256": self.evidence_sha256,
            "parent_forward_calls": 0,
            "training_steps": 0,
        }


def _seal_short_conv_output_action_evidence(
    *,
    layer_index: int,
    target_hidden_size: int,
    sampled_output_row_count: int,
    parent_cache_key: str,
    selective_session_sha256: str,
    selected_payload_sha256s: Sequence[str],
    covariance: Any,
) -> _ShortConvOutputActionEvidence:
    torch = _torch()
    value = (
        covariance.detach()
        .to(device="cpu", dtype=torch.float64)
        .contiguous()
        .clone()
    )
    value = (0.5 * (value + value.T)).contiguous()
    covariance_sha256 = _tensor_sha256(value)
    payloads = tuple(selected_payload_sha256s)
    body = {
        "schema": SHORT_CONV_OUTPUT_ACTION_EVIDENCE_SCHEMA,
        "layer_index": layer_index,
        "target_hidden_size": target_hidden_size,
        "sampled_output_row_count": sampled_output_row_count,
        "parent_cache_key": parent_cache_key,
        "selective_session_sha256": selective_session_sha256,
        "selected_payload_sha256s": list(payloads),
        "covariance_sha256": covariance_sha256,
        "parent_forward_calls": 0,
        "training_steps": 0,
    }
    return _ShortConvOutputActionEvidence(
        layer_index=layer_index,
        target_hidden_size=target_hidden_size,
        sampled_output_row_count=sampled_output_row_count,
        parent_cache_key=parent_cache_key,
        selective_session_sha256=selective_session_sha256,
        selected_payload_sha256s=payloads,
        covariance_sha256=covariance_sha256,
        evidence_sha256=canonical_sha256(body),
        covariance=value,
    ).verify()


def _collect_short_conv_output_action_evidence(
    selective_session: Lfm2CircuitTraceSelectiveAuthenticatedSession,
    *,
    factor_layer_indices: Sequence[int],
    residual_mapping: Any,
    progress: _Lfm2DenseFoldProgress | None = None,
) -> dict[int, _ShortConvOutputActionEvidence]:
    """Consume only cached ShortConv output actions; never execute the parent."""

    if not isinstance(selective_session, SEALED_EVIDENCE_SESSION_TYPES):
        raise Lfm2DenseBudgetFoldError(
            "ShortConv action evidence requires an authenticated selective session."
        )
    indices = tuple(sorted(set(factor_layer_indices)))
    if any(
        isinstance(index, bool) or not isinstance(index, int) or index < 0
        for index in indices
    ):
        raise Lfm2DenseBudgetFoldError(
            "Factor-writer layer indices must be canonical nonnegative integers."
        )
    if not indices:
        return {}
    torch = _torch()
    target_width = _positive_int(
        getattr(residual_mapping, "target_width", None),
        "residual_mapping.target_width",
    )
    source_width = _positive_int(
        getattr(residual_mapping, "source_width", None),
        "residual_mapping.source_width",
    )
    covariances = {
        index: torch.zeros((target_width, target_width), dtype=torch.float64)
        for index in indices
    }
    row_counts = {index: 0 for index in indices}
    payload_sha256s: dict[int, list[str]] = {index: [] for index in indices}
    suffixes = {
        f".layer.{index:03d}.short_conv.o": index for index in indices
    }
    if progress is not None:
        progress.emit(
            "dense_structural_short_conv_action_evidence_started",
            cache_batch_count=len(selective_session.batch_references),
            factor_writer_layer_count=len(indices),
            target_hidden_size=target_width,
        )
    selective_session.verify()
    selected_payload_count = 0
    selected_tensor_count = 0
    for batch_ordinal, reference in enumerate(selective_session.batch_references):
        selected: dict[str, int] = {}
        for name in reference.ordered_tensor_names:
            for suffix, index in suffixes.items():
                if name.endswith(suffix):
                    selected[name] = index
                    break
        if not selected:
            continue
        ordered_names = tuple(sorted(selected))
        payload = selective_session.load_selected_tensors(
            reference.index,
            ordered_names,
        )
        try:
            for name in ordered_names:
                index = selected[name]
                action = payload.tensors[name]
                if (
                    not isinstance(action, torch.Tensor)
                    or action.ndim < 2
                    or int(action.shape[-1]) != source_width
                    or not torch.is_floating_point(action)
                    or torch.is_complex(action)
                    or not bool(torch.isfinite(action).all())
                ):
                    raise Lfm2DenseBudgetFoldError(
                        f"Cached ShortConv output action {name!r} is invalid."
                    )
                target_action = residual_mapping.encode(
                    action.detach().to(device="cpu", dtype=torch.float64)
                ).reshape(-1, target_width)
                covariances[index].add_(target_action.T @ target_action)
                row_counts[index] += int(target_action.shape[0])
                payload_sha256s[index].append(
                    canonical_sha256(
                        {
                            "batch_index": reference.index,
                            "input_sha256": reference.input_sha256,
                            "tensor_name": name,
                            "source_tensor_sha256": _tensor_sha256(action),
                            "selected_payload_sha256": payload.selection_sha256,
                        }
                    )
                )
                del action, target_action
        finally:
            selective_session.release_selected_tensors(payload)
            del payload
        selected_payload_count += 1
        selected_tensor_count += len(ordered_names)
        cleanup: dict[str, JsonScalar] = {}
        if (
            selected_payload_count % 16 == 0
            or batch_ordinal + 1 == len(selective_session.batch_references)
        ):
            cleanup = _release_cpu_allocator_retention(
                caller_declared_release_plan_units=len(ordered_names) + 1,
            )
        if progress is not None:
            progress.emit(
                "dense_structural_short_conv_action_evidence_progress",
                cache_batch_index=reference.index,
                cache_batches_scanned=batch_ordinal + 1,
                cache_batch_count=len(selective_session.batch_references),
                selected_payload_count=selected_payload_count,
                selected_tensor_count=selected_tensor_count,
                **cleanup,
            )
    selective_session.verify()
    result = {}
    for index in indices:
        if row_counts[index] <= 0:
            continue
        result[index] = _seal_short_conv_output_action_evidence(
            layer_index=index,
            target_hidden_size=target_width,
            sampled_output_row_count=row_counts[index],
            parent_cache_key=selective_session.cache_key,
            selective_session_sha256=selective_session.evidence_sha256,
            selected_payload_sha256s=payload_sha256s[index],
            covariance=covariances[index],
        )
    covariances.clear()
    row_counts.clear()
    payload_sha256s.clear()
    cleanup = _release_cpu_allocator_retention(
        caller_declared_release_plan_units=len(indices) * 3,
    )
    if progress is not None:
        progress.emit(
            "dense_structural_short_conv_action_evidence_completed",
            cache_batch_count=len(selective_session.batch_references),
            selected_payload_count=selected_payload_count,
            selected_tensor_count=selected_tensor_count,
            evidence_layer_count=len(result),
            **cleanup,
        )
    return result


def _canonicalize_paired_factor_signs(decoder: Any, encoder: Any) -> None:
    """Remove the paired sign ambiguity without changing ``decoder @ encoder``."""

    torch = _torch()
    for index in range(int(encoder.shape[0])):
        row = encoder[index]
        pivot = int(torch.argmax(row.abs()).item())
        value = float(row[pivot].item())
        if value == 0.0:
            column = decoder[:, index]
            pivot = int(torch.argmax(column.abs()).item())
            value = float(column[pivot].item())
        if value < 0.0:
            encoder[index].neg_()
            decoder[:, index].neg_()


def _factorize_short_conv_dense_writer_action(
    dense_writer_action: Any,
    writer_rank: int,
    *,
    output_action_evidence: _ShortConvOutputActionEvidence | None = None,
) -> tuple[Any, Any, dict[str, Any]]:
    """Factor one folded dense writer by cached action subspace or exact SVD."""

    torch = _torch()
    dense = (
        dense_writer_action.detach()
        .to(device="cpu", dtype=torch.float64)
        .contiguous()
        .clone()
    )
    if (
        dense.ndim != 2
        or any(int(size) <= 0 for size in dense.shape)
        or not bool(torch.isfinite(dense).all())
    ):
        raise Lfm2DenseBudgetFoldError(
            "Folded ShortConv dense writer action must be one finite matrix."
        )
    hidden, internal = (int(size) for size in dense.shape)
    rank = _positive_int(writer_rank, "short_conv_writer_rank")
    if rank > min(hidden, internal):
        raise Lfm2DenseBudgetFoldError(
            "ShortConv writer rank exceeds its dense action dimensions."
        )
    dense_norm = float(torch.linalg.vector_norm(dense).item())
    evidence_report: Mapping[str, Any] | None = None
    if dense_norm == 0.0:
        encoder = torch.zeros((rank, internal), dtype=torch.float64)
        decoder = torch.zeros((hidden, rank), dtype=torch.float64)
        method = "deterministic_structural_zero_dense_action"
    elif output_action_evidence is not None:
        evidence = output_action_evidence.verify()
        if evidence.target_hidden_size != hidden:
            raise Lfm2DenseBudgetFoldError(
                "Cached ShortConv output-action width differs from dense writer."
            )
        covariance = evidence.covariance
        action_energy = float(torch.trace(covariance).item())
        if action_energy > 0.0:
            eigenvalues, eigenvectors = torch.linalg.eigh(covariance)
            order = torch.argsort(eigenvalues, descending=True, stable=True)
            decoder = eigenvectors[:, order[:rank]].contiguous()
            encoder = (decoder.T @ dense).contiguous()
            _canonicalize_paired_factor_signs(decoder, encoder)
            method = "authenticated_cached_output_action_eigenspace_projection"
            evidence_report = evidence.as_dict()
        else:
            output_action_evidence = None
    if dense_norm != 0.0 and output_action_evidence is None:
        decoder_basis, singular_values, encoder = torch.linalg.svd(
            dense,
            full_matrices=False,
        )
        decoder = (
            decoder_basis[:, :rank] * singular_values[:rank].unsqueeze(0)
        ).contiguous()
        encoder = encoder[:rank, :].contiguous()
        _canonicalize_paired_factor_signs(decoder, encoder)
        method = "deterministic_structural_cpu_fp64_exact_svd_truncation"
    reconstructed = (decoder @ encoder).contiguous()
    residual = dense - reconstructed
    residual_norm = float(torch.linalg.vector_norm(residual).item())
    relative_error = 0.0 if dense_norm == 0.0 else residual_norm / dense_norm
    body: dict[str, Any] = {
        "schema": SHORT_CONV_FACTOR_WRITER_SCHEMA,
        "method": method,
        "writer_rank": rank,
        "dense_writer_shape": [hidden, internal],
        "encoder_shape": [rank, internal],
        "decoder_shape": [hidden, rank],
        "dense_writer_action_sha256": _tensor_sha256(dense),
        "encoder_sha256": _tensor_sha256(encoder),
        "decoder_sha256": _tensor_sha256(decoder),
        "reconstructed_writer_action_sha256": _tensor_sha256(reconstructed),
        "dense_writer_frobenius_norm": dense_norm,
        "residual_frobenius_norm": residual_norm,
        "relative_frobenius_error": relative_error,
        "cached_output_action_evidence_used": evidence_report is not None,
        "cached_output_action_evidence": evidence_report,
        "calculation_device": "cpu",
        "calculation_dtype": "float64",
        "deterministic": True,
        "optimization_used": False,
        "training_used": False,
        "optimizer_steps": 0,
        "backward_calls": 0,
        "parent_forward_calls": 0,
    }
    return encoder, decoder, {
        **body,
        "factorization_sha256": canonical_sha256(body),
    }


@dataclass(frozen=True, slots=True)
class Lfm2DenseBudgetFoldConfig:
    """Residual-basis selection plus optional cached closed-loop refinement."""

    residual_basis_mode: str = "weight_complete"
    body_reclosure_mode: str = LFM2_BODY_RECLOSURE_DISABLED
    body_coordinate_completion_recipe: str = "bridge-procrustes-isometric"
    run_closed_loop: bool = True
    circuit_validation_fraction: float = 0.25
    circuit_split_seed: str = "lfm2-dense-budget-circuit-basis-v1"
    circuit_max_rows_per_block: int = 512
    minimum_heldout_retained_energy_fraction: float = 0.0
    vocabulary_margin_observability: bool = False
    vocabulary_margin_top_k: int = 8
    vocabulary_margin_floor_fraction: float = 0.05
    streaming_vocabulary_margin_v2: bool = False
    streaming_vocabulary_margin_pair_chunk_size: int = 256
    vocabulary_margin_candidate_gate_enabled: bool = False
    vocabulary_margin_candidate_replay_mode: str = CHILD_REPLAY_SINGLE_PASS_CAUSAL_MODE
    vocabulary_margin_candidate_minimum_sign_agreement_fraction: float = 0.9
    vocabulary_margin_candidate_minimum_top_competitor_nonnegative_fraction: float = 0.9
    vocabulary_margin_candidate_minimum_all_top_k_nonnegative_fraction: float = 0.9
    vocabulary_margin_candidate_minimum_exact_top1_agreement_fraction: float = 0.9
    closed_loop_adapter_config: Lfm2DynamicClosedLoopAdapterConfig = field(
        default_factory=Lfm2DynamicClosedLoopAdapterConfig
    )
    closed_loop_compiler_config: ClosedLoopCompilerConfig = field(
        default_factory=ClosedLoopCompilerConfig
    )
    # Execution-only multi-device child-replay sharding.  ``None`` is the
    # serial path; every honoured shard plan seals identical bytes, so this
    # knob changes the wall clock and nothing else (NOTES-2B).
    closed_loop_replay_devices: tuple[str, ...] | None = None
    child_replay_phase_cache_context: (
        DynamicChildReplayPhaseCacheContext | None
    ) = field(default=None, compare=False, repr=False)
    macro_cell_attractor_gate_config: Lfm2MacroCellAttractorGateConfig | None = None
    restart_capsule_directory: Path | None = None
    restart_capsule_rotation_keep: int = DEFAULT_RESTART_CAPSULE_ROTATION_KEEP
    # Opt-in post-output-interface capsule: a crash in the terminal phase or the
    # evaluators otherwise costs the whole transaction, not just that window.
    restart_capsule_publish_terminal: bool = False
    resume_from_restart_capsule: Path | None = None

    def __post_init__(self) -> None:
        mode = _text(self.residual_basis_mode, "residual_basis_mode")
        if mode not in {"weight_complete", "circuit_balanced"}:
            raise Lfm2DenseBudgetFoldError(
                "residual_basis_mode must be weight_complete or circuit_balanced."
            )
        object.__setattr__(self, "residual_basis_mode", mode)
        body_mode = _text(
            self.body_reclosure_mode,
            "body_reclosure_mode",
        ).lower()
        if body_mode not in LFM2_BODY_RECLOSURE_MODES:
            raise Lfm2DenseBudgetFoldError(
                "body_reclosure_mode must be disabled or moving_gauge_v3."
            )
        object.__setattr__(self, "body_reclosure_mode", body_mode)
        completion_recipe = _text(
            self.body_coordinate_completion_recipe,
            "body_coordinate_completion_recipe",
        ).lower()
        if completion_recipe not in LFM2_BODY_GLOBAL_COORDINATE_COMPLETION_RECIPES:
            raise Lfm2DenseBudgetFoldError(
                "body_coordinate_completion_recipe is unsupported."
            )
        object.__setattr__(
            self,
            "body_coordinate_completion_recipe",
            completion_recipe,
        )
        if not isinstance(self.run_closed_loop, bool):
            raise Lfm2DenseBudgetFoldError("run_closed_loop must be boolean.")
        if (
            body_mode == LFM2_BODY_RECLOSURE_MOVING_GAUGE_V3
            and not self.run_closed_loop
        ):
            raise Lfm2DenseBudgetFoldError(
                "moving_gauge_v3 requires run_closed_loop=True."
            )
        fraction = float(self.circuit_validation_fraction)
        if not 0.0 < fraction < 1.0:
            raise Lfm2DenseBudgetFoldError(
                "circuit_validation_fraction must be within (0, 1)."
            )
        object.__setattr__(self, "circuit_validation_fraction", fraction)
        object.__setattr__(
            self,
            "circuit_split_seed",
            _text(self.circuit_split_seed, "circuit_split_seed"),
        )
        object.__setattr__(
            self,
            "circuit_max_rows_per_block",
            _positive_int(
                self.circuit_max_rows_per_block,
                "circuit_max_rows_per_block",
            ),
        )
        retained = float(self.minimum_heldout_retained_energy_fraction)
        if not 0.0 <= retained <= 1.0:
            raise Lfm2DenseBudgetFoldError(
                "minimum_heldout_retained_energy_fraction must be within [0, 1]."
            )
        object.__setattr__(
            self,
            "minimum_heldout_retained_energy_fraction",
            retained,
        )
        if not isinstance(self.vocabulary_margin_observability, bool):
            raise Lfm2DenseBudgetFoldError(
                "vocabulary_margin_observability must be boolean."
            )
        if self.vocabulary_margin_observability and mode != "circuit_balanced":
            raise Lfm2DenseBudgetFoldError(
                "vocabulary_margin_observability requires "
                "residual_basis_mode='circuit_balanced'."
            )
        object.__setattr__(
            self,
            "vocabulary_margin_top_k",
            _positive_int(
                self.vocabulary_margin_top_k,
                "vocabulary_margin_top_k",
            ),
        )
        margin_floor = float(self.vocabulary_margin_floor_fraction)
        if not 0.0 < margin_floor <= 1.0:
            raise Lfm2DenseBudgetFoldError(
                "vocabulary_margin_floor_fraction must be within (0, 1]."
            )
        object.__setattr__(
            self,
            "vocabulary_margin_floor_fraction",
            margin_floor,
        )
        if not isinstance(self.streaming_vocabulary_margin_v2, bool):
            raise Lfm2DenseBudgetFoldError(
                "streaming_vocabulary_margin_v2 must be boolean."
            )
        if (
            self.streaming_vocabulary_margin_v2
            and not self.vocabulary_margin_observability
        ):
            raise Lfm2DenseBudgetFoldError(
                "streaming_vocabulary_margin_v2 requires "
                "vocabulary_margin_observability=True."
            )
        object.__setattr__(
            self,
            "streaming_vocabulary_margin_pair_chunk_size",
            _positive_int(
                self.streaming_vocabulary_margin_pair_chunk_size,
                "streaming_vocabulary_margin_pair_chunk_size",
            ),
        )
        if not isinstance(
            self.vocabulary_margin_candidate_gate_enabled,
            bool,
        ):
            raise Lfm2DenseBudgetFoldError(
                "vocabulary_margin_candidate_gate_enabled must be boolean."
            )
        if (
            self.vocabulary_margin_candidate_gate_enabled
            and not self.vocabulary_margin_observability
        ):
            raise Lfm2DenseBudgetFoldError(
                "vocabulary_margin_candidate_gate_enabled requires "
                "vocabulary_margin_observability=True."
            )
        if not isinstance(
            self.vocabulary_margin_candidate_replay_mode,
            str,
        ) or self.vocabulary_margin_candidate_replay_mode not in {
            CHILD_REPLAY_PREFIX_BY_PREFIX_MODE,
            CHILD_REPLAY_SINGLE_PASS_CAUSAL_MODE,
        }:
            raise Lfm2DenseBudgetFoldError(
                "vocabulary_margin_candidate_replay_mode must be "
                "'prefix_by_prefix_canonical' or 'single_pass_causal'."
            )
        for attribute in (
            "vocabulary_margin_candidate_minimum_sign_agreement_fraction",
            ("vocabulary_margin_candidate_minimum_top_competitor_nonnegative_fraction"),
            ("vocabulary_margin_candidate_minimum_all_top_k_nonnegative_fraction"),
            ("vocabulary_margin_candidate_minimum_exact_top1_agreement_fraction"),
        ):
            object.__setattr__(
                self,
                attribute,
                _unit_fraction(getattr(self, attribute), attribute),
            )
        if not isinstance(
            self.closed_loop_adapter_config,
            Lfm2DynamicClosedLoopAdapterConfig,
        ):
            raise Lfm2DenseBudgetFoldError(
                "closed_loop_adapter_config has the wrong type."
            )
        if not isinstance(
            self.closed_loop_compiler_config,
            ClosedLoopCompilerConfig,
        ):
            raise Lfm2DenseBudgetFoldError(
                "closed_loop_compiler_config has the wrong type."
            )
        if (
            self.child_replay_phase_cache_context is not None
            and not isinstance(
                self.child_replay_phase_cache_context,
                DynamicChildReplayPhaseCacheContext,
            )
        ):
            raise Lfm2DenseBudgetFoldError(
                "child_replay_phase_cache_context has the wrong type."
            )
        self._resolve_closed_loop_replay_devices()
        if self.macro_cell_attractor_gate_config is not None and not isinstance(
            self.macro_cell_attractor_gate_config,
            Lfm2MacroCellAttractorGateConfig,
        ):
            raise Lfm2DenseBudgetFoldError(
                "macro_cell_attractor_gate_config has the wrong type."
            )
        if (
            self.macro_cell_attractor_gate_config is not None
            and not self.run_closed_loop
        ):
            raise Lfm2DenseBudgetFoldError(
                "macro-cell attractor gating requires run_closed_loop=True."
            )
        object.__setattr__(
            self,
            "restart_capsule_rotation_keep",
            _positive_int(
                self.restart_capsule_rotation_keep,
                "restart_capsule_rotation_keep",
            ),
        )
        if not isinstance(self.restart_capsule_publish_terminal, bool):
            raise Lfm2DenseBudgetFoldError(
                "restart_capsule_publish_terminal must be boolean."
            )
        for name in ("restart_capsule_directory", "resume_from_restart_capsule"):
            value = getattr(self, name)
            if value is None:
                continue
            if not isinstance(value, (str, Path)):
                raise Lfm2DenseBudgetFoldError(
                    f"{name} must be a filesystem path or None."
                )
            object.__setattr__(
                self,
                name,
                Path(value).expanduser().absolute(),
            )
        if (
            self.restart_capsule_directory is not None
            or self.resume_from_restart_capsule is not None
        ) and not self.run_closed_loop:
            raise Lfm2DenseBudgetFoldError(
                "Accepted-layer restart capsules only exist inside the cached "
                "closed-loop body fold; they require run_closed_loop=True."
            )
        if (
            self.resume_from_restart_capsule is not None
            and self.restart_capsule_directory is None
        ):
            raise Lfm2DenseBudgetFoldError(
                "Resuming from a restart capsule requires the restart-capsule "
                "directory the resumed run keeps writing to."
            )
    def _closed_loop_compiler_config_for_execution(
        self,
    ) -> ClosedLoopCompilerConfig:
        """Resolve execution policy without changing capsule identity policy."""

        resume_requested = self.resume_from_restart_capsule is not None
        terminal_only_requested = bool(
            resume_requested
            and self.closed_loop_compiler_config.allow_terminal_only_restart_resume
        )
        return replace(
            self.closed_loop_compiler_config,
            fold_body_reclosure=(
                self.body_reclosure_mode
                == LFM2_BODY_RECLOSURE_MOVING_GAUGE_V3
            ),
            allow_terminal_only_restart_resume=terminal_only_requested,
        )

    def _resolve_closed_loop_replay_devices(self) -> None:
        """Keep one source of truth for the opt-in replay shard request.

        The request may arrive either on this config or already on the
        adapter config it carries.  Both spellings are accepted, they must
        agree, and the adapter config always ends up holding the resolved
        request because the adapter is what performs the capture.
        """

        requested = self.closed_loop_replay_devices
        if requested is not None:
            if isinstance(requested, (str, bytes)) or not isinstance(
                requested,
                Sequence,
            ):
                raise Lfm2DenseBudgetFoldError(
                    "closed_loop_replay_devices must be a sequence of device "
                    "strings or None."
                )
            devices = []
            for entry in requested:
                if not isinstance(entry, str) or not entry.strip():
                    raise Lfm2DenseBudgetFoldError(
                        "closed_loop_replay_devices entries must be nonempty "
                        "device strings."
                    )
                devices.append(entry.strip())
            requested = tuple(devices) or None
        adapter_devices = self.closed_loop_adapter_config.replay_devices
        if requested is None:
            requested = adapter_devices
        elif adapter_devices is not None and adapter_devices != requested:
            raise Lfm2DenseBudgetFoldError(
                "closed_loop_replay_devices and the adapter config's "
                "replay_devices name different shard worker lists."
            )
        if requested is not None and not self.run_closed_loop:
            raise Lfm2DenseBudgetFoldError(
                "Multi-device child-replay sharding only applies to the "
                "cached closed-loop body fold; it requires "
                "run_closed_loop=True."
            )
        object.__setattr__(self, "closed_loop_replay_devices", requested)
        if requested != adapter_devices:
            object.__setattr__(
                self,
                "closed_loop_adapter_config",
                replace(
                    self.closed_loop_adapter_config,
                    replay_devices=requested,
                ),
            )


@dataclass(frozen=True, slots=True)
class Lfm2DenseBudgetFoldPlan:
    """Immutable audit report for one installed dense child candidate."""

    report: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not isinstance(self.report, Mapping):
            raise Lfm2DenseBudgetFoldError("report must be a mapping.")
        object.__setattr__(self, "report", MappingProxyType(dict(self.report)))

    @property
    def zero_gradient(self) -> bool:
        return bool(self.report["zero_gradient"])

    @property
    def seed_erasure_by_construction(self) -> bool:
        return bool(self.report["seed_erasure_by_construction"])

    def as_dict(self) -> dict[str, Any]:
        return dict(self.report)


def _build_residual_basis(
    parent_model: Any,
    parent_graph: ModelCircuitGraph,
    trace_cache: Lfm2CircuitTraceCache,
    target_width: int,
    config: Lfm2DenseBudgetFoldConfig,
    selective_session: Lfm2CircuitTraceSelectiveAuthenticatedSession | None = None,
    target_tokenizer_vocabulary_margin_binding: (
        Lfm2TargetTokenizerVocabularyMarginBinding | None
    ) = None,
    phase_cache_context: Lfm2BalancedBasisPhaseCacheContext | None = None,
    phase_cache_binding_provider: (
        Callable[[], Mapping[str, Mapping[str, Any]]] | None
    ) = None,
    autoregressive_hankel_observability: (
        Lfm2AutoregressiveHankelObservabilityResult
        | PrecomputedDownstreamObservability
        | None
    ) = None,
) -> Any:
    if config.residual_basis_mode == "weight_complete":
        return build_lfm2_weight_complete_basis(
            parent_model,
            target_width,
        )
    from .hf_lfm2_balanced_circuit_basis import (
        build_lfm2_circuit_balanced_basis,
    )

    def build_direct() -> Any:
        return build_lfm2_circuit_balanced_basis(
            parent_model,
            trace_cache,
            target_width,
            selective_session=selective_session,
            validation_fraction=config.circuit_validation_fraction,
            split_seed=config.circuit_split_seed,
            max_rows_per_block=config.circuit_max_rows_per_block,
            minimum_heldout_retained_energy_fraction=(
                config.minimum_heldout_retained_energy_fraction
            ),
            circuit_graph=parent_graph,
            vocabulary_margin_observability=(
                config.vocabulary_margin_observability
            ),
            vocabulary_margin_top_k=config.vocabulary_margin_top_k,
            vocabulary_margin_floor_fraction=(
                config.vocabulary_margin_floor_fraction
            ),
            streaming_vocabulary_margin_v2=(
                config.streaming_vocabulary_margin_v2
            ),
            streaming_vocabulary_margin_pair_chunk_size=(
                config.streaming_vocabulary_margin_pair_chunk_size
            ),
            target_tokenizer_vocabulary_margin_binding=(
                target_tokenizer_vocabulary_margin_binding
            ),
            autoregressive_hankel_observability=(
                autoregressive_hankel_observability
            ),
        )

    if phase_cache_context is None:
        return build_direct()
    build_request = Lfm2BalancedBasisPhaseBuildRequest(
        adapter_source_sha256=hashlib.sha256(
            Path(__file__).resolve(strict=True).read_bytes()
        ).hexdigest(),
        validation_fraction=config.circuit_validation_fraction,
        split_seed=config.circuit_split_seed,
        max_rows_per_block=config.circuit_max_rows_per_block,
        minimum_heldout_retained_energy_fraction=(
            config.minimum_heldout_retained_energy_fraction
        ),
        vocabulary_margin_observability=(
            config.vocabulary_margin_observability
        ),
        vocabulary_margin_top_k=config.vocabulary_margin_top_k,
        vocabulary_margin_floor_fraction=(
            config.vocabulary_margin_floor_fraction
        ),
        streaming_vocabulary_margin_v2=(
            config.streaming_vocabulary_margin_v2
        ),
        streaming_vocabulary_margin_pair_chunk_size=(
            config.streaming_vocabulary_margin_pair_chunk_size
        ),
        target_tokenizer_vocabulary_margin_binding=(
            target_tokenizer_vocabulary_margin_binding
        ),
        autoregressive_hankel_observability=(
            autoregressive_hankel_observability
        ),
    )
    return load_or_build_lfm2_circuit_balanced_basis(
        phase_cache_context,
        parent_model,
        trace_cache,
        target_width,
        circuit_graph=parent_graph,
        selective_session=selective_session,
        build_request=build_request,
        binding_provider=phase_cache_binding_provider,
        live_vocabulary_candidate_gate_required=(
            config.vocabulary_margin_candidate_gate_enabled
        ),
    )


def _candidate_replay_capture_config(
    trace_cache: Lfm2CircuitTraceCache,
) -> Lfm2CircuitTraceCaptureConfig:
    manifest_capture = trace_cache.manifest.get("capture")
    if not isinstance(manifest_capture, Mapping):
        raise Lfm2DenseBudgetFoldError(
            "The sealed parent cache omits its capture configuration."
        )
    try:
        return Lfm2CircuitTraceCaptureConfig(
            sample_last_tokens=int(manifest_capture.get("sample_last_tokens", 8)),
            max_decode_steps=int(manifest_capture.get("max_decode_steps", 32)),
            max_capture_bytes=int(
                manifest_capture.get(
                    "max_capture_bytes",
                    512 * 1024 * 1024,
                )
            ),
            logit_rtol=float(manifest_capture.get("logit_rtol", 1e-5)),
            logit_atol=float(manifest_capture.get("logit_atol", 1e-6)),
            require_top1_agreement=bool(
                manifest_capture.get("require_top1_agreement", True)
            ),
            decode_trace_mode=FULL_PREFIX_CANONICAL_TRACE_MODE,
        )
    except (TypeError, ValueError, OverflowError) as exc:
        raise Lfm2DenseBudgetFoldError(
            "The sealed parent cache has an invalid replay configuration."
        ) from exc


def _disabled_vocabulary_margin_candidate_gate_report() -> dict[str, Any]:
    body = {
        "schema": VOCABULARY_MARGIN_CANDIDATE_GATE_SCHEMA,
        "enabled": False,
        "gate_passed": None,
        "candidate_replay_capture_calls": 0,
        "actual_child_forward_calls": 0,
        "parent_forward_calls": 0,
        "trace_regeneration_calls": 0,
        "training_steps": 0,
        "optimizer_steps": 0,
        "backward_calls": 0,
    }
    return {**body, "audit_sha256": canonical_sha256(body)}


def _evaluate_vocabulary_margin_candidate_gate(
    child_model: Any,
    trace_cache: Lfm2CircuitTraceCache,
    basis: Any,
    config: Lfm2DenseBudgetFoldConfig,
) -> dict[str, Any]:
    from .hf_lfm2_balanced_circuit_basis import (
        Lfm2CircuitBalancedBasisResult,
    )

    if (
        not isinstance(basis, Lfm2CircuitBalancedBasisResult)
        or basis.vocabulary_margin_gate is None
    ):
        raise Lfm2DenseBudgetFoldError(
            "The enabled vocabulary-margin candidate gate requires a "
            "circuit-balanced basis with sealed held-out margin evidence."
        )
    heldout_record_ids = frozenset(basis.vocabulary_margin_gate.heldout_record_ids)
    if not heldout_record_ids:
        raise Lfm2DenseBudgetFoldError(
            "The vocabulary-margin candidate gate has no held-out records."
        )
    heldout_batches = tuple(
        batch
        for batch in trace_cache.iter_batches()
        if batch.input_sha256 in heldout_record_ids
    )
    replay_record_ids = tuple(batch.input_sha256 for batch in heldout_batches)
    if (
        len(replay_record_ids) != len(heldout_record_ids)
        or len(set(replay_record_ids)) != len(replay_record_ids)
        or set(replay_record_ids) != set(heldout_record_ids)
    ):
        raise Lfm2DenseBudgetFoldError(
            "The sealed parent cache cannot materialize the exact held-out "
            "vocabulary-margin replay split."
        )

    child_before = fingerprint_model_state(child_model)
    replay = capture_lfm2_child_replay(
        child_model,
        heldout_batches,
        selected_layer_indices=(len(_layers(child_model)) - 1,),
        config=_candidate_replay_capture_config(trace_cache),
        replay_capture_mode=(config.vocabulary_margin_candidate_replay_mode),
    )
    child_after = fingerprint_model_state(child_model)
    if child_after != child_before:
        raise Lfm2DenseBudgetFoldError(
            "Vocabulary-margin candidate replay mutated the folded child."
        )

    metadata = replay.metadata
    runtime = metadata.get("runtime")
    forwards = metadata.get("forward_counts")
    selection = metadata.get("selection")
    benchmark = metadata.get("replay_benchmark")
    if (
        not isinstance(runtime, Mapping)
        or not isinstance(forwards, Mapping)
        or not isinstance(selection, Mapping)
        or not isinstance(benchmark, Mapping)
        or runtime.get("parent_model_supplied") is not False
        or runtime.get("parent_forward_count") != 0
        or runtime.get("tokenizer_accessed") is not False
        or runtime.get("disk_artifacts_written") != 0
        or runtime.get("child_state_preserved") is not True
        or forwards.get("parent") != 0
        or selection.get("replay_capture_mode")
        != config.vocabulary_margin_candidate_replay_mode
    ):
        raise Lfm2DenseBudgetFoldError(
            "Vocabulary-margin candidate replay crossed a sealed runtime "
            "or provenance tripwire."
        )
    actual_child_forwards = benchmark.get("actual_child_forwards")
    canonical_prefix_child_forwards = benchmark.get("canonical_prefix_child_forwards")
    saved_child_forwards = benchmark.get("saved_child_forwards")
    if (
        isinstance(actual_child_forwards, bool)
        or not isinstance(actual_child_forwards, int)
        or actual_child_forwards <= 0
        or isinstance(canonical_prefix_child_forwards, bool)
        or not isinstance(canonical_prefix_child_forwards, int)
        or canonical_prefix_child_forwards < actual_child_forwards
        or isinstance(saved_child_forwards, bool)
        or not isinstance(saved_child_forwards, int)
        or saved_child_forwards
        != canonical_prefix_child_forwards - actual_child_forwards
        or forwards.get("child") != actual_child_forwards
    ):
        raise Lfm2DenseBudgetFoldError(
            "Vocabulary-margin candidate replay forward accounting is invalid."
        )

    causal_contract_sha256: str | None = None
    single_pass_authenticated = False
    if (
        config.vocabulary_margin_candidate_replay_mode
        == CHILD_REPLAY_SINGLE_PASS_CAUSAL_MODE
    ):
        if actual_child_forwards != len(heldout_batches):
            raise Lfm2DenseBudgetFoldError(
                "Authenticated single-pass vocabulary replay did not use "
                "exactly one child forward per held-out batch."
            )
        contracts = []
        for batch in replay.iter_batches():
            contract = batch.capture.get("causal_equivalence_contract")
            if not isinstance(contract, Mapping):
                raise Lfm2DenseBudgetFoldError(
                    "Single-pass vocabulary replay omitted its authenticated "
                    "causal contract."
                )
            contracts.append(
                _digest(
                    contract.get("contract_sha256"),
                    "candidate replay causal contract",
                )
            )
        if len(set(contracts)) != 1:
            raise Lfm2DenseBudgetFoldError(
                "Single-pass vocabulary replay changed causal contract "
                "between held-out batches."
            )
        causal_contract_sha256 = contracts[0]
        single_pass_authenticated = True

    evaluation = basis.evaluate_vocabulary_margin_candidate_gate(
        replay,
        minimum_sign_agreement_fraction=(
            config.vocabulary_margin_candidate_minimum_sign_agreement_fraction
        ),
        minimum_top_competitor_nonnegative_fraction=(
            config.vocabulary_margin_candidate_minimum_top_competitor_nonnegative_fraction
        ),
        minimum_all_top_k_nonnegative_fraction=(
            config.vocabulary_margin_candidate_minimum_all_top_k_nonnegative_fraction
        ),
        minimum_exact_top1_agreement_fraction=(
            config.vocabulary_margin_candidate_minimum_exact_top1_agreement_fraction
        ),
    )
    if (
        not isinstance(evaluation, Mapping)
        or not isinstance(evaluation.get("gate_passed"), bool)
        or evaluation.get("parent_forward_calls") != 0
        or evaluation.get("candidate_forward_calls") != 0
        or evaluation.get("training_steps") != 0
    ):
        raise Lfm2DenseBudgetFoldError(
            "Vocabulary-margin candidate gate returned an invalid audit."
        )

    body = {
        "schema": VOCABULARY_MARGIN_CANDIDATE_GATE_SCHEMA,
        "enabled": True,
        "gate_passed": bool(evaluation["gate_passed"]),
        "sealed_parent_cache_key": trace_cache.cache_key,
        "heldout_record_count": len(heldout_batches),
        "heldout_record_ids_sha256": canonical_sha256(sorted(heldout_record_ids)),
        "heldout_used_for_basis_selection": False,
        "candidate_replay_capture_calls": 1,
        "candidate_replay_sha256": replay.replay_sha256,
        "candidate_replay_mode": (config.vocabulary_margin_candidate_replay_mode),
        "single_pass_causal_authenticated": single_pass_authenticated,
        "causal_contract_sha256": causal_contract_sha256,
        "selected_layer_indices": list(replay.selected_layer_indices),
        "actual_child_forward_calls": actual_child_forwards,
        "canonical_prefix_child_forward_calls": (canonical_prefix_child_forwards),
        "saved_child_forward_calls": saved_child_forwards,
        "evaluation_forward_calls": 0,
        "candidate_state_preserved_during_replay": True,
        "candidate_state_fingerprint": child_before,
        "evaluation": dict(evaluation),
        "parent_forward_calls": 0,
        "trace_regeneration_calls": 0,
        "training_steps": 0,
        "optimizer_steps": 0,
        "backward_calls": 0,
    }
    return {**body, "audit_sha256": canonical_sha256(body)}


@dataclass(frozen=True, slots=True)
class _AuthenticatedSparseAxisMaterialization:
    """Private, post-authentication tensors consumed by one structural layer."""

    layer_index: int
    axis_kind: str
    admission_sha256: str
    map_sha256: str
    witness_sha256: str
    feature_map: SparseFeatureFoldMap
    source_writer: Any


@dataclass(frozen=True, slots=True)
class _AuthenticatedSparseBundleMaterialization:
    """One pre-write snapshot of every compile-time sparse bundle authority."""

    axes: Mapping[tuple[int, str], _AuthenticatedSparseAxisMaterialization]
    bundle_sha256: str
    provenance_sha256: str
    parent_state_fingerprint: str
    trace_cache_key: str
    admitted_sha256s: tuple[str, ...]


def _sparse_axis_paths(
    layer_index: int,
    axis_kind: str,
) -> tuple[str, dict[str, str]]:
    if axis_kind == _SPARSE_AXIS_MLP_POST_SWIGLU:
        site = f"model.layers.{layer_index}.feed_forward"
        return site, {
            "w1": f"{site}.w1.weight",
            "w3": f"{site}.w3.weight",
            "w2": f"{site}.w2.weight",
        }
    if axis_kind == _SPARSE_AXIS_SHORT_CONV_CONTEXT:
        site = f"model.layers.{layer_index}.conv"
        packed = f"{site}.in_proj.weight"
        return site, {
            "in_proj_b": packed,
            "in_proj_c": packed,
            "in_proj_x": packed,
            "fir_kernel": f"{site}.conv.weight",
            "out_proj": f"{site}.out_proj.weight",
        }
    raise Lfm2DenseBudgetFoldError(
        f"Sparse bundle axis kind {axis_kind!r} is not materializable."
    )


def _short_conv_axis_slices(width: int) -> dict[str, tuple[int, int]]:
    return {
        "in_proj_b": (0, width),
        "in_proj_c": (width, 2 * width),
        "in_proj_x": (2 * width, 3 * width),
    }


def _sparse_axis_identity(axis: Any) -> tuple[int, str, str, str, str]:
    """Capture the exact sealed identities consumed from one admitted axis."""

    identity = (
        axis.layer_index,
        axis.axis_kind,
        _digest(axis.admission_sha256, "axis admission_sha256"),
        _digest(axis.feature_map.map_sha256, "axis feature_map_sha256"),
        _digest(axis.source_witness.witness_sha256, "axis source_witness_sha256"),
    )
    if (
        axis.report.get("admission_sha256") != identity[2]
        or axis.report.get("feature_map_sha256") != identity[3]
        or axis.report.get("source_witness_sha256") != identity[4]
    ):
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold axis live identities differ from its sealed report."
        )
    return identity


def _authenticate_sparse_bundle_for_materialization(
    sparse_feature_fold_bundle: Lfm2SparseFeatureFoldBundle,
    *,
    parent_model: Any,
    source_graph: ModelCircuitGraph | None,
    target_graph: ModelCircuitGraph | None,
    trace_cache_key: str | None,
    source_layers: Sequence[Any],
    target_layers: Sequence[Any],
    source_types: Sequence[str],
    short_conv_geometries: Mapping[
        int,
        tuple[_ShortConvPhysicalGeometry, _ShortConvPhysicalGeometry],
    ],
) -> _AuthenticatedSparseBundleMaterialization:
    """Authenticate and clone all sparse authority before the first child write."""

    from .hf_lfm2_sparse_feature_fold_bundle import (
        AXIS_MLP_POST_SWIGLU,
        AXIS_SHORT_CONV_CONTEXT,
        Lfm2SparseFeatureFoldBundle,
        Lfm2SparseFeatureFoldBundleError,
        lfm2_sparse_feature_axis_binding,
    )
    from .matrix_technique_body_routes import (
        T5BodyRouteAuthenticationError,
        sparse_feature_fold_map_from_body_route,
        verify_sealed_body_route_record,
        verify_t5_body_route_source_witness,
    )

    if (
        AXIS_MLP_POST_SWIGLU != _SPARSE_AXIS_MLP_POST_SWIGLU
        or AXIS_SHORT_CONV_CONTEXT != _SPARSE_AXIS_SHORT_CONV_CONTEXT
    ):
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle axis identifiers changed incompatibly."
        )
    if not isinstance(sparse_feature_fold_bundle, Lfm2SparseFeatureFoldBundle):
        raise Lfm2DenseBudgetFoldError(
            "sparse_feature_fold_bundle must be Lfm2SparseFeatureFoldBundle."
        )
    if not isinstance(source_graph, ModelCircuitGraph) or not isinstance(
        target_graph, ModelCircuitGraph
    ):
        raise Lfm2DenseBudgetFoldError(
            "Sparse bundle materialization requires the live source and target graphs."
        )
    cache_key = _digest(trace_cache_key, "trace_cache_key")
    try:
        bundle = sparse_feature_fold_bundle.verify()
        verified_axes = tuple(bundle.axes)
        verified_axis_identities = tuple(
            _sparse_axis_identity(axis) for axis in verified_axes
        )
        sealed_bundle_sha256 = _digest(bundle.bundle_sha256, "bundle_sha256")
        sealed_provenance_sha256 = _digest(
            bundle.provenance["provenance_sha256"],
            "bundle provenance_sha256",
        )
        sealed_report_admissions = tuple(
            _digest(value, "bundle axis admission_sha256")
            for value in bundle.report["axis_admission_sha256s"]
        )
        sealed_provenance_admissions = tuple(
            _digest(value, "bundle provenance axis admission_sha256")
            for value in bundle.provenance["axis_admission_sha256s"]
        )
        verified_axis_admissions = tuple(
            identity[2] for identity in verified_axis_identities
        )
    except (
        Lfm2SparseFeatureFoldBundleError,
        FeatureFoldError,
        T5BodyRouteAuthenticationError,
        AttributeError,
        KeyError,
        TypeError,
    ) as exc:
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle failed authentication before materialization."
        ) from exc
    if (
        bundle.report.get("bundle_sha256") != sealed_bundle_sha256
        or bundle.report.get("provenance_sha256") != sealed_provenance_sha256
        or sealed_report_admissions != verified_axis_admissions
        or sealed_provenance_admissions != verified_axis_admissions
    ):
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle live axes differ from its sealed admission order."
        )
    verified_axis_keys = tuple(
        (identity[0], identity[1]) for identity in verified_axis_identities
    )
    verified_identity_by_key = dict(
        zip(verified_axis_keys, verified_axis_identities, strict=True)
    )
    verified_axes_by_key = dict(zip(verified_axis_keys, verified_axes, strict=True))
    if len(verified_axes_by_key) != len(verified_axes):
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle contains duplicate materialization axes."
        )
    if (
        bundle.source_graph_sha256 != source_graph.fingerprint
        or bundle.target_graph_sha256 != target_graph.fingerprint
        or bundle.source_graph.fingerprint != source_graph.fingerprint
        or bundle.target_graph.fingerprint != target_graph.fingerprint
    ):
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle names different live source/target graphs."
        )
    if tuple(bundle.attention_sites):
        raise Lfm2DenseBudgetFoldError(
            "Dense sparse bundle materialization admits MLP and ShortConv axes only."
        )

    expected_keys = {
        (layer_index, _SPARSE_AXIS_MLP_POST_SWIGLU)
        for layer_index in range(len(source_layers))
    }
    for layer_index, layer_type in enumerate(source_types):
        if layer_type == "full_attention":
            continue
        source_geometry, target_geometry = short_conv_geometries[layer_index]
        if source_geometry.writer_rank is not None or target_geometry.writer_rank is not None:
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold ShortConv admission requires dense source and "
                "target out_proj.weight writers."
            )
        if source_geometry.fir_length != 3 or target_geometry.fir_length != 3:
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold ShortConv admission currently requires three "
                "authenticated FIR taps."
            )
        expected_keys.add((layer_index, _SPARSE_AXIS_SHORT_CONV_CONTEXT))
    actual_keys = set(verified_axis_keys)
    if actual_keys != expected_keys or len(actual_keys) != len(verified_axes):
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle does not cover every MLP and dense "
            "ShortConv axis exactly once."
        )

    parent_state = fingerprint_model_state(parent_model)
    authenticated: dict[
        tuple[int, str], _AuthenticatedSparseAxisMaterialization
    ] = {}
    for key in sorted(verified_axes_by_key):
        axis = verified_axes_by_key[key]
        sealed_axis_identity = verified_identity_by_key[key]
        if _sparse_axis_identity(axis) != sealed_axis_identity:
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold axis changed after bundle authentication."
            )
        source_layer = source_layers[axis.layer_index]
        target_layer = target_layers[axis.layer_index]
        site, source_paths = _sparse_axis_paths(axis.layer_index, axis.axis_kind)
        _target_site, target_paths = _sparse_axis_paths(
            axis.layer_index, axis.axis_kind
        )
        if axis.axis_kind == _SPARSE_AXIS_MLP_POST_SWIGLU:
            source_width = int(source_layer.feed_forward.w1.weight.shape[0])
            target_width = int(target_layer.feed_forward.w1.weight.shape[0])
            source_slices: Mapping[str, Sequence[int]] | None = None
            target_slices: Mapping[str, Sequence[int]] | None = None
            writer_role = "w2"
            evidence_endpoint = "mlp.post_swiglu"
            live_writer = source_layer.feed_forward.w2.weight
        else:
            source_geometry, target_geometry = short_conv_geometries[axis.layer_index]
            source_width = source_geometry.internal_channels
            target_width = target_geometry.internal_channels
            source_slices = _short_conv_axis_slices(source_width)
            target_slices = _short_conv_axis_slices(target_width)
            writer_role = "out_proj"
            evidence_endpoint = "short_conv.context"
            live_writer = source_layer.conv.out_proj.weight
        if (
            axis.coefficient_set != "write"
            or axis.site != site
            or dict(axis.source_parameter_paths) != source_paths
            or dict(axis.target_parameter_paths) != target_paths
            or dict(axis.source_parameter_row_slices)
            != ({} if source_slices is None else dict(source_slices))
            or dict(axis.target_parameter_row_slices)
            != ({} if target_slices is None else dict(target_slices))
        ):
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold axis differs from its exact materialized "
                f"layer contract: layer={axis.layer_index}, kind={axis.axis_kind}."
            )
        witness = axis.source_witness
        if (
            witness.parent_state_fingerprint != parent_state
            or witness.evidence_cache_sha256 != cache_key
        ):
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold witness differs from the live parent state "
                "or sealed trace cache."
            )
        normalized_live_writer = (
            live_writer.detach()
            .to(device="cpu", dtype=witness.parent_weight.dtype)
            .contiguous()
            .clone()
        )
        try:
            authority = verify_sealed_body_route_record(axis.body_route_fold.record)
            caller_binding = lfm2_sparse_feature_axis_binding(
                source_graph=source_graph,
                target_graph=target_graph,
                source_graph_sha256=source_graph.fingerprint,
                target_graph_sha256=target_graph.fingerprint,
                layer_index=axis.layer_index,
                site=site,
                axis_kind=axis.axis_kind,
                source_parameter_paths=source_paths,
                target_parameter_paths=target_paths,
                source_parameter_row_slices=source_slices,
                target_parameter_row_slices=target_slices,
                source_width=source_width,
                target_width=target_width,
                authority_schema=authority["schema"],
                authority_record_sha256=authority["record_sha256"],
            )
            private_map = sparse_feature_fold_map_from_body_route(
                axis.body_route_fold,
                coefficient_set="write",
                admission_binding=caller_binding,
            )
            authenticated_witness = verify_t5_body_route_source_witness(
                witness,
                axis.body_route_fold,
                parent_weight=normalized_live_writer,
                component_rows=witness.component_rows,
                heldout_component_rows=witness.heldout_component_rows,
                parameter_path=source_paths[writer_role],
                graph_fingerprint=source_graph.fingerprint,
                parent_state_fingerprint=parent_state,
                component_id=(
                    "C13"
                    if axis.axis_kind == _SPARSE_AXIS_MLP_POST_SWIGLU
                    else "C05"
                ),
                layer_index=axis.layer_index,
                site=f"L{axis.layer_index:02d}",
                role="writer",
                evidence_cache_sha256=cache_key,
                evidence_selection_sha256=witness.evidence_selection_sha256,
                evidence_endpoint=evidence_endpoint,
                coefficient_set="write",
            )
        except (
            FeatureFoldError,
            Lfm2SparseFeatureFoldBundleError,
            T5BodyRouteAuthenticationError,
        ) as exc:
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold axis failed live route/value authentication."
            ) from exc
        if (
            private_map.map_sha256 != sealed_axis_identity[3]
            or private_map.admission_binding_sha256
            != axis.report["admission_binding_sha256"]
            or authenticated_witness.witness_sha256 != sealed_axis_identity[4]
        ):
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold private snapshot differs from its admission seal."
            )
        authenticated[key] = _AuthenticatedSparseAxisMaterialization(
            layer_index=axis.layer_index,
            axis_kind=axis.axis_kind,
            admission_sha256=sealed_axis_identity[2],
            map_sha256=private_map.map_sha256,
            witness_sha256=authenticated_witness.witness_sha256,
            feature_map=private_map,
            source_writer=authenticated_witness.parent_weight,
        )
    if fingerprint_model_state(parent_model) != parent_state:
        raise Lfm2DenseBudgetFoldError(
            "Sparse bundle source model changed during pre-write authentication."
        )
    authenticated_axis_identities = tuple(
        (
            key[0],
            key[1],
            authenticated[key].admission_sha256,
            authenticated[key].map_sha256,
            authenticated[key].witness_sha256,
        )
        for key in verified_axis_keys
    )
    if authenticated_axis_identities != verified_axis_identities:
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold private snapshots differ from the verified bundle."
        )
    try:
        final_bundle = sparse_feature_fold_bundle.verify()
        final_axes = tuple(final_bundle.axes)
        final_axis_identities = tuple(
            _sparse_axis_identity(axis) for axis in final_axes
        )
        final_axis_keys = tuple(
            (identity[0], identity[1]) for identity in final_axis_identities
        )
        final_report_admissions = tuple(
            _digest(value, "final bundle axis admission_sha256")
            for value in final_bundle.report["axis_admission_sha256s"]
        )
        final_provenance_admissions = tuple(
            _digest(value, "final bundle provenance axis admission_sha256")
            for value in final_bundle.provenance["axis_admission_sha256s"]
        )
        final_bundle_sha256 = _digest(
            final_bundle.bundle_sha256,
            "final bundle_sha256",
        )
        final_provenance_sha256 = _digest(
            final_bundle.provenance["provenance_sha256"],
            "final bundle provenance_sha256",
        )
    except (
        Lfm2SparseFeatureFoldBundleError,
        FeatureFoldError,
        T5BodyRouteAuthenticationError,
        AttributeError,
        KeyError,
        TypeError,
    ) as exc:
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle changed during pre-write authentication."
        ) from exc
    if (
        final_bundle_sha256 != sealed_bundle_sha256
        or final_provenance_sha256 != sealed_provenance_sha256
        or final_report_admissions != sealed_report_admissions
        or final_provenance_admissions != sealed_provenance_admissions
        or final_axis_keys != verified_axis_keys
        or final_axis_identities != verified_axis_identities
        or authenticated_axis_identities != final_axis_identities
    ):
        raise Lfm2DenseBudgetFoldError(
            "Sparse feature-fold bundle identity changed during pre-write closure."
        )
    admitted = tuple(
        verified_identity_by_key[key][2] for key in sorted(verified_identity_by_key)
    )
    return _AuthenticatedSparseBundleMaterialization(
        axes=MappingProxyType(authenticated),
        bundle_sha256=sealed_bundle_sha256,
        provenance_sha256=sealed_provenance_sha256,
        parent_state_fingerprint=parent_state,
        trace_cache_key=cache_key,
        admitted_sha256s=admitted,
    )


def _fold_dense_blank_from_parent(
    parent_model: Any,
    child_model: Any,
    mapping: Any,
    tokenizer_bridge_artifact: StrictTokenizerBridgeArtifact | None = None,
    *,
    selective_session: Lfm2CircuitTraceSelectiveAuthenticatedSession | None = None,
    progress: _Lfm2DenseFoldProgress | None = None,
    sparse_feature_fold_bundle: Lfm2SparseFeatureFoldBundle | None = None,
    source_graph: ModelCircuitGraph | None = None,
    target_graph: ModelCircuitGraph | None = None,
    trace_cache_key: str | None = None,
) -> dict[str, Any]:
    """Overwrite every learned child tensor from the complete parent state."""

    torch = _torch()
    source_layers = _layers(parent_model)
    target_layers = _layers(child_model)
    if len(source_layers) != len(target_layers):
        raise Lfm2DenseBudgetFoldError(
            "Ordered source-span composition is required for a depth-changing "
            "dense target; the executable dense lane currently requires equal "
            "source/target depth."
        )
    source_types = tuple(
        _fold_layer_kind(layer, label=f"source layer {index}")
        for index, layer in enumerate(source_layers)
    )
    target_types = tuple(
        _fold_layer_kind(layer, label=f"target layer {index}")
        for index, layer in enumerate(target_layers)
    )
    if source_types != target_types:
        raise Lfm2DenseBudgetFoldError(
            "Dense width folding requires identical source/target operator order."
        )
    attention_folds: dict[int, tuple[Any, Any, tuple[int, ...], tuple[int, ...]]] = {}
    short_conv_geometries: dict[
        int,
        tuple[_ShortConvPhysicalGeometry, _ShortConvPhysicalGeometry],
    ] = {}
    for layer_index, (source_layer, target_layer, layer_type) in enumerate(
        zip(source_layers, target_layers, source_types, strict=True)
    ):
        if layer_type == "full_attention":
            source_geometry = _attention_physical_geometry(
                source_layer.self_attn,
                label=f"source layer {layer_index}.self_attn",
            )
            target_geometry = _attention_physical_geometry(
                target_layer.self_attn,
                label=f"target layer {layer_index}.self_attn",
            )
            (
                source_query_heads,
                source_key_value_heads,
                source_head_dim,
                source_residual_width,
            ) = source_geometry
            (
                target_query_heads,
                target_key_value_heads,
                target_head_dim,
                target_residual_width,
            ) = target_geometry
            if source_residual_width != int(
                mapping.source_width
            ) or target_residual_width != int(mapping.target_width):
                raise Lfm2DenseBudgetFoldError(
                    f"Layer {layer_index} attention residual widths disagree "
                    "with the shared residual coordinate map."
                )
            attention_maps = build_gqa_attention_fold_maps(
                source_query_heads=source_query_heads,
                source_key_value_heads=source_key_value_heads,
                source_head_dim=source_head_dim,
                target_query_heads=target_query_heads,
                target_key_value_heads=target_key_value_heads,
                target_head_dim=target_head_dim,
            )
            rope_pair_map = build_gqa_attention_fold_maps(
                source_query_heads=1,
                source_key_value_heads=1,
                source_head_dim=source_head_dim,
                target_query_heads=1,
                target_key_value_heads=1,
                target_head_dim=target_head_dim,
            ).query
            attention_folds[layer_index] = (
                attention_maps,
                rope_pair_map,
                source_geometry,
                target_geometry,
            )
        else:
            source_geometry = _short_conv_physical_geometry(
                source_layer.conv,
                label=f"source layer {layer_index}.conv",
            )
            target_geometry = _short_conv_physical_geometry(
                target_layer.conv,
                label=f"target layer {layer_index}.conv",
            )
            if (
                source_geometry.residual_width != int(mapping.source_width)
                or target_geometry.residual_width != int(mapping.target_width)
            ):
                raise Lfm2DenseBudgetFoldError(
                    f"Layer {layer_index} ShortConv residual widths disagree "
                    "with the shared residual coordinate map."
                )
            if source_geometry.fir_length != target_geometry.fir_length:
                raise Lfm2DenseBudgetFoldError(
                    f"Layer {layer_index} changes its ShortConv FIR length."
                )
            short_conv_geometries[layer_index] = (
                source_geometry,
                target_geometry,
            )
    authenticated_sparse_bundle = (
        None
        if sparse_feature_fold_bundle is None
        else _authenticate_sparse_bundle_for_materialization(
            sparse_feature_fold_bundle,
            parent_model=parent_model,
            source_graph=source_graph,
            target_graph=target_graph,
            trace_cache_key=trace_cache_key,
            source_layers=source_layers,
            target_layers=target_layers,
            source_types=source_types,
            short_conv_geometries=short_conv_geometries,
        )
    )
    sparse_axes = (
        {}
        if authenticated_sparse_bundle is None
        else dict(authenticated_sparse_bundle.axes)
    )
    consumed_sparse_admissions: list[str] = []
    dynamic_body_feature_map_solve_count = 0
    factor_layer_indices = tuple(
        index
        for index, (_source, target) in short_conv_geometries.items()
        if target.writer_rank is not None
    )
    factor_output_action_evidence = (
        {}
        if selective_session is None or not factor_layer_indices
        else _collect_short_conv_output_action_evidence(
            selective_session,
            factor_layer_indices=factor_layer_indices,
            residual_mapping=mapping,
            progress=progress,
        )
    )
    factor_output_action_evidence_count = len(factor_output_action_evidence)
    written: set[int] = set()
    layer_reports = []

    with torch.no_grad():
        source_embedding = parent_model.get_input_embeddings().weight
        target_embedding = child_model.get_input_embeddings().weight
        source_head = parent_model.get_output_embeddings().weight
        target_head = child_model.get_output_embeddings().weight
        target_tied = id(target_head) == id(target_embedding)
        source_tied = id(source_head) == id(source_embedding)
        vocabulary_transport_report: Mapping[str, Any] | None = None
        if progress is not None:
            progress.emit(
                "dense_structural_token_transport_started",
                tokenizer_bridge_used=tokenizer_bridge_artifact is not None,
                target_vocabulary_size=int(target_embedding.shape[0]),
                target_hidden_size=int(target_embedding.shape[1]),
            )
        if tokenizer_bridge_artifact is not None:
            if target_tied and not source_tied:
                raise Lfm2DenseBudgetFoldError(
                    "A tied dense target cannot exactly represent an untied "
                    "source token interface."
                )
            transported = compile_strict_vocabulary_operators(
                source_embedding,
                source_head,
                tokenizer_bridge_artifact,
                mapping,
                mapping,
                source_lm_head_bias=getattr(
                    parent_model.get_output_embeddings(),
                    "bias",
                    None,
                ),
                require_tied_target=target_tied,
            )
            _copy_parameter(
                target_embedding,
                transported.embedding_weight,
                name="model.embed_tokens.weight",
                written=written,
            )
            if target_tied:
                written.add(id(target_head))
            else:
                _copy_parameter(
                    target_head,
                    transported.lm_head_weight,
                    name="lm_head.weight",
                    written=written,
                )
            target_bias = getattr(
                child_model.get_output_embeddings(),
                "bias",
                None,
            )
            if target_bias is not None:
                if transported.lm_head_bias is None:
                    raise Lfm2DenseBudgetFoldError(
                        "Bridged target LM-head bias lacks transported source values."
                    )
                _copy_parameter(
                    target_bias,
                    transported.lm_head_bias,
                    name="lm_head.bias",
                    written=written,
                )
            elif transported.lm_head_bias is not None:
                raise Lfm2DenseBudgetFoldError(
                    "Bridged source LM-head bias has no target parameter."
                )
            vocabulary_transport_report = dict(transported.report)
            del transported
        else:
            _copy_parameter(
                target_embedding,
                mapping.fold_consumer_weight(
                    source_embedding.detach().to(
                        device="cpu",
                        dtype=torch.float64,
                    )
                ),
                name="model.embed_tokens.weight",
                written=written,
            )
            if target_tied:
                if not source_tied:
                    raise Lfm2DenseBudgetFoldError(
                        "A tied dense target cannot merge an untied source token "
                        "interface without an explicit tokenizer/output bridge."
                    )
                written.add(id(target_head))
            else:
                _copy_parameter(
                    target_head,
                    mapping.fold_consumer_weight(
                        source_head.detach().to(
                            device="cpu",
                            dtype=torch.float64,
                        )
                    ),
                    name="lm_head.weight",
                    written=written,
                )

        token_cleanup = _release_cpu_allocator_retention(
            caller_declared_release_plan_units=1,
        )
        if progress is not None:
            progress.emit(
                "dense_structural_token_transport_completed",
                tokenizer_bridge_used=tokenizer_bridge_artifact is not None,
                **token_cleanup,
            )

        for layer_index, (source_layer, target_layer) in enumerate(
            zip(source_layers, target_layers, strict=True)
        ):
            layer_type = source_types[layer_index]
            canonical_kind = (
                "full_attention" if layer_type == "full_attention" else "short_conv"
            )
            if progress is not None:
                progress.emit(
                    "dense_structural_layer_started",
                    layer_index=layer_index,
                    layer_count=len(source_layers),
                    layer_kind=canonical_kind,
                )
            _copy_parameter(
                target_layer.operator_norm.weight,
                _transport_diagonal(mapping, source_layer.operator_norm.weight),
                name=f"model.layers.{layer_index}.operator_norm.weight",
                written=written,
            )
            _copy_parameter(
                target_layer.ffn_norm.weight,
                _transport_diagonal(mapping, source_layer.ffn_norm.weight),
                name=f"model.layers.{layer_index}.ffn_norm.weight",
                written=written,
            )

            source_mlp = source_layer.feed_forward
            target_mlp = target_layer.feed_forward
            source_intermediate = int(source_mlp.w1.weight.shape[0])
            target_intermediate = int(target_mlp.w1.weight.shape[0])
            sparse_mlp_axis = sparse_axes.pop(
                (layer_index, _SPARSE_AXIS_MLP_POST_SWIGLU),
                None,
            )
            if sparse_mlp_axis is None:
                mlp_map = build_feature_fold_map(
                    (
                        source_mlp.w1.weight.detach().T,
                        source_mlp.w3.weight.detach().T,
                        source_mlp.w2.weight.detach(),
                    ),
                    target_intermediate,
                    source_width=source_intermediate,
                    chunk_size=min(256, source_intermediate),
                    sketch_size=min(64, max(8, int(mapping.source_width))),
                    balance_strength=0.35,
                    allow_sign_flip=False,
                )
                dynamic_body_feature_map_solve_count += 1
                source_down_weight = source_mlp.w2.weight.detach()
            else:
                mlp_map = sparse_mlp_axis.feature_map
                source_down_weight = sparse_mlp_axis.source_writer
            folded_gate = mapping.fold_consumer_weight(
                source_mlp.w1.weight.detach().to(device="cpu", dtype=torch.float64)
            )
            folded_up = mapping.fold_consumer_weight(
                source_mlp.w3.weight.detach().to(device="cpu", dtype=torch.float64)
            )
            folded_down = mlp_map.fold_consumer_weight(
                source_down_weight.to(device="cpu", dtype=torch.float64)
            )
            _copy_parameter(
                target_mlp.w1.weight,
                mlp_map.fold_producer_weight(folded_gate),
                name=f"model.layers.{layer_index}.feed_forward.w1.weight",
                written=written,
            )
            _copy_parameter(
                target_mlp.w3.weight,
                mlp_map.fold_producer_weight(folded_up),
                name=f"model.layers.{layer_index}.feed_forward.w3.weight",
                written=written,
            )
            _copy_parameter(
                target_mlp.w2.weight,
                mapping.fold_producer_weight(folded_down),
                name=f"model.layers.{layer_index}.feed_forward.w2.weight",
                written=written,
            )
            if sparse_mlp_axis is not None:
                consumed_sparse_admissions.append(
                    sparse_mlp_axis.admission_sha256
                )

            if layer_type == "full_attention":
                source_attention = source_layer.self_attn
                target_attention = target_layer.self_attn
                (
                    attention_maps,
                    rope_pair_map,
                    source_attention_geometry,
                    target_attention_geometry,
                ) = attention_folds.pop(layer_index)
                for role, projection in (
                    ("query", "q_proj"),
                    ("key", "k_proj"),
                    ("value", "v_proj"),
                ):
                    source_projection = getattr(source_attention, projection)
                    target_projection = getattr(target_attention, projection)
                    channel_map = getattr(attention_maps, role)
                    folded = mapping.fold_consumer_weight(
                        source_projection.weight.detach().to(
                            device="cpu", dtype=torch.float64
                        )
                    )
                    _copy_parameter(
                        target_projection.weight,
                        channel_map.fold_producer_weight(folded),
                        name=(
                            f"model.layers.{layer_index}.self_attn.{projection}.weight"
                        ),
                        written=written,
                    )
                    _copy_optional_bias(
                        source_projection.bias,
                        target_projection.bias,
                        (
                            None
                            if source_projection.bias is None
                            else channel_map.fold_producer_weight(
                                source_projection.bias.detach()
                                .to(device="cpu", dtype=torch.float64)
                                .reshape(-1, 1)
                            ).reshape(-1)
                        ),
                        name=(
                            f"model.layers.{layer_index}.self_attn.{projection}.bias"
                        ),
                        written=written,
                    )
                source_output = source_attention.out_proj
                target_output = target_attention.out_proj
                context_folded = attention_maps.context.fold_consumer_weight(
                    source_output.weight.detach().to(device="cpu", dtype=torch.float64)
                )
                _copy_parameter(
                    target_output.weight,
                    mapping.fold_producer_weight(context_folded),
                    name=(f"model.layers.{layer_index}.self_attn.out_proj.weight"),
                    written=written,
                )
                _copy_optional_bias(
                    source_output.bias,
                    target_output.bias,
                    (
                        None
                        if source_output.bias is None
                        else mapping.fold_producer_weight(
                            source_output.bias.detach()
                            .to(device="cpu", dtype=torch.float64)
                            .reshape(-1, 1)
                        ).reshape(-1)
                    ),
                    name=f"model.layers.{layer_index}.self_attn.out_proj.bias",
                    written=written,
                )
                for norm_name in ("q_layernorm", "k_layernorm"):
                    source_norm = getattr(source_attention, norm_name, None)
                    target_norm = getattr(target_attention, norm_name, None)
                    if (source_norm is None) != (target_norm is None):
                        raise Lfm2DenseBudgetFoldError(
                            f"Attention {norm_name} presence differs."
                        )
                    if source_norm is not None:
                        _copy_parameter(
                            target_norm.weight,
                            _transport_feature_diagonal(
                                rope_pair_map,
                                source_norm.weight,
                            ),
                            name=(
                                f"model.layers.{layer_index}.self_attn."
                                f"{norm_name}.weight"
                            ),
                            written=written,
                        )
                operator_report = {
                    "kind": "gqa_rope_pair_constrained_full_source_fold",
                    "query": attention_maps.query.report.as_dict(),
                    "key": attention_maps.key.report.as_dict(),
                    "value": attention_maps.value.report.as_dict(),
                    "context": attention_maps.context.report.as_dict(),
                    "source_physical_geometry": {
                        "query_heads": source_attention_geometry[0],
                        "key_value_heads": source_attention_geometry[1],
                        "head_dim": source_attention_geometry[2],
                    },
                    "target_physical_geometry": {
                        "query_heads": target_attention_geometry[0],
                        "key_value_heads": target_attention_geometry[1],
                        "head_dim": target_attention_geometry[2],
                    },
                    "source_heads_dropped": 0,
                    "rope_pairs_preserved": True,
                }
                del (
                    attention_maps,
                    channel_map,
                    context_folded,
                    folded,
                    rope_pair_map,
                    source_attention_geometry,
                    source_norm,
                    source_output,
                    source_projection,
                    target_attention_geometry,
                    target_norm,
                    target_output,
                    target_projection,
                )
            else:
                source_conv = source_layer.conv
                target_conv = target_layer.conv
                source_blocks = source_conv.in_proj.weight.chunk(3, dim=0)
                source_kernel = source_conv.conv.weight.detach()[:, 0, :]
                source_geometry, target_geometry = short_conv_geometries.pop(
                    layer_index
                )
                source_channels = source_geometry.internal_channels
                target_channels = target_geometry.internal_channels
                sparse_short_conv_axis = sparse_axes.pop(
                    (layer_index, _SPARSE_AXIS_SHORT_CONV_CONTEXT),
                    None,
                )
                if sparse_short_conv_axis is None:
                    source_dense_writer = _short_conv_dense_writer_action(
                        source_conv,
                        source_geometry,
                        label=f"source layer {layer_index}.conv.out_proj",
                    )
                    internal_map = build_feature_fold_map(
                        (
                            *(block.detach().T for block in source_blocks),
                            source_dense_writer,
                            source_kernel.T,
                        ),
                        target_channels,
                        source_width=source_channels,
                        chunk_size=min(256, source_channels),
                        sketch_size=min(64, max(8, source_channels)),
                        balance_strength=0.35,
                        allow_sign_flip=False,
                    )
                    dynamic_body_feature_map_solve_count += 1
                else:
                    source_dense_writer = sparse_short_conv_axis.source_writer
                    internal_map = sparse_short_conv_axis.feature_map
                _copy_parameter(
                    target_conv.in_proj.weight,
                    torch.cat(
                        tuple(
                            internal_map.fold_producer_weight(
                                mapping.fold_consumer_weight(
                                    block.detach().to(
                                        device="cpu",
                                        dtype=torch.float64,
                                    )
                                )
                            )
                            for block in source_blocks
                        ),
                        dim=0,
                    ),
                    name=f"model.layers.{layer_index}.conv.in_proj.weight",
                    written=written,
                )
                dense_writer_action = mapping.fold_producer_weight(
                    internal_map.fold_consumer_weight(
                        source_dense_writer.detach().to(
                            device="cpu",
                            dtype=torch.float64,
                        )
                    )
                )
                factorization_report: Mapping[str, Any] | None = None
                if target_geometry.writer_rank is None:
                    _copy_parameter(
                        target_conv.out_proj.weight,
                        dense_writer_action,
                        name=f"model.layers.{layer_index}.conv.out_proj.weight",
                        written=written,
                    )
                else:
                    encoder, decoder, factorization_report = (
                        _factorize_short_conv_dense_writer_action(
                            dense_writer_action,
                            target_geometry.writer_rank,
                            output_action_evidence=(
                                factor_output_action_evidence.get(layer_index)
                            ),
                        )
                    )
                    _copy_parameter(
                        target_conv.out_proj[0].weight,
                        encoder,
                        name=(
                            f"model.layers.{layer_index}.conv.out_proj.0.weight"
                        ),
                        written=written,
                    )
                    _copy_parameter(
                        target_conv.out_proj[1].weight,
                        decoder,
                        name=(
                            f"model.layers.{layer_index}.conv.out_proj.1.weight"
                        ),
                        written=written,
                    )
                    del decoder, encoder
                _copy_parameter(
                    target_conv.conv.weight,
                    (
                        _transport_depthwise_kernel(
                            internal_map,
                            source_kernel,
                        ).unsqueeze(1)
                        if sparse_short_conv_axis is None
                        else source_conv.conv.weight.detach()
                        .to(device="cpu", dtype=torch.float64)
                        .index_select(
                            0,
                            internal_map.kept_source_ids,
                        )
                        .contiguous()
                    ),
                    name=f"model.layers.{layer_index}.conv.conv.weight",
                    written=written,
                )
                source_in_bias = source_conv.in_proj.bias
                target_in_bias = target_conv.in_proj.bias
                _copy_optional_bias(
                    source_in_bias,
                    target_in_bias,
                    (
                        None
                        if source_in_bias is None
                        else torch.cat(
                            tuple(
                                internal_map.fold_producer_weight(
                                    block.detach()
                                    .to(device="cpu", dtype=torch.float64)
                                    .reshape(-1, 1)
                                ).reshape(-1)
                                for block in source_in_bias.chunk(3)
                            )
                        )
                    ),
                    name=f"model.layers.{layer_index}.conv.in_proj.bias",
                    written=written,
                )
                source_output_bias = _short_conv_writer_bias(
                    source_conv,
                    source_geometry,
                    label=f"source layer {layer_index}.conv.out_proj",
                )
                target_output_bias = _short_conv_writer_bias(
                    target_conv,
                    target_geometry,
                    label=f"target layer {layer_index}.conv.out_proj",
                )
                _copy_optional_bias(
                    source_output_bias,
                    target_output_bias,
                    (
                        None
                        if source_output_bias is None
                        else mapping.fold_producer_weight(
                            source_output_bias.detach()
                            .to(device="cpu", dtype=torch.float64)
                            .reshape(-1, 1)
                        ).reshape(-1)
                    ),
                    name=f"model.layers.{layer_index}.conv.out_proj.bias",
                    written=written,
                )
                _copy_optional_bias(
                    source_conv.conv.bias,
                    target_conv.conv.bias,
                    (
                        None
                        if source_conv.conv.bias is None
                        else internal_map.fold_producer_weight(
                            source_conv.conv.bias.detach()
                            .to(device="cpu", dtype=torch.float64)
                            .reshape(-1, 1)
                        ).reshape(-1)
                    ),
                    name=f"model.layers.{layer_index}.conv.conv.bias",
                    written=written,
                )
                operator_report = {
                    "kind": (
                        "factorized_residual_internal_short_conv_transport"
                        if target_geometry.writer_rank is not None
                        else "dense_residual_internal_short_conv_transport"
                    ),
                    "input_projection": "F.T @ W_block @ B",
                    "output_projection": "B.T @ W @ F",
                    "depthwise_fir": (
                        "diag(F.T @ diag(kernel_tap) @ F)"
                        if sparse_short_conv_axis is None
                        else "authenticated_exact_anchor_row_selection"
                    ),
                    "source_internal_channels": source_channels,
                    "target_internal_channels": target_channels,
                    "internal_feature_fold": internal_map.report.as_dict(),
                    "source_channels_dropped": 0,
                    "source_writer_topology": source_geometry.writer_topology,
                    "target_writer_topology": target_geometry.writer_topology,
                    "target_writer_rank": target_geometry.writer_rank,
                    "factorization": factorization_report,
                    "sparse_axis_admission_sha256": (
                        None
                        if sparse_short_conv_axis is None
                        else sparse_short_conv_axis.admission_sha256
                    ),
                }
                if sparse_short_conv_axis is not None:
                    consumed_sparse_admissions.append(
                        sparse_short_conv_axis.admission_sha256
                    )
                factor_output_action_evidence.pop(layer_index, None)
                del (
                    dense_writer_action,
                    factorization_report,
                    internal_map,
                    source_blocks,
                    source_dense_writer,
                    source_in_bias,
                    source_kernel,
                    source_output_bias,
                    sparse_short_conv_axis,
                    target_in_bias,
                    target_output_bias,
                )

            layer_reports.append(
                {
                    "layer_index": layer_index,
                    "kind": canonical_kind,
                    "swiglu": {
                        "source_neurons": source_intermediate,
                        "target_neurons": target_intermediate,
                        "source_neurons_dropped": 0,
                        "full_source_coverage": True,
                        "feature_fold": mlp_map.report.as_dict(),
                        "sparse_axis_admission_sha256": (
                            None
                            if sparse_mlp_axis is None
                            else sparse_mlp_axis.admission_sha256
                        ),
                    },
                    "operator": operator_report,
                }
            )
            del (
                folded_down,
                folded_gate,
                folded_up,
                mlp_map,
                operator_report,
                source_down_weight,
                sparse_mlp_axis,
            )
            layer_cleanup = _release_cpu_allocator_retention(
                caller_declared_release_plan_units=(
                    17 if canonical_kind == "full_attention" else 15
                ),
            )
            if progress is not None:
                progress.emit(
                    "dense_structural_layer_completed",
                    layer_index=layer_index,
                    layer_count=len(source_layers),
                    layer_kind=canonical_kind,
                    **layer_cleanup,
                )

        if sparse_axes:
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold materialization left authenticated axes "
                f"unconsumed: {sorted(sparse_axes)}."
            )
        if (
            authenticated_sparse_bundle is not None
            and tuple(consumed_sparse_admissions)
            != authenticated_sparse_bundle.admitted_sha256s
        ):
            raise Lfm2DenseBudgetFoldError(
                "Sparse feature-fold admissions were not consumed exactly once "
                "in canonical layer/axis order."
            )

        source_final_norm = parent_model.model.embedding_norm
        target_final_norm = child_model.model.embedding_norm
        _copy_parameter(
            target_final_norm.weight,
            _transport_diagonal(mapping, source_final_norm.weight),
            name="model.embedding_norm.weight",
            written=written,
        )

    target_unique = {id(parameter) for parameter in child_model.parameters()}
    missing = target_unique - written
    if missing:
        names = [
            name
            for name, parameter in child_model.named_parameters(
                recurse=True,
                remove_duplicate=False,
            )
            if id(parameter) in missing
        ]
        raise Lfm2DenseBudgetFoldError(
            "Dense fold did not overwrite every target parameter: "
            + ", ".join(sorted(names))
        )
    nonzero = sum(
        int(torch.count_nonzero(parameter.detach()).item())
        for parameter in child_model.parameters()
    )
    if nonzero <= 0:
        raise Lfm2DenseBudgetFoldError("Dense fold left the compiler-zero child blank.")
    if progress is not None:
        progress.emit(
            "dense_structural_fold_completed",
            layer_count=len(source_layers),
            target_unique_parameter_objects_written=len(written),
            target_nonzero_parameter_elements=nonzero,
            complete_target_parameter_overwrite=True,
        )
    sparse_bundle_report = None
    if authenticated_sparse_bundle is not None:
        ordered_axes = tuple(
            authenticated_sparse_bundle.axes[key]
            for key in sorted(authenticated_sparse_bundle.axes)
        )
        sparse_bundle_report = {
            "resource_name": LFM2_SPARSE_FEATURE_FOLD_BUNDLE_RESOURCE_NAME,
            "bundle_sha256": authenticated_sparse_bundle.bundle_sha256,
            "provenance_sha256": authenticated_sparse_bundle.provenance_sha256,
            "source_graph_sha256": source_graph.fingerprint,
            "target_graph_sha256": target_graph.fingerprint,
            "parent_state_fingerprint": (
                authenticated_sparse_bundle.parent_state_fingerprint
            ),
            "trace_cache_key": authenticated_sparse_bundle.trace_cache_key,
            "admitted_axis_sha256s": list(
                authenticated_sparse_bundle.admitted_sha256s
            ),
            "consumed_axis_sha256s": list(consumed_sparse_admissions),
            "map_sha256s": [axis.map_sha256 for axis in ordered_axes],
            "source_witness_sha256s": [
                axis.witness_sha256 for axis in ordered_axes
            ],
            "admitted_axis_count": len(ordered_axes),
            "consumed_axis_count": len(consumed_sparse_admissions),
            "all_admissions_consumed": True,
            "dynamic_body_feature_map_solve_count": 0,
            "live_source_values_reauthenticated": True,
            "compile_time_only": True,
            "runtime_parameter_count": 0,
            "runtime_buffer_count": 0,
            "runtime_sidecar_count": 0,
        }
        sparse_bundle_report["materialization_sha256"] = canonical_sha256(
            sparse_bundle_report
        )
    return {
        "schema": DENSE_BUDGET_FOLD_SCHEMA,
        "layers": layer_reports,
        "complete_target_parameter_overwrite": True,
        "target_unique_parameter_objects_written": len(written),
        "target_nonzero_parameter_elements": nonzero,
        "source_layer_count": len(source_layers),
        "target_layer_count": len(target_layers),
        "source_layer_types": list(source_types),
        "target_layer_types": list(target_types),
        "depth_composition_used": False,
        "quantization_used": False,
        "pruning_used": False,
        "training_used": False,
        "optimizer_steps": 0,
        "backward_calls": 0,
        "parent_forward_calls": 0,
        "parent_trace_regeneration_calls": 0,
        "dynamic_body_feature_map_solve_count": (
            dynamic_body_feature_map_solve_count
        ),
        "sparse_feature_fold_bundle_used": (
            authenticated_sparse_bundle is not None
        ),
        "sparse_feature_fold_bundle": sparse_bundle_report,
        "factor_writer_layer_count": len(factor_layer_indices),
        "factor_writer_cached_output_action_evidence_count": (
            factor_output_action_evidence_count
        ),
        "per_layer_cpu_fp64_temporary_release": True,
        "cpu_allocator_trim_requested_after_each_structural_layer": True,
        "tokenizer_bridge_used": tokenizer_bridge_artifact is not None,
        "strict_vocabulary_operator_transport": vocabulary_transport_report,
    }


def _initial_structural_fold_or_authenticated_resume(
    *,
    restart_resume: Any | None,
    structural_fold: Callable[[], Mapping[str, Any]],
    fold_progress: _Lfm2DenseFoldProgress,
) -> Mapping[str, Any]:
    """Execute structural folding only when no authenticated capsule restored it."""

    if restart_resume is None:
        report = structural_fold()
        if not isinstance(report, Mapping):
            raise Lfm2DenseBudgetFoldError(
                "The initial structural fold returned no report."
            )
        return report
    skipped_body = {
        "schema": "neural-forge-lfm2-dense-structural-fold-resume-skip-v1",
        "mode": "authenticated_restart_capsule_restore",
        "structural_parent_to_blank_fold_executed": False,
        "capsule_key": restart_resume.reference.capsule_key,
        "capsule_manifest_sha256": restart_resume.reference.manifest_sha256,
        "restored_child_state_sha256": restart_resume.child_state_sha256,
        "restored_child_topology_sha256": restart_resume.child_topology_sha256,
        "parent_forward_calls": 0,
        "training_steps": 0,
        "backward_calls": 0,
        "optimizer_steps": 0,
    }
    fold_progress.emit(
        "dense_structural_fold_skipped_restart_resume",
        capsule_key=restart_resume.reference.capsule_key,
        structural_parent_to_blank_fold_executed=False,
        restored_child_state_sha256=restart_resume.child_state_sha256,
    )
    return {**skipped_body, "report_sha256": canonical_sha256(skipped_body)}


class Lfm2DenseBudgetModelTransaction:
    """Whole-child transaction around initial transport and closed-loop repair."""

    method_id = DENSE_BUDGET_MODEL_METHOD

    def __init__(
        self,
        context: FoldExecutionContext,
        snapshot: tuple[tuple[str, Any], ...],
        topology_before: str,
        incumbent_state_fingerprint: str,
    ) -> None:
        self.context = context
        self._snapshot = snapshot
        self._topology_before = topology_before
        self.incumbent_state_fingerprint = incumbent_state_fingerprint
        self.candidate_state_fingerprint = incumbent_state_fingerprint
        self.plan = Lfm2DenseBudgetFoldPlan(
            {
                "schema": DENSE_BUDGET_FOLD_SCHEMA,
                "zero_gradient": True,
                "seed_erasure_by_construction": False,
                "prepared": False,
            }
        )
        self.active = True

    def bind_candidate(
        self,
        *,
        plan: Lfm2DenseBudgetFoldPlan,
        candidate_state_fingerprint: str,
    ) -> None:
        if not self.active:
            raise Lfm2DenseBudgetFoldError("Cannot bind an inactive dense transaction.")
        candidate = _digest(
            candidate_state_fingerprint,
            "candidate_state_fingerprint",
        )
        if candidate == self.incumbent_state_fingerprint:
            raise Lfm2DenseBudgetFoldError(
                "Dense fold candidate is identical to the blank child."
            )
        if _topology_fingerprint(self.context.child_model) != self._topology_before:
            raise Lfm2DenseBudgetFoldError("Dense fold changed Parameter topology.")
        self.plan = plan
        self.candidate_state_fingerprint = candidate

    def commit(self) -> Mapping[str, Any]:
        if not self.active:
            raise Lfm2DenseBudgetFoldError("Dense fold transaction is inactive.")
        final = self.context.child_state_fingerprint
        if (
            final != self.candidate_state_fingerprint
            or _topology_fingerprint(self.context.child_model) != self._topology_before
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense fold candidate changed before commit."
            )
        self.active = False
        result = {
            **self.plan.as_dict(),
            "action": "commit",
            "accepted": True,
            "exact": True,
            "candidate_state_fingerprint": self.candidate_state_fingerprint,
            "final_state_fingerprint": final,
            "parameter_topology_preserved": True,
        }
        diagnostic = self.plan.report.get("whole_child_component_diagnostic_execution")
        if isinstance(diagnostic, Mapping):
            result[TRANSACTION_REPORT_BINDING_KEY] = diagnostic["binding"]
        return result

    def rollback(self) -> Mapping[str, Any]:
        if not self.active:
            raise Lfm2DenseBudgetFoldError("Dense fold transaction is inactive.")
        _restore_state(self.context.child_model, self._snapshot)
        final = self.context.child_state_fingerprint
        topology = _topology_fingerprint(self.context.child_model)
        if (
            final != self.incumbent_state_fingerprint
            or topology != self._topology_before
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense fold rollback did not exactly restore the blank."
            )
        self.active = False
        result = {
            **self.plan.as_dict(),
            "action": "rollback",
            "accepted": False,
            "exact": True,
            "rollback_exact": True,
            "candidate_state_fingerprint": self.candidate_state_fingerprint,
            "final_state_fingerprint": final,
            "parameter_topology_preserved": True,
            "zero_gradient": True,
        }
        diagnostic = self.plan.report.get("whole_child_component_diagnostic_execution")
        if isinstance(diagnostic, Mapping):
            result[TRANSACTION_REPORT_BINDING_KEY] = diagnostic["binding"]
        return result


class Lfm2DenseBudgetModelOperator:
    """One authenticated, full-coverage dense-width model FoldOperator."""

    method_id = DENSE_BUDGET_MODEL_METHOD
    whole_child_component_diagnostic_capability = (
        WHOLE_CHILD_DIAGNOSTIC_OPERATOR_CAPABILITY
    )

    def __init__(
        self,
        selected_target: Lfm2DenseBudgetedSelectedTarget,
        trace_cache: Lfm2CircuitTraceCache,
        *,
        config: Lfm2DenseBudgetFoldConfig | None = None,
        verification_lease: Lfm2DenseCacheVerificationLease | None = None,
        selective_session: Lfm2CircuitTraceSelectiveAuthenticatedSession | None = None,
        tokenizer_bridge_artifact: StrictTokenizerBridgeArtifact | None = None,
        tokenizer_bridge_trace_adapter: (
            Lfm2StrictTokenizerBridgeTraceAdapter | None
        ) = None,
        target_tokenizer_vocabulary_margin_binding: (
            Lfm2TargetTokenizerVocabularyMarginBinding | None
        ) = None,
        residual_basis_phase_cache_context: (
            Lfm2BalancedBasisPhaseCacheContext | None
        ) = None,
        autoregressive_hankel_observability: (
            Lfm2AutoregressiveHankelObservabilityResult
            | PrecomputedDownstreamObservability
            | None
        ) = None,
        sparse_feature_fold_bundle: Lfm2SparseFeatureFoldBundle | None = None,
        evidence_set: Lfm2SealedEvidenceSet | None = None,
        progress_sink: (
            Callable[[str, Mapping[str, JsonScalar]], None] | None
        ) = None,
    ) -> None:
        if not isinstance(
            selected_target,
            Lfm2DenseBudgetedSelectedTarget,
        ):
            raise Lfm2DenseBudgetFoldError(
                "selected_target must be Lfm2DenseBudgetedSelectedTarget."
            )
        # Additive base+extension entry point.  Without an evidence set, or
        # with a base-only one, every binding below is the single sealed handle
        # this operator has always taken.
        trace_cache, selective_session = _resolve_dense_evidence_handles(
            trace_cache,
            selective_session,
            evidence_set,
        )
        self.evidence_set = evidence_set
        if not isinstance(trace_cache, SEALED_EVIDENCE_CACHE_TYPES):
            raise Lfm2DenseBudgetFoldError(
                "Dense folding requires a typed sealed Lfm2CircuitTraceCache or "
                "one merged sealed evidence-set view."
            )
        self.selected_target = selected_target
        if progress_sink is not None and not callable(progress_sink):
            raise Lfm2DenseBudgetFoldError(
                "progress_sink must be callable or None."
            )
        self.progress_sink = progress_sink
        if selective_session is not None and not isinstance(
            selective_session,
            SEALED_EVIDENCE_SESSION_TYPES,
        ):
            raise Lfm2DenseBudgetFoldError(
                "selective_session must be an authenticated LFM2 cache session."
            )
        if selective_session is not None and (
            selective_session.cache_key != trace_cache.cache_key
            or selective_session.path != trace_cache.path
            or len(selective_session) != len(trace_cache)
        ):
            raise Lfm2DenseBudgetFoldError(
                "selective_session differs from the dense parent cache."
            )
        self.selective_session = selective_session
        self.verification_lease = verification_lease
        self.trace_cache = _verify_dense_trace_cache(
            trace_cache,
            verification_lease,
        )
        self.config = config or Lfm2DenseBudgetFoldConfig()
        if not isinstance(self.config, Lfm2DenseBudgetFoldConfig):
            raise Lfm2DenseBudgetFoldError("config must be Lfm2DenseBudgetFoldConfig.")
        if sparse_feature_fold_bundle is not None:
            from .hf_lfm2_sparse_feature_fold_bundle import (
                Lfm2SparseFeatureFoldBundle,
                Lfm2SparseFeatureFoldBundleError,
            )
            from .matrix_technique_body_routes import (
                T5BodyRouteAuthenticationError,
            )

            if not isinstance(
                sparse_feature_fold_bundle,
                Lfm2SparseFeatureFoldBundle,
            ):
                raise Lfm2DenseBudgetFoldError(
                    "sparse_feature_fold_bundle must be "
                    "Lfm2SparseFeatureFoldBundle."
                )
            try:
                sparse_feature_fold_bundle.verify()
            except (
                Lfm2SparseFeatureFoldBundleError,
                FeatureFoldError,
                T5BodyRouteAuthenticationError,
            ) as exc:
                raise Lfm2DenseBudgetFoldError(
                    "Sparse feature-fold bundle failed constructor authentication."
                ) from exc
            if (
                self.config.restart_capsule_directory is not None
                or self.config.resume_from_restart_capsule is not None
            ):
                raise Lfm2DenseBudgetFoldError(
                    "Sparse feature-fold bundles cannot use restart capsules until "
                    "the capsule schema binds bundle admission consumption."
                )
        self.sparse_feature_fold_bundle = sparse_feature_fold_bundle
        self.resource_fingerprint = (
            None
            if sparse_feature_fold_bundle is None
            else external_resource_bindings_sha256(
                {
                    LFM2_SPARSE_FEATURE_FOLD_BUNDLE_RESOURCE_NAME: (
                        sparse_feature_fold_bundle.bundle_sha256
                    )
                }
            )
        )
        if evidence_set is not None and evidence_set.has_extension_evidence:
            # Honest gates.  These three consumers still bind exactly the base
            # sealed corpus, so a base+extension request would silently be
            # solved base-only in them.
            if selected_target.tokenizer_bridge_required:
                # A bridged target may consume extension evidence exactly when
                # its target-token replay covers the merged corpus, which is
                # what a round's sealed target-token preimage buys.  A
                # base-only replay leaves every extension batch without a
                # child replay, so it still fails closed here and not later.
                _assert_bridge_replay_covers_evidence_set(
                    tokenizer_bridge_trace_adapter,
                    evidence_set,
                )
            if self.config.macro_cell_attractor_gate_config is not None:
                raise Lfm2DenseBudgetFoldError(
                    "The macro-cell attractor gate binds one sealed cache "
                    "handle and cannot consume on-policy extension evidence."
                )
            if self.config.vocabulary_margin_candidate_gate_enabled:
                raise Lfm2DenseBudgetFoldError(
                    "The vocabulary-margin candidate gate binds one sealed "
                    "cache handle and cannot consume on-policy extension "
                    "evidence."
                )
        if residual_basis_phase_cache_context is not None and not isinstance(
            residual_basis_phase_cache_context,
            Lfm2BalancedBasisPhaseCacheContext,
        ):
            raise Lfm2DenseBudgetFoldError(
                "residual_basis_phase_cache_context has the wrong type."
            )
        if (
            residual_basis_phase_cache_context is not None
            and self.config.residual_basis_mode != "circuit_balanced"
        ):
            raise Lfm2DenseBudgetFoldError(
                "Residual-basis phase caching is only defined for the "
                "circuit-balanced basis."
            )
        if autoregressive_hankel_observability is not None:
            if not isinstance(
                autoregressive_hankel_observability,
                (
                    Lfm2AutoregressiveHankelObservabilityResult,
                    PrecomputedDownstreamObservability,
                ),
            ):
                raise Lfm2DenseBudgetFoldError(
                    "autoregressive_hankel_observability has the wrong type."
                )
            if self.config.residual_basis_mode != "circuit_balanced":
                raise Lfm2DenseBudgetFoldError(
                    "Autoregressive Hankel observability requires the "
                    "circuit-balanced residual basis."
                )
            evidence = (
                autoregressive_hankel_observability.evidence
                if isinstance(
                    autoregressive_hankel_observability,
                    Lfm2AutoregressiveHankelObservabilityResult,
                )
                else autoregressive_hankel_observability
            )
            if not evidence.verify():
                raise Lfm2DenseBudgetFoldError(
                    "Autoregressive Hankel observability failed authentication."
                )
        if (
            residual_basis_phase_cache_context is not None
            and selective_session is None
            and not self.config.vocabulary_margin_candidate_gate_enabled
        ):
            raise Lfm2DenseBudgetFoldError(
                "Residual-basis phase caching requires the selective "
                "authenticated trace session so a hit loads no trace tensors."
            )
        if selected_target.tokenizer_bridge_required:
            if not isinstance(
                tokenizer_bridge_artifact,
                StrictTokenizerBridgeArtifact,
            ):
                raise Lfm2DenseBudgetFoldError(
                    "Bridged dense target requires its explicit strict "
                    "tokenizer bridge artifact."
                )
            try:
                tokenizer_bridge_artifact.verify_files()
            except ValueError as exc:
                raise Lfm2DenseBudgetFoldError(
                    "Dense tokenizer bridge artifact failed verification."
                ) from exc
            if (
                tokenizer_bridge_artifact.artifact_sha256
                != selected_target.tokenizer_bridge_artifact_sha256
                or tokenizer_bridge_artifact.profile_fingerprint
                != selected_target.tokenizer_transport_profile_sha256
                or tokenizer_bridge_artifact.donor_tokenizer_semantics_sha256
                != selected_target.parent_tokenizer_semantics_sha256
                or tokenizer_bridge_artifact.target_tokenizer_semantics_sha256
                != selected_target.child_tokenizer_semantics_sha256
                or tokenizer_bridge_artifact.transport_profile.target_row_capacity
                != selected_target.vocabulary_size
            ):
                raise Lfm2DenseBudgetFoldError(
                    "Dense tokenizer bridge artifact differs from selected "
                    "target metadata."
                )
            if tokenizer_bridge_trace_adapter is not None:
                if not isinstance(
                    tokenizer_bridge_trace_adapter,
                    Lfm2StrictTokenizerBridgeTraceAdapter,
                ):
                    raise Lfm2DenseBudgetFoldError(
                        "Dense tokenizer bridge trace adapter has the wrong type."
                    )
                try:
                    tokenizer_bridge_trace_adapter.verify()
                except Lfm2StrictTokenizerBridgeTraceError as exc:
                    raise Lfm2DenseBudgetFoldError(
                        "Dense tokenizer bridge trace adapter failed verification."
                    ) from exc
                ordered_cache_inputs = tuple(
                    str(value)
                    for value in self.trace_cache.manifest["corpus"][
                        "ordered_batch_input_sha256"
                    ]
                )
                if (
                    tokenizer_bridge_trace_adapter.bridge_artifact_sha256
                    != tokenizer_bridge_artifact.artifact_sha256
                    or tokenizer_bridge_trace_adapter.transport_profile_fingerprint
                    != tokenizer_bridge_artifact.profile_fingerprint
                    or tokenizer_bridge_trace_adapter.record_count
                    != len(self.trace_cache)
                    or any(
                        record.ordinal != index
                        or record.donor_cache_input_sha256 != input_sha256
                        for index, (record, input_sha256) in enumerate(
                            zip(
                                tokenizer_bridge_trace_adapter.records,
                                ordered_cache_inputs,
                                strict=True,
                            )
                        )
                    )
                ):
                    raise Lfm2DenseBudgetFoldError(
                        "Dense tokenizer bridge trace evidence differs from the "
                        "artifact or sealed parent cache."
                    )
            elif self.config.run_closed_loop:
                raise Lfm2DenseBudgetFoldError(
                    "Bridged closed-loop folding requires its sealed target-token "
                    "trace adapter."
                )
            if (
                self.config.vocabulary_margin_candidate_gate_enabled
                or self.config.macro_cell_attractor_gate_config is not None
            ):
                raise Lfm2DenseBudgetFoldError(
                    "Bridged vocabulary-margin or macro-attractor replay requires "
                    "its target-token-aware evaluator; use the bridged closed loop "
                    "and external whole-output semantic evaluation for this run."
                )
            if self.config.vocabulary_margin_observability:
                if not self.config.streaming_vocabulary_margin_v2:
                    raise Lfm2DenseBudgetFoldError(
                        "Bridged vocabulary-margin observability requires the "
                        "target-aware streaming-v2 path."
                    )
                if not isinstance(
                    target_tokenizer_vocabulary_margin_binding,
                    Lfm2TargetTokenizerVocabularyMarginBinding,
                ):
                    raise Lfm2DenseBudgetFoldError(
                        "Bridged streaming-v2 vocabulary margins require their "
                        "fully authenticated target tokenizer binding."
                    )
                try:
                    target_tokenizer_vocabulary_margin_binding.verify()
                except ValueError as exc:
                    raise Lfm2DenseBudgetFoldError(
                        "Target tokenizer vocabulary-margin binding failed "
                        "verification."
                    ) from exc
                if (
                    tokenizer_bridge_trace_adapter is None
                    or target_tokenizer_vocabulary_margin_binding.trace_adapter
                    is not tokenizer_bridge_trace_adapter
                ):
                    raise Lfm2DenseBudgetFoldError(
                        "Target vocabulary-margin binding differs from the dense "
                        "tokenizer trace adapter."
                    )
            elif target_tokenizer_vocabulary_margin_binding is not None:
                raise Lfm2DenseBudgetFoldError(
                    "Dense fold received an unused target vocabulary-margin "
                    "binding."
                )
        elif tokenizer_bridge_artifact is not None:
            raise Lfm2DenseBudgetFoldError(
                "Unbridged dense target received an unused tokenizer bridge artifact."
            )
        elif tokenizer_bridge_trace_adapter is not None:
            raise Lfm2DenseBudgetFoldError(
                "Unbridged dense target received an unused tokenizer bridge "
                "trace adapter."
            )
        elif target_tokenizer_vocabulary_margin_binding is not None:
            raise Lfm2DenseBudgetFoldError(
                "Unbridged dense target received an unused target "
                "vocabulary-margin binding."
            )
        self.tokenizer_bridge_artifact = tokenizer_bridge_artifact
        self.tokenizer_bridge_trace_adapter = tokenizer_bridge_trace_adapter
        self.target_tokenizer_vocabulary_margin_binding = (
            target_tokenizer_vocabulary_margin_binding
        )
        self.residual_basis_phase_cache_context = (
            residual_basis_phase_cache_context
        )
        self.autoregressive_hankel_observability = (
            autoregressive_hankel_observability
        )

    def _residual_basis_phase_bindings(
        self,
    ) -> Mapping[str, Mapping[str, Any]]:
        """Reauthenticate compact target/token bindings around every phase use."""

        bridge = self.tokenizer_bridge_artifact
        adapter = self.tokenizer_bridge_trace_adapter
        vocabulary_binding = self.target_tokenizer_vocabulary_margin_binding
        tokenizer: dict[str, Any] = {
            "schema": "neural-forge-lfm2-balanced-basis-tokenizer-binding-v1",
            "parent_tokenizer_semantics_sha256": (
                self.selected_target.parent_tokenizer_semantics_sha256
            ),
            "child_tokenizer_semantics_sha256": (
                self.selected_target.child_tokenizer_semantics_sha256
            ),
            "bridge_required": self.selected_target.tokenizer_bridge_required,
            "bridge_artifact_sha256": None,
            "bridge_profile_sha256": None,
            "bridge_target_package_sha256": None,
            "bridge_trace_adapter_evidence_sha256": None,
            "target_vocabulary_margin_binding_sha256": None,
        }
        if bridge is not None:
            try:
                bridge.verify_files()
            except ValueError as exc:
                raise Lfm2DenseBudgetFoldError(
                    "Tokenizer bridge changed while authenticating the "
                    "residual-basis phase."
                ) from exc
            tokenizer.update(
                {
                    "bridge_artifact_sha256": bridge.artifact_sha256,
                    "bridge_profile_sha256": bridge.profile_fingerprint,
                }
            )
        if adapter is not None:
            try:
                adapter.verify()
            except Lfm2StrictTokenizerBridgeTraceError as exc:
                raise Lfm2DenseBudgetFoldError(
                    "Tokenizer bridge trace adapter changed while authenticating "
                    "the residual-basis phase."
                ) from exc
            tokenizer.update(
                {
                    "bridge_target_package_sha256": (
                        adapter.target_tokenizer_package_fingerprint
                    ),
                    "bridge_trace_adapter_evidence_sha256": (
                        adapter.evidence_sha256
                    ),
                }
            )
        if vocabulary_binding is not None:
            try:
                vocabulary_binding.verify()
            except ValueError as exc:
                raise Lfm2DenseBudgetFoldError(
                    "Target vocabulary binding changed while authenticating the "
                    "residual-basis phase."
                ) from exc
            tokenizer["target_vocabulary_margin_binding_sha256"] = (
                vocabulary_binding.binding_sha256
            )
        return {
            "selected_target": self.selected_target.as_dict(),
            "tokenizer": tokenizer,
        }

    # -- accepted-layer restart capsules -------------------------------

    def _load_restart_capsule_resume(
        self,
        child_model: Any,
        fold_progress: _Lfm2DenseFoldProgress,
    ) -> Any | None:
        """Restore the newest sealed capsule into the fresh blank child.

        The capsule is loaded before the structural fold and closed-loop
        adapter exist because it already contains the exact structural fold
        plus accepted layer prefix, and because
        ``Lfm2DynamicClosedLoopAdapter.__init__`` snapshots the child's input
        vocabulary digest into the identity bindings the capsule pins.
        """

        root = self.config.resume_from_restart_capsule
        if root is None:
            return None
        try:
            reference = latest_lfm2_closed_loop_restart_capsule(root)
        except Lfm2ClosedLoopRestartCapsuleError as exc:
            raise Lfm2DenseBudgetFoldError(
                "Restart-capsule resume root failed authentication."
            ) from exc
        if reference is None:
            raise Lfm2DenseBudgetFoldError(
                "An explicit restart-capsule resume found no sealed capsule "
                f"under {root}."
            )
        try:
            resume = load_lfm2_closed_loop_restart_capsule(
                reference,
                child_model=child_model,
            )
        except Lfm2ClosedLoopRestartCapsuleError as exc:
            raise Lfm2DenseBudgetFoldError(
                "Restart capsule failed to restore into the fresh child."
            ) from exc
        fold_progress.emit(
            "dense_restart_capsule_resume_loaded",
            capsule_key=resume.reference.capsule_key,
            capsule_sequence=resume.reference.capsule_sequence,
            capsule_layer_index=resume.reference.layer_index,
            completed_layer_count=len(resume.completed_layer_indices),
            resume_layer_index=resume.resume_layer_index,
            child_state_sha256=resume.child_state_sha256,
            skipped_layers_are_not_replayed=True,
        )
        return resume

    def _build_restart_capsule_writer(
        self,
        adapter: Lfm2DynamicClosedLoopAdapter,
        compiler_config: ClosedLoopCompilerConfig,
        *,
        action: FoldAction,
        context: FoldExecutionContext,
        resume: Any | None,
        fold_progress: _Lfm2DenseFoldProgress,
    ) -> Lfm2ClosedLoopRestartCapsuleWriter | None:
        """Bind one accepted-layer capsule writer to this body fold."""

        directory = self.config.restart_capsule_directory
        if directory is None:
            if resume is not None:
                raise Lfm2DenseBudgetFoldError(
                    "A restart-capsule resume requires the capsule directory "
                    "the resumed run keeps writing to."
                )
            return None
        directory.mkdir(parents=True, exist_ok=True)
        try:
            writer = Lfm2ClosedLoopRestartCapsuleWriter(
                adapter=adapter,
                directory=directory,
                run_id=action.action_sha256,
                child_name=context.child_graph.model_name,
                trajectory_split_sha256=lfm2_restart_capsule_split_sha256(
                    adapter,
                    compiler_config,
                ),
                run_schema=CLOSED_LOOP_RUN_SCHEMA,
                resume=resume,
                rotation_keep=self.config.restart_capsule_rotation_keep,
                fold_progress_sink=fold_progress,
                publish_terminal_capsule=(
                    self.config.restart_capsule_publish_terminal
                ),
            )
        except Lfm2ClosedLoopRestartCapsuleError as exc:
            raise Lfm2DenseBudgetFoldError(
                "Accepted-layer restart capsule writer failed to bind to this "
                "dense body fold."
            ) from exc
        fold_progress.emit(
            "dense_restart_capsule_writer_bound",
            capsule_directory=str(directory),
            rotation_keep=writer.rotation_keep,
            resumed=resume is not None,
            completed_layer_count=len(writer.completed_layer_indices()),
            bindings_sha256=writer.bindings.bindings_sha256,
        )
        return writer

    def _restart_capsule_binding(
        self,
        writer: Lfm2ClosedLoopRestartCapsuleWriter,
        *,
        resume: Any | None,
    ) -> Mapping[str, Any]:
        """Record the capsule identities this transaction report binds to."""

        body = {
            "schema": DENSE_RESTART_CAPSULE_BINDING_SCHEMA,
            "enabled": True,
            "directory": str(writer.directory),
            "rotation_keep": writer.rotation_keep,
            "terminal_capsule_enabled": bool(writer.publish_terminal_capsule),
            "bindings_sha256": writer.bindings.bindings_sha256,
            "resumed": resume is not None,
            "resumed_capsule_key": (
                None if resume is None else resume.reference.capsule_key
            ),
            "resumed_capsule_chain_sha256": (
                None
                if resume is None
                else resume.reference.capsule_chain_sha256
            ),
            "resumed_completed_layer_indices": (
                []
                if resume is None
                else [int(value) for value in resume.completed_layer_indices]
            ),
            "restart_capsule_is_not_a_promotable_child": True,
        }
        return MappingProxyType({**body, "binding_sha256": canonical_sha256(body)})

    def _validate_action(
        self,
        action: FoldAction,
        context: FoldExecutionContext,
    ) -> tuple[
        str,
        Any,
        ModelCircuitGraph,
        AuthenticatedWholeChildComponentDispatch | None,
    ]:
        if action.method_id != self.method_id:
            raise Lfm2DenseBudgetFoldError(
                "Dense LFM2 operator received a different method."
            )
        if len(action.sources) != 1 or action.compression_delta <= 0:
            raise Lfm2DenseBudgetFoldError(
                "Dense LFM2 execution requires one parent and positive compaction."
            )
        source = action.sources[0]
        if source.parent_name != self.selected_target.source_parent:
            raise Lfm2DenseBudgetFoldError(
                "Dense action source differs from the selected catalog parent."
            )
        parent_graph = context.parent_graphs[source.parent_name]
        if (
            parent_graph.fingerprint != self.selected_target.source_graph_fingerprint
            or parent_graph.tokenizer_fingerprint
            != self.selected_target.parent_tokenizer_semantics_sha256
            or set(source.node_ids) != {node.node_id for node in parent_graph.nodes}
            or set(action.target_node_ids)
            != {node.node_id for node in context.child_graph.nodes}
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense action must own the authenticated complete source and target."
            )
        expected_source_units = {
            f"{source.parent_name}:{node.node_id}" for node in parent_graph.nodes
        }
        if (
            action.signature.method_id != self.method_id
            or action.signature.parent_graph_fingerprints
            != (parent_graph.fingerprint,)
            or action.signature.child_graph_fingerprint
            != context.child_graph.fingerprint
            or dict(action.signature.parent_state_fingerprints)
            != {
                source.parent_name: self.selected_target.source_state_fingerprint
            }
            or set(action.signature.source_unit_ids) != expected_source_units
            or set(action.signature.target_unit_ids)
            != {node.node_id for node in context.child_graph.nodes}
            or action.signature.child_state_fingerprint
            != context.child_state_fingerprint
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense action signature differs from the live source/target "
                "graph and state identities."
            )
        expected_paths = {
            name
            for name, _parameter in context.child_model.named_parameters(
                recurse=True,
                remove_duplicate=False,
            )
        }
        if set(action.target_parameter_paths) != expected_paths:
            raise Lfm2DenseBudgetFoldError(
                "Dense action does not own every target parameter path."
            )
        configuration = dict(action.configuration)
        if dict(action.signature.configuration) != configuration:
            raise Lfm2DenseBudgetFoldError(
                "Dense action and signature configurations differ."
            )
        aggregate_present = (
            EXTERNAL_RESOURCE_BINDINGS_CONFIGURATION_KEY in configuration
        )
        if self.resource_fingerprint is None:
            if aggregate_present:
                raise Lfm2DenseBudgetFoldError(
                    "Dense action declares unexpected external resource bindings."
                )
        elif (
            not aggregate_present
            or configuration[EXTERNAL_RESOURCE_BINDINGS_CONFIGURATION_KEY]
            != self.resource_fingerprint
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense action external resource aggregate differs from the "
                "authenticated sparse feature-fold bundle."
            )
        expected = {
            "catalog_id": self.selected_target.catalog_id,
            "source_depth": len(parent_graph.layer_indices),
            "target_depth": self.selected_target.target_depth,
            "source_spans": encode_lfm2_source_spans(
                self.selected_target.ordered_source_spans
            ),
            "target_layer_types": encode_lfm2_layer_types(
                self.selected_target.layer_types
            ),
            "target_hidden_size": self.selected_target.hidden_size,
            "target_intermediate_size": self.selected_target.intermediate_size,
            "target_query_heads": self.selected_target.query_heads,
            "target_key_value_heads": self.selected_target.key_value_heads,
            "target_head_dim": self.selected_target.head_dim,
        }
        if self.selected_target.tokenizer_bridge_required:
            expected.update(
                {
                    "tokenizer_bridge_required": True,
                    "tokenizer_bridge_artifact_sha256": (
                        self.selected_target.tokenizer_bridge_artifact_sha256
                    ),
                    "tokenizer_transport_profile_sha256": (
                        self.selected_target.tokenizer_transport_profile_sha256
                    ),
                    "parent_tokenizer_semantics_sha256": (
                        self.selected_target.parent_tokenizer_semantics_sha256
                    ),
                    "child_tokenizer_semantics_sha256": (
                        self.selected_target.child_tokenizer_semantics_sha256
                    ),
                }
            )
        if any(configuration.get(name) != value for name, value in expected.items()):
            raise Lfm2DenseBudgetFoldError(
                "Dense action topology differs from its selected catalog target."
            )
        if len(parent_graph.layer_indices) != self.selected_target.target_depth:
            raise Lfm2DenseBudgetFoldError(
                "Ordered source-span composition is required for this depth-"
                "changing dense target; 4x/10x depth compaction is fail-closed "
                "until that composition operator is implemented."
            )
        expected_spans = tuple(
            (index,) for index in range(len(parent_graph.layer_indices))
        )
        if self.selected_target.ordered_source_spans != expected_spans:
            raise Lfm2DenseBudgetFoldError(
                "Same-depth dense folding requires one source layer per target."
            )
        parent_model = context.parent_models[source.parent_name]
        if fingerprint_model_state(parent_model) != (
            self.selected_target.source_state_fingerprint
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense source checkpoint changed after target selection."
            )
        if self.sparse_feature_fold_bundle is not None:
            from .hf_lfm2_sparse_feature_fold_bundle import (
                Lfm2SparseFeatureFoldBundleError,
            )
            from .matrix_technique_body_routes import (
                T5BodyRouteAuthenticationError,
            )

            try:
                bundle = self.sparse_feature_fold_bundle.verify()
            except (
                Lfm2SparseFeatureFoldBundleError,
                FeatureFoldError,
                T5BodyRouteAuthenticationError,
            ) as exc:
                raise Lfm2DenseBudgetFoldError(
                    "Sparse feature-fold bundle changed after operator construction."
                ) from exc
            if (
                bundle.source_graph_sha256 != parent_graph.fingerprint
                or bundle.target_graph_sha256 != context.child_graph.fingerprint
                or any(
                    axis.source_witness.parent_state_fingerprint
                    != self.selected_target.source_state_fingerprint
                    or axis.source_witness.evidence_cache_sha256
                    != self.trace_cache.cache_key
                    for axis in bundle.axes
                )
            ):
                raise Lfm2DenseBudgetFoldError(
                    "Sparse feature-fold bundle differs from the action graphs, "
                    "parent state, or sealed trace cache."
                )
        validate_lfm2_dense_budgeted_child(
            self.selected_target,
            context.child_model,
            context.child_graph,
        )
        try:
            dispatch = authenticate_whole_child_component_dispatch(
                action,
                context.child_graph,
                expected_method_id=self.method_id,
            )
        except WholeChildComponentDiagnosticError as exc:
            raise Lfm2DenseBudgetFoldError(
                "Dense LFM2 component dispatch failed authentication."
            ) from exc
        if dispatch is not None:
            _component_stage_assignments(dispatch)
        return source.parent_name, parent_model, parent_graph, dispatch

    def prepare(
        self,
        action: FoldAction,
        context: FoldExecutionContext,
        evidence: FoldEvidence,
    ) -> FoldTransaction:
        (
            source_name,
            parent_model,
            parent_graph,
            component_dispatch,
        ) = self._validate_action(action, context)
        if not isinstance(
            evidence.payload,
            Lfm2SealedDenseBudgetEvidence,
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense fold evidence lost its verified trace-cache seal."
            )
        sealed_evidence = evidence.payload.verify()
        if sealed_evidence.trace_cache is not self.trace_cache:
            raise Lfm2DenseBudgetFoldError(
                "Dense fold evidence contains a different trace-cache handle."
            )
        incumbent = context.child_state_fingerprint
        topology_before = _topology_fingerprint(context.child_model)
        snapshot = _state_snapshot(context.child_model)
        parent_before = fingerprint_model_state(parent_model)
        transaction = Lfm2DenseBudgetModelTransaction(
            context,
            snapshot,
            topology_before,
            incumbent,
        )
        try:
            fold_progress = _Lfm2DenseFoldProgress(
                self.progress_sink,
                action_sha256=action.action_sha256,
                catalog_id=self.selected_target.catalog_id,
                parent_cache_key=self.trace_cache.cache_key,
                target_hidden_size=self.selected_target.hidden_size,
            )
            basis = _build_residual_basis(
                parent_model,
                parent_graph,
                self.trace_cache,
                self.selected_target.hidden_size,
                self.config,
                selective_session=self.selective_session,
                target_tokenizer_vocabulary_margin_binding=(
                    self.target_tokenizer_vocabulary_margin_binding
                ),
                phase_cache_context=self.residual_basis_phase_cache_context,
                phase_cache_binding_provider=(
                    None
                    if self.residual_basis_phase_cache_context is None
                    else self._residual_basis_phase_bindings
                ),
                autoregressive_hankel_observability=(
                    self.autoregressive_hankel_observability
                ),
            )
            if (
                component_dispatch is not None
                and self.config.resume_from_restart_capsule is not None
            ):
                raise Lfm2DenseBudgetFoldError(
                    "Accepted-layer resume cannot reconstruct the separate "
                    "pre-closed-loop structural snapshot required by a "
                    "component-dispatch diagnostic."
                )
            if self.sparse_feature_fold_bundle is not None and (
                self.config.restart_capsule_directory is not None
                or self.config.resume_from_restart_capsule is not None
            ):
                raise Lfm2DenseBudgetFoldError(
                    "Sparse feature-fold bundle execution cannot use restart "
                    "capsules until their schema binds bundle consumption."
                )
            # A capsule already contains the structural parent-to-blank fold
            # plus its accepted closed-loop prefix.  Restore it before any
            # structural materialization and do not recompute work whose exact
            # child bytes the authenticated capsule replaces.
            restart_resume = self._load_restart_capsule_resume(
                context.child_model,
                fold_progress,
            )
            initial_report = _initial_structural_fold_or_authenticated_resume(
                restart_resume=restart_resume,
                structural_fold=lambda: _fold_dense_blank_from_parent(
                    parent_model,
                    context.child_model,
                    basis,
                    self.tokenizer_bridge_artifact,
                    selective_session=self.selective_session,
                    progress=fold_progress,
                    sparse_feature_fold_bundle=(
                        self.sparse_feature_fold_bundle
                    ),
                    source_graph=parent_graph,
                    target_graph=context.child_graph,
                    trace_cache_key=self.trace_cache.cache_key,
                ),
                fold_progress=fold_progress,
            )
            sparse_bundle_action_binding: Mapping[str, Any] | None = None
            if self.sparse_feature_fold_bundle is not None:
                materialization = initial_report.get(
                    "sparse_feature_fold_bundle"
                )
                if (
                    not isinstance(materialization, Mapping)
                    or materialization.get("bundle_sha256")
                    != self.sparse_feature_fold_bundle.bundle_sha256
                    or materialization.get("all_admissions_consumed") is not True
                    or materialization.get("runtime_sidecar_count") != 0
                ):
                    raise Lfm2DenseBudgetFoldError(
                        "Sparse feature-fold structural report lost exact bundle "
                        "consumption authority."
                    )
                binding_body = {
                    "schema": (
                        "neural-forge-lfm2-sparse-feature-fold-action-binding-v1"
                    ),
                    "resource_name": (
                        LFM2_SPARSE_FEATURE_FOLD_BUNDLE_RESOURCE_NAME
                    ),
                    "bundle_sha256": (
                        self.sparse_feature_fold_bundle.bundle_sha256
                    ),
                    "external_resource_bindings_sha256": self.resource_fingerprint,
                    "action_sha256": action.action_sha256,
                    "configuration_sha256": (
                        action.signature.configuration_sha256
                    ),
                    "source_graph_sha256": parent_graph.fingerprint,
                    "target_graph_sha256": context.child_graph.fingerprint,
                    "parent_state_fingerprint": parent_before,
                    "trace_cache_key": self.trace_cache.cache_key,
                    "materialization_sha256": materialization[
                        "materialization_sha256"
                    ],
                    "all_admissions_consumed": True,
                    "compile_time_only": True,
                    "runtime_parameter_count": 0,
                    "runtime_buffer_count": 0,
                    "runtime_sidecar_count": 0,
                }
                sparse_bundle_action_binding = MappingProxyType(
                    {
                        **binding_body,
                        "binding_sha256": canonical_sha256(binding_body),
                    }
                )
                initial_report = {
                    **dict(initial_report),
                    "sparse_feature_fold_action_binding": dict(
                        sparse_bundle_action_binding
                    ),
                }
            initial_state = context.child_state_fingerprint
            structural_snapshot = (
                None
                if component_dispatch is None
                else _parameter_snapshot(context.child_model)
            )
            structural_buffers = (
                None
                if component_dispatch is None
                else _buffer_snapshot(context.child_model)
            )
            component_path_stages = (
                {}
                if component_dispatch is None
                else dict(_component_stage_assignments(component_dispatch))
            )
            execute_closed_loop = (
                self.config.run_closed_loop
                if component_dispatch is None
                else LFM2_COMPONENT_CLOSED_LOOP_STAGE
                in set(component_path_stages.values())
            )
            if execute_closed_loop and not self.config.run_closed_loop:
                raise Lfm2DenseBudgetFoldError(
                    "Component diagnostics requested cached closed-loop refinement "
                    "from an operator configured without that production stage."
                )
            closed_loop_report: Mapping[str, Any] | None = None
            restart_capsule_binding: Mapping[str, Any] | None = None
            if execute_closed_loop:
                compiler_config = (
                    self.config._closed_loop_compiler_config_for_execution()
                )
                available_layer_indices = tuple(
                    range(len(_layers(context.child_model)))
                )
                resolved_selected_layer_indices = (
                    available_layer_indices
                    if compiler_config.selected_layers is None
                    else compiler_config.selected_layers
                )
                terminal_only_restart_resume_requested = bool(
                    restart_resume is not None
                    and compiler_config.allow_terminal_only_restart_resume
                    and tuple(restart_resume.completed_layer_indices)
                    == tuple(resolved_selected_layer_indices)
                    and tuple(resolved_selected_layer_indices)
                    == available_layer_indices
                )
                body_reclosure_execution_requested = bool(
                    compiler_config.fold_body_reclosure
                    and not terminal_only_restart_resume_requested
                )
                fold_progress.emit(
                    "dense_closed_loop_started",
                    layer_count=len(_layers(context.child_model)),
                    body_reclosure_enabled=(
                        compiler_config.fold_body_reclosure
                    ),
                    restart_capsule_enabled=(
                        self.config.restart_capsule_directory is not None
                    ),
                    restart_capsule_resume_requested=(
                        self.config.resume_from_restart_capsule is not None
                    ),
                    **(
                        {}
                        if self.config.resume_from_restart_capsule is None
                        else {
                            "configured_body_reclosure_mode": (
                                self.config.body_reclosure_mode
                            ),
                            "body_reclosure_executed": (
                                body_reclosure_execution_requested
                            ),
                            "terminal_only_restart_resume_requested": (
                                terminal_only_restart_resume_requested
                            ),
                            "adapter_body_reclosure_mode_preserved": True,
                        }
                    ),
                )
                macro_cell_attractor_gate = (
                    None
                    if self.config.macro_cell_attractor_gate_config is None
                    else Lfm2MacroCellAttractorGate(
                        self.trace_cache,
                        config=(self.config.macro_cell_attractor_gate_config),
                    )
                )
                adapter = Lfm2DynamicClosedLoopAdapter(
                    source_model=parent_model,
                    child_model=context.child_model,
                    parent_cache=self.trace_cache,
                    coordinate_map=basis,
                    initial_child_basis_sha256=basis.map_sha256,
                    body_reclosure_mode=self.config.body_reclosure_mode,
                    body_coordinate_completion_recipe=(
                        self.config.body_coordinate_completion_recipe
                    ),
                    parent_residual_operators=basis.inventory.operators,
                    config=self.config.closed_loop_adapter_config,
                    macro_cell_attractor_gate=macro_cell_attractor_gate,
                    tokenizer_bridge_artifact=self.tokenizer_bridge_artifact,
                    tokenizer_bridge_trace_adapter=(
                        self.tokenizer_bridge_trace_adapter
                    ),
                    selective_session=self.selective_session,
                    source_graph_fingerprint=(
                        parent_graph.fingerprint
                        if self.selected_target.heterogeneous_layout
                        else None
                    ),
                    heterogeneous_layout_selection_receipt=(
                        self.selected_target.heterogeneous_layout_selection_receipt
                    ),
                    identity_tokenizer_evidence_sha256=(
                        None
                        if (
                            not self.selected_target.heterogeneous_layout
                            or self.tokenizer_bridge_artifact is not None
                        )
                        else lfm2_identity_tokenizer_evidence_sha256(
                            tokenizer_semantics_sha256=(
                                self.selected_target.parent_tokenizer_semantics_sha256
                            ),
                            vocabulary_size=(self.selected_target.vocabulary_size),
                        )
                    ),
                    evidence_set=self.evidence_set,
                    progress_sink=fold_progress,
                    child_replay_phase_cache_context=(
                        self.config.child_replay_phase_cache_context
                    ),
                    selected_layer_indices=compiler_config.selected_layers,
                )
                # Requested is a configuration fact; admitted is the adapter's
                # own decision about this exact child, replay mode, and parent
                # evidence.  Both are reported before any capture runs so an
                # opted-in run is auditable even when the hook declines.
                merge_requested = bool(
                    compiler_config.merge_adjacent_layer_captures
                )
                fold_progress.emit(
                    DENSE_CLOSED_LOOP_MERGE_CAPTURE_POLICY_STAGE,
                    merge_adjacent_layer_captures_requested=merge_requested,
                    merge_adjacent_layer_captures_admitted=bool(
                        adapter.supports_merged_child_captures()
                    ),
                    replay_capture_mode=(
                        self.config.closed_loop_adapter_config
                        .replay_capture_mode
                    ),
                    selective_session_bound=(
                        self.selective_session is not None
                    ),
                    heterogeneous_child=bool(
                        self.selected_target.heterogeneous_layout
                    ),
                )
                restart_writer = self._build_restart_capsule_writer(
                    adapter,
                    compiler_config,
                    action=action,
                    context=context,
                    resume=restart_resume,
                    fold_progress=fold_progress,
                )
                restart_capsule_binding = (
                    None
                    if restart_writer is None
                    else self._restart_capsule_binding(
                        restart_writer,
                        resume=restart_resume,
                    )
                )
                closed_loop_report = ChildClosedLoopCompiler(
                    adapter,
                    compiler_config,
                    progress_sink=fold_progress,
                    restart_capsule_config=restart_writer,
                ).run()
                fold_progress.emit(
                    "dense_closed_loop_completed",
                    closed_loop_run_sha256=str(
                        closed_loop_report["run_sha256"]
                    ),
                    body_reclosure_enabled=(
                        compiler_config.fold_body_reclosure
                    ),
                    **(
                        {}
                        if self.config.resume_from_restart_capsule is None
                        else {
                            "configured_body_reclosure_mode": (
                                self.config.body_reclosure_mode
                            ),
                            "body_reclosure_executed": (
                                bool(
                                    closed_loop_report[
                                        "body_reclosure_executed"
                                    ]
                                )
                            ),
                            "terminal_only_restart_resume_requested": (
                                terminal_only_restart_resume_requested
                            ),
                            "adapter_body_reclosure_mode_preserved": True,
                        }
                    ),
                )
                if restart_writer is not None:
                    fold_progress.emit(
                        "dense_restart_capsule_run_completed",
                        published_capsule_count=len(
                            restart_writer.as_dict()["published_capsule_keys"]
                        ),
                        resumed=restart_resume is not None,
                        rotation_keep=(
                            self.config.restart_capsule_rotation_keep
                        ),
                    )
            component_dispatch_report: Mapping[str, Any] | None = None
            if component_dispatch is not None:
                assert structural_snapshot is not None
                assert structural_buffers is not None
                closed_loop_snapshot = (
                    _parameter_snapshot(context.child_model)
                    if execute_closed_loop
                    else None
                )
                if execute_closed_loop:
                    _assert_buffer_snapshot_equal(
                        structural_buffers,
                        _buffer_snapshot(context.child_model),
                    )
                    assert closed_loop_snapshot is not None
                    _compose_component_stage_parameters(
                        context.child_model,
                        path_stages=component_path_stages,
                        structural_snapshot=structural_snapshot,
                        closed_loop_snapshot=closed_loop_snapshot,
                    )
                component_dispatch_report = _component_dispatch_execution_report(
                    component_dispatch,
                    context.child_model,
                    path_stages=component_path_stages,
                    structural_snapshot=structural_snapshot,
                    closed_loop_snapshot=closed_loop_snapshot,
                    exact_target_unique_parameters=(
                        self.selected_target.exact_target_unique_parameters
                    ),
                )
            candidate = context.child_state_fingerprint
            if fingerprint_model_state(parent_model) != parent_before:
                raise Lfm2DenseBudgetFoldError("Dense model fold mutated its parent.")
            if _topology_fingerprint(context.child_model) != topology_before:
                raise Lfm2DenseBudgetFoldError(
                    "Dense model fold changed child Parameter topology."
                )
            vocabulary_margin_candidate_gate = (
                _evaluate_vocabulary_margin_candidate_gate(
                    context.child_model,
                    self.trace_cache,
                    basis,
                    self.config,
                )
                if self.config.vocabulary_margin_candidate_gate_enabled
                else _disabled_vocabulary_margin_candidate_gate_report()
            )
            if context.child_state_fingerprint != candidate:
                raise Lfm2DenseBudgetFoldError(
                    "Vocabulary-margin candidate gating changed the folded child."
                )
            if fingerprint_model_state(parent_model) != parent_before:
                raise Lfm2DenseBudgetFoldError(
                    "Vocabulary-margin candidate gating mutated its parent."
                )
            report = {
                "schema": DENSE_BUDGET_FOLD_SCHEMA,
                "method_id": self.method_id,
                "source_parent": source_name,
                "catalog_id": self.selected_target.catalog_id,
                "tokenizer_bridge_required": (
                    self.selected_target.tokenizer_bridge_required
                ),
                "tokenizer_bridge_artifact_sha256": (
                    self.selected_target.tokenizer_bridge_artifact_sha256
                ),
                "tokenizer_transport_profile_sha256": (
                    self.selected_target.tokenizer_transport_profile_sha256
                ),
                **(
                    {
                        "tokenizer_bridge_trace_evidence_sha256": (
                            self.tokenizer_bridge_trace_adapter.evidence_sha256
                        ),
                        "tokenizer_bridge_target_token_replay": bool(
                            execute_closed_loop and closed_loop_report is not None
                        ),
                        "target_vocabulary_margin_binding_sha256": (
                            None
                            if self.target_tokenizer_vocabulary_margin_binding
                            is None
                            else self
                            .target_tokenizer_vocabulary_margin_binding
                            .binding_sha256
                        ),
                    }
                    if self.tokenizer_bridge_trace_adapter is not None
                    else {}
                ),
                "exact_target_unique_parameters": (
                    self.selected_target.exact_target_unique_parameters
                ),
                "residual_basis_mode": self.config.residual_basis_mode,
                "body_reclosure_mode": self.config.body_reclosure_mode,
                "body_coordinate_completion_recipe": (
                    self.config.body_coordinate_completion_recipe
                ),
                "streaming_vocabulary_margin_v2": (
                    self.config.streaming_vocabulary_margin_v2
                ),
                "residual_basis_sha256": basis.map_sha256,
                "residual_basis": basis.as_dict(),
                "residual_basis_reuse": (
                    None
                    if getattr(basis, "reuse_provenance", None) is None
                    else dict(basis.reuse_provenance)
                ),
                "initial_structural_fold": initial_report,
                "initial_structural_state_fingerprint": initial_state,
                "sparse_feature_fold_bundle_binding": (
                    None
                    if sparse_bundle_action_binding is None
                    else dict(sparse_bundle_action_binding)
                ),
                "closed_loop_enabled": execute_closed_loop,
                "macro_cell_attractor_gate_enabled": (
                    self.config.macro_cell_attractor_gate_config is not None
                ),
                "closed_loop": (
                    None if closed_loop_report is None else dict(closed_loop_report)
                ),
                "restart_capsule_binding": (
                    None
                    if restart_capsule_binding is None
                    else dict(restart_capsule_binding)
                ),
                **(
                    {
                        "closed_loop_configured": self.config.run_closed_loop,
                        "whole_child_component_diagnostic_execution": dict(
                            component_dispatch_report
                        ),
                    }
                    if component_dispatch_report is not None
                    else {}
                ),
                "vocabulary_margin_candidate_gate": (vocabulary_margin_candidate_gate),
                "complete_target_parameter_overwrite": True,
                "seed_erasure_by_construction": True,
                "parameter_topology_preserved": True,
                "parameter_count_preserved": True,
                "parent_immutable": True,
                "parent_trace_cache_reused": True,
                "parent_traces_regenerated": False,
                "quantization_used": False,
                "pruning_used": False,
                "training_used": False,
                "zero_gradient": True,
                "optimizer_steps": 0,
                "backward_calls": 0,
            }
            plan = Lfm2DenseBudgetFoldPlan(report)
            transaction.bind_candidate(
                plan=plan,
                candidate_state_fingerprint=candidate,
            )
            return transaction
        except BaseException:
            if transaction.active:
                transaction.rollback()
            raise


class Lfm2DenseBudgetEvidenceProvider:
    """Expose one verified cache handle without regenerating parent traces."""

    def __init__(
        self,
        trace_cache: Lfm2CircuitTraceCache,
        parent_cache_fingerprint: str,
        *,
        verification_lease: Lfm2DenseCacheVerificationLease | None = None,
        evidence_set: Lfm2SealedEvidenceSet | None = None,
    ) -> None:
        # The provider and the operator have to seal the *same* handle: the
        # operator compares its own trace cache against the sealed evidence
        # payload by identity, and the merged view is memoized per evidence set
        # exactly so that comparison still holds.
        trace_cache = _resolve_dense_evidence_cache(trace_cache, evidence_set)
        self.evidence_set = evidence_set
        if not isinstance(trace_cache, SEALED_EVIDENCE_CACHE_TYPES):
            raise Lfm2DenseBudgetFoldError(
                "trace_cache must be a sealed trace cache or one merged sealed "
                "evidence-set view."
            )
        self.verification_lease = verification_lease
        self.trace_cache = _verify_dense_trace_cache(
            trace_cache,
            verification_lease,
        )
        self.sealed_evidence = Lfm2SealedDenseBudgetEvidence(
            self.trace_cache,
            verification_lease=verification_lease,
        )
        self.parent_cache_fingerprint = _digest(
            parent_cache_fingerprint,
            "parent_cache_fingerprint",
        )
        if self.trace_cache.cache_key != self.parent_cache_fingerprint:
            raise Lfm2DenseBudgetFoldError(
                "Trace cache key differs from the stack evidence fingerprint."
            )
        self.prepare_count = 0
        self.refresh_count = 0
        self.restore_count = 0

    @property
    def base_fingerprint(self) -> str:
        return self.parent_cache_fingerprint

    def prepare(
        self,
        action: FoldAction,
        context: FoldExecutionContext,
    ) -> FoldEvidence:
        del context
        if action.method_id != DENSE_BUDGET_MODEL_METHOD:
            raise Lfm2DenseBudgetFoldError(
                "Dense evidence provider received an unsupported method."
            )
        _verify_dense_trace_cache(
            self.trace_cache,
            self.verification_lease,
        )
        self.prepare_count += 1
        return FoldEvidence(
            self.parent_cache_fingerprint,
            payload=self.sealed_evidence,
            channels=action.evidence_requirements,
            parent_forward_count=0,
            child_forward_count=0,
            root_fingerprint=self.parent_cache_fingerprint,
        )

    def refresh(
        self,
        action: FoldAction,
        context: FoldExecutionContext,
        transaction_report: Mapping[str, Any],
    ) -> None:
        del action, context, transaction_report
        _verify_dense_trace_cache(
            self.trace_cache,
            self.verification_lease,
        )
        self.refresh_count += 1

    def restore(
        self,
        context: FoldExecutionContext,
        state_fingerprint: str,
        action_ids: Sequence[str],
    ) -> None:
        del action_ids
        if context.child_state_fingerprint != _digest(
            state_fingerprint,
            "state_fingerprint",
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense evidence restore observed an unrestored child."
            )
        _verify_dense_trace_cache(
            self.trace_cache,
            self.verification_lease,
        )
        self.restore_count += 1


class Lfm2DenseBudgetFoldOnlyInitializer:
    """Non-mutating proof that the plan owns one complete dense transaction."""

    def __init__(
        self,
        parent_cache_fingerprint: str,
        selected_target: Lfm2DenseBudgetedSelectedTarget,
    ) -> None:
        self.parent_cache_fingerprint = _digest(
            parent_cache_fingerprint,
            "parent_cache_fingerprint",
        )
        if not isinstance(
            selected_target,
            Lfm2DenseBudgetedSelectedTarget,
        ):
            raise Lfm2DenseBudgetFoldError(
                "selected_target must be Lfm2DenseBudgetedSelectedTarget."
            )
        self.selected_target = selected_target

    def initialize(
        self,
        plan: DynamicFoldPlan,
        context: FoldExecutionContext,
    ) -> Mapping[str, Any]:
        before = context.child_state_fingerprint
        if (
            plan.evidence_fingerprint != self.parent_cache_fingerprint
            or plan.exact_target_unique_parameters
            != self.selected_target.exact_target_unique_parameters
            or len(plan.actions) != 1
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense plan evidence, budget, or action count is invalid."
            )
        action = plan.actions[0]
        if (
            action.method_id != DENSE_BUDGET_MODEL_METHOD
            or not action.signature.zero_gradient
            or action.compression_delta <= 0
            or set(action.target_node_ids)
            != {node.node_id for node in context.child_graph.nodes}
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense target must compile to one positive-compaction, "
                "zero-gradient, complete-model action."
            )
        if len(context.parent_graphs) != 1:
            raise Lfm2DenseBudgetFoldError(
                "Dense LFM2 folding currently accepts exactly one parent."
            )
        parent_graph = next(iter(context.parent_graphs.values()))
        if (
            parent_graph.model_name != self.selected_target.source_parent
            or parent_graph.fingerprint != self.selected_target.source_graph_fingerprint
            or dict(plan.parent_state_fingerprints)
            != {
                self.selected_target.source_parent: (
                    self.selected_target.source_state_fingerprint
                )
            }
        ):
            raise Lfm2DenseBudgetFoldError(
                "Dense execution parent differs from target selection."
            )
        if len(parent_graph.layer_indices) != self.selected_target.target_depth:
            raise Lfm2DenseBudgetFoldError(
                "Ordered source-span composition is required for this depth-"
                "changing target; the current executable lane is width-only."
            )
        validate_lfm2_dense_budgeted_child(
            self.selected_target,
            context.child_model,
            context.child_graph,
        )
        after = context.child_state_fingerprint
        if after != before:
            raise Lfm2DenseBudgetFoldError("Dense fold initializer mutated the child.")
        return {
            "kind": "lfm2_dense_budget_fold_only",
            "child_state_fingerprint": after,
            "complete_target_coverage": True,
            "parent_cache_fingerprint": self.parent_cache_fingerprint,
            "parent_traces_regenerated": False,
            "zero_gradient": True,
            "optimizer_steps": 0,
            "backward_calls": 0,
        }


class Lfm2DenseBudgetAdmissionEvaluator:
    """Enforce fold integrity while retaining numeric behavior as diagnostics."""

    def evaluate(self, context: FoldEvaluationContext) -> FoldDecision:
        transaction = context.transaction
        if not isinstance(transaction, Lfm2DenseBudgetModelTransaction):
            return FoldDecision.reject(
                "Dense LFM2 action lacks its typed whole-model transaction."
            )
        report = transaction.plan.as_dict()
        metrics: dict[str, JsonScalar] = {
            "local_gate_only": True,
            "model_level_action": True,
            "zero_gradient": bool(report.get("zero_gradient", False)),
            "seed_erasure_by_construction": bool(
                report.get("seed_erasure_by_construction", False)
            ),
            "complete_target_parameter_overwrite": bool(
                report.get("complete_target_parameter_overwrite", False)
            ),
            "parameter_topology_preserved": bool(
                report.get("parameter_topology_preserved", False)
            ),
            "quantization_used": bool(report.get("quantization_used", True)),
            "pruning_used": bool(report.get("pruning_used", True)),
            "training_used": bool(report.get("training_used", True)),
        }
        candidate_gate = report.get("vocabulary_margin_candidate_gate")
        candidate_gate_enabled = (
            isinstance(candidate_gate, Mapping)
            and candidate_gate.get("enabled") is True
        )
        candidate_gate_passed = (
            isinstance(candidate_gate, Mapping)
            and candidate_gate.get("gate_passed") is True
        )
        metrics["vocabulary_margin_candidate_gate_enabled"] = candidate_gate_enabled
        metrics["vocabulary_margin_candidate_gate_passed"] = candidate_gate_passed
        metrics["vocabulary_margin_candidate_is_decision_authority"] = False
        if candidate_gate_enabled:
            evaluation = candidate_gate.get("evaluation")
            measured = (
                evaluation.get("metrics") if isinstance(evaluation, Mapping) else None
            )
            minimums = (
                evaluation.get("minimums") if isinstance(evaluation, Mapping) else None
            )
            checks = (
                evaluation.get("checks") if isinstance(evaluation, Mapping) else None
            )
            metric_names = (
                "candidate_vs_cached_sign_agreement_fraction",
                ("candidate_top1_vs_top_competitor_nonnegative_fraction"),
                ("candidate_top1_vs_all_top_k_nonnegative_fraction"),
                "candidate_exact_parent_top1_agreement_fraction",
            )
            if (
                isinstance(measured, Mapping)
                and isinstance(minimums, Mapping)
                and isinstance(checks, Mapping)
            ):
                for name in metric_names:
                    value = measured.get(name)
                    minimum = minimums.get(name)
                    check = checks.get(name)
                    if (
                        isinstance(value, (int, float))
                        and not isinstance(value, bool)
                        and isinstance(minimum, (int, float))
                        and not isinstance(minimum, bool)
                        and isinstance(check, bool)
                    ):
                        metrics[f"vocabulary_margin_candidate_{name}"] = float(value)
                        metrics[f"vocabulary_margin_candidate_minimum_{name}"] = float(
                            minimum
                        )
                        metrics[f"vocabulary_margin_candidate_check_{name}"] = check
            for source_name in (
                "heldout_record_count",
                "actual_child_forward_calls",
                "parent_forward_calls",
                "training_steps",
            ):
                value = candidate_gate.get(source_name)
                if (
                    isinstance(value, int)
                    and not isinstance(value, bool)
                    and value >= 0
                ):
                    metrics[f"vocabulary_margin_candidate_{source_name}"] = value
            audit_sha256 = candidate_gate.get("audit_sha256")
            if isinstance(audit_sha256, str):
                metrics["vocabulary_margin_candidate_audit_sha256"] = audit_sha256
        required = (
            metrics["zero_gradient"],
            metrics["seed_erasure_by_construction"],
            metrics["complete_target_parameter_overwrite"],
            metrics["parameter_topology_preserved"],
            not metrics["quantization_used"],
            not metrics["pruning_used"],
            not metrics["training_used"],
        )
        if not all(required):
            return FoldDecision.reject(
                "Dense LFM2 model transaction failed a local fold-only invariant.",
                metrics,
            )
        return FoldDecision.accept(
            "Dense LFM2 blank was fully filled from parent-derived structural "
            "maps; numeric replay is diagnostic and complete decoded behavior "
            "remains mandatory evidence.",
            metrics,
        )


__all__ = [
    "DENSE_BUDGET_FOLD_SCHEMA",
    "DENSE_BUDGET_MODEL_METHOD",
    "LFM2_COMPONENT_CLOSED_LOOP_STAGE",
    "LFM2_COMPONENT_DISPATCH_EXECUTION_SCHEMA",
    "LFM2_COMPONENT_FOLD_STAGE_CONFIGURATION_KEY",
    "LFM2_COMPONENT_STRUCTURAL_STAGE",
    "LFM2_SPARSE_FEATURE_FOLD_BUNDLE_RESOURCE_NAME",
    "Lfm2DenseBudgetAdmissionEvaluator",
    "Lfm2DenseBudgetEvidenceProvider",
    "Lfm2DenseBudgetFoldConfig",
    "Lfm2DenseBudgetFoldError",
    "Lfm2DenseBudgetFoldOnlyInitializer",
    "Lfm2DenseBudgetFoldPlan",
    "Lfm2DenseBudgetModelOperator",
    "Lfm2DenseBudgetModelTransaction",
    "Lfm2SealedDenseBudgetEvidence",
]
