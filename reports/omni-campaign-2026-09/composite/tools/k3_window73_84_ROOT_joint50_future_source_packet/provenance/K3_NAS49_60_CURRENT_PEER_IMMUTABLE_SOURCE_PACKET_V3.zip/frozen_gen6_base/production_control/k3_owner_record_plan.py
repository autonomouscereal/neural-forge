"""Convert a strictly verified K3 continuation plan to the owner's diagnostic mode.

This never launches, copies checkpoints, rewrites historical markers, or weakens
the original preflight's source/runtime/prefix checks. Acceptance mode is an
operational flag excluded by k3_dense_pass._resume_context. All other argv bytes
remain identical. The original plan is bound by its exact SHA256.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import re

SCHEMA = "neural_forge.k3_owner_diagnostic_continuation_plan.v1"
GPU_UUID = "GPU-f5a09535-fc85-a027-50f7-734b344747dd"
TOOL_SHA = "44ccfba059f0da1a5b2c63dfcbbb54e2f4e2b641fed5d0273cc00437cb6d8dde"
VALUE_OPTIONS = set("src-dir model-dir input-ids review-input-ids out receipt-dir body-dir chimera-src digest-receipt layer0-import-receipt device experts-device resid-device compute-dtype kda-backend layers rung k-pool-factor row-chunk token-chunk chunk holdout-blocks divergence-rows review-topk max-gram-gb max-device-gb snapshot-every snapshot-keep acceptance".split())
FLAG_OPTIONS = {"resume", "no-share-read"}


def require(ok, why):
    if not ok:
        raise ValueError(why)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def pinned_bytes(path, expected, maximum=4 << 20):
    require(isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected), "SHA256 required")
    require(not path.is_symlink() and path.is_file(), "regular nonsymlink input required")
    before = path.stat()
    require(before.st_size <= maximum, "metadata input exceeds bound")
    data = path.read_bytes()
    after = path.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), "input changed")
    require(hashlib.sha256(data).hexdigest() == expected, "input hash mismatch")
    return data


def adapt(plan, original_sha, tool_sha):
    require(plan.get("schema") == "neural-forge.k3-continuation-preflight.v1", "original strict preflight required")
    require(plan.get("action") == "plan_only_no_allocation_or_launch", "unexecuted plan required")
    require(plan.get("required_gpu_uuid") == GPU_UUID, "exact original RTX8000 GPU required")
    require(tool_sha == TOOL_SHA, "unchanged accepted K3 tool required")
    argv = plan.get("command_argv")
    require(isinstance(argv, list) and argv and all(isinstance(x, str) and x and "\x00" not in x for x in argv), "structured argv required")
    # The original planner emits exact, split option/value tokens. Refuse
    # --option=value, argparse abbreviations, duplicate singleton options,
    # shell wrappers and extra positional arguments that could override mode.
    require(len(argv)>=2 and re.fullmatch(r"python(?:\d+(?:\.\d+)*)?(?:\.exe)?",Path(argv[0]).name), "direct Python argv required")
    require(Path(argv[1]).name=="k3_dense_pass.py", "direct K3 script required")
    seen={}; cursor=2
    while cursor<len(argv):
        option=argv[cursor]
        require(option.startswith("--") and option[2:] in VALUE_OPTIONS | FLAG_OPTIONS,
                "exact original preflight option grammar required")
        seen[option]=seen.get(option,0)+1
        require(option=="--review-input-ids" or seen[option]==1, "duplicate singleton option")
        if option[2:] in VALUE_OPTIONS:
            require(cursor+1<len(argv) and not argv[cursor+1].startswith("--"), "split option value required")
            cursor+=2
        else:
            cursor+=1
    require(argv.count("--acceptance") == 1, "one explicit acceptance option required")
    i = argv.index("--acceptance")
    require(i + 1 < len(argv) and argv[i + 1] == "gate", "original preflight gate argument required")
    require("--resume" in argv and argv.count("--layers") == 1, "strict resumed layer window required")
    j = argv.index("--layers")
    require(j + 1 < len(argv) and argv[j + 1] == "5-12", "original L5-12 window required")
    require(plan.get("next_layers") == "5-12" and plan.get("remaining_moe_layers") == 88, "prefix coverage mismatch")
    installed = plan.get("installed_ffn_sha256")
    require(isinstance(installed, dict) and set(map(str, installed)) == {"1", "2", "3", "4"}, "complete L1-4 prefix required")
    require(all(isinstance(x, str) and re.fullmatch(r"[0-9a-f]{64}", x) for x in installed.values()), "prefix hashes required")
    out = copy.deepcopy(plan)
    out["schema"] = SCHEMA
    out["command_argv"][i + 1] = "record"
    out["original_preflight_sha256"] = original_sha
    out["unchanged_k3_tool_sha256"] = tool_sha
    out["owner_policy"] = {
        "numerical_measurements": "record diagnostics without finite target veto or deletion",
        "artifact_state": "unevaluated development component; historical verdicts preserved",
        "capability_accepted": False,
        "assembled_child": False,
        "training_authorized": False,
        "existing_gpu_priority": True,
        "artificial_project_deadline": None,
        "functional_guards": ["identity/runtime/prefix continuity", "tensor load and shape",
                              "actual coefficient/output finiteness", "hash-verified durable readback"],
    }
    out["launch_obligations"] = [
        "Rerun the original strict preflight against the actual isolated continuation copy and fresh runtime observation.",
        "Use the genuine executor identity, current shared allocator and original GPU6; drain/preserve the exact idle provider.",
        "Run a tensor coefficient/loadability checker on every new FFN; preserve partial/refused diagnostics without promotion.",
        "Seal before-L05 and earlier capture endpoints independently; snapshot retention must not remove required originals.",
        "Recheck RAM/disk capacity; max-gram-gb 160 is a cap, not available-memory evidence.",
        "Use record for successive windows through L92 and canonical dense/L##/ffn.safetensors discovery.",
    ]
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--preflight-plan", type=Path, required=True)
    ap.add_argument("--preflight-plan-sha256", required=True)
    ap.add_argument("--k3-tool", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    data = pinned_bytes(a.preflight_plan, a.preflight_plan_sha256)
    pinned_bytes(a.k3_tool, TOOL_SHA)
    plan = json.loads(data.decode("utf-8"), object_pairs_hook=unique)
    result = adapt(plan, a.preflight_plan_sha256, TOOL_SHA)
    require(not a.out.exists() and not a.out.is_symlink(), "new output required")
    with a.out.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    main()
