"""Local scalar derivation for a prospective 49-60 phase, never an admission.

Inputs describing newly emitted layer files and the 48 receipt must be supplied
from their actual sealed metadata.  This module reads no model files, performs
no runtime actions, and makes no claim about total process or cgroup memory.
"""

from math import ceil


def derive_phase49_60(tokens, hidden, block_size, element_bytes, rung, latent_out,
                      max_ffn_bytes=None, max_body_bytes=None,
                      max_held_bytes=None, sealed48_receipt_bytes=None):
    values = (tokens, hidden, block_size, element_bytes, rung, latent_out)
    if any(type(value) is not int or value <= 0 for value in values):
        raise ValueError("positive integer actual model/corpus geometry required")
    if block_size != 12 or element_bytes != 2:
        raise ValueError("this reviewed phase derivation requires block12/BF16 geometry")
    prefix = tokens * hidden * element_bytes
    before_blocks = ceil(49 / block_size)
    after_blocks = ceil(61 / block_size)
    before_pair = (1 + before_blocks) * prefix
    after_pair = (1 + after_blocks) * prefix
    before_dual = 2 * before_pair
    after_dual = 2 * after_pair
    # Pair.blocks aliases the old blocks off a boundary.  Only the two new
    # CPU prefixes coexist with the old pair prefixes before run() replaces
    # teacher/folded.  At L60 both torch.cat results coexist with the old stacks.
    steady_between_layers = before_dual
    nonboundary_old_and_new_prefixes = before_dual + 2 * prefix
    boundary_fit_residuals = before_dual + after_pair + after_blocks * prefix
    boundary_old_and_new_pairs = before_dual + after_dual
    # c14.gram_memory_estimate: two Gram/cross residents plus clone/factor/RHS
    # and solution.  It does not include residual pairs or the whole process.
    one_gram = rung * rung * 8
    one_cross = rung * latent_out * 8
    gram_peak = 4 * one_gram + 4 * one_cross
    result = {
        "schema": "neural_forge.k3_source_only_49_60_scalar_geometry.v1",
        "phase": [49, 60],
        "geometry": {"tokens": tokens, "hidden": hidden, "block_size": block_size,
                     "element_bytes": element_bytes, "rung": rung, "latent_out": latent_out},
        "prefix_bytes": prefix,
        "before49_blocks": before_blocks,
        "before49_dual_tensor_bytes": before_dual,
        "before61_blocks": after_blocks,
        "before61_dual_tensor_bytes": after_dual,
        "CPU_residual_lifetime_bytes": {
            "between_layers_49_through_59": steady_between_layers,
            "nonboundary_old_pairs_plus_two_new_prefixes": nonboundary_old_and_new_prefixes,
            "L60_refit_old_pairs_new_teacher_and_new_folded_stack": boundary_fit_residuals,
            "L60_old_and_new_pairs_before_run_replacement": boundary_old_and_new_pairs,
        },
        "host_Gram_refit_component": {
            "one_Gram_bytes": one_gram, "one_cross_bytes": one_cross,
            "source_estimated_peak_bytes": gram_peak,
            "L60_refit_residuals_plus_Gram_component_bytes": boundary_fit_residuals + gram_peak,
        },
        "checkpoint_disk_tensor_schedule": {
            "periodic_before60_dual_bytes": before_dual,
            "final_before61_dual_bytes": after_dual,
            "exclusive_verifier_before61_copy_dual_bytes": after_dual,
            "exact_three_pair_tensor_sum_bytes": before_dual + 2 * after_dual,
            "inherited_Driver_three_maximum_pairs_bytes": 3 * after_dual,
            "one_additional_maximum_single_stream_saver_temp_bytes": after_pair,
        },
        "inherited_Driver_projection": None,
        "admitted": False,
        "whole_RSS_or_cgroup_peak_proved": False,
        "new_RAM_or_CPU_cap_selected": False,
        "physical_filesystem_quota_claimed": False,
        "remaining_layers_61_92_admitted": False,
    }
    optional = (max_ffn_bytes, max_body_bytes, max_held_bytes, sealed48_receipt_bytes)
    if any(value is not None for value in optional):
        if any(type(value) is not int or value <= 0 for value in optional):
            raise ValueError("complete positive actual file/receipt extents required together")
        per_layer = max_ffn_bytes + max_body_bytes + max_held_bytes
        metadata = 16 * sealed48_receipt_bytes
        result["inherited_Driver_projection"] = {
            "max_ffn_bytes": max_ffn_bytes, "max_body_bytes": max_body_bytes,
            "max_held_bytes": max_held_bytes, "actual_sealed48_receipt_bytes": sealed48_receipt_bytes,
            "new_layers": 12, "per_layer_bytes": per_layer,
            "maximum_checkpoint_pair_copies": 3, "metadata_estimate_bytes": metadata,
            "old_prefix_tensor_copy_bytes": 0,
            "required_new_bytes": 12 * per_layer + 3 * after_dual + metadata,
            "finite_FormE_temporary_and_header_overhead_proof_still_required": True,
        }
    return result
