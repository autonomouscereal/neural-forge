"""Compose a local, deliberately unbound single-window controller proposal.

This performs no staging or execution. Actual next identity, source pins and
resource caps must replace the explicit sentinels after genuine48 closure.
"""
import ast
import hashlib
import json
from pathlib import Path
import textwrap

HERE = Path(__file__).resolve().parent
RECOVERY = HERE.parents[1]
BASE = RECOVERY / "nas_window37_48_generation6/continuation_worker.py"
EXPECTED = "511c60bae9ed47ac6ca0fcb3de8f9777250229bd707f8ae32051dfda06e6f7ee"
raw = BASE.read_bytes()
if hashlib.sha256(raw).hexdigest() != EXPECTED:
    raise ValueError("exact frozen37-48 base source required")
source = raw.decode("utf-8")
source = source.replace('RUN = "764524b1-96a9-4636-be74-942f9c54754c"', '''RUN = "__UNRESOLVED_NEXT_RUN_UUID__"
IDENTITY_SHA = "__UNRESOLVED_NEXT_IDENTITY_SHA256__"
CAP_BYTES = None  # exact newly funded49-60 cap; never inferred from88GiB
CAP_CPUS = None  # exact newly funded49-60 CPU quota
SESSION_GENERATION = None
SESSION_ID = "__UNRESOLVED_NEXT_GENUINE_NATIVE_SESSION__"
PREVIOUS_NAS = "/mnt/ai_data/omni-campaign/k3-nas-window37-48-oct07-764524b1-96a9-4636-be74-942f9c54754c/model"
NAS_PREFIX = Path("/resume-window37-48")''')
source = source.replace('"k3-nas-window37-48-oct07-" + RUN', '"k3-nas-window49-60-oct07-" + RUN')
source = source.replace('/k3-nas-window37-48-oct07-" + RUN', '/k3-nas-window49-60-oct07-" + RUN')
tree = ast.parse(source)
driver = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Driver")
methods = {node.name: node for node in driver.body if isinstance(node, ast.FunctionDef)}
lines = source.splitlines()


def method(name):
    node = methods[name]
    return "\n".join(lines[node.lineno - 1:node.end_lineno])


init = method("__init__")
init = init.replace('self.config_path=pinned(config_path,config_sha);self.config_sha=config_sha', '''require(re.fullmatch(r"[0-9a-f-]{36}", RUN) is not None and str(uuid.UUID(RUN)) == RUN,
                "unresolved next-phase RUN; proposal cannot execute")
        require(re.fullmatch(r"[0-9a-f]{64}", IDENTITY_SHA) is not None,
                "unresolved next-phase exact identity source pin")
        require(type(CAP_BYTES) is int and CAP_BYTES > 0 and type(CAP_CPUS) is int and CAP_CPUS > 0
                and type(SESSION_GENERATION) is int and SESSION_GENERATION > 0
                and str(uuid.UUID(SESSION_ID)) == SESSION_ID,
                "new actual resource cap and genuine native binding required")
        self.config_path=pinned(config_path,config_sha);self.config_sha=config_sha''')
init = init.replace('neural_forge.k3_nas_closed36_worker_config.v1', 'neural_forge.k3_nas_closed48_worker_config.v1')
init = init.replace('sha(CONTROL/"identity.json")=="d8bf5e9270930e0bdb4b470a07402791d16529c0c23546a31c9ec79e500b4997"', 'sha(CONTROL/"identity.json")==IDENTITY_SHA')
init = init.replace('current exact gen6 identity required', 'new exact phase identity required')
init = init.replace('self.identity["readonly_resume_source_root"]==HOST_PREFIX', 'self.identity["readonly_resume_source_roots"]=={"legacy_closed36": HOST_PREFIX, "closed37_48": PREVIOUS_NAS}')
init = init.replace('self.identity["native_binding"]["session_generation"]==6 and self.identity["native_binding"]["session_id"]=="a88b21eb-2e23-434d-bec3-e268ef59b3f2"', 'self.identity["native_binding"]["session_generation"]==SESSION_GENERATION and self.identity["native_binding"]["session_id"]==SESSION_ID')
init = init.replace('actual gen6 supported binding required', 'new actual supported native binding required')
init = init.replace('[37,48]', '[49,60]').replace('37-48', '49-60')
init = init.replace('self.budget["memory_limit_bytes"]==88*GIB and self.budget["cpus"]==22', 'self.budget["memory_limit_bytes"]==CAP_BYTES and self.budget["cpus"]==CAP_CPUS')
init = init.replace('unchanged reviewed88GiB22CPU noSwap budget required', 'new source-funded exact49-60 cap and noSwap budget required')
init = init.replace('"full_prefix_layers":36,"saved_valid_prefix_layers":36', '"full_prefix_layers":48,"saved_valid_prefix_layers":48')
init = init.replace('operational_argv(self.first_argv,"49-60")', '''operational_argv(self.first_argv,"49-60")
        for flag in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
            require(flag + "=" + str(CAP_CPUS) in self.first_argv,
                    "new exact CPU cap must retain the source selected native thread count")''')

admit = '''
def admit(self, receipt, next_window, destination, resume_layer=None):
    require(next_window == (49, 60) and resume_layer is None,
            "only full49-60 phase admission required")
    require(receipt.get("resume_context") == self.guard.previous_context
            and set(receipt.get("installed_ffn_sha256", {})) == {str(i) for i in range(1, 49)}
            and receipt.get("layers_processed_this_run") == list(range(37, 49)),
            "authentic actual closed48 native producer receipt required")
    sample = self.samples("next_window_admission")
    group = sample["cgroup"]
    require(group["memory.max"] == CAP_BYTES and group["memory.swap.max"] == group["memory.swap.current"] == 0
            and group["cpu.max"]["cpus"] == CAP_CPUS,
            "new actual owned source-selected cap and noSwap required")
    additional = max(0, CAP_BYTES - group["memory.current"])
    host_need = additional + 16 * GIB
    # Exact read-map hashing/stat guards bind all48 FFN/body files. Older held
    # payloads need no recopy/read: their actual closed36 maximum is preserved
    # in the pinned historical resource proof and MAXed with all12 new rows.
    historical = pinned(self.config["closed36_disk_projection"]["path"],
                        self.config["closed36_disk_projection"]["sha256"])
    prior = read(historical)
    require(prior["next_window"] == "37-48" and prior["disk_estimate"]["required_new_bytes"] == 103035350992,
            "unaltered authentic closed36 historical layer maximum proof required")
    max_ffn = max(self.resolver.read_path(f"/run-output/fold/dense/L{layer:02d}/ffn.safetensors").stat().st_size
                  for layer in range(1, 49))
    max_body = max(self.resolver.read_path(f"/run-output/body/L{layer:02d}/body.safetensors").stat().st_size
                   for layer in range(1, 49))
    held_sizes = [prior["disk_estimate"]["max_actual_held_rows_bytes"]]
    for layer in range(37, 49):
        held = receipt["layers"][str(layer)]["held_rows"]
        logical = f"/run-output/fold/resid/L{layer:02d}/held_rows.safetensors"
        require(held["path"] == logical, "actual new37-48 held-row source role required")
        path = self.resolver.read_path(logical)
        require(path.stat().st_size == held["bytes"] and self.resolver.old[logical]["sha256"] == held["sha256"],
                "actual held-row fullSHA/extent differs from latest sealed producer")
        held_sizes.append(path.stat().st_size)
    boundary = self.resolver.read_path("/run-output/fold/snapshots/before_L49.safetensors")
    h = header(boundary)
    tokens = self.baseline["corpus"]["tokens"]
    hidden = self.model_cfg["hidden_size"]
    dtype = h["prefix_sum"]["dtype"]
    require(dtype == "BF16" and h["prefix_sum"]["shape"] == [tokens, hidden]
            and h["block_residual"]["dtype"] == dtype
            and h["block_residual"]["shape"] == [tokens, 5, hidden]
            and self.model_cfg["attn_res_block_size"] == 12,
            "actual before49 BF16/block5 geometry required")
    blocks = math.ceil(61 / self.model_cfg["attn_res_block_size"])
    dual = 2 * tokens * hidden * (1 + blocks) * 2
    from ro_resume_paths import NativeResumeReads
    terminal = NativeResumeReads(self.resolver).sealed_metadata("k3_dense_pass_receipt.json")
    require(terminal is not None and read(terminal) == receipt,
            "unique latest sealed48 full receipt required for metadata extent")
    metadata = terminal.stat().st_size * 16
    max_held = max(held_sizes)
    projection = {"new_layers": 12, "boundary_copies_budgeted": 3,
                  "dual_boundary_bytes": dual, "max_actual_ffn_bytes": max_ffn,
                  "max_actual_body_bytes": max_body, "max_actual_held_rows_bytes": max_held,
                  "metadata_bytes": metadata, "saved_head_bytes": 0,
                  "required_new_bytes": 12 * (max_ffn + max_body + max_held) + 3 * dual + metadata,
                  "method": "actual whole48 RO FFN/body maxima and historical held maximum MAX actual12 newheld; BF16/block6 three boundary pairs plus actual sealed48 receipt metadata",
                  "old_prefix_tensor_copy_bytes": 0}
    admission = {"schema": "neural_forge.k3_actual_next_window_resource_admission.v1",
                 "next_window": "49-60", "actual_resources": sample,
                 "current_owned_memory_limit_bytes": CAP_BYTES,
                 "current_owned_resident_bytes": group["memory.current"],
                 "additional_owned_budget_bytes": additional, "host_headroom_bytes": 16 * GIB,
                 "host_available_required_bytes": host_need, "disk_estimate": projection,
                 "new_output_filesystem": "NAS", "old_prefix_readonly": True,
                 "memory_admitted": sample["host_memory"]["MemAvailable_bytes"] >= host_need,
                 "disk_admitted": sample["output_disk"]["free_bytes"] >= projection["required_new_bytes"],
                 "numerical_quality_gate": False, "overall_92_completion_claimed": False}
    new_json(destination, admission)
    self.event("next_window_resource_admission", resource_admission=admission)
    if not admission["memory_admitted"]:
        raise CapacityDenied("actual RAM insufficient for new own growth plus16GiB headroom")
    if not admission["disk_admitted"]:
        raise CapacityDenied("actual NAS free insufficient for full49-60 new writes")
    self.own_capacity_admit(admission, destination, None)
'''
admit = textwrap.indent(textwrap.dedent(admit).strip(), "    ")

execute = method("execute")
execute = execute.replace('len(mounts)==9', 'len(mounts)==10')
execute = execute.replace('"exact nine disjoint readonly prefix/fresh NAS mounts required"', '"exact ten disjoint two-origin RO/fresh NAS mounts required"')
execute = execute.replace('next(m for m in mounts if m["target"]==str(PREFIX))=={"source":HOST_PREFIX,"target":str(PREFIX),"read_only":True}', 'next(m for m in mounts if m["target"]==str(PREFIX))=={"source":HOST_PREFIX,"target":str(PREFIX),"read_only":True} and next(m for m in mounts if m["target"]==str(NAS_PREFIX))=={"source":PREVIOUS_NAS,"target":str(NAS_PREFIX),"read_only":True}')
execute = execute.replace('self.root/"window37_48_launch"', 'self.root/"window49_60_launch"')
execute = execute.replace('closed["full_prefix_layers"]==36 and closed["completed_window"]=="25-36"', 'closed["full_prefix_layers"]==48 and closed["completed_window"]=="37-48" and str(prior)==self.guard.prior["path"] and sha(prior)==self.guard.prior["sha256"]')
execute = execute.replace('"actual sealed36 boundary required"', '"actual sealed48 boundary required"')
execute = execute.replace('receipt_path=self.resolver.read_path("/run-output/ancestry/window-25-36-b873d51f-b251-4944-aa84-5d91df96e87b/receipts/k3_dense_pass_receipt.json")', 'from ro_resume_paths import NativeResumeReads\n        receipt_path=NativeResumeReads(self.resolver).sealed_metadata("k3_dense_pass_receipt.json")\n        require(receipt_path is not None,"actual unique latest sealed48 terminal receipt required")')
execute = execute.replace('"37-48"', '"49-60"').replace('(37,48)', '(49,60)').replace('fitter-37-48.log', 'fitter-49-60.log')
execute = execute.replace('list(range(37,49))', 'list(range(49,61))').replace('get("layer")==37', 'get("layer")==49').replace('list(range(1,37))', 'list(range(1,49))')
execute = execute.replace('"actual37-48 processing and preserved36 resume required"', '"actual49-60 processing and preserved48 resume required"')
execute = execute.replace('"exact source-backed37-48 command/identity required"', '"exact source-backed49-60 command/identity required"')
execute = execute.replace('full_prefix_layers=48', 'full_prefix_layers=60')
execute = execute.replace('closed["completed_window"]=="49-60"', 'closed["completed_window"]=="37-48"')

replacements = {"__init__": init, "admit": admit, "execute": execute}
for name in sorted(replacements, key=lambda name: methods[name].lineno, reverse=True):
    node = methods[name]
    lines[node.lineno - 1:node.end_lineno] = replacements[name].splitlines()
candidate = "\n".join(lines) + "\n"
compile(candidate, "unbound49_60_controller_proposal", "exec")
target = HERE / "continuation_worker49_60_template_v3.py"
with target.open("xb") as handle:
    handle.write(candidate.encode("utf-8"))
pin = lambda p: {"path": str(p), "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
report = {"schema": "neural_forge.k3_source_only_49_60_controller_composition.v1",
          "base": pin(BASE), "candidate": pin(target), "composer": pin(Path(__file__)),
          "changed_existing_methods": sorted(replacements),
          "new_control_or_model_actions": 0, "proposal_executable": False,
          "exact_future_bindings_unresolved": ["RUN", "IDENTITY_SHA", "CAP_BYTES", "CAP_CPUS", "SESSION_GENERATION", "SESSION_ID", "actual48 continuity and all RO catalog/source/observation pins", "new native/verifier/qualification/caller/facts/preflight config fullpins"],
          "unchanged_boundary_protocol": ["new_json", "own_capacity_publish", "own_capacity_recheck", "observe", "validate_window", "source_check", "scanner_request", "run_command"],
          "supported_API": "same nas_resume_from_arguments; guard.prior and NativeResumeReads.sealed_metadata return actual latest48 mapped physical paths; exact two origins and all12newheld rows supplied only from actual seal",
          "new_phase_future_admitted": False}
out = HERE / "CONTROLLER49_60_UNBOUND_SOURCE_COMPOSITION_V3.json"
with out.open("x", encoding="utf-8", newline="\n") as handle:
    json.dump(report, handle, indent=2, sort_keys=True)
    handle.write("\n")
print(json.dumps(pin(out), sort_keys=True))
