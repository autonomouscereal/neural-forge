"""CPU-only structural metadata checks; no tensors or future actual-proof claims."""
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
import copy
import hashlib
import json
import stat
import sys
import unittest

HERE = Path(__file__).resolve().parent
RECOVERY = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.append(str(RECOVERY / "resume_review"))
from ro_resume_paths import ROResumePaths, NativeResumeReads, ControllerReads, CATALOG_SCHEMA, CONTRACT_SCHEMA, PARENT_CATALOG_SHA
from ro_resume_runtime import Closed48Ancestry, validate_closed48_metadata
import ro_resume_paths

# The explicit synthetic backend models Linux POSIX paths on the Windows review
# host. It performs no native filesystem or tensor calls through this substitute.
ro_resume_paths.Path = PurePosixPath

SEAL = "/run-output/ancestry/window-37-48-11111111-1111-4111-8111-111111111111"


def raw_pin(value):
    raw = json.dumps(value, sort_keys=True).encode()
    return raw, hashlib.sha256(raw).hexdigest()


class SyntheticFiles:
    """Only declared structural stat/hash metadata; never reads payloads."""
    def __init__(self):
        self.entries, self.hashes, self.hash_calls = {}, {}, []
        self.next_inode = 20

    def add(self, path, device, size=0, digest=None, directory=False):
        path = PurePosixPath(path)
        if str(path) in self.entries:
            return
        if path != path.parent and str(path.parent) not in self.entries:
            self.add(path.parent, device, directory=True)
        self.next_inode += 1
        self.entries[str(path)] = dict(dev=device, ino=self.next_inode, size=size,
                                      mtime_ns=1, ctime_ns=1,
                                      mode=(stat.S_IFDIR | 0o755) if directory else (stat.S_IFREG | 0o444))
        if digest:
            self.hashes[str(path)] = digest

    def identity(self, path):
        return dict(self.entries[str(path)])

    def exists(self, path):
        return str(path) in self.entries

    def hash(self, path):
        self.hash_calls.append(str(path))
        return self.hashes[str(path)]


def structural_case():
    # Existing127 source metadata is genuine; added48 roles/stat/hash values are
    # explicitly synthetic test-only structures, never an actual sealed48 claim.
    parent = json.loads((RECOVERY / "nas37_48_resume_review/ro_prefix_catalog_v2.json").read_bytes())
    rows = [dict(row, source_origin="legacy_closed36") for row in parent["input_catalog"]]
    roots = {
        "legacy_closed36": dict(path="/resume-prefix", alias="/resume-prefix", host_path="/mnt/lexar/old", read_only=True),
        "closed37_48": dict(path="/resume-window37-48", alias="/resume-window37-48", host_path="/mnt/ai_data/old37/model", read_only=True),
    }
    output = dict(path="/run-output", alias="/run-output", host_path="/mnt/ai_data/new49/model", read_only=False)
    fs = SyntheticFiles()
    for origin, root in roots.items():
        fs.add(root["path"], 1 if origin == "legacy_closed36" else 2, directory=True)
        root["stat"] = fs.identity(root["path"])
    fs.add(output["path"], 2, directory=True)
    output["stat"] = fs.identity(output["path"])
    for row in rows:
        logical = row.get("recorded_logical_path", "/run-output/" + row.get("relative_path", ""))
        relative = str(PurePosixPath(logical).relative_to("/run-output"))
        # Keep all127 inherited row values unchanged, including original hostroot.
        roots["legacy_closed36"]["host_path"] = str(PurePosixPath(row["unchanged_host_input_path"]).parents[len(PurePosixPath(relative).parts)-1])
    def add(logical, role):
        relative = str(PurePosixPath(logical).relative_to("/run-output"))
        digest = hashlib.sha256(("synthetic metadata " + logical).encode()).hexdigest()
        root = roots["closed37_48"]
        rows.append(dict(recorded_logical_path=logical, role=role, source_origin="closed37_48",
                         sha256=digest, bytes=7, prospective_RO_input_path=root["alias"] + "/" + relative,
                         unchanged_host_input_path=root["host_path"] + "/" + relative))
    for layer in range(37, 49):
        for name in ("ffn.safetensors", "done.json"):
            add(f"/run-output/fold/dense/L{layer:02d}/{name}", "closed_prefix_" + name)
        add(f"/run-output/body/L{layer:02d}/body.safetensors", "closed_prefix_verbatim_body")
        add(f"/run-output/fold/resid/L{layer:02d}/held_rows.safetensors", "closed_prefix_retained_held_rows")
    for suffix in ("", "_folded"):
        add(f"/run-output/fold/snapshots/before_L49{suffix}.safetensors", "native_before49_dual_boundary")
    for inner in ("window_continuity.json", "inputs/full_ffn_validation.json", "receipts/k3_dense_pass_receipt.json",
                  "receipts/k3_dense_pass_receipt.partial.json", "receipts/k3_dense_pass_receipt.sha256", "fold/snapshots/snapshots_manifest.json"):
        add(SEAL + "/" + inner, "sealed37_48_ancestry")
    facts = {}
    for row in rows:
        logical = row.get("recorded_logical_path", "/run-output/" + row.get("relative_path", ""))
        root = roots[row["source_origin"]]
        path = root["alias"] + "/" + str(PurePosixPath(logical).relative_to("/run-output"))
        fs.add(path, root["stat"]["dev"], row.get("bytes", 7), row["sha256"])
        facts[logical] = dict(path=path, source_origin=row["source_origin"], source_sha256=row["sha256"], stat=fs.identity(path))
    identity = dict(owner="codex-native-01a11108-009c-72f3-b2ba-e0d48fca1435", native_context="01a11108-009c-72f3-b2ba-e0d48fca1435",
                    run_uuid="22222222-2222-4222-8222-222222222222", image="sha256:d4ef16f161e51df2bd51df62c1aaa4ea7d9fc65fefcbaef8382027a527ec3ba6",
                    control_binding={"harness_id": "01a11108-009c-72f3-b2ba-e0d48fca1435"})
    proof = dict(schema=CONTRACT_SCHEMA, acting_identity=identity, first_new_layer=49, last_new_layer=60,
                 source_roots=roots, output_root=output, source_files=facts,
                 closed48_continuity={"path": SEAL + "/window_continuity.json", "sha256": rows[-6]["sha256"]},
                 new_write_paths=["/run-output/fold/dense/L49/ffn.safetensors", "/run-output/fold/snapshots/before_L60.safetensors"])
    proof["current_mounts"] = [{"source": root["host_path"], "target": root["alias"], "read_only": root["read_only"]} for root in [*roots.values(), output]]
    catalog = dict(schema=CATALOG_SCHEMA, parent_catalog_sha256=PARENT_CATALOG_SHA, input_catalog=rows)
    return catalog, proof, identity, fs


def resolver(case):
    catalog, proof, identity, fs = case
    raw, digest = raw_pin(catalog)
    proof["source_catalog_sha256"] = digest
    observed, observed_sha = raw_pin(proof)
    return ROResumePaths(raw, digest, observed, observed_sha, acting_identity=identity, backend=fs)


class PathSeams(unittest.TestCase):
    def test_same_NAS_device_is_disjoint_and_old_reads_select_exact_origin(self):
        case = structural_case()
        paths = resolver(case)
        self.assertEqual(paths.read_path("/run-output/fold/dense/L36/ffn.safetensors"), PurePosixPath("/resume-prefix/fold/dense/L36/ffn.safetensors"))
        self.assertEqual(paths.read_path("/run-output/fold/dense/L37/ffn.safetensors"), PurePosixPath("/resume-window37-48/fold/dense/L37/ffn.safetensors"))
        paths.read_path("/run-output/fold/dense/L37/ffn.safetensors")
        self.assertEqual(case[3].hash_calls.count("/resume-window37-48/fold/dense/L37/ffn.safetensors"), 1)
        self.assertEqual(NativeResumeReads(paths).sealed_metadata("k3_dense_pass_receipt.json"), PurePosixPath("/resume-window37-48" + SEAL[len("/run-output"):] + "/receipts/k3_dense_pass_receipt.json"))
        with self.assertRaises(ValueError): paths.read_path("/run-output/fold/dense/L49/ffn.safetensors")
        with self.assertRaises(ValueError): ControllerReads(paths).existing_layer(36, "held")

    def test_overlap_and_same_physical_root_refused(self):
        for physical in (False, True):
            case = structural_case()
            if physical:
                case[1]["output_root"]["stat"]["ino"] = case[1]["source_roots"]["closed37_48"]["stat"]["ino"]
            else:
                case[1]["output_root"]["host_path"] = case[1]["source_roots"]["closed37_48"]["host_path"] + "/child"
                case[1]["current_mounts"][-1]["source"] = case[1]["output_root"]["host_path"]
            with self.assertRaises(ValueError): resolver(case)

    def test_changed_actual_hash_stat_and_inherited_catalog_refused(self):
        for change in ("hash", "stat", "parent"):
            case = structural_case()
            if change == "parent":
                case[0]["input_catalog"][0]["sha256"] = "a" * 64
                with self.assertRaises(ValueError): resolver(case)
                continue
            paths = resolver(case)
            path = "/resume-window37-48/fold/dense/L37/ffn.safetensors"
            if change == "hash": case[3].hashes[path] = "b" * 64
            else: case[3].entries[path]["ctime_ns"] += 1
            with self.assertRaises(ValueError): paths.read_path("/run-output/fold/dense/L37/ffn.safetensors")

    def test_old_unlisted_foreign_and_changed_owned_output_refused(self):
        case = structural_case(); paths = resolver(case)
        for logical in ("/run-output/fold/dense/L37/ffn.safetensors", "/run-output/fold/dense/L61/ffn.safetensors"):
            with self.assertRaises(ValueError): paths.write_path(logical)
        logical = "/run-output/fold/dense/L49/ffn.safetensors"
        paths.write_path(logical)
        case[3].add(logical, 2, 7, "a" * 64)
        with self.assertRaises(ValueError): paths.write_path(logical)
        paths.note_created_output(logical)
        self.assertEqual(paths.write_path(logical), PurePosixPath(logical))
        case[3].entries[logical]["ino"] += 1
        with self.assertRaises(ValueError): paths.write_path(logical)

    def test_unresolved48_and_incomplete_actual36_cannot_admit48(self):
        case = structural_case(); case[1]["closed48_continuity"]["sha256"] = None
        with self.assertRaises(ValueError): resolver(case)
        actual = json.loads((RECOVERY / "generation5_capacity_wait/actual_closed36_metadata_20261007T101629064667Z/window_continuity.json").read_bytes())
        with self.assertRaises(ValueError): validate_closed48_metadata(actual, {}, {}, {}, SimpleNamespace(old={}), actual["resume_context"])

    def test_exact_context_and_origin_only_no_legacy_or_new_stamp_bypass(self):
        paths = resolver(structural_case())
        guard = Closed48Ancestry.__new__(Closed48Ancestry)
        guard.paths = paths
        guard.legacy_context = {"software": {"tool_sha256": "4" * 64}, "runtime": {"chunk": 1}}
        guard.closed36_context = copy.deepcopy(guard.legacy_context); guard.closed36_context["software"]["tool_sha256"] = "9" * 64
        guard.previous_context = copy.deepcopy(guard.legacy_context); guard.previous_context["software"]["tool_sha256"] = "7" * 64
        guard.current_context = copy.deepcopy(guard.legacy_context); guard.current_context["software"]["tool_sha256"] = "c" * 64
        old = "/resume-prefix/fold/dense/L36/done.json"
        new_old = "/resume-window37-48/fold/dense/L37/done.json"
        self.assertTrue(guard.matches(guard.closed36_context, old))
        self.assertTrue(guard.matches(guard.previous_context, new_old))
        self.assertFalse(guard.matches(guard.closed36_context, new_old))
        self.assertFalse(guard.matches(guard.current_context, new_old))
        wrong = copy.deepcopy(guard.previous_context); wrong["runtime"]["chunk"] = 2
        self.assertFalse(guard.matches(wrong, new_old))
        wrong["runtime"]["chunk"] = True
        self.assertFalse(guard.matches(wrong, new_old))
        self.assertFalse(guard.matches_stamp('{"software":{},"software":{}}', new_old))


if __name__ == "__main__":
    unittest.main(verbosity=2)
