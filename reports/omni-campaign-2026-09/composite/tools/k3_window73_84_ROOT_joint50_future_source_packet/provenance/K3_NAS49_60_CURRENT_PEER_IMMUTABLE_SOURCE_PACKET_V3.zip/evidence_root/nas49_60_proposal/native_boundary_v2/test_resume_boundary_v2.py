"""Three CPU checks of the actual supplied native resume_point AST.

The dual-snapshot predicate is a structural callback, not an actual closed48
snapshot claim. This imports no native module, Torch, or model payload.
"""
import argparse
import ast
import io
from pathlib import Path
import unittest


def run_actual_method_checks(native_raw):
    tree = ast.parse(native_raw)
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'DualStreamRun')
    actual = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == 'resume_point')
    namespace = {}
    exec(compile(ast.Module(body=[actual], type_ignores=[]), '<actual-candidate-resume_point>', 'exec'), namespace)
    method = namespace['resume_point']

    class State:
        def __init__(self, available):
            self.available = available
            self.requested = []

        def dual_snapshot_available(self, layer):
            self.requested.append(layer)
            return self.available

    class ActualResumePoint(unittest.TestCase):
        def test_legal49_60_returns49_after_before49_predicate(self):
            state = State(True)
            self.assertEqual(method(state, list(range(49, 61))), 49)
            self.assertEqual(state.requested, [49])

        def test_wrong_range_refused_before_snapshot_callback(self):
            state = State(True)
            with self.assertRaisesRegex(SystemExit, 'closed48 before49'):
                method(state, list(range(37, 49)))
            self.assertEqual(state.requested, [])

        def test_missing_dual_before49_refused(self):
            state = State(False)
            with self.assertRaisesRegex(SystemExit, 'closed48 before49'):
                method(state, list(range(49, 61)))
            self.assertEqual(state.requested, [49])

    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(
        unittest.TestLoader().loadTestsFromTestCase(ActualResumePoint))
    if not result.wasSuccessful():
        raise ValueError(output.getvalue())
    return {'tests_run': result.testsRun, 'successful': True, 'output': output.getvalue(),
            'source': 'actual supplied candidate resume_point AST',
            'actual_snapshot_or_future48_proof_claimed': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-source', type=Path, default=Path(__file__).with_name('k3_dense_pass.py'))
    args = parser.parse_args()
    import json
    print(json.dumps(run_actual_method_checks(args.native_source.read_bytes()), indent=2))
